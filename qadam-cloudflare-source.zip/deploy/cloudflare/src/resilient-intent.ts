// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { interpretIntent, intentSchema, manualIntent, systemInstruction, validateIntentContract } from '../../../qadam/lib/intent.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { boundedOperation, isAbortError, StageTimeout, throwIfAborted } from '../../../qadam/lib/request-abort.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { INTENT_PROVIDER_TIMEOUT_MS } from '../../../qadam/lib/ai-policy.ts';
import type { PlanRequest } from '../../../qadam/lib/qadam-types';
import type { IntentResolution } from '../../../qadam/lib/intent-types';

export const RESERVE_MODEL = '@cf/google/gemma-4-26b-a4b-it';
export const INTENT_HEDGE_AFTER_MS = 1_500;
export type IntentAI = { run(model:string,input:Record<string,unknown>,options?:{signal?:AbortSignal}):Promise<unknown> };
const record=(v:unknown):v is Record<string,unknown>=>!!v&&typeof v==='object'&&!Array.isArray(v);

/** Same closed language task, no coordinates, passport, precise clock or venue data. */
export function reserveInput(request:PlanRequest):Record<string,unknown> {
 return {
  messages:[{role:'system',content:systemInstruction+`\nSerialization reminders: includeMode counts desired categories only, never excluded categories. An explicitly abandoned activity is removed completely, including its unsupported quotation. The following examples are demonstrations, not current visitor wishes:
"Хочу в музей, но не в библиотеку" => {"version":1,"desiredCategories":["museum"],"excludedCategories":["library"],"includeMode":"any","unsupported":[],"needsClarification":false}
"Кофе керек емес" => {"version":1,"desiredCategories":[],"excludedCategories":["cafe"],"includeMode":"any","unsupported":[],"needsClarification":false}
"shopping. Clarification: forget shopping; visit an art gallery instead" => {"version":1,"desiredCategories":["art"],"excludedCategories":[],"includeMode":"any","unsupported":[],"needsClarification":false}
"I want to play tennis" => {"version":1,"desiredCategories":[],"excludedCategories":[],"includeMode":"any","unsupported":[{"text":"play tennis","reason":"not-supported"}],"needsClarification":true}
For a recognizable activity outside the closed categories, always include its verbatim unsupported quotation and not-supported reason. An unrecognized vague string may have no quote; a named sport or shopping activity is recognizable, not vague.`},{role:'user',content:JSON.stringify({
   query:request.query,language:request.language,chips:manualIntent(request).desiredCategories,
   indoor:request.indoor,knownHoursOnly:request.knownHoursOnly,accessible:request.accessible,minutes:request.minutes,
   ...(request.contextConfirmed?{contextConfirmed:true}:{}),
  })}],
  chat_template_kwargs:{enable_thinking:false},
  response_format:{type:'json_schema',json_schema:{name:'qadam_intent',schema:intentSchema,strict:true}},
  max_completion_tokens:1600,stream:false,store:false,temperature:1,
 };
}

type ReserveOutcome='success'|'envelope'|'incomplete'|'refused'|'json'|'contract'|'provider';
type Attempt={provider:'gemini'|'cloudflare';outcome:string;outputTokens?:number;normalization?:'single-category-mode'};
function inspectReserveOutput(payload:unknown,request:PlanRequest):{contract:ReturnType<typeof validateIntentContract>;outcome:ReserveOutcome;outputTokens?:number;normalization?:'single-category-mode'}{
 const tokenValue=record(payload)&&record(payload.usage)?payload.usage.completion_tokens:undefined;
 const tokens=typeof tokenValue==='number'&&Number.isSafeInteger(tokenValue)&&tokenValue>=0&&tokenValue<=100_000?{outputTokens:tokenValue}:{};
 const bad=(outcome:ReserveOutcome)=>({contract:null,outcome,...tokens});
 if(!record(payload)||!Array.isArray(payload.choices)||!record(payload.choices[0]))return bad('envelope');
 const choice=payload.choices[0];
 if(choice.finish_reason!=='stop')return bad('incomplete');
 if(!record(choice.message))return bad('envelope');
 if(choice.message.refusal)return bad('refused');
 let value:unknown=choice.message.content;
 if(typeof value==='string'){try{value=JSON.parse(value);}catch{return bad('json');}}
 const contract=validateIntentContract(value,request);
 const normalized=!!contract&&record(value)&&Array.isArray(value.desiredCategories)&&value.desiredCategories.length<=1&&value.includeMode==='all';
 return {contract,outcome:contract?'success':'contract',...tokens,...(normalized?{normalization:'single-category-mode' as const}:{})};
}
export function parseReserveOutput(payload:unknown,request:PlanRequest) {
 return inspectReserveOutput(payload,request).contract;
}

/** One Gemini call and at most one independent reserve call, one shared deadline.
 * Reserve starts on a failed primary or after 1.5 s. A valid clarification is an
 * answer, not a failure to overwrite with a more convenient interpretation.
 */
export async function interpretResilientIntent(request:PlanRequest,
 options:Parameters<typeof interpretIntent>[1]&{ai?:IntentAI;hedgeAfterMs?:number}={}):Promise<IntentResolution>{
 throwIfAborted(options.signal);
 if(!options.ai||!request.query.trim())return interpretIntent(request,options);
 const started=performance.now(),elapsed=()=>Math.max(0,Math.round(performance.now()-started));
 const supplied=options.totalTimeoutMs??INTENT_PROVIDER_TIMEOUT_MS;
 const cap=Math.max(1,Math.min(INTENT_PROVIDER_TIMEOUT_MS,Number.isFinite(supplied)?supplied:INTENT_PROVIDER_TIMEOUT_MS));
 const children=new AbortController();
 const attempts:Attempt[]=[];
 let hedge:ReturnType<typeof setTimeout>|undefined;
 let detach=()=>{};
 try{
  const result=await boundedOperation(signal=>new Promise<IntentResolution>((resolve,reject)=>{
   let finished=false,primaryDone=false,reserveDone=false,reserveStarted=false;
   let primaryFailure:IntentResolution|undefined,reserveFailure:IntentResolution|undefined;
   const abort=()=>{children.abort();};
   signal.addEventListener('abort',abort,{once:true});
   detach=()=>signal.removeEventListener('abort',abort);
   const finish=(value:IntentResolution)=>{
    if(finished)return;finished=true;signal.removeEventListener('abort',abort);
    if(hedge!==undefined)clearTimeout(hedge);children.abort();resolve({...value,ms:elapsed(),attempts:[...attempts]} as IntentResolution);
   };
   const failed=()=>{
    if(primaryDone&&reserveDone)finish({mode:'unavailable',contract:null,
     failure:primaryFailure?.failure==='quota'&&reserveFailure?.failure==='quota'?'quota':reserveFailure?.failure??primaryFailure?.failure??'provider',ms:elapsed()});
   };
   const reserve=()=>{
    if(reserveStarted||finished||signal.aborted)return;
    reserveStarted=true;if(hedge!==undefined)clearTimeout(hedge);
    void Promise.resolve().then(()=>{throwIfAborted(children.signal);return options.ai!.run(RESERVE_MODEL,reserveInput(request),{signal:children.signal});})
     .then(payload=>{
      if(finished||signal.aborted)return;
      const {contract,outcome,outputTokens,normalization}=inspectReserveOutput(payload,request);reserveDone=true;
      attempts.push({provider:'cloudflare',outcome,...(outputTokens===undefined?{}:{outputTokens}),...(normalization?{normalization}:{})});
      if(contract)finish({mode:'cloudflare',contract,ms:elapsed()});
      else{reserveFailure={mode:'unavailable',contract:null,failure:'invalid-output',ms:elapsed()};failed();}
     },()=>{
      if(finished||signal.aborted)return;
      attempts.push({provider:'cloudflare',outcome:'provider'});
      reserveDone=true;reserveFailure={mode:'unavailable',contract:null,failure:'provider',ms:elapsed()};failed();
     });
   };
   hedge=setTimeout(reserve,Math.max(0,Math.min(cap,options.hedgeAfterMs??INTENT_HEDGE_AFTER_MS)));
   void interpretIntent(request,{...options,retryTransient:false,totalTimeoutMs:cap,signal:children.signal}).then(value=>{
    if(finished||signal.aborted)return;
    primaryDone=true;
    attempts.push({provider:'gemini',outcome:value.contract?'success':value.failure??'provider'});
    if(value.contract&&value.mode==='gemini')finish(value);
    else{primaryFailure=value;reserve();failed();}
   },error=>{
    if(finished||signal.aborted)return;
    if(children.signal.aborted)return;
    primaryDone=true;primaryFailure={mode:'unavailable',contract:null,failure:'provider',ms:elapsed()};reserve();failed();
   });
  }),cap,options.signal);
  return result;
 }catch(error){
  if(isAbortError(error))throw error;
  return {mode:'unavailable',contract:null,failure:error instanceof StageTimeout?'timeout':'provider',ms:elapsed(),attempts:[...attempts]} as IntentResolution;
 }finally{if(hedge!==undefined)clearTimeout(hedge);detach();children.abort();}
}
