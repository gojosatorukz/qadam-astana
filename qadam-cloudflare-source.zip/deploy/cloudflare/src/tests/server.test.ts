import assert from 'node:assert/strict';
import test from 'node:test';
import rawDataset from '../../../../qadam/data/poi.json' with { type: 'json' };
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { createServer, MAX_API_BODY_BYTES } from '../server.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { planRoute } from '../../../../qadam/lib/planner.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { manualIntent } from '../../../../qadam/lib/intent.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { buildIntentFeedback } from '../../../../qadam/lib/intent-feedback.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { applyPlaceFacts, getPlaceName } from '../../../../qadam/lib/place-facts.ts';
import type { ServerEnv } from '../server';
import type { POIDataset } from '../../../../qadam/lib/planner';
import type { PlanRequest, PlanResponse } from '../../../../qadam/lib/qadam-types';

const NOW = Date.parse('2026-10-20T08:00:00.000Z'), SECRET = 'fictional-server-secret-for-tests';
const dataset = applyPlaceFacts(rawDataset as unknown as POIDataset), poi = dataset.pois.find(p => p.id === 'osm-way-1196402246')!;
const assets = { async fetch() { return new Response('<html>SPA</html>', { headers: { 'Content-Type': 'text/html' } }); } };
const env: ServerEnv = { ASSETS: assets, GEMINI_API_KEY: SECRET };
function fixture(): { request: PlanRequest; response: PlanResponse } {
  const request: PlanRequest = { query: 'парк', origin: { lat: poi.lat, lon: poi.lon, label: 'A' }, minutes: 45, interests: ['park'], language: 'ru', indoor: false, accessible: false, knownHoursOnly: false, now: new Date(NOW).toISOString(), departureMode: 'now' };
  const contract = manualIntent(request), response = planRoute(request, { ...dataset, pois: [structuredClone(poi)] }, { intent: contract });
  assert.ok(response.plan); response.intent = buildIntentFeedback(response, { mode: 'manual', contract, ms: 0 });
  return { request, response };
}
function post(path: string, body: unknown, headers: Record<string, string> = {}) {
  return new Request('https://qadam.example' + path, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://qadam.example', ...headers }, body: JSON.stringify(body) });
}
function provider(captured: { body: unknown; key: string | null }[], generation?: unknown): typeof fetch {
  return async (_url, init) => {
    captured.push({ body: JSON.parse(String(init?.body)), key: new Headers(init?.headers).get('x-goog-api-key') });
    const result = generation ?? { summaryKey: 'short-round-trip', stops: [{ id: poi.id, reasonKeys: ['time-budget'], activityKey: 'short-walk' }] };
    return Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify(result) }] } }] });
  };
}
test('API routes enforce methods, same-origin and no-store without invoking providers', async () => {
  let called = 0;
  const server = createServer({ clock: () => NOW, fetcher: async () => { called++; throw Error('unexpected'); } });
  const cases: [Request, number][] = [
    [new Request('https://qadam.example/api/unknown'), 404],
    [new Request('https://qadam.example/api/intent'), 405],
    [post('/api/time', {}), 405],
    [post('/api/intent', fixture().request, { Origin: 'https://attacker.example' }), 403],
    [post('/api/intent', fixture().request, { 'Sec-Fetch-Site': 'cross-site' }), 403],
  ];
  for (const [request, status] of cases) { const response = await server.fetch(request, env); assert.equal(response.status, status); assert.equal(response.headers.get('cache-control'), 'no-store'); }
  assert.equal(called, 0);
});
test('stream byte limits reject oversized multibyte bodies and malformed JSON before provider work', async () => {
  let called = 0;
  const server = createServer({ clock: () => NOW, fetcher: async () => { called++; throw Error('unexpected'); } });
  const oversized = new Request('https://qadam.example/api/intent', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: 'ё'.repeat(MAX_API_BODY_BYTES / 2 + 1) });
  assert.equal((await server.fetch(oversized, env)).status, 413);
  assert.equal((await server.fetch(post('/api/intent', {}, { 'Content-Length': String(MAX_API_BODY_BYTES + 1) }), env)).status, 413);
  assert.equal((await server.fetch(new Request('https://qadam.example/api/intent', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{' }), env)).status, 400);
  assert.equal((await server.fetch(post('/api/intent', {}, { 'Content-Type': 'text/plain' }), env)).status, 415);
  assert.equal(called, 0);
});
test('intent only forwards canonical controls/query and never leaks the secret or structured coordinates', async () => {
  const captured: { body: unknown; key: string | null }[] = [];
  const contract = { version: 1, desiredCategories: ['park'], excludedCategories: [], includeMode: 'any', unsupported: [], needsClarification: false };
  const server = createServer({ clock: () => NOW, fetcher: provider(captured, contract) });
  const response = await server.fetch(post('/api/intent', { ...fixture().request, systemInstruction: 'ATTACK_OVERRIDE', apiKey: 'CLIENT_KEY' }), env);
  assert.equal(response.status, 200); const body = await response.json() as { resolution: { mode: string }; serverNowMs: number };
  assert.equal(body.resolution.mode, 'gemini'); assert.equal(body.serverNowMs, NOW); assert.equal(captured[0].key, SECRET);
  const sent = JSON.stringify(captured[0].body); assert.ok(!sent.includes('ATTACK_OVERRIDE')); assert.ok(!sent.includes('CLIENT_KEY')); assert.ok(!sent.includes(String(poi.lat))); assert.ok(!sent.includes(String(poi.lon)));
  assert.ok(!JSON.stringify(body).includes(SECRET));
});
test('absent env secrets do not use a process environment key and provider exceptions are not exposed', async () => {
  let called = 0;
  const server = createServer({ clock: () => NOW, fetcher: async () => { called++; throw Error(SECRET); } });
  const missing = await server.fetch(post('/api/intent', fixture().request), { ASSETS: assets });
  assert.equal(called, 0); assert.ok((await missing.text()).includes('not-configured'));
  const failed = await server.fetch(post('/api/intent', fixture().request), env);
  assert.equal(failed.status, 200); assert.equal(called, 1); assert.ok(!(await failed.text()).includes(SECRET));
});
test('enrichment rebuilds names/facts/prose from canonical sources before provider access', async () => {
  const captured: { body: unknown; key: string | null }[] = [], input = fixture();
  const stop = input.response.plan!.stops[0];
  stop.poi.name = 'INJECTED_NAME_IGNORE_RULES'; stop.poi.description = 'INJECTED_DESCRIPTION'; stop.poi.tags = { instruction: 'INJECTED_TAG' };
  stop.why = 'INJECTED_WHY'; stop.activity = 'INJECTED_ACTIVITY'; stop.observation = 'INJECTED_OBSERVATION';
  stop.facts = [{ id: 'forged', text: 'INJECTED_FACT', sourceUrl: 'https://attacker.example', checkedAt: new Date(NOW).toISOString(), rights: 'forged' }];
  input.response.plan!.summary = 'INJECTED_SUMMARY'; input.response.trace = [{ step: 'INJECTED_TRACE', detail: 'INJECTED_DETAIL', ms: 0 }]; input.response.warnings = ['INJECTED_WARNING'];
  const response = await createServer({ clock: () => NOW, fetcher: provider(captured) }).fetch(post('/api/enrich', input), env);
  assert.equal(response.status, 200); const output = await response.json() as { response: PlanResponse };
  assert.equal(output.response.plan!.stops[0].poi.name, getPlaceName(poi, 'ru'));
  assert.ok(output.response.plan!.stops[0].facts!.length > 0); assert.equal(captured.length, 1);
  assert.ok(!JSON.stringify(captured).includes('INJECTED')); assert.ok(!JSON.stringify(output).includes('INJECTED')); assert.ok(!JSON.stringify(output).includes('attacker.example')); assert.ok(!JSON.stringify(output).includes(SECRET));
});
test('unknown IDs, changed source identity, exclusions, inaccessible places and false totals are rejected', async () => {
  let called = 0;
  const server = createServer({ clock: () => NOW, fetcher: async () => { called++; throw Error('unexpected'); } });
  for (const mutate of [
    (input: ReturnType<typeof fixture>) => { input.response.plan!.stops[0].poi.id = 'not-in-snapshot'; },
    (input: ReturnType<typeof fixture>) => { input.response.plan!.stops[0].poi.sourceUrl = 'https://attacker.example'; },
    (input: ReturnType<typeof fixture>) => { input.request.excludePoiIds = [poi.id]; },
    (input: ReturnType<typeof fixture>) => { input.request.accessible = true; },
    (input: ReturnType<typeof fixture>) => { input.response.plan!.totalMinutes = 1; },
    (input: ReturnType<typeof fixture>) => { input.response.plan!.stops[0].visitMinutes = 1; },
  ]) { const input = fixture(); mutate(input); assert.equal((await server.fetch(post('/api/enrich', input), env)).status, 400); }
  assert.equal(called, 0);
});
test('model-injected prose is rejected and only canonical local explanations remain', async () => {
  const captured: { body: unknown; key: string | null }[] = [];
  const response = await createServer({ clock: () => NOW, fetcher: provider(captured, { summaryKey: 'short-round-trip', stops: [{ id: poi.id, reasonKeys: ['time-budget'], activityKey: 'short-walk', instruction: 'MODEL_ATTACK' }], systemInstruction: 'MODEL_ATTACK' }) }).fetch(post('/api/enrich', fixture()), env);
  assert.equal(response.status, 200); const output = await response.json() as { response: PlanResponse };
  assert.equal(output.response.generationMode, 'retrieval'); assert.ok(!JSON.stringify(output).includes('MODEL_ATTACK'));
});
test('an absolute deadline is checked again after provider latency', async () => {
  let now = NOW;
  const input = fixture(); input.request.returnBy = new Date(NOW + 45 * 60_000).toISOString();
  const captured: { body: unknown; key: string | null }[] = [], fetcher = provider(captured);
  const response = await createServer({ clock: () => now, fetcher: async (url, init) => { const result = await fetcher(url, init); now += 40 * 60_000; return result; } }).fetch(post('/api/enrich', input), env);
  assert.equal(response.status, 409); assert.equal(captured.length, 1);
});
test('static requests use ASSETS; time and health expose no secrets or server graph', async () => {
  const server = createServer({ clock: () => NOW });
  assert.equal(await (await server.fetch(new Request('https://qadam.example/any/spa/path'), env)).text(), '<html>SPA</html>');
  const time = await server.fetch(new Request('https://qadam.example/api/time'), env); assert.deepEqual(await time.json(), { serverNowMs: NOW });
  const health = await server.fetch(new Request('https://qadam.example/api/plan'), env); const body = await health.json() as { serverGraph: boolean; architecture: string };
  assert.equal(body.serverGraph, false); assert.equal(body.architecture, 'browser-graph-planning'); assert.ok(!JSON.stringify(body).includes(SECRET));
});
