import rawDataset from '../../../qadam/data/poi.json' with { type: 'json' };
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { categoriesOf, validatePlanRequest } from '../../../qadam/lib/planner.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { validateIntentContract } from '../../../qadam/lib/intent.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { enrichWithGemini } from '../../../qadam/lib/rag.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { DEFAULT_GEMINI_MODEL, INTENT_PROVIDER_TIMEOUT_MS, ENRICHMENT_TIMEOUT_MS } from '../../../qadam/lib/ai-policy.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { isPlanResponse, planSemanticsValid } from '../../../qadam/lib/plan-validation.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { applyPlaceFacts, getCanonicalId, getPlaceEditorial, getPlaceName, getFactText } from '../../../qadam/lib/place-facts.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { buildIntentFeedback } from '../../../qadam/lib/intent-feedback.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { resolvePlanTime } from '../../../qadam/lib/time-context.ts';
import type { POIDataset } from '../../../qadam/lib/planner';
import type { PlanRequest, PlanResponse, PlanStop, RoutePlan } from '../../../qadam/lib/qadam-types';
import type { IntentResolution } from '../../../qadam/lib/intent-types';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { interpretResilientIntent, RESERVE_MODEL, INTENT_HEDGE_AFTER_MS } from './resilient-intent.ts';
import type { IntentAI } from './resilient-intent';

export type ServerEnv = {
  ASSETS: { fetch(request: Request): Promise<Response> };
  GEMINI_API_KEY?: string;
  GEMINI_MODEL?: string;
  GEMINI_FALLBACK_MODELS?: string;
  AI?: IntentAI;
};
export const MAX_API_BODY_BYTES = 128 * 1024;
const MAX_PRIMARY_COORDINATES = 5000;
const dataset = applyPlaceFacts(rawDataset as unknown as POIDataset);
const knownPOIs = new Map(dataset.pois.map(poi => [poi.id, poi]));
const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
class BodyFailure extends Error { readonly status: number; constructor(status: number) { super('Invalid request body.'); this.status = status; } }
function json(value: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers } });
}
async function readBody(request: Request): Promise<unknown> {
  if (request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json') throw new BodyFailure(415);
  const declared = request.headers.get('content-length');
  if (declared !== null && (!/^\d+$/.test(declared) || !Number.isSafeInteger(Number(declared)))) throw new BodyFailure(400);
  if (declared !== null && Number(declared) > MAX_API_BODY_BYTES) throw new BodyFailure(413);
  if (!request.body) throw new BodyFailure(400);
  const reader = request.body.getReader(), chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      if (request.signal.aborted) throw new BodyFailure(499);
      const chunk = await reader.read();
      if (chunk.done) break;
      size += chunk.value.byteLength;
      if (size > MAX_API_BODY_BYTES) { void reader.cancel().catch(() => {}); throw new BodyFailure(413); }
      chunks.push(chunk.value);
    }
    if (request.signal.aborted) throw new BodyFailure(499);
    const bytes = new Uint8Array(size); let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  } catch (error) { throw error instanceof BodyFailure ? error : new BodyFailure(400); }
  finally { reader.releaseLock(); }
}
const localCopy = {
  ru: { title: 'Места по пути', summary: 'План рассчитан на устройстве с учётом времени и конечной точки.', why: 'Место из снимка OpenStreetMap; условия посещения проверены по доступным данным.', activity: 'Идея: сделай остановку и осмотрись.', warning: 'Часы из источника не подтверждают открытую дверь.' },
  en: { title: 'Places along your way', summary: 'The plan was calculated on your device using your time and destination.', why: 'An OpenStreetMap snapshot place; available visit constraints were checked.', activity: 'Idea: pause here and look around.', warning: 'Listed hours do not confirm an open door.' },
  kk: { title: 'Жол бойындағы орындар', summary: 'Жоспар құрылғыда уақыт пен соңғы нүктені ескеріп есептелді.', why: 'OpenStreetMap деректеріндегі орын; қолжетімді сапар шарттары тексерілді.', activity: 'Идея: осы жерде аялдап, айналаңа қара.', warning: 'Кесте есіктің ашық екенін растамайды.' },
};
function canonicalStop(stop: PlanStop, request: PlanRequest): PlanStop | null {
  const poi = knownPOIs.get(stop.poi.id);
  if (!poi || stop.poi.lat !== poi.lat || stop.poi.lon !== poi.lon || stop.poi.category !== poi.category || stop.poi.sourceUrl !== poi.sourceUrl) return null;
  const categories = categoriesOf(poi);
  const minimum = categories.includes('museum') ? 25 : categories.includes('art') ? 15 : categories.includes('food') ? 20 : categories.includes('cafe') || categories.includes('park') ? 12 : 8;
  if (stop.visitMinutes < minimum || stop.visitMinutes > request.minutes || stop.travelMinutes > request.minutes) return null;
  const editorial = getPlaceEditorial(poi.id), copy = localCopy[request.language];
  return {
    poi: { ...poi, name: getPlaceName(poi, request.language), tags: { ...poi.tags } },
    canonicalId: getCanonicalId(poi), visitMinutes: stop.visitMinutes, travelMinutes: stop.travelMinutes,
    hoursStatus: stop.hoursStatus, why: copy.why, activity: copy.activity,
    ...(editorial ? { facts: editorial.facts.map(fact => ({ id: fact.id, text: getFactText(fact, request.language), sourceUrl: fact.sourceUrl, checkedAt: fact.checkedAt, rights: fact.rights })), ...(editorial.observation ? { observation: editorial.observation[request.language] } : {}) } : {}),
  };
}
/** Client geometry remains a client computation; this endpoint attests no graph path. */
function canonicalResponse(value: unknown, request: PlanRequest): PlanResponse | null {
  if (!isPlanResponse(value) || !value.plan || value.plan.routeCoordinates.length > MAX_PRIMARY_COORDINATES) return null;
  const contract = validateIntentContract(value.intent?.contract, request);
  if (!contract || contract.needsClarification || !value.intent || !['gemini', 'cloudflare', 'manual'].includes(value.intent.mode)) return null;
  const stops = value.plan.stops.map(stop => canonicalStop(stop, request));
  if (stops.some(stop => stop === null)) return null;
  const source = value.plan, copy = localCopy[request.language];
  if (source.distanceMeters > 100_000 || source.routeCoordinates.some(([lon, lat]) => lon < 71.15 || lon > 71.75 || lat < 50.9 || lat > 51.35)) return null;
  const plan: RoutePlan = {
    title: copy.title, summary: copy.summary, stops: stops as PlanStop[],
    totalMinutes: source.totalMinutes, walkingMinutes: source.walkingMinutes, visitMinutes: source.visitMinutes,
    bufferMinutes: source.bufferMinutes, distanceMeters: source.distanceMeters, returnMinutes: source.returnMinutes,
    routeCoordinates: source.routeCoordinates.map(([lon, lat]) => [lon, lat]), routeKind: source.routeKind,
    ...(source.legEndIndices ? { legEndIndices: [...source.legEndIndices] } : {}),
    ...(request.destination ? { destination: { ...request.destination }, routeMode: 'one-way' as const } : { routeMode: 'round-trip' as const }),
  };
  const resolution: IntentResolution = { mode: value.intent.mode, contract, ms: 0 };
  const result: PlanResponse = {
    plan, candidates: stops.length, excluded: [], generationMode: 'retrieval', warnings: [copy.warning],
    trace: [{ step: 'source-check', detail: 'Client-computed geometry; canonical POI identities, visit constraints and explanation inputs checked without a server graph.', ms: 0 }],
    dataset: { count: dataset.pois.length, fetchedAt: dataset.fetchedAt, source: dataset.source },
    diagnostics: { stage: 'complete', intent: resolution.mode, enrichment: 'local', coverage: plan.routeKind, codes: ['browser-planning', 'canonical-explanation-input'] },
  };
  result.intent = buildIntentFeedback(result, resolution);
  return planSemanticsValid(result, request, dataset, contract) ? result : null;
}

/** Static SPA + bounded Gemini endpoints; no graph, SSR, connector or paid binding. */
export function createServer(dependencies: { fetcher?: typeof fetch; clock?: () => number } = {}) {
  const clock = dependencies.clock ?? Date.now;
  return {
    async fetch(request: Request, env: ServerEnv): Promise<Response> {
      const url = new URL(request.url), path = url.pathname;
      if (!path.startsWith('/api/')) {
        if (!['GET', 'HEAD'].includes(request.method)) return json({ error: 'Method not allowed.' }, 405, { Allow: 'GET, HEAD' });
        try { return await env.ASSETS.fetch(request); } catch { return json({ error: 'Assets unavailable.' }, 503); }
      }
      const origin = request.headers.get('origin');
      if ((origin && origin !== url.origin) || request.headers.get('sec-fetch-site') === 'cross-site') return json({ error: 'Cross-origin request rejected.' }, 403);
      if (!['/api/time', '/api/plan', '/api/intent', '/api/enrich'].includes(path)) return json({ error: 'Not found.' }, 404);
      const method = ['/api/time', '/api/plan'].includes(path) ? 'GET' : 'POST';
      if (request.method !== method) return json({ error: 'Method not allowed.' }, 405, { Allow: method });
      if (path === '/api/time') return json({ serverNowMs: clock() });
      if (path === '/api/plan') return json({ status: 'ok', architecture: 'browser-graph-planning', routing: 'client-osm-walking-graph', serverGraph: false, geminiConfigured: Boolean(env.GEMINI_API_KEY?.trim()), intentModel: env.GEMINI_MODEL ?? DEFAULT_GEMINI_MODEL, reserveConfigured: Boolean(env.AI), reserveModel: RESERVE_MODEL, hedgeAfterMs: INTENT_HEDGE_AFTER_MS, poiCount: dataset.pois.length, serverNowMs: clock() });
      try {
        const input = await readBody(request), candidate = path === '/api/intent' ? input : record(input) ? input.request : null;
        const parsed = validatePlanRequest(candidate);
        if ('error' in parsed) return json({ error: 'Invalid planning request.' }, 400);
        const selectedTime = resolvePlanTime(parsed.value, new Date(clock()), true);
        if ('error' in selectedTime) return json({ error: 'Invalid or expired time window.' }, 400);
        const effectiveRequest = { ...parsed.value, now: selectedTime.departureAt, minutes: selectedTime.effectiveMinutes };
        const provider = { apiKey: env.GEMINI_API_KEY ?? '', model: env.GEMINI_MODEL ?? DEFAULT_GEMINI_MODEL, fetcher: dependencies.fetcher ?? fetch, totalTimeoutMs: url.pathname === '/api/intent' ? INTENT_PROVIDER_TIMEOUT_MS : ENRICHMENT_TIMEOUT_MS, signal: request.signal };
        if (path === '/api/intent') {
          const resolution = await interpretResilientIntent(effectiveRequest, {...provider,ai:env.AI});
          return json({ resolution, serverNowMs: clock() });
        }
        const safe = canonicalResponse(record(input) ? input.response : null, effectiveRequest);
        if (!safe) return json({ error: 'Invalid source or itinerary constraints.' }, 400);
        const enriched = parsed.value.localOnly || safe.intent?.mode==='cloudflare' ? safe : await enrichWithGemini(safe, effectiveRequest, { ...provider, fallbackModels: (env.GEMINI_FALLBACK_MODELS ?? '').split(',').map(value => value.trim()).filter(Boolean).slice(0, 2) });
        const finalTime = resolvePlanTime(parsed.value, new Date(clock()), true);
        if ('error' in finalTime || !planSemanticsValid(enriched, { ...parsed.value, now: finalTime.departureAt, minutes: finalTime.effectiveMinutes }, dataset, safe.intent!.contract!)) return json({ error: 'Time window changed during explanation.' }, 409);
        return json({ response: { ...enriched, ...finalTime }, serverNowMs: clock() });
      } catch (error) {
        if (error instanceof BodyFailure) return json({ error: error.status === 413 ? 'Request is too large.' : 'Invalid request body.' }, error.status);
        return json({ error: request.signal.aborted ? 'Request cancelled.' : 'Explanation service unavailable.' }, request.signal.aborted ? 499 : 503);
      }
    },
  };
}
export default createServer();
