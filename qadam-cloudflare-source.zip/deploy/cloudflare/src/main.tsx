import React from 'react';
import { createRoot } from 'react-dom/client';
import Home from './Home';
import '../../../qadam/app/globals.css';
import '../../../qadam/app/mobile-journey.css';
import '../../../qadam/app/route-choice.css';
const root = document.getElementById('root');
if (!root) throw new Error('Missing Qadam root');
createRoot(root).render(<Home />);
