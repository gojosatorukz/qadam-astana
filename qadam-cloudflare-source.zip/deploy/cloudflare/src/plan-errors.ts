import type { Language } from '../../../qadam/lib/experience';

/** Only closed, non-sensitive support codes cross the UI boundary. */
export function planningFailureText(error: unknown, language: Language): string | null {
  if (!(error instanceof Error)) return null;
  const code = /^QADAM:([A-Z_0-9]{1,32})$/.exec(error.message)?.[1];
  if (!code) return null;
  const messages: Record<string, [string, string, string]> = {
    WORKER_UNSUPPORTED: ['Этот браузер не поддерживает расчёт. Открой сайт в обновлённом Safari или Chrome.', 'This browser does not support planning. Open the site in an updated Safari or Chrome.', 'Бұл браузер есептеуді қолдамайды. Сайтты жаңартылған Safari немесе Chrome арқылы аш.'],
    WORKER_START: ['Не удалось загрузить модуль расчёта. Обнови страницу и попробуй снова.', 'The planning module could not load. Refresh the page and retry.', 'Есептеу модулі жүктелмеді. Бетті жаңартып, қайталап көр.'],
    WORKER_RUNTIME: ['Модуль расчёта остановился. Обнови страницу и попробуй снова.', 'The planning module stopped. Refresh the page and retry.', 'Есептеу модулі тоқтады. Бетті жаңартып, қайталап көр.'],
    TIMEOUT: ['Расчёт занял слишком много времени. Проверь соединение и попробуй снова.', 'Planning took too long. Check the connection and retry.', 'Есептеу ұзаққа созылды. Байланысты тексеріп, қайталап көр.'],
    SERVER_CLOCK: ['Сервер времени не ответил. Проверь соединение и попробуй снова.', 'The time service did not respond. Check the connection and retry.', 'Уақыт қызметі жауап бермеді. Байланысты тексеріп, қайталап көр.'],
    INVALID_TIME: ['Выбранное время уже недоступно. Обнови время выхода и попробуй снова.', 'The selected time is no longer available. Update the departure time and retry.', 'Таңдалған уақыт қолжетімсіз. Шығу уақытын жаңартып, қайталап көр.'],
    LOCAL_PLANNER: ['Не удалось завершить расчёт на устройстве. Попробуй ещё раз.', 'The device could not finish planning. Please retry.', 'Құрылғы есептеуді аяқтай алмады. Қайталап көр.'],
    INVALID_REPLY: ['Ответ расчёта не прошёл проверку. Попробуй ещё раз.', 'The planning response could not be validated. Please retry.', 'Есептеу жауабы тексеруден өтпеді. Қайталап көр.'],
    POI_LOAD: ['Не удалось загрузить места. Проверь соединение и попробуй снова.', 'Places could not load. Check the connection and retry.', 'Орындар жүктелмеді. Байланысты тексеріп, қайталап көр.'],
    POI_INIT: ['Не удалось подготовить данные мест. Обнови страницу и попробуй снова.', 'Place data could not be prepared. Refresh the page and retry.', 'Орындар деректері дайындалмады. Бетті жаңартып, қайталап көр.'],
    GRAPH_LOAD: ['Не удалось загрузить пешеходную сеть. Проверь соединение и попробуй снова.', 'The walking network could not load. Check the connection and retry.', 'Жаяу жолдар желісі жүктелмеді. Байланысты тексеріп, қайталап көр.'],
    GRAPH_INIT: ['Не удалось подготовить пешеходную сеть. Обнови страницу и попробуй снова.', 'The walking network could not be prepared. Refresh the page and retry.', 'Жаяу жолдар желісі дайындалмады. Бетті жаңартып, қайталап көр.'],
    PLAN_COMPUTE: ['Не удалось рассчитать путь на устройстве. Попробуй ещё раз.', 'The device could not calculate the route. Please retry.', 'Құрылғы бағытты есептей алмады. Қайталап көр.'],
  };
  const known = messages[code];
  const generic = ['Не удалось выполнить расчёт. Твои точки, время и желание сохранены.', 'Planning failed. Your points, time and wish are preserved.', 'Есептеу орындалмады. Нүктелер, уақыт пен тілек сақталды.'];
  return `${(known || generic)[language === 'ru' ? 0 : language === 'en' ? 1 : 2]} (${code})`;
}
