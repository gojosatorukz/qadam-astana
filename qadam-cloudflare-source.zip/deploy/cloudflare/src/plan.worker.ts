// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { buildPlan } from '../../../qadam/lib/build-plan.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { validatePlanRequest } from '../../../qadam/lib/planner.ts';
import type { POIDataset } from '../../../qadam/lib/planner';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { applyPlaceFacts } from '../../../qadam/lib/place-facts.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { WalkingGraph } from '../../../qadam/lib/walking-graph.ts';
import type { RawWalkingGraph } from '../../../qadam/lib/walking-graph';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { manualIntent } from '../../../qadam/lib/intent.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { resolvePlanTime } from '../../../qadam/lib/time-context.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { isPlanResponse } from '../../../qadam/lib/plan-validation.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { POI_COVERAGE } from '../../../qadam/lib/planning-context.ts';
import type { IntentResolution } from '../../../qadam/lib/intent-types';
import type { PlanRequest, PlanResponse } from '../../../qadam/lib/qadam-types';
import type { PlanWorkerRequest, PlanWorkerReply, PlanErrorCode } from './plan-client';

/** Preserve locally verified routing evidence while keeping server display outputs. */
export function mergeEnrichmentMetadata(original:PlanResponse,explained:PlanResponse):PlanResponse {
  const warnings=explained.generationMode==='gemini'
    ?original.warnings.filter(warning=>!/^(?:Режим поиска:|Retrieval mode:|Іздеу режимі:)/.test(warning))
    :original.warnings;
  return {...explained,trace:[...original.trace,...explained.trace],warnings:[...new Set([...warnings,...explained.warnings])]};
}

type Scope={location:{origin:string};onmessage:((event:MessageEvent<PlanWorkerRequest>)=>void)|null;postMessage(message:PlanWorkerReply):void};
const scope=globalThis as unknown as Scope;
let dataset:POIDataset|null=null,graph:WalkingGraph|null=null,busy=false;
const record=(value:unknown):value is Record<string,unknown>=>!!value&&typeof value==='object'&&!Array.isArray(value);
const serverTime=(value:unknown):value is number=>typeof value==='number'&&Number.isFinite(value)&&value>=0&&value<=8.64e15;

scope.onmessage=event=>{
  const message=event.data;
  if(busy||!message||message.type!=='plan'||!Number.isSafeInteger(message.id)||message.id<1)return;
  busy=true;
  const error=(status:number,detail:string,code:PlanErrorCode)=>scope.postMessage({type:'plan-error',id:message.id,status,error:detail,code});
  let failureCode:PlanErrorCode='LOCAL_PLANNER';
  void(async()=>{
    if(message.apiOrigin!==scope.location.origin||!/^https?:\/\//u.test(message.apiOrigin)){error(400,'Invalid planning origin.','ORIGIN_INVALID');return;}
    const parsed=validatePlanRequest(message.request);if('error'in parsed){error(400,parsed.error,'REQUEST_INVALID');return;}
    const request=parsed.value;
    let anchor=0,base=0;
    const clock=()=>new Date(base+performance.now()-anchor);
    const sync=(now:number,roundTripMs:number)=>{
      // Server time + full RTT is conservative; monotonic updates never regain
      // minutes after a slow model call or browser clock correction.
      const received=performance.now(),candidate=now+Math.max(0,roundTripMs);
      base=Math.max(anchor?clock().getTime():candidate,candidate);anchor=received;
    };
    async function api(path:string,body?:unknown,signal?:AbortSignal):Promise<Record<string,unknown>>{
      const started=performance.now();
      const response=await fetch(new URL(path,message.apiOrigin),{method:body===undefined?'GET':'POST',headers:{Accept:'application/json',...(body===undefined?{}:{'Content-Type':'application/json'})},...(body===undefined?{}:{body:JSON.stringify(body)}),signal,credentials:'same-origin',redirect:'error',cache:'no-store'});
      if(!response.ok)throw new Error('Planning service unavailable.');
      const result:unknown=await response.json();if(!record(result)||!serverTime(result.serverNowMs))throw new Error('Invalid server time.');
      sync(result.serverNowMs,performance.now()-started);return result;
    }
    async function asset(url:URL):Promise<unknown>{
      // Raw JSON avoids compiling large object-literal modules in Safari.
      // Browser same-origin mode rejects cross-origin asset requests/redirects.
      const response=await fetch(url,{headers:{Accept:'application/json'},mode:'same-origin',credentials:'same-origin',redirect:'error',cache:'force-cache'});
      if(!response.ok)throw new Error('Local planning data unavailable.');
      return response.json();
    }
    const timeController=new AbortController(),timeTimer=setTimeout(()=>timeController.abort(),5000);
    try{await api('/api/time',undefined,timeController.signal);}catch{error(503,'The server clock could not be verified. Retry planning.','SERVER_CLOCK');return;}finally{clearTimeout(timeTimer);}
    const time=resolvePlanTime(request,clock(),true);
    if('error'in time){error(400,`Invalid planning time: ${time.error}`,'INVALID_TIME');return;}
    // Vite emits hashed JSON assets; parsing and construction stay off-main.
    if(!dataset){failureCode='POI_LOAD';const source=await asset(new URL('../../../qadam/data/poi.json',import.meta.url));failureCode='POI_INIT';dataset=applyPlaceFacts(source as POIDataset);}
    if(!graph){failureCode='GRAPH_LOAD';const source=await asset(new URL('../../../qadam/data/walk-graph.json',import.meta.url));failureCode='GRAPH_INIT';graph=new WalkingGraph(source as RawWalkingGraph);}
    // Loading graph chunks can consume a custom departure: reject it before AI.
    const afterLoad=resolvePlanTime(request,clock(),true);
    if('error'in afterLoad){error(400,`Invalid planning time: ${afterLoad.error}`,'INVALID_TIME');return;}
    failureCode='PLAN_COMPUTE';
    const result=await buildPlan(request,dataset,{routing:graph,coverageBounds:POI_COVERAGE,clock,
      interpret:async(current,options)=>{
        if(!current.query.trim())return {mode:'manual',contract:manualIntent(current),ms:0};
        const reply=await api('/api/intent',current,options?.signal);
        return reply.resolution as IntentResolution; // buildPlan validates the closed contract.
      },
      enrich:async(response,current,options)=>{
        // Only primary display generation crosses the API. All alternatives and
        // routing remain local; canonical buildPlan preserves them independently.
        const {options:_alternatives,...primary}=response;
        const reply=await api('/api/enrich',{request:current,response:primary},options?.signal);
        if(!isPlanResponse(reply.response))throw new Error('Invalid explanation response.');
        return mergeEnrichmentMetadata(response,reply.response);
      },
    });
    if(!isPlanResponse(result)){error(502,'The local planner returned an invalid response.','INVALID_REPLY');return;}
    scope.postMessage({type:'plan-result',id:message.id,status:200,body:result});
  })().catch(()=>error(503,'The local planner could not complete this request.',failureCode)).finally(()=>{busy=false;});
};
