// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { validatePlanRequest } from '../../../qadam/lib/planner.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { isPlanResponse } from '../../../qadam/lib/plan-validation.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { MAX_PLAN_REQUEST_BYTES } from '../../../qadam/lib/query-policy.ts';
import type { PlanRequest } from '../../../qadam/lib/qadam-types';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { readPassport, recommendationSnapshot } from '../../../qadam/lib/passport.ts';
import type { PassportRecommendation } from '../../../qadam/lib/passport-types';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { PLAN_RPC_TIMEOUT_MS } from '../../../qadam/lib/ai-policy.ts';

export type PlanWorker = Pick<Worker,'postMessage'|'terminate'|'onmessage'|'onerror'|'onmessageerror'>;
export type PlanWorkerRequest={type:'plan';id:number;request:PlanRequest;apiOrigin:string;localPreferences?:PassportRecommendation};
export const PLAN_ERROR_CODES=['REQUEST_INVALID','ORIGIN_INVALID','ENDPOINT_INVALID','METHOD_INVALID','REQUEST_TOO_LARGE','WORKER_UNSUPPORTED','WORKER_START','WORKER_RUNTIME','TIMEOUT','INVALID_REPLY','SERVER_CLOCK','INVALID_TIME','LOCAL_PLANNER','POI_LOAD','POI_INIT','GRAPH_LOAD','GRAPH_INIT','PLAN_COMPUTE']as const;
export type PlanErrorCode=typeof PLAN_ERROR_CODES[number];
const isErrorCode=(value:unknown):value is PlanErrorCode=>typeof value==='string'&&(PLAN_ERROR_CODES as readonly string[]).includes(value);
export type PlanWorkerReply={type:'plan-result';id:number;status:200;body:unknown}|{type:'plan-error';id:number;status:number;error:string;code?:PlanErrorCode};
export type PlanFetchOptions={workerFactory?:()=>PlanWorker|Promise<PlanWorker>;timeoutMs?:number;origin?:string};
// Safari 16 supports Response construction but not the static Response.json API.
const jsonResponse=(body:unknown,status=200,code?:PlanErrorCode)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Qadam-Planning':'browser-worker',...(code?{'X-Qadam-Error':code}:{})}});
const failure=(status:number,error:string,code:PlanErrorCode)=>jsonResponse({error},status,code);
const aborted=()=>new DOMException('Request cancelled','AbortError');

/** Fetch-compatible initial planning RPC; each call owns and disposes its worker. */
export function createPlanFetch(options:PlanFetchOptions={}):(input:RequestInfo|URL,init?:RequestInit)=>Promise<Response> {
  let sequence=0;
  const timeoutMs=Number.isFinite(options.timeoutMs)?Math.min(PLAN_RPC_TIMEOUT_MS,Math.max(1,options.timeoutMs!)):PLAN_RPC_TIMEOUT_MS;
  return (input,init={})=>{
    const original=typeof Request!=='undefined'&&input instanceof Request?input:null;
    const origin=options.origin??(typeof location!=='undefined'?location.origin:'');
    let url:URL;try{url=new URL(original?.url??String(input),origin);}catch{return Promise.resolve(failure(400,'Invalid planning URL.','REQUEST_INVALID'));}
    if(url.origin!==origin)return Promise.resolve(failure(403,'Planning requests must use the current site origin.','ORIGIN_INVALID'));
    if(url.pathname!=='/api/plan')return Promise.resolve(failure(404,'Unknown planning endpoint.','ENDPOINT_INVALID'));
    if((init.method??original?.method??'GET').toUpperCase()!=='POST')return Promise.resolve(failure(405,'Planning requires POST.','METHOD_INVALID'));
    const signal=init.signal===null?undefined:init.signal??original?.signal;
    if(signal?.aborted)return Promise.reject(aborted());
    return new Promise<Response>((resolve,reject)=>{
      const id=++sequence;let active=true,worker:PlanWorker|null=null;
      const stop=()=>{const previous=worker;worker=null;if(previous){previous.onmessage=null;previous.onerror=null;previous.onmessageerror=null;try{previous.terminate();}catch{/* Already stopped. */}}};
      const complete=(response:Response|null,error?:Error)=>{if(!active)return;active=false;clearTimeout(timer);signal?.removeEventListener('abort',cancel);stop();if(error)reject(error);else resolve(response!);};
      const cancel=()=>complete(null,aborted());
      const timer=setTimeout(()=>complete(failure(504,'Local planning timed out. Your choices are preserved.','TIMEOUT')),timeoutMs);
      signal?.addEventListener('abort',cancel,{once:true});if(signal?.aborted){cancel();return;}
      void(async()=>{
        let body:string;
        try {
          if(typeof init.body==='string')body=init.body;
          else if(init.body===undefined&&original)body=await original.clone().text();
          else {complete(failure(400,'Planning requires a JSON text body.','REQUEST_INVALID'));return;}
        }catch{if(active)complete(failure(400,'Could not read the planning request.','REQUEST_INVALID'));return;}
        if(!active)return;
        if(new TextEncoder().encode(body).byteLength>MAX_PLAN_REQUEST_BYTES){complete(failure(413,'Planning request is too large.','REQUEST_TOO_LARGE'));return;}
        let raw:unknown;try{raw=JSON.parse(body);}catch{complete(failure(400,'Planning requires valid JSON.','REQUEST_INVALID'));return;}
        const parsed=validatePlanRequest(raw);if('error'in parsed){complete(failure(400,parsed.error,'REQUEST_INVALID'));return;}
        try {
          let instance:PlanWorker;
          if(options.workerFactory)instance=await options.workerFactory();
          else {
            if(typeof Worker==='undefined'){complete(failure(503,'This browser does not support local planning workers.','WORKER_UNSUPPORTED'));return;}
            // Vite supplies the module/chunk URL. There is no synchronous planner fallback.
            // @ts-ignore Vite's ?worker wrapper is declared by the host application.
            const module=await import('./plan.worker.ts?worker');
            if(!active)return;
            instance=new module.default({name:'qadam-initial-plan'});
          }
          if(!active){try{instance.terminate();}catch{/* Cancelled during lazy loading. */}return;}
          worker=instance;
          instance.onmessage=event=>{
            if(!active||worker!==instance)return;
            const reply=event.data as Partial<PlanWorkerReply>|null;
            if(!reply||typeof reply!=='object'||reply.id!==id)return;
            if(reply.type==='plan-result'&&reply.status===200&&'body'in reply&&isPlanResponse(reply.body)){
              complete(jsonResponse(reply.body));
            }else if(reply.type==='plan-error'&&typeof reply.status==='number'&&Number.isInteger(reply.status)&&reply.status>=400&&reply.status<=599&&typeof reply.error==='string'&&reply.error.length<=1000&&(reply.code===undefined||isErrorCode(reply.code)))complete(failure(reply.status,reply.error,reply.code??'WORKER_RUNTIME'));
            else complete(failure(502,'The planning worker returned an invalid response.','INVALID_REPLY'));
          };
          instance.onerror=()=>{if(active&&worker===instance)complete(failure(503,'The local planning worker failed.','WORKER_RUNTIME'));};
          instance.onmessageerror=()=>{if(active&&worker===instance)complete(failure(502,'The planning worker response could not be read.','INVALID_REPLY'));};
          let localPreferences:PassportRecommendation|undefined;
          try{if(typeof localStorage!=='undefined'){const stored=readPassport(localStorage);if(!stored.error&&stored.passport.personalizationEnabled){const snapshot=recommendationSnapshot(stored.passport);if(Object.keys(snapshot.placePreferences).length||Object.keys(snapshot.interestWeights).length)localPreferences=snapshot;}}}catch{/* Storage never blocks route planning. */}
          // Separate local RPC field: never part of PlanRequest/API/Gemini data.
          instance.postMessage({type:'plan',id,request:parsed.value,apiOrigin:origin,...(localPreferences?{localPreferences}:{})} satisfies PlanWorkerRequest);
        }catch{if(active)complete(failure(503,'The local planning worker could not start.','WORKER_START'));}
      })();
    });
  };
}
export const planFetch=createPlanFetch();
