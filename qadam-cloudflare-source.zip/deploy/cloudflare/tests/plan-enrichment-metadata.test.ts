import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { mergeEnrichmentMetadata } from '../src/plan.worker.ts';
import type { PlanResponse } from '../../../qadam/lib/qadam-types';

test('enrichment retains local intent and walking evidence, unions warnings and keeps server outputs',()=>{
 const base:PlanResponse={plan:null,candidates:0,excluded:[],trace:[{step:'intent',detail:'Gemini food',ms:600},{step:'walking-graph',detail:'2 Dijkstra; bounded connectors',ms:20}],generationMode:'retrieval',warnings:['Unverified connectors','Unknown hours'],dataset:{count:1204,fetchedAt:'2026-10-20T00:00:00Z',source:'OpenStreetMap'}};
 const server:PlanResponse={...base,plan:{title:'Server canonical display',summary:'Server canonical summary',stops:[],totalMinutes:3,walkingMinutes:0,visitMinutes:0,bufferMinutes:3,distanceMeters:0,returnMinutes:0,routeCoordinates:[[71.43,51.128],[71.43,51.128]],routeKind:'walking'},generationMode:'gemini',trace:[{step:'source-check',detail:'Canonical source verification',ms:0},{step:'gemini',detail:'Closed display codes',ms:200}],warnings:['Unknown hours','Server warning']};
 const beforeOriginal=JSON.stringify(base),beforeServer=JSON.stringify(server);Object.freeze(base.trace);Object.freeze(base.warnings);Object.freeze(server.trace);Object.freeze(server.warnings);
 const result=mergeEnrichmentMetadata(base,server);assert.deepEqual(result.trace.map(t=>t.step),['intent','walking-graph','source-check','gemini']);assert.deepEqual(result.warnings,['Unverified connectors','Unknown hours','Server warning']);assert.equal(result.generationMode,'gemini');assert.equal(result.plan,server.plan);assert.equal(result.dataset,server.dataset);assert.notEqual(result.trace,base.trace);assert.notEqual(result.trace,server.trace);assert.equal(JSON.stringify(base),beforeOriginal);assert.equal(JSON.stringify(server),beforeServer);
});

for(const [language,retrievalWarning]of[
 ['ru','Режим поиска: пояснения подготовлены локально'],
 ['en','Retrieval mode: explanations prepared locally'],
 ['kk','Іздеу режимі: түсіндірмелер жергілікті дайындалды'],
]as const){
 for(const mode of ['gemini','retrieval']as const){
  test(`${language}: ${mode} removes only superseded original retrieval warnings on AI success`,()=>{
   const base:PlanResponse={plan:null,candidates:0,excluded:[],trace:[],generationMode:'retrieval',warnings:[retrievalWarning,'Unknown hours',`Note: ${retrievalWarning}`],dataset:{count:1204,fetchedAt:'2026-10-20T00:00:00Z',source:'OpenStreetMap'}};
   // Returned server warnings remain authoritative, including any similar prefix.
   const serverWarning=retrievalWarning+' — server';
   const server:PlanResponse={...base,generationMode:mode,warnings:['Unknown hours',serverWarning]};
   const beforeOriginal=JSON.stringify(base),beforeServer=JSON.stringify(server);
   const result=mergeEnrichmentMetadata(base,server);
   assert.deepEqual(result.warnings,[...(mode==='retrieval'?[retrievalWarning]:[]),'Unknown hours',`Note: ${retrievalWarning}`,serverWarning]);
   assert.equal(JSON.stringify(base),beforeOriginal);assert.equal(JSON.stringify(server),beforeServer);
  });
 }
}
