import assert from 'node:assert/strict';
import test from 'node:test';
import '../src/plan.worker.ts';
import type { PlanWorkerReply,PlanWorkerRequest } from '../src/plan-client';

test('worker clock failures and invalid departure have fixed diagnostics without raw service details',async t=>{
 const origin='https://qadam.example';
 const scope=globalThis as unknown as {location:{origin:string};postMessage:(value:PlanWorkerReply)=>void;onmessage:(event:MessageEvent<PlanWorkerRequest>)=>void};
 const previousLocation=Object.getOwnPropertyDescriptor(globalThis,'location'),previousPost=Object.getOwnPropertyDescriptor(globalThis,'postMessage');
 Object.defineProperty(globalThis,'location',{configurable:true,value:{origin}});
 let clockFails=true,calls=0;
 t.mock.method(globalThis,'fetch',async(input:RequestInfo|URL)=>{calls++;assert.equal(String(input),origin+'/api/time');if(clockFails)throw new Error('private-token and query and GPS must never be returned');return new Response(JSON.stringify({serverNowMs:Date.parse('2026-10-20T12:00:00Z')}),{headers:{'Content-Type':'application/json'}});});
 const request:PlanWorkerRequest['request']={query:'',origin:{lat:51.128,lon:71.43,label:'A'},minutes:45,interests:['park'],indoor:false,knownHoursOnly:false,accessible:false,language:'ru',departureMode:'custom',now:'2026-10-20T10:00:00Z'};
 async function dispatch(id:number){const reply=await new Promise<PlanWorkerReply>(resolve=>{Object.defineProperty(globalThis,'postMessage',{configurable:true,value:resolve});scope.onmessage({data:{type:'plan',id,request,apiOrigin:origin}} as MessageEvent<PlanWorkerRequest>);});for(let i=0;i<6;i++)await Promise.resolve();return reply;}
 try{
  const clock=await dispatch(1);assert.equal(clock.type,'plan-error');if(clock.type!=='plan-error')throw new Error('Expected clock rejection');assert.equal(clock.status,503);assert.equal(clock.code,'SERVER_CLOCK');assert.doesNotMatch(JSON.stringify(clock),/private-token|query and GPS/);
  clockFails=false;const time=await dispatch(2);assert.equal(time.type,'plan-error');if(time.type!=='plan-error')throw new Error('Expected departure rejection');assert.equal(time.status,400);assert.equal(time.code,'INVALID_TIME');assert.equal(calls,2);
 }finally{
  if(previousLocation)Object.defineProperty(globalThis,'location',previousLocation);else Reflect.deleteProperty(globalThis,'location');
  if(previousPost)Object.defineProperty(globalThis,'postMessage',previousPost);else Reflect.deleteProperty(globalThis,'postMessage');
 }
});
