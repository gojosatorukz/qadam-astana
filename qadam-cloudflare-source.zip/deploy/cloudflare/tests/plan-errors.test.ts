import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { planningFailureText } from '../src/plan-errors.ts';

test('error UI accepts closed support codes without exposing raw error content', () => {
  assert.match(planningFailureText(new Error('QADAM:WORKER_START'), 'ru')!, /WORKER_START/);
  assert.match(planningFailureText(new Error('QADAM:SERVER_CLOCK'), 'en')!, /time service/);
  assert.match(planningFailureText(new Error('QADAM:TIMEOUT'), 'kk')!, /TIMEOUT/);
  assert.equal(planningFailureText(new Error('https://private.example/?secret=abc'), 'ru'), null);
  assert.equal(planningFailureText({ message: 'QADAM:WORKER_START' }, 'ru'), null);
  assert.equal(planningFailureText(new Error('QADAM:CODE user query or coordinates'), 'ru'), null);
});
