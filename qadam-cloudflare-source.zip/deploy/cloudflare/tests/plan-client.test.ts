import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import { createPlanFetch } from '../src/plan-client.ts';
import type { PlanWorker } from '../src/plan-client';

class FakeWorker implements PlanWorker {
 onmessage:PlanWorker['onmessage']=null;onerror:PlanWorker['onerror']=null;onmessageerror:PlanWorker['onmessageerror']=null;
 requests:{type:string;id:number;request:unknown;apiOrigin:string}[]=[];terminations=0;
 postMessage(value:unknown){this.requests.push(value as typeof this.requests[number]);}
 terminate(){this.terminations++;}
 reply(value:unknown){this.onmessage?.call(this as unknown as Worker,{data:value} as MessageEvent);}
 fail(){this.onerror?.call(this as unknown as Worker,{} as ErrorEvent);}
}
const ORIGIN='https://qadam.example';
const request={query:'покушать',origin:{lat:51.128,lon:71.43,label:'A'},minutes:45,interests:['food'],indoor:false,knownHoursOnly:false,accessible:false,language:'ru',departureMode:'now',now:'2026-10-20T12:00:00+05:00'};
const init=(signal?:AbortSignal):RequestInit=>({method:'POST',body:JSON.stringify(request),signal});
const empty={plan:null,options:[],candidates:0,excluded:[],trace:[],warnings:[],generationMode:'retrieval',dataset:{count:0,fetchedAt:'2026-10-20T00:00:00Z',source:'Test source'}};
const flush=async()=>{for(let i=0;i<6;i++)await Promise.resolve();};
function harness(timeoutMs=1000){const workers:FakeWorker[]=[];const fetchPlan=createPlanFetch({origin:ORIGIN,timeoutMs,workerFactory:()=>{const w=new FakeWorker();workers.push(w);return w;}});return {fetchPlan,workers};}
const reply=(worker:FakeWorker,body:unknown=empty)=>worker.reply({type:'plan-result',id:worker.requests[0].id,status:200,body});

test('planning is lazy, posts only validated canonical JSON and disposes its own worker after success',async()=>{
 const {fetchPlan,workers}=harness();assert.equal(workers.length,0);const pending=fetchPlan('/api/plan',init());await flush();assert.equal(workers.length,1);assert.deepEqual(workers[0].requests[0].request,request);assert.equal(workers[0].requests[0].apiOrigin,ORIGIN);
 workers[0].reply({type:'plan-result',id:999,status:200,body:empty});assert.equal(workers[0].terminations,0);reply(workers[0]);const response=await pending;assert.equal(response.status,200);assert.deepEqual(await response.json(),empty);assert.equal(workers[0].terminations,1);assert.equal(workers[0].onmessage,null);
});
test('two concurrent requests own separate workers; cancelling one cannot hide the other',async()=>{
 const {fetchPlan,workers}=harness(),controller=new AbortController();const first=fetchPlan('/api/plan',init(controller.signal));const rejected=assert.rejects(first,{name:'AbortError'});const second=fetchPlan('/api/plan',init());await flush();assert.equal(workers.length,2);const oldCallback=workers[0].onmessage!;
 controller.abort();await rejected;assert.equal(workers[0].terminations,1);assert.equal(workers[1].terminations,0);oldCallback.call(workers[0] as unknown as Worker,{data:{type:'plan-result',id:workers[1].requests[0].id,status:200,body:empty}} as MessageEvent);assert.equal(workers[1].terminations,0);
 reply(workers[1]);assert.equal((await second).status,200);assert.equal(workers[1].terminations,1);
});
test('pre-aborted requests create no worker and lazy-loading cancellation terminates a late instance',async()=>{
 const controller=new AbortController();controller.abort();const first=harness();await assert.rejects(first.fetchPlan('/api/plan',init(controller.signal)),{name:'AbortError'});assert.equal(first.workers.length,0);
 let resolveFactory:((w:FakeWorker)=>void)|undefined;const fetchPlan=createPlanFetch({origin:ORIGIN,workerFactory:()=>new Promise<FakeWorker>(resolve=>{resolveFactory=resolve;})});const nextController=new AbortController(),pending=fetchPlan('/api/plan',init(nextController.signal));const rejection=assert.rejects(pending,{name:'AbortError'});await flush();nextController.abort();await rejection;const late=new FakeWorker();resolveFactory!(late);await flush();assert.equal(late.terminations,1);assert.equal(late.requests.length,0);
});
test('overall timeout includes module loading and a late factory cannot launch planning',async()=>{
 let resolveFactory:((w:FakeWorker)=>void)|undefined;const fetchPlan=createPlanFetch({origin:ORIGIN,timeoutMs:5,workerFactory:()=>new Promise<FakeWorker>(resolve=>{resolveFactory=resolve;})});const pending=fetchPlan('/api/plan',init());await flush();assert.equal((await pending).status,504);const late=new FakeWorker();resolveFactory!(late);await flush();assert.equal(late.terminations,1);assert.equal(late.requests.length,0);
});
test('malformed worker replies and runtime failures return honest non-200 responses',async()=>{
 const {fetchPlan,workers}=harness();const malformed=fetchPlan('/api/plan',init());await flush();reply(workers[0],{plan:'invented'});assert.equal((await malformed).status,502);assert.equal(workers[0].terminations,1);
 const crashed=fetchPlan('/api/plan',init());await flush();workers[1].fail();assert.equal((await crashed).status,503);assert.equal(workers[1].terminations,1);
 const context=fetchPlan('/api/plan',init());await flush();workers[2].reply({type:'plan-error',id:workers[2].requests[0].id,status:400,error:'Invalid planning time.'});assert.equal((await context).status,400);assert.equal(workers[2].terminations,1);
});
test('invalid JSON, byte limits, method and external origins never start a worker',async()=>{
 const {fetchPlan,workers}=harness();assert.equal((await fetchPlan('/api/plan',{method:'POST',body:'{'})).status,400);assert.equal((await fetchPlan('/api/plan',{method:'POST',body:JSON.stringify({...request,minutes:1})})).status,400);assert.equal((await fetchPlan('/api/plan',{method:'POST',body:'x'.repeat(32769)})).status,413);assert.equal((await fetchPlan('/api/plan',{method:'GET'})).status,405);assert.equal((await fetchPlan('https://another.example/api/plan',init())).status,403);assert.equal((await fetchPlan('/api/other',init())).status,404);assert.equal(workers.length,0);
});
test('Request objects work and a completed request removes its abort listener',async()=>{
 const {fetchPlan,workers}=harness(),controller=new AbortController(),input=new Request(ORIGIN+'/api/plan',{...init(),signal:controller.signal});const pending=fetchPlan(input);for(let i=0;i<10&&!workers.length;i++)await new Promise(resolve=>setTimeout(resolve,0));await flush();reply(workers[0]);assert.equal((await pending).status,200);controller.abort();assert.equal(workers[0].terminations,1);
});
test('Safari without static Response.json receives success, validation failure and timeout responses',async()=>{
 const descriptor=Object.getOwnPropertyDescriptor(Response,'json')!;
 Object.defineProperty(Response,'json',{value:undefined,configurable:true,writable:true});
 try{
  const {fetchPlan,workers}=harness();const pending=fetchPlan('/api/plan',init());await flush();reply(workers[0]);const success=await pending;
  assert.equal(success.status,200);assert.equal(success.headers.get('Content-Type'),'application/json');assert.equal(success.headers.get('X-Qadam-Error'),null);assert.deepEqual(await success.json(),empty);assert.equal(workers[0].terminations,1);
  const invalid=await fetchPlan('/api/plan',{method:'POST',body:'{'});assert.equal(invalid.status,400);assert.equal(invalid.headers.get('X-Qadam-Error'),'REQUEST_INVALID');assert.equal((await invalid.json()).error,'Planning requires valid JSON.');
  const timed=harness(5);const timeout=await timed.fetchPlan('/api/plan',init());assert.equal(timeout.status,504);assert.equal(timeout.headers.get('X-Qadam-Error'),'TIMEOUT');assert.equal(timed.workers[0].terminations,1);assert.equal(typeof(await timeout.json()).error,'string');
 }finally{Object.defineProperty(Response,'json',descriptor);}
});
test('stable failure codes distinguish worker stages and reject arbitrary diagnostic headers',async()=>{
 const {fetchPlan,workers}=harness();
 const clock=fetchPlan('/api/plan',init());await flush();workers[0].reply({type:'plan-error',id:workers[0].requests[0].id,status:503,error:'The server clock could not be verified. Retry planning.',code:'SERVER_CLOCK'});assert.equal((await clock).headers.get('X-Qadam-Error'),'SERVER_CLOCK');
 const runtime=fetchPlan('/api/plan',init());await flush();workers[1].fail();assert.equal((await runtime).headers.get('X-Qadam-Error'),'WORKER_RUNTIME');
 const malformed=fetchPlan('/api/plan',init());await flush();workers[2].reply({type:'plan-error',id:workers[2].requests[0].id,status:503,error:'Ignored detail',code:'query=secret;lat=51.1'});const rejected=await malformed;assert.equal(rejected.status,502);assert.equal(rejected.headers.get('X-Qadam-Error'),'INVALID_REPLY');assert.doesNotMatch(await rejected.text(),/secret|51\.1|Ignored detail/);
 const blocked=createPlanFetch({origin:ORIGIN,workerFactory:()=>{throw new Error('private provider diagnostic');}});const startup=await blocked('/api/plan',init());assert.equal(startup.headers.get('X-Qadam-Error'),'WORKER_START');assert.doesNotMatch(await startup.text(),/private provider/);
 for(const worker of workers)assert.equal(worker.terminations,1);
});
