import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Native Node tests use source extensions.
import { interpretResilientIntent,parseReserveOutput,reserveInput,RESERVE_MODEL } from '../src/resilient-intent.ts';
import type { PlanRequest } from '../../../qadam/lib/qadam-types';
const request:PlanRequest={query:'a park without coffee',language:'en',origin:{lat:51.12828,lon:71.43055,label:'private home'},minutes:90,interests:['museum'],indoor:false,knownHoursOnly:false,accessible:false};
const contract={version:1,desiredCategories:['park'],excludedCategories:['cafe'],includeMode:'any',unsupported:[],needsClarification:false};
const google=(value=contract)=>new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(value)}]}}]}));
const cf=(value:unknown=contract)=>({choices:[{finish_reason:'stop',message:{content:JSON.stringify(value),refusal:null}}]});
const flush=()=>new Promise<void>(resolve=>setImmediate(resolve));

test('fast validated Gemini does not consume reserve quota',async()=>{
 let calls=0;
 const r=await interpretResilientIntent(request,{apiKey:'synthetic',fetcher:async()=>google(),ai:{run:async()=>{calls++;return cf();}}});
 assert.equal(r.mode,'gemini');assert.equal(calls,0);assert.deepEqual(r.contract,contract);
});
test('503 and 429 each switch once to an independent reserve without a repeated Gemini request',async()=>{
 for(const status of [503,429]){
  let primary=0,reserve=0;
  const r=await interpretResilientIntent(request,{apiKey:'synthetic',fetcher:async()=>{primary++;return new Response('private provider error',{status});},ai:{run:async model=>{assert.equal(model,RESERVE_MODEL);reserve++;return cf();}}});
  assert.equal(primary,1);assert.equal(reserve,1);assert.equal(r.mode,'cloudflare');assert.deepEqual(r.contract,contract);assert.ok(!JSON.stringify(r).includes('private'));
 }
});
test('slow Gemini launches one reserve after 1.5s, aborts the loser and ignores its late result',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});let reserve=0,signal:AbortSignal|undefined,late:(value:Response)=>void=()=>{};
 const pending=interpretResilientIntent(request,{apiKey:'synthetic',fetcher:async(_u,i)=>{signal=i?.signal??undefined;return new Promise(resolve=>{late=resolve;});},ai:{run:async()=>{reserve++;return cf();}}});
 await flush();t.mock.timers.tick(1499);await flush();assert.equal(reserve,0);
 t.mock.timers.tick(1);await flush();const r=await pending;
 assert.equal(r.mode,'cloudflare');assert.equal(reserve,1);assert.equal(signal?.aborted,true);
 late(google({...contract,desiredCategories:['museum']}));await flush();assert.deepEqual(r.contract,contract);
});
test('a valid clarification from Gemini is not overwritten by a convenient reserve answer',async()=>{
 let calls=0;
 const clarified={...contract,desiredCategories:[],excludedCategories:[],needsClarification:true};
 const r=await interpretResilientIntent({...request,query:'football'},{apiKey:'synthetic',fetcher:async()=>google(clarified),ai:{run:async()=>{calls++;return cf();}}});
 assert.equal(r.mode,'gemini');assert.equal(r.contract?.needsClarification,true);assert.equal(calls,0);
});
test('invalid reserve output cannot win; the delayed valid Gemini can still finish',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});
 const pending=interpretResilientIntent(request,{apiKey:'synthetic',fetcher:async()=>{await new Promise(r=>setTimeout(r,7000));return google();},ai:{run:async()=>cf({...contract,desiredCategories:['invented']})}});
 await flush();t.mock.timers.tick(4000);await flush();t.mock.timers.tick(3000);await flush();const r=await pending;
 assert.equal(r.mode,'gemini');assert.deepEqual(r.contract,contract);
});
test('both non-cooperative providers remain bounded by the original deadline',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});let p=0,c=0,gs:AbortSignal|undefined,cs:AbortSignal|undefined;
 const pending=interpretResilientIntent(request,{apiKey:'synthetic',totalTimeoutMs:100,hedgeAfterMs:20,fetcher:async(_u,i)=>{p++;gs=i?.signal??undefined;return new Promise(()=>{});},ai:{run:async(_m,_i,o)=>{c++;cs=o?.signal;return new Promise(()=>{});}}});
 await flush();t.mock.timers.tick(20);await flush();t.mock.timers.tick(80);await flush();const r=await pending;
 assert.equal(p,1);assert.equal(c,1);assert.equal(r.mode,'unavailable');assert.equal(r.failure,'timeout');assert.equal(gs?.aborted,true);assert.equal(cs?.aborted,true);
});
test('parent cancellation aborts active providers and does not launch a delayed reserve',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});const controller=new AbortController();let calls=0,signal:AbortSignal|undefined;
 const pending=interpretResilientIntent(request,{apiKey:'synthetic',signal:controller.signal,fetcher:async(_u,i)=>{signal=i?.signal??undefined;return new Promise(()=>{});},ai:{run:async()=>{calls++;return cf();}}});
 const rejected=assert.rejects(pending,{name:'AbortError'});await flush();controller.abort();await rejected;t.mock.timers.tick(5000);await flush();
 assert.equal(calls,0);assert.equal(signal?.aborted,true);
});
test('cancellation after the hedge aborts both active providers and ignores both late completions',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});const controller=new AbortController();let g:AbortSignal|undefined,c:AbortSignal|undefined;
 let lateGoogle:(v:Response)=>void=()=>{},lateReserve:(v:unknown)=>void=()=>{};
 const pending=interpretResilientIntent(request,{apiKey:'synthetic',signal:controller.signal,fetcher:async(_u,i)=>{g=i?.signal??undefined;return new Promise(r=>{lateGoogle=r;});},ai:{run:async(_m,_i,o)=>{c=o?.signal;return new Promise(r=>{lateReserve=r;});}}});
 const rejected=assert.rejects(pending,{name:'AbortError'});await flush();t.mock.timers.tick(1500);await flush();controller.abort();await rejected;
 assert.equal(g?.aborted,true);assert.equal(c?.aborted,true);lateGoogle(google());lateReserve(cf());await flush();
});
test('blank manual request calls neither provider; reserve-only operation needs no Google key',async()=>{
 let g=0,c=0;
 const options={apiKey:'',fetcher:async()=>{g++;return google();},ai:{run:async()=>{c++;return cf();}}};
 const blank=await interpretResilientIntent({...request,query:''},options);assert.equal(blank.mode,'manual');assert.equal(g,0);assert.equal(c,0);
 const text=await interpretResilientIntent(request,options);assert.equal(text.mode,'cloudflare');assert.equal(g,0);assert.equal(c,1);
});
test('reserve rejects truncation, refusal, extra keys, invented quotes and invalid semantics',()=>{
 for(const payload of [
  {choices:[{finish_reason:'length',message:{content:JSON.stringify(contract)}}]},
  {choices:[{finish_reason:'stop',message:{content:JSON.stringify(contract),refusal:'blocked'}}]},
  cf({...contract,route:[1,2]}),cf({...contract,excludedCategories:['park']}),
  cf({...contract,unsupported:[{text:'invented Wi-Fi',reason:'no-data'}]}),
  {response:contract},
 ])assert.equal(parseReserveOutput(payload,request),null);
});
test('reserve carries exact negation/unknown quotes and excludes private structured context',()=>{
 const rq={...request,query:'a park without coffee, Wi-Fi'};
 const value={...contract,unsupported:[{text:'Wi-Fi',reason:'no-data'}]};
 assert.deepEqual(parseReserveOutput(cf(value),rq),value);
 const input=reserveInput(rq),text=JSON.stringify(input);
 assert.ok(!text.includes('51.12828'));assert.ok(!text.includes('private home'));
 assert.deepEqual(input.chat_template_kwargs,{enable_thinking:false});
 const content=JSON.parse((input.messages as {content:string}[])[1].content);
 assert.equal(content.query,rq.query);assert.equal(content.minutes,90);assert.deepEqual(content.chips,['museum']);
});
