import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile}from'node:fs/promises';
import '../src/plan.worker.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import {isPlanResponse,planSemanticsValid}from'../../../qadam/lib/plan-validation.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import {manualIntent}from'../../../qadam/lib/intent.ts';
// @ts-expect-error Native Node verification uses explicit TypeScript extensions.
import {applyPlaceFacts}from'../../../qadam/lib/place-facts.ts';
import type{POIDataset}from'../../../qadam/lib/planner';
import type{PlanWorkerReply,PlanWorkerRequest}from'../src/plan-client';

test('raw worker assets fail with safe stage codes, then real corpus food routes produce four valid choices',async t=>{
 const [poiText,graphText]=await Promise.all([readFile(new URL('../../../qadam/data/poi.json',import.meta.url),'utf8'),readFile(new URL('../../../qadam/data/walk-graph.json',import.meta.url),'utf8')]);
 const canonical=applyPlaceFacts(JSON.parse(poiText)as POIDataset),origin='https://qadam.example';
 const scope=globalThis as unknown as {location:{origin:string};postMessage:(value:PlanWorkerReply)=>void;onmessage:(event:MessageEvent<PlanWorkerRequest>)=>void};
 const previousLocation=Object.getOwnPropertyDescriptor(globalThis,'location'),previousPost=Object.getOwnPropertyDescriptor(globalThis,'postMessage');
 Object.defineProperty(globalThis,'location',{configurable:true,value:{origin}});
 let stage='POI_LOAD',assetCalls=0,providerCalls=0;
 t.mock.method(globalThis,'fetch',async(input:RequestInfo|URL,init?:RequestInit)=>{
  const url=new URL(String(input));
  if(url.pathname==='/api/time')return new Response(JSON.stringify({serverNowMs:Date.parse('2026-10-20T12:00:00Z')}));
  if(url.pathname.startsWith('/api/')){providerCalls++;throw new Error('Manual planning must not call AI');}
  assetCalls++;assert.equal(init?.mode,'same-origin');assert.equal(init?.credentials,'same-origin');assert.equal(init?.redirect,'error');assert.equal(init?.cache,'force-cache');
  if(url.pathname.endsWith('/poi.json')){
   if(stage==='POI_LOAD')throw new Error('secret-query GPS raw exception');
   return new Response(stage==='POI_INIT'?JSON.stringify({pois:null}):poiText);
  }
  assert.ok(url.pathname.endsWith('/walk-graph.json'));
  if(stage==='GRAPH_LOAD')return new Response('private response body',{status:503});
  return new Response(stage==='GRAPH_INIT'?JSON.stringify({nodes:null,edges:[]}):graphText);
 });
 const request:PlanWorkerRequest['request']={query:'',origin:{lat:51.128,lon:71.43,label:'A'},minutes:45,interests:['food'],indoor:false,knownHoursOnly:false,accessible:false,language:'ru',departureMode:'now',now:'2026-10-20T12:00:00Z',localOnly:true};
 async function dispatch(id:number,current=request){const reply=await new Promise<PlanWorkerReply>(resolve=>{Object.defineProperty(globalThis,'postMessage',{configurable:true,value:resolve});scope.onmessage({data:{type:'plan',id,request:current,apiOrigin:origin}}as MessageEvent<PlanWorkerRequest>);});for(let i=0;i<6;i++)await Promise.resolve();return reply;}
 try{
  let id=0;
  for(const code of ['POI_LOAD','POI_INIT','GRAPH_LOAD','GRAPH_INIT']){
   stage=code;const reply=await dispatch(++id);assert.equal(reply.type,'plan-error');if(reply.type!=='plan-error')throw new Error('Expected stage failure');assert.equal(reply.status,503);assert.equal(reply.code,code);assert.doesNotMatch(JSON.stringify(reply),/secret-query|GPS raw|private response/);
  }
  stage='valid';
  const museum=canonical.pois.find(p=>p.id==='osm-node-4894937300')!;assert.ok(museum);
  for(const current of [request,{...request,minutes:90,destination:{lat:museum.lat,lon:museum.lon,label:'B'}}]){
   const reply=await dispatch(++id,current);assert.equal(reply.type,'plan-result');if(reply.type!=='plan-result')throw new Error(JSON.stringify(reply));assert.ok(isPlanResponse(reply.body));
   const result=reply.body;if(!isPlanResponse(result))throw new Error('Invalid route shape');assert.equal(result.options?.length,4);assert.equal(result.intent?.mode,'manual');assert.equal(result.generationMode,'retrieval');
   const effective={...current,now:result.departureAt??current.now};assert.ok(planSemanticsValid(result,effective,canonical,manualIntent(effective)));
   for(const option of result.options!){const end=current.destination??current.origin;assert.equal(option.plan.routeKind,'walking');assert.ok(option.plan.stops.every(stop=>stop.poi.category==='food'));assert.deepEqual(option.plan.routeCoordinates[0],[current.origin.lon,current.origin.lat]);assert.deepEqual(option.plan.routeCoordinates.at(-1),[end.lon,end.lat]);assert.equal(option.plan.legEndIndices?.length,option.plan.stops.length+1);assert.ok(option.plan.totalMinutes<=current.minutes);}
  }
  assert.equal(providerCalls,0);assert.equal(assetCalls,6,'failed loads retry; successful corpus and graph are reused');
 }finally{
  if(previousLocation)Object.defineProperty(globalThis,'location',previousLocation);else Reflect.deleteProperty(globalThis,'location');
  if(previousPost)Object.defineProperty(globalThis,'postMessage',previousPost);else Reflect.deleteProperty(globalThis,'postMessage');
 }
});
