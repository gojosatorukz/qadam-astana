import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const modules=path.resolve(project,'../../qadam/node_modules');
try { await fs.access(modules); } catch { throw new Error('First run npm ci in qadam/. The standalone profile reuses its pinned dependencies.'); }
try { await fs.lstat(path.join(project,'node_modules')); } catch { await fs.symlink(modules,path.join(project,'node_modules'),process.platform==='win32'?'junction':'dir'); }
console.log('Pinned canonical dependencies linked; no new installation was performed.');
