import { build } from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
await build({entryPoints:[path.join(project,'src/worker-entry.ts')],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:path.join(project,'dist/client/_worker.js'),minify:true,legalComments:'none',sourcemap:false});
await fs.writeFile(path.join(project,'dist/client/_routes.json'),JSON.stringify({version:1,include:['/api/*'],exclude:['/api/places']})+'\n');
await fs.writeFile(path.join(project,'dist/client/_headers'),`/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(self), camera=(), microphone=()
/api/places
  Content-Type: application/json; charset=utf-8
  Cache-Control: public, max-age=300
/assets/*
  Cache-Control: public, max-age=31536000, immutable
/\n  Cache-Control: no-cache
`);
console.log('Pages advanced-mode server and API-only routes prepared; static UI and graph computation remain browser assets.');
