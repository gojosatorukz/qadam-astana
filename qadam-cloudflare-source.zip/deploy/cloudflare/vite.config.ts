import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
const canonical = path.resolve(import.meta.dirname, '../../qadam');
export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@': canonical }, dedupe: ['react', 'react-dom'] },
  publicDir: './public',
  css: { postcss: canonical },
  build: { outDir: 'dist/client', emptyOutDir: true, sourcemap: false },
  worker: { format: 'es' },
  server: { host: '127.0.0.1', fs: { allow: [canonical, import.meta.dirname] }, watch: {useFsEvents: false, usePolling:true} },
});
