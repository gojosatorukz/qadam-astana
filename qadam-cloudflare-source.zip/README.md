# Qadam Cloudflare source

The canonical Qadam source is in qadam/. The independent Free Cloudflare Pages profile and reproducible setup are documented in deploy/cloudflare/README.md.

No credentials, generated build assets, private test evidence or dependency directories are included.
