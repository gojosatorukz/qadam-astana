'use client';
import { Check, Star, ThumbsDown, ThumbsUp } from 'lucide-react';
import type { POI } from '@/lib/qadam-types';
import type { PassportRating } from '@/lib/passport-types';
import { usePassport } from '@/lib/passport-hook';
import { getPlacePreference, hasVisitedPlace } from '@/lib/passport';
import { getPersonalizationLabels, passportErrorMessage } from '@/lib/passport-copy';
import './city-passport.css';

/** Impressions are private preferences, never a global venue score or proof of a visit. */
export default function PlaceFeedback({poi,language,compact=false}:{poi:POI;language:'ru'|'en'|'kk';compact?:boolean}) {
  const {passport,loading,status,error,setPlacePreference}=usePassport();
  const pref=getPlacePreference(passport,poi.id),visited=hasVisitedPlace(passport,poi.id),labels=getPersonalizationLabels(language);
  const L=(ru:string,en:string,kk:string)=>language==='en'?en:language==='kk'?kk:ru;
  const disabled=loading||status!=='ready';
  return <section className={'passport-feedback'+(compact?' is-compact':'')} aria-label={L('Моё впечатление о месте','My place preference','Орын туралы қалауым')}>
    <div className="passport-feedback-heading"><strong>{visited?L('Как тебе это место?','How was this place?','Бұл орын ұнады ма?'):L('Твоё предпочтение','Your preference','Жеке қалауың')}</strong>{visited&&<span><Check size={12}/>{L('Посещение подтверждено','Visit confirmed','Барғаның расталды')}</span>}</div>
    <div className="passport-impressions"><button disabled={disabled} aria-pressed={pref?.sentiment==='liked'} onClick={()=>setPlacePreference(poi.id,{sentiment:pref?.sentiment==='liked'?undefined:'liked'})}><ThumbsUp size={17}/>{L('Нравится','Like it','Ұнайды')}</button><button disabled={disabled} aria-pressed={pref?.sentiment==='disliked'} onClick={()=>setPlacePreference(poi.id,{sentiment:pref?.sentiment==='disliked'?undefined:'disliked'})}><ThumbsDown size={17}/>{L('Не моё','Not for me','Маған сай емес')}</button></div>
    {visited?<div className="passport-rating"><span>{L('Личная оценка · необязательно','Your rating · optional','Жеке баға · міндетті емес')}</span><div role="group" aria-label={L('Оценка от одного до пяти','Rating from one to five','Бірден беске дейінгі баға')}>{([1,2,3,4,5] as PassportRating[]).map(value=><button key={value} disabled={disabled} className={(pref?.rating??0)>=value?'filled':''} aria-pressed={pref?.rating===value} aria-label={L(`Моя оценка: ${value} из 5`,`My rating: ${value} out of 5`,`Жеке бағам: 5-тен ${value}`)} onClick={()=>setPlacePreference(poi.id,{rating:pref?.rating===value?undefined:value})}><Star size={21}/></button>)}</div></div>:!compact&&<p className="passport-feedback-note">{L('Оценка звёздами откроется после подтверждённого посещения в прогулке.','Star ratings unlock after a confirmed walking visit.','Жұлдызбен бағалау серуенде барғаның расталған соң ашылады.')}</p>}
    <label className="passport-soft-avoid"><input type="checkbox" disabled={disabled} checked={pref?.avoid??false} onChange={event=>setPlacePreference(poi.id,{avoid:event.currentTarget.checked})}/><span>{labels.softAvoid}<small>{L('Мягкое предпочтение: место может остаться, если ты выберешь его целью.','A soft preference: an explicitly chosen place can remain.','Жұмсақ қалау: нысана етіп таңдаған орын қалуы мүмкін.')}</small></span></label>
    {!compact&&<p className="passport-feedback-note">{labels.notGlobal} {L('Не даёт XP. Только в этом браузере.','No XP awarded. Only in this browser.','XP берілмейді. Тек осы браузерде.')}</p>}
    {error&&<p className="passport-error" role="alert">{passportErrorMessage(error,language)}</p>}
  </section>;
}
