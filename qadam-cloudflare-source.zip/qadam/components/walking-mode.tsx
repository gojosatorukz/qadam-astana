'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ArrowUp, ArrowUpLeft, ArrowUpRight, Check, ChevronLeft, ChevronRight, Clock3, CornerUpLeft, CornerUpRight, ExternalLink, Flag, Footprints, Info, List, LocateFixed, MapPin, Pause, Play, RotateCcw, Volume2, VolumeX, X } from 'lucide-react';
import CityMap from './city-map';
import PlaceDiscovery from './place-discovery';
import { createWalkGuide, createGuideProgress, updateWalkGuide, confirmGuideLeg } from '@/lib/walk-guide';
import type { GuideFix, GuideInstructionKind, GuideProgress, GuideUpdate, SupportedWalkGuide } from '@/lib/walk-guide';
import { createLocationWatch, walkStartBlock } from '@/lib/walk-session';
import { walkDirection, walkDistance } from '@/lib/walk-copy';
import { createWalkRerouter } from '@/lib/walk-reroute-client';
import { createOffRoutePolicy, observeOffRoute, beginOffRouteAttempt, finishOffRouteAttempt, resetOffRoutePolicy, REROUTE_COOLDOWN_MS } from '@/lib/walk-reroute-policy';
import { activeLegCrossTrackMeters } from '@/lib/walk-route-distance';
import { rerouteApplyBlock } from '@/lib/walk-reroute-apply';
import type { RerouteRequest } from '@/lib/walk-reroute';
import { poiDisplayName } from '@/lib/ui-copy';
import { publicMapLink } from '@/lib/experience';
import type { Language, Origin } from '@/lib/experience';
import type { PlanStop, RoutePlan } from '@/lib/qadam-types';
import './walking-mode.css';

type Props={plan:RoutePlan;origin:Origin;destination:Origin|null;language:Language;deadlineAt:string;departureAt?:string;computedAt?:string;departureMode:'now'|'custom';accessible:boolean;knownHoursOnly:boolean;locationAPI?:Pick<Geolocation,'watchPosition'|'clearWatch'>;onClose:()=>void};
type Phase='intro'|'preview'|'live'|'paused'|'visiting'|'done';
type Fix=GuideFix&{heading:number|null};
const icons={start:ArrowUp,straight:ArrowUp,left:CornerUpLeft,right:CornerUpRight,'bear-left':ArrowUpLeft,'bear-right':ArrowUpRight,'u-turn':RotateCcw,arrive:Flag};
const MAX_FIX_AGE=20_000;

export default function WalkingMode(props:Props){
  const guide=useMemo(()=>createWalkGuide(props.plan),[props.plan]);
  const L=(ru:string,en:string,kk:string)=>props.language==='en'?en:props.language==='kk'?kk:ru;
  if(!guide.supported)return <section className="walking-mode walk-unavailable"><button className="walk-close" onClick={props.onClose} aria-label={L('Закрыть режим прогулки','Close walking mode','Серуен режимін жабу')}><X size={22}/></button><Flag size={38}/><h2 id="walk-title">{L('Для этого пути доступны схема и места.','This route has a map and places to explore.','Бұл бағытта карта мен орындар қолжетімді.')}</h2><p>{L('Повороты не подтверждены геометрией пути. Открой карту маршрута или выбранное место в 2ГИС.','Turn geometry is not confirmed. Open the route map or the selected place in 2GIS.','Бұрылыс геометриясы расталмады. Бағыт картасын не орынды 2GIS-те аш.')}</p><button className="primary-action" onClick={props.onClose}><ArrowLeft size={18}/>{L('Вернуться к маршруту','Back to route','Бағытқа қайту')}</button>{props.plan.stops[0]&&<a className="outline-button" href={publicMapLink(props.plan.stops[0].poi,'2gis')} target="_blank" rel="noreferrer">2ГИС<ExternalLink size={16}/></a>}</section>;
  return <WalkingSession {...props} guide={guide}/>;
}

function WalkingSession({plan:initialPlan,origin,destination,language,deadlineAt,departureAt,computedAt,departureMode,accessible,knownHoursOnly,locationAPI,onClose,guide:initialGuide}:Props&{guide:SupportedWalkGuide}){
  const [journey,setJourney]=useState({plan:initialPlan,guide:initialGuide});
  const {plan,guide}=journey;
  const journeyRef=useRef(journey);
  const phaseRef=useRef<Phase>('intro');
  const latestFix=useRef<Fix|null>(null);
  const rerouter=useRef<ReturnType<typeof createWalkRerouter>|null>(null);
  const policy=useRef(createOffRoutePolicy());
  const rerouteEpoch=useRef(0),reroutingRef=useRef(false);
  const [rerouting,setRerouting]=useState(false);
  const [rerouteNotice,setRerouteNotice]=useState<{kind:'updated'|'failed';removed:string[];lateBy:number;reason?:string}|null>(null);
  const L=(ru:string,en:string,kk:string)=>language==='en'?en:language==='kk'?kk:ru;
  const [phase,setPhase]=useState<Phase>('intro');
  const [progress,setProgress]=useState<GuideProgress>(()=>createGuideProgress());
  const progressRef=useRef(progress);
  const [snapshot,setSnapshot]=useState<{fix:Fix;update:GuideUpdate}|null>(null);
  const [gpsError,setGPSError]=useState('');
  const [previewLeg,setPreviewLeg]=useState(0),[previewStep,setPreviewStep]=useState(0);
  const [follow,setFollow]=useState(true),[voice,setVoice]=useState(false),[voiceAvailable,setVoiceAvailable]=useState(false);
  const [voiceError,setVoiceError]=useState('');
  const [detail,setDetail]=useState<PlanStop|null>(null);
  const [tick,setTick]=useState(()=>Date.now());
  const rootRef=useRef<HTMLElement>(null),headerRef=useRef<HTMLElement>(null),instructionRef=useRef<HTMLDivElement>(null),bottomRef=useRef<HTMLDivElement>(null);
  const [mapInsets,setMapInsets]=useState({top:80,right:64,bottom:440,left:12});
  useEffect(()=>{
    function measure(){
      const root=rootRef.current?.getBoundingClientRect(),header=headerRef.current?.getBoundingClientRect(),bottom=bottomRef.current?.getBoundingClientRect(),cue=instructionRef.current?.getBoundingClientRect();
      if(!root||!bottom)return;
      const next={top:Math.ceil((cue?.bottom??header?.bottom??root.top+64)-root.top+12),right:root.width>800?Math.ceil(root.right-bottom.left+16):64,bottom:root.width>800?16:Math.ceil(root.bottom-bottom.top+12),left:12};
      setMapInsets(old=>Object.keys(next).every(key=>next[key as keyof typeof next]===old[key as keyof typeof old])?old:next);
    }
    measure();const observer=new ResizeObserver(measure);
    [rootRef.current,headerRef.current,instructionRef.current,bottomRef.current].forEach(element=>{if(element)observer.observe(element);});
    window.addEventListener('resize',measure);return()=>{observer.disconnect();window.removeEventListener('resize',measure);};
  },[phase]);
  const watcher=useRef<ReturnType<typeof createLocationWatch>|null>(null);
  const lastTimestamp=useRef(0),started=useRef(false),lastSpoken=useRef(''),speechEpoch=useRef(0);

  function cancelSpeech(){speechEpoch.current++;lastSpoken.current='';if(typeof window!=='undefined'&&'speechSynthesis'in window)window.speechSynthesis.cancel();}
  function changePhase(next:Phase){phaseRef.current=next;setPhase(next);}
  function cancelReroute(updateUI=true){rerouteEpoch.current++;rerouter.current?.dispose();rerouter.current=null;reroutingRef.current=false;policy.current=resetOffRoutePolicy(finishOffRouteAttempt(policy.current));if(updateUI)setRerouting(false);}
  function stopGPS(){watcher.current?.stop();cancelSpeech();cancelReroute();}
  function close(){stopGPS();onClose();}
  useEffect(()=>{
    setVoiceAvailable('speechSynthesis'in window&&'SpeechSynthesisUtterance'in window);
    const timer=window.setInterval(()=>setTick(Date.now()),1000);
    function hidden(){if(document.visibilityState!=='visible'){stopGPS();latestFix.current=null;setSnapshot(null);if(phaseRef.current==='live')changePhase('paused');}}
    document.addEventListener('visibilitychange',hidden);
    return()=>{window.clearInterval(timer);document.removeEventListener('visibilitychange',hidden);watcher.current?.stop();cancelReroute(false);speechEpoch.current++;if('speechSynthesis'in window)window.speechSynthesis.cancel();};
  },[]);

  const index=phase==='preview'?previewLeg:Math.min(progress.legIndex,guide.legs.length-1);
  const leg=guide.legs[index],targetStop=leg.kind==='stop'?plan.stops[index]:null;
  const target=targetStop?poiDisplayName(targetStop.poi,language):destination?.label??origin.label;
  const startBlock=walkStartBlock({nowMs:tick,departureMode,departureAt,computedAt,deadlineAt,hasStarted:started.current});
  const future=startBlock==='future',expiredBeforeStart=startBlock==='expired';
  const canStart=!future&&!expiredBeforeStart&&phase!=='done';
  const fresh=!!snapshot&&tick-snapshot.fix.timestamp<=MAX_FIX_AGE;
  const status=phase==='live'&&snapshot?(fresh?snapshot.update.status:'stale-fix'):null;
  const update=phase==='live'&&fresh?snapshot?.update:null;
  const navPosition=phase==='live'&&fresh&&snapshot&&(status==='tracking'||status==='off-route')?snapshot.fix:undefined;
  const instruction=phase==='preview'?leg.instructions[previewStep]:update?.nextInstruction??leg.instructions[0];
  const remaining=phase==='preview'?Math.max(0,leg.totalMeters-(instruction?.atMeters??0)):update?.remainingMeters??Math.max(0,leg.totalMeters-progress.meters);
  const cueDistance=phase==='preview'?Math.max(0,(instruction?.atMeters??0)-(leg.instructions[previewStep-1]?.atMeters??0)):update?.distanceToInstruction??0;
  const kind:GuideInstructionKind=instruction?.kind??'start';
  const Icon=icons[kind];
  const near=!rerouting&&!!update?.canConfirmArrival&&status==='tracking';
  const remainingMinutes=Math.ceil((Date.parse(deadlineAt)-tick)/60_000);
  const goalCount=guide.legs.length;
  const retrySeconds=policy.current.lastAttemptAt===null?0:Math.max(0,Math.ceil((policy.current.lastAttemptAt+REROUTE_COOLDOWN_MS-tick)/1000));
  const qualityMessage=rerouting?L('Считаем путь от твоей позиции с оставшимся временем. Финиш сохраняется.','Recalculating from your position with the time left. Your finish stays the same.','Қалған уақытпен орныңнан жолды есептейміз. Соңғы нүкте сақталады.'):status==='off-route'?L('Проверяем отклонение. При точном GPS перестроим путь автоматически.','Checking the deviation. Accurate GPS will trigger automatic rerouting.','Ауытқуды тексереміз. Дәл GPS болса, бағыт автоматты өзгереді.'):status==='poor-accuracy'?L('GPS недостаточно точный. Ждём более точную позицию.','GPS accuracy is low. Waiting for a better fix.','GPS дәлдігі төмен. Дәлірек орынды күтеміз.'):status==='stale-fix'?L('Позиция устарела. Ждём обновление GPS.','The position is stale. Waiting for GPS.','Орның ескірді. GPS жаңаруын күтеміз.'):status==='invalid-fix'?L('Позиция не распознана. Ждём обновление GPS.','The position could not be read. Waiting for GPS.','Орның анықталмады. GPS жаңаруын күтеміз.'):'';
  const title=rerouting?L('Перестраиваем путь…','Rerouting…','Бағытты өзгертеміз…'):phase==='live'&&!snapshot?L('Ищем твоё положение…','Finding your position…','Орныңды іздеудеміз…'):qualityMessage?L('Сверься с картой','Check the map','Картамен салыстыр'):near?L('Остановка рядом','Your stop is nearby','Аялдама жақын'):walkDirection(kind,language);
  const distanceText=phase==='preview'?L('Участок перед подсказкой: ','Distance before this cue: ','Нұсқауға дейін: ')+walkDistance(cueDistance,language):kind==='start'?L('До следующей точки ','To the next point ','Келесі нүктеге ')+walkDistance(remaining,language):L('Через ','In ','Кейін ')+walkDistance(cueDistance,language);

  function speak(text:string){
    if(!('speechSynthesis'in window)||!('SpeechSynthesisUtterance'in window))return;
    try{window.speechSynthesis.cancel();window.speechSynthesis.resume();const epoch=++speechEpoch.current,utterance=new SpeechSynthesisUtterance(text);utterance.lang=language==='en'?'en-US':language==='kk'?'kk-KZ':'ru-RU';const voices=window.speechSynthesis.getVoices();utterance.voice=voices.find(v=>v.localService&&v.lang.toLowerCase().startsWith(language))??voices.find(v=>v.lang.toLowerCase().startsWith(language))??null;utterance.rate=.96;utterance.onerror=event=>{if(epoch===speechEpoch.current&&!['canceled','interrupted'].includes(event.error)){setVoice(false);setVoiceError(L('Голос недоступен. Текстовые подсказки остаются.','Voice is unavailable. Text guidance remains.','Дауыс қолжетімсіз. Мәтіндік нұсқаулар бар.'));}};window.speechSynthesis.speak(utterance);}catch{setVoice(false);setVoiceError(L('Голос недоступен. Читай подсказки на экране.','Voice is unavailable. Read the on-screen cues.','Дауыс қолжетімсіз. Экрандағы нұсқауды оқы.'));}
  }
  const spokenText=qualityMessage||(!snapshot&&phase==='live'?'':near?L('Остановка рядом. Подтверди, когда придёшь.','Your stop is nearby. Confirm when you arrive.','Аялдама жақын. Келгенде раста.'):distanceText+'. '+walkDirection(kind,language));
  const speechKey=(rerouting?'rerouting:':phase==='preview'?'preview:':'live:')+index+':'+instruction?.id+':'+(qualityMessage?status:near?'near':cueDistance<20?'20':cueDistance<60?'60':'far');
  useEffect(()=>{
    if(!voice||!['live','preview'].includes(phase)||!spokenText||lastSpoken.current===speechKey)return;
    lastSpoken.current=speechKey;speak((phase==='preview'?L('Просмотр. ','Preview. ','Қарау. '):'')+spokenText);
  },[voice,phase,speechKey,spokenText]);

  async function replan(fix:Fix){
    const nowMs=Date.now();
    if(phaseRef.current!=='live'||reroutingRef.current||!Number.isFinite(fix.accuracy)||fix.accuracy<0||fix.accuracy>25||nowMs-fix.timestamp>MAX_FIX_AGE||fix.timestamp>nowMs+5000)return;
    const attempt=beginOffRouteAttempt(policy.current,nowMs);if(!attempt.inFlight)return;
    const current=journeyRef.current,epoch=++rerouteEpoch.current;
    const endpoint=destination??origin;
    const request:RerouteRequest={fix:{lat:fix.lat,lon:fix.lon,accuracy:fix.accuracy,timestamp:fix.timestamp},endpoint:{lat:endpoint.lat,lon:endpoint.lon,label:endpoint.label},remainingStops:current.plan.stops.slice(progressRef.current.legIndex),deadlineAt,nowMs,accessible,knownHoursOnly,language};
    policy.current=attempt;reroutingRef.current=true;setRerouting(true);setRerouteNotice(null);cancelSpeech();
    rerouter.current??=createWalkRerouter();
    const reply=await rerouter.current.reroute(request);
    if(epoch!==rerouteEpoch.current||phaseRef.current!=='live')return;
    policy.current=finishOffRouteAttempt(policy.current);reroutingRef.current=false;setRerouting(false);
    if(!reply.ok){setRerouteNotice({kind:'failed',removed:[],lateBy:0,reason:reply.reason});return;}
    const block=rerouteApplyBlock(reply.result,request,latestFix.current,Date.now());
    if(block||reply.result.kind!=='route'){setRerouteNotice({kind:'failed',removed:[],lateBy:0,reason:reply.result.kind==='unavailable'?reply.result.reason:block??'unavailable'});return;}
    const result=reply.result,nextGuide=createWalkGuide(result.plan);
    if(!nextGuide.supported){setRerouteNotice({kind:'failed',removed:[],lateBy:0,reason:'unavailable'});return;}
    const nextJourney={plan:result.plan,guide:nextGuide},fixNow=latestFix.current!;
    const nextProgress=updateWalkGuide(nextGuide,createGuideProgress(),fixNow,{nowMs:Date.now(),maxAccuracyMeters:45,staleAfterMs:MAX_FIX_AGE});
    journeyRef.current=nextJourney;setJourney(nextJourney);progressRef.current=nextProgress.state;setProgress(nextProgress.state);setSnapshot({fix:fixNow,update:nextProgress});setPreviewLeg(0);setPreviewStep(0);setDetail(null);setFollow(true);started.current=true;setTick(Date.now());cancelSpeech();
    setRerouteNotice({kind:'updated',removed:request.remainingStops.filter(stop=>result.removedPoiIds.includes(stop.poi.id)).map(stop=>poiDisplayName(stop.poi,language)),lateBy:result.overBudget?result.lateByMinutes:0});
  }

  function startGPS(){
    if(walkStartBlock({nowMs:Date.now(),departureMode,departureAt,computedAt,deadlineAt,hasStarted:started.current})||phase==='done')return;
    stopGPS();setGPSError('');setSnapshot(null);latestFix.current=null;lastTimestamp.current=0;setFollow(true);setDetail(null);
    const location=locationAPI??navigator.geolocation;
    if(!location){setGPSError(L('GPS здесь недоступен. Можно посмотреть шаги без GPS.','GPS is unavailable here. You can preview the steps.','GPS қолжетімсіз. Қадамдарды GPS-сіз қарауға болады.'));changePhase('paused');return;}
    changePhase('live');
    watcher.current??=createLocationWatch(location);
    try{watcher.current.start(position=>{
      const fix:Fix={lat:position.coords.latitude,lon:position.coords.longitude,accuracy:position.coords.accuracy,timestamp:position.timestamp,heading:typeof position.coords.heading==='number'&&Number.isFinite(position.coords.heading)&&(position.coords.speed??0)>.5?position.coords.heading:null};
      if(walkStartBlock({nowMs:Date.now(),departureMode,departureAt,computedAt,deadlineAt,hasStarted:started.current})){stopGPS();setSnapshot(null);changePhase('paused');setGPSError(L('Время плана изменилось. Пересчитай маршрут перед стартом.','Plan time changed. Refresh the route before starting.','Жоспар уақыты өзгерді. Бастамас бұрын қайта есепте.'));return;}
      if(fix.timestamp<=lastTimestamp.current)return;lastTimestamp.current=fix.timestamp;
      const observation=updateWalkGuide(journeyRef.current.guide,progressRef.current,fix,{nowMs:Date.now(),maxAccuracyMeters:45,staleAfterMs:MAX_FIX_AGE});
      latestFix.current=fix;
      if(observation.status==='tracking'){started.current=true;if(reroutingRef.current){cancelReroute();setRerouteNotice(null);}}
      progressRef.current=observation.state;setProgress(observation.state);setSnapshot({fix,update:observation});setTick(Date.now());setGPSError('');
      const crossTrack=observation.status==='off-route'?activeLegCrossTrackMeters(journeyRef.current.guide,observation.state,fix):observation.crossTrackMeters;
      const decision=observeOffRoute(policy.current,{fix,status:observation.status,crossTrackMeters:crossTrack,nowMs:Date.now()});policy.current=decision.state;
      if(decision.shouldReroute)void replan(fix);
    },error=>{stopGPS();setSnapshot(null);changePhase('paused');setGPSError(error.code===1?L('Доступ к геолокации не разрешён. Разреши его в браузере или просмотри шаги без GPS.','Location access is denied. Allow it in the browser or preview the steps.','Геолокацияға рұқсат жоқ. Браузерде рұқсат бер не қадамдарды GPS-сіз қара.'):error.code===3?L('GPS не ответил вовремя. Повтори запуск или просмотри шаги.','GPS timed out. Retry or preview the steps.','GPS уақытында жауап бермеді. Қайтала не қадамдарды қара.'):L('Не удалось получить позицию. Повтори запуск или просмотри шаги.','Could not get your position. Retry or preview the steps.','Орның анықталмады. Қайтала не қадамдарды қара.'));});}catch{stopGPS();changePhase('paused');setGPSError(L('Браузер не дал включить GPS. Можно посмотреть шаги без него.','The browser could not start GPS. You can preview the steps.','Браузер GPS қоса алмады. Қадамдарды GPS-сіз қарауға болады.'));}
  }
  function pause(){stopGPS();setSnapshot(null);changePhase('paused');}
  function preview(){stopGPS();setSnapshot(null);setPreviewLeg(Math.min(progressRef.current.legIndex,guide.legs.length-1));setPreviewStep(0);setDetail(null);changePhase('preview');}
  function movePreview(direction:1|-1){
    if(direction===1){if(previewStep<leg.instructions.length-1)setPreviewStep(n=>n+1);else if(previewLeg<guide.legs.length-1){setPreviewLeg(n=>n+1);setPreviewStep(0);}}
    else if(previewStep>0)setPreviewStep(n=>n-1);else if(previewLeg>0){setPreviewLeg(n=>n-1);setPreviewStep(guide.legs[previewLeg-1].instructions.length-1);}
  }
  function confirmArrival(){if(!near)return;stopGPS();setSnapshot(null);setDetail(null);if(leg.kind==='finish'){const next=confirmGuideLeg(guide,progressRef.current);progressRef.current=next;setProgress(next);changePhase('done');}else changePhase('visiting');}
  function continueWalk(){const next=confirmGuideLeg(guide,progressRef.current);progressRef.current=next;setProgress(next);setDetail(null);startGPS();}

  return <section ref={rootRef} className={'walking-mode phase-'+phase}>
    <h2 id="walk-title" className="sr-only">{L('Режим прогулки','Walking mode','Серуен режимі')}</h2>
    <div className="walking-map" style={{'--walk-map-center':`calc((${mapInsets.top}px + (100dvh - ${mapInsets.bottom}px)) / 2)`} as React.CSSProperties}><CityMap origin={origin} destination={destination??undefined} pois={plan.stops.map(s=>s.poi)} plan={plan} language={language} viewportInsets={mapInsets} hideChrome onSelect={poi=>setDetail(plan.stops.find(s=>s.poi.id===poi.id)??null)} navigationPosition={navPosition} followPosition={!!navPosition&&follow} onFollowChange={setFollow}/></div>
    <header ref={headerRef} className="walk-header"><button className="walk-close" onClick={close} aria-label={L('Закрыть режим прогулки','Close walking mode','Серуен режимін жабу')}><X size={21}/></button><span className={'walk-state state-'+phase}><i/>{phase==='preview'?L('ПРОСМОТР · БЕЗ GPS','PREVIEW · NO GPS','ҚАРАУ · GPS-СІЗ'):phase==='live'?status==='tracking'?L('В ПУТИ · GPS','WALKING · GPS','ЖОЛДА · GPS'):L('ОЖИДАЕМ GPS','WAITING FOR GPS','GPS КҮТЕМІЗ'):phase==='paused'?L('ПАУЗА · GPS ВЫКЛ.','PAUSED · GPS OFF','ҮЗІЛІС · GPS ӨШІРУЛІ'):phase==='visiting'?L('НА ОСТАНОВКЕ','AT YOUR STOP','АЯЛДАМАДА'):phase==='done'?L('ГОТОВО · GPS ВЫКЛ.','DONE · GPS OFF','ДАЙЫН · GPS ӨШІРУЛІ'):L('ТВОЯ ПРОГУЛКА','YOUR WALK','СЕНІҢ СЕРУЕНІҢ')}</span><button className={'walk-voice '+(voice?'enabled':'')} disabled={!voiceAvailable} aria-pressed={voice} aria-label={voice?L('Выключить голос','Turn voice off','Дауысты өшіру'):L('Включить голос','Turn voice on','Дауысты қосу')} onClick={()=>{if(voice){setVoice(false);cancelSpeech();}else{setVoiceError('');setVoice(true);speak(L('Голосовые подсказки включены.','Voice guidance is on.','Дауыстық нұсқаулар қосылды.'));}}}>{voice?<Volume2 size={21}/>:<VolumeX size={21}/>}</button></header>

    {['live','preview'].includes(phase)&&<div ref={instructionRef} className={'walk-instruction '+(qualityMessage?'walk-instruction-uncertain':'')} aria-live="polite"><span className="walk-direction-icon">{qualityMessage?<LocateFixed size={37}/>:<Icon size={39}/>}</span><div><small>{phase==='preview'?L('ШАГ ','STEP ','ҚАДАМ ')+(previewStep+1)+' / '+leg.instructions.length+' · '+walkDistance(cueDistance,language):distanceText}</small><h3>{title}</h3><p>{qualityMessage||target}</p></div></div>}
    {phase==='live'&&<button className={'walk-follow '+(follow?'following':'')} style={{top:`calc((${mapInsets.top}px + (100dvh - ${mapInsets.bottom}px)) / 2) - 23px)`}} disabled={!navPosition} onClick={()=>setFollow(true)} aria-label={L('Следовать за моей позицией','Follow my location','Менің орнымды қадағалау')}><LocateFixed size={22}/></button>}

    <div ref={bottomRef} className="walk-bottom">
      {phase==='done'?<div className="walk-complete"><span><Check size={29}/></span><h3>{L('Прогулка завершена.','Walk complete.','Серуен аяқталды.')}</h3><p>{L('GPS и голос выключены.','GPS and voice are off.','GPS пен дауыс өшірілді.')}</p><button className="primary-action" onClick={close}>{L('К маршрутам','Back to routes','Бағыттарға қайту')}<ArrowLeft size={18}/></button></div>:<>
        {phase==='intro'&&<><p className="walk-eyebrow">{L('ОТКРЫВАЙ ГОРОД ПО ПУТИ','DISCOVER THE CITY ON YOUR WAY','ЖОЛДА ҚАЛАНЫ ТАНЫ')}</p><h3 className="walk-intro-title">{L('Теперь — идём.','Now, let’s walk.','Енді — жүрейік.')}</h3><p className="walk-intro-text">{L('Повороты и остановки по пути. Если свернёшь — перестроим маршрут под оставшееся время до Б или обратно в А.','Turns and stops on your way. If you go off route, we replan for the time left to B or back to A.','Жолдағы бұрылыстар мен аялдамалар. Ауытқысаң, қалған уақытпен B-ге не A-ға қайту жолын өзгертеміз.')}</p></>}
        <div className="walk-goal"><span className="walk-goal-number">{leg.kind==='finish'?<Flag size={18}/>:index+1}</span><div><small>{leg.kind==='finish'?(destination?L('КОНЕЧНАЯ ТОЧКА Б','DESTINATION B','СОҢҒЫ B НҮКТЕСІ'):L('ВОЗВРАЩЕНИЕ В А','BACK TO A','A НҮКТЕСІНЕ ҚАЙТУ')):L('СЛЕДУЮЩАЯ ОСТАНОВКА','NEXT STOP','КЕЛЕСІ АЯЛДАМА')}</small><b>{target}</b></div><button onClick={()=>setDetail(targetStop)} disabled={!targetStop} aria-label={L('Данные об остановке','Stop details','Аялдама деректері')}><Info size={20}/></button></div>
        <div className="walk-stats"><span><Footprints size={15}/>{walkDistance(remaining,language)}<small>{phase==='live'&&update?L('до точки','to stop','нүктеге'):L('на участке','on this leg','осы бөлікте')}</small></span><span><Clock3 size={15}/>{Math.max(0,Math.ceil(remaining/70))} {L('мин','min','мин')}<small>{L('пешком ≈','walking ≈','жаяу ≈')}</small></span><span className={remainingMinutes<0?'walk-time-late':''}>{remainingMinutes>0?remainingMinutes+' '+L('мин','min','мин'):L('Время вышло','Time elapsed','Уақыт бітті')}<small>{L('в окне плана','in plan window','жоспар уақытында')}</small></span></div>
        {rerouteNotice&&<div className={'walk-reroute-notice '+(rerouteNotice.kind==='failed'||rerouteNotice.lateBy>0?'walk-reroute-warning':'')} role="status"><b>{rerouteNotice.kind==='failed'?L('Не удалось обновить путь','Could not update the route','Бағыт жаңармады'):rerouteNotice.lateBy>0?L('Идём прямо к финишу','Heading straight to the finish','Тікелей соңғы нүктеге'):L('Маршрут перестроен','Route updated','Бағыт өзгертілді')}</b><p>{rerouteNotice.kind==='failed'?L('Прежняя линия сохранена. Для пересчёта нужны точная свежая позиция и доступный пешеходный путь.','The previous line is kept. Rerouting needs a fresh accurate position and a connected walking path.','Бұрынғы сызық сақталды. Дәл жаңа орын мен жаяу жол қажет.'):rerouteNotice.lateBy>0?L('В срок уже не успеть: при пересчёте примерно +','The deadline no longer fits: about +','Уақытқа үлгеру мүмкін емес: есептеуде +')+rerouteNotice.lateBy+L(' мин. Новые остановки не добавляем.',' min at the last replan. No extra stops added.',' мин. Жаңа аялдама қоспаймыз.'):L('Финиш и исходный срок сохранены.','Your finish and original deadline are unchanged.','Соңғы нүкте мен бастапқы мерзім сақталды.')}</p>{rerouteNotice.removed.length>0&&<small>{L('Убрали из оставшегося пути: ','Removed from the remaining walk: ','Қалған жолдан алынды: ')}{rerouteNotice.removed.join(', ')}</small>}</div>}
        {phase==='live'&&status==='off-route'&&!rerouting&&<button className="walk-retry-route" disabled={!snapshot||snapshot.fix.accuracy>25||!fresh||retrySeconds>0} onClick={()=>{if(snapshot)void replan(snapshot.fix);}}><RotateCcw size={16}/>{retrySeconds>0?L('Повторить через ','Retry in ','Қайталау: ')+retrySeconds+L(' с',' s',' с'):L('Перестроить сейчас','Reroute now','Қазір қайта құру')}</button>}
        {(gpsError||voiceError)&&<p className="walk-error" role="status">{gpsError||voiceError}</p>}
        {(future||expiredBeforeStart)&&<p className="walk-error">{future?L('Этот план на другое время. Для прогулки сейчас поменяй время и пересчитай маршрут.','This plan is for a later departure. Change the time and rebuild to walk now.','Бұл жоспар басқа уақытқа арналған. Қазір жүру үшін уақытты өзгертіп, қайта есепте.'):L('Перед стартом обнови расчёт маршрута: время плана уже изменилось.','Refresh the route before starting: the plan time has changed.','Бастамас бұрын бағытты жаңарт: жоспар уақыты өзгерді.')}</p>}
        {phase==='visiting'?<><div className="walk-visit"><b>{L('Ты подтвердил остановку.','You confirmed this stop.','Аялдаманы растадың.')}</b><p>{targetStop?.activity}</p><small>{L('По плану на месте: ','Planned visit: ','Жоспардағы аялдау: ')}{targetStop?.visitMinutes} {L('мин','min','мин')}. {L('GPS сейчас выключен.','GPS is off now.','GPS қазір өшірулі.')}</small></div><button className="primary-action" onClick={continueWalk}><Play size={18}/>{L('Продолжить прогулку','Continue walking','Серуенді жалғастыру')}<ChevronRight size={18}/></button></>:phase==='preview'?<><div className="walk-preview-pager"><button onClick={()=>movePreview(-1)} disabled={previewLeg===0&&previewStep===0} aria-label={L('Предыдущий шаг','Previous step','Алдыңғы қадам')}><ChevronLeft size={21}/></button><span>{L('Участок ','Leg ','Бөлік ')}{previewLeg+1} / {goalCount}<small>{L('Это просмотр, не твоя GPS-позиция.','A preview, not your GPS position.','Бұл қарау, сенің GPS орның емес.')}</small></span><button onClick={()=>movePreview(1)} disabled={previewLeg===guide.legs.length-1&&previewStep===leg.instructions.length-1} aria-label={L('Следующий шаг','Next step','Келесі қадам')}><ChevronRight size={21}/></button></div><button className="primary-action" disabled={!canStart} onClick={startGPS}><LocateFixed size={18}/>{L('Начать с GPS','Start with GPS','GPS-пен бастау')}<Play size={18}/></button></>:phase==='live'?<><div className="walk-live-controls"><button onClick={pause}><Pause size={17}/>{L('Пауза','Pause','Үзіліс')}</button><button onClick={preview}><List size={17}/>{L('Шаги','Steps','Қадамдар')}</button><small>{snapshot?L('Точность ±','Accuracy ±','Дәлдігі ±')+Math.round(snapshot.fix.accuracy)+' '+L('м','m','м')+' · '+Math.max(0,Math.floor((tick-snapshot.fix.timestamp)/1000))+' '+L('с назад','s ago','с бұрын'):L('Запрашиваем геолокацию','Requesting location','Геолокация сұралады')}</small></div><button className="primary-action" disabled={!near} onClick={confirmArrival}><Check size={19}/>{leg.kind==='finish'?L('Завершить прогулку','Finish walk','Серуенді аяқтау'):L('Я на месте','I am here','Мен келдім')}<Flag size={18}/></button>{!near&&<p className="walk-arrival-hint">{L('Подтверждение станет доступно у точки при точном GPS.','Confirm when you are near the point with an accurate GPS fix.','Нүктеге жақындап, GPS дәл болғанда растауға болады.')}</p>}</>:<><button className="primary-action" disabled={!canStart} onClick={startGPS}><LocateFixed size={19}/>{phase==='paused'?L('Возобновить с GPS','Resume with GPS','GPS-пен жалғастыру'):L('Включить GPS и начать','Enable GPS and start','GPS қосып бастау')}<Play size={18}/></button><button className="walk-preview-link" onClick={preview}><List size={17}/>{L('Посмотреть шаги без GPS','Preview steps without GPS','Қадамдарды GPS-сіз қарау')}</button></>}
        <details className="walk-method"><summary>{L('Подсказки по линии OSM · что важно','OSM line guidance · details','OSM сызығы бойынша · маңыздысы')}</summary><p>{L('Повороты вычислены по геометрии пути. Входы, переходы и короткие подходы к местам не проверены на месте. Смотри на обстановку. При отклонении пересчёт работает в браузере: финиш и исходный срок сохраняются, не помещающиеся остановки убираются. GPS ведения не отправляется на API Qadam или в модель; история не сохраняется. При скрытии вкладки GPS останавливается. Голос использует возможности браузера.','Turns come from route geometry. Entrances, crossings and short venue connectors have not been checked on site. Check your surroundings. Off-route recalculation runs in the browser: the finish and original deadline stay fixed, stops that no longer fit are removed. Guidance GPS is not sent to Qadam API or the model; no history is saved. Hiding the tab stops GPS. Voice uses browser capabilities.','Бұрылыстар жол геометриясынан есептелген. Кіреберістер, өткелдер мен орындарға жақындау жергілікті тексерілмеген. Айналаға қара. Ауытқығанда браузерде қайта есептейміз: соңғы нүкте мен мерзім сақталады, уақытқа сыймаған аялдамалар алынады. GPS деректері Qadam API не модельге жіберілмейді; тарих сақталмайды. Қойынды жасырылса, GPS тоқтайды. Дауыс браузерге байланысты.')}</p></details>
      </>}
    </div>
    {detail&&<section className="walk-place-sheet" aria-label={L('Об остановке','About this stop','Аялдама туралы')}><button className="walk-close" onClick={()=>setDetail(null)} aria-label={L('Закрыть данные остановки','Close stop details','Аялдама деректерін жабу')}><X size={21}/></button><h3>{poiDisplayName(detail.poi,language)}</h3><p>{detail.why}</p><div className="walk-visit"><b>{L('Идея действия','Activity idea','Әрекет идеясы')}</b><p>{detail.observation||detail.activity}</p><small>{detail.visitMinutes} {L('мин на месте','min at this stop','мин аялдау')} · {detail.hoursStatus==='open'?L('По расписанию открыто','Open by listed hours','Кесте бойынша ашық'):L('Часы неизвестны','Hours unknown','Уақыты белгісіз')}</small></div><PlaceDiscovery facts={detail.facts??[]} language={language}/><div className="walk-place-links"><a href={detail.poi.sourceUrl} target="_blank" rel="noreferrer">OpenStreetMap<ExternalLink size={13}/></a><a href={publicMapLink(detail.poi,'2gis')} target="_blank" rel="noreferrer">2ГИС<ExternalLink size={13}/></a></div></section>}
  </section>;
}
