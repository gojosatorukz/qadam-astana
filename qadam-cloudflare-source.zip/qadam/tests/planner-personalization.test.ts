import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { planRoute } from '../lib/planner.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { createEmptyPassport, scoreLocalPOI } from '../lib/passport.ts';
import type { IntentContract } from '../lib/intent-types';
import type { PlanRequest, PlanResponse, POI } from '../lib/qadam-types';

const request: PlanRequest = {
  origin: { lat: 51.128, lon: 71.43, label: 'A' }, minutes: 45,
  query: 'alpha beta gamma', interests: [], language: 'en',
  indoor: false, knownHoursOnly: false, accessible: false,
  now: '2026-10-21T12:00:00+05:00',
};
const cafeIntent: IntentContract = {
  version: 1, desiredCategories: ['cafe'], excludedCategories: [],
  includeMode: 'any', unsupported: [], needsClarification: false,
};
function poi(index: number, overrides: Partial<POI> = {}): POI {
  const name = index === 1 ? 'Reviewed source' : `alpha beta gamma ${index}`;
  return {
    id: `osm-node-${index}`, name, lat: request.origin.lat, lon: request.origin.lon,
    category: 'cafe', description: '', tags: { amenity: 'cafe', name },
    openingHours: '24/7', website: null,
    sourceUrl: `https://www.openstreetmap.org/node/${index}`,
    fetchedAt: '2026-10-20T00:00:00Z', indoor: true, wheelchair: 'yes',
    ...overrides,
  };
}
const cafes = Array.from({ length: 20 }, (_, i) => poi(i + 1));
function dataset(pois: POI[]) {
  return { pois, fetchedAt: '2026-10-20T00:00:00Z', source: 'Controlled synthetic ranking fixture' };
}
function graph() {
  return new WalkingGraph({
    nodes: [[1, 51.128, 71.43], [2, 51.128, 71.432]], edges: [[1, 2, 140]],
  });
}
const quality = (place: POI) => place.id === cafes[0].id ? 2 : 1;
function selection(result: PlanResponse) {
  return { plan: result.plan, options: result.options, candidates: result.candidates, excluded: result.excluded };
}
function plans(result: PlanResponse) {
  return [result.plan, ...(result.options ?? []).map(option => option.plan)].filter(plan => plan !== null);
}

test('neutral, OFF and unrelated preferences preserve the reviewed-source baseline in a 20-café shortlist', () => {
  const unrelated = {
    ...createEmptyPassport(),
    placePreferences: { 'osm-node-999': { sentiment: 'liked' as const, rating: 5 as const, avoid: false } },
    interestWeights: { food: 3 },
  };
  const off = {
    ...unrelated, personalizationEnabled: false,
    placePreferences: { [cafes[0].id]: { sentiment: 'disliked' as const, rating: 1 as const, avoid: true } },
    interestWeights: { cafe: -3 },
  };
  // Exercise both bounded graph selection and the explicit-estimate branch.
  for (const routing of [undefined, graph()]) {
    const options = { routing, intent: cafeIntent, retrievalQuality: quality, withAlternatives: true };
    const baseline = planRoute(request, dataset(cafes), options);
    assert.equal(baseline.plan?.stops[0].poi.id, cafes[0].id);
    for (const personalScore of [
      () => 0,
      (place: POI) => scoreLocalPOI(place, createEmptyPassport()),
      (place: POI) => scoreLocalPOI(place, off),
      (place: POI) => scoreLocalPOI(place, unrelated),
      () => Number.NaN,
      () => { throw new Error('Optional local preference unavailable'); },
    ]) {
      assert.deepEqual(selection(planRoute(request, dataset(cafes), { ...options, personalScore })), selection(baseline));
    }
  }
});

test('bounded positive and negative scores still change comparable valid café choices', () => {
  for (const routing of [undefined, graph()]) {
    const input = dataset(cafes.slice(1));
    const options = { routing, intent: cafeIntent, retrievalQuality: () => 1 };
    const baseline = planRoute(request, input, options);
    assert.equal(baseline.plan?.stops[0].poi.id, 'osm-node-10');
    const liked = planRoute(request, input, { ...options, personalScore: (place: POI) => place.id === 'osm-node-20' ? 6 : 0 });
    assert.equal(liked.plan?.stops[0].poi.id, 'osm-node-20');
    const disliked = planRoute(request, input, { ...options, personalScore: (place: POI) => place.id === 'osm-node-10' ? -6 : 0 });
    assert.notEqual(disliked.plan?.stops[0].poi.id, 'osm-node-10');
    assert.ok(disliked.plan && liked.plan && disliked.plan.totalMinutes <= request.minutes && liked.plan.totalMinutes <= request.minutes);
    const clamped = planRoute(request, input, { ...options, personalScore: (place: POI) => place.id === 'osm-node-20' ? 1000 : 0 });
    assert.deepEqual(selection(clamped), selection(liked));
  }
});

test('personal preference cannot crowd out stronger source quality even with lexical overlap and extreme scores', () => {
  for (const routing of [undefined, graph()]) {
    const result = planRoute(request, dataset(cafes), {
      routing, intent: cafeIntent, retrievalQuality: quality,
      personalScore: (place: POI) => place.id === cafes[0].id ? -1000 : 1000,
    });
    assert.equal(result.plan?.stops[0].poi.id, cafes[0].id);
  }
});

test('positive preferences cannot bypass hours, indoor, accessibility, exclusions or a required POI', () => {
  const input = dataset([
    poi(1), poi(2), poi(3, { indoor: false }), poi(4, { wheelchair: null }),
    poi(5, { openingHours: null }), poi(6, { openingHours: 'Mo-Su 20:00-21:00' }),
    poi(7), poi(8, { lat: 51.3, lon: 71.7 }),
  ]);
  const base = { ...request, indoor: true, accessible: true, knownHoursOnly: true, excludePoiIds: ['osm-node-7'] };
  for (const routing of [undefined, graph()]) {
    const options = { routing, intent: cafeIntent, withAlternatives: true,
      personalScore: (place: POI) => ['osm-node-1', 'osm-node-2'].includes(place.id) ? -6 : 1000 };
    const result = planRoute(base, input, options);
    assert.ok(result.plan);
    assert.ok(plans(result).every(plan => plan.totalMinutes <= base.minutes && plan.stops.every(stop => ['osm-node-1', 'osm-node-2'].includes(stop.poi.id))));
    const required = planRoute({ ...base, requiredPoiId: 'osm-node-1' }, input, options);
    assert.ok(plans(required).length);
    assert.ok(plans(required).every(plan => plan.stops.some(stop => stop.poi.id === 'osm-node-1')));
    const excludedRequired = planRoute({ ...base, requiredPoiId: 'osm-node-7' }, input, options);
    assert.equal(excludedRequired.plan, null);
  }
});

test('personal scores retain all-category coverage and cannot revive a forbidden category', () => {
  const input = dataset([poi(1), poi(2, { category: 'park', tags: { leisure: 'park', name: 'Park' } })]);
  const all: IntentContract = { ...cafeIntent, desiredCategories: ['cafe', 'park'], includeMode: 'all' };
  for (const routing of [undefined, graph()]) {
    const options = { routing, intent: all, personalScore: (place: POI) => place.category === 'cafe' ? 1000 : -1000 };
    const result = planRoute({ ...request, minutes: 90 }, input, options);
    assert.deepEqual(result.plan?.stops.map(stop => stop.poi.category).sort(), ['cafe', 'park']);
    assert.ok(result.plan && result.plan.totalMinutes <= 90);
    const excluded = planRoute({ ...request, minutes: 90 }, input, {
      ...options, intent: { ...all, excludedCategories: ['cafe'] },
    });
    assert.deepEqual(excluded.plan?.stops.map(stop => stop.poi.category), ['park']);
  }
});
