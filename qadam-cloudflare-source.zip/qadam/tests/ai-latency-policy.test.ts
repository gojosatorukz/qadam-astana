import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS execution uses explicit source extensions.
import { interpretIntent } from '../lib/intent.ts';
// @ts-expect-error Native Node TS execution uses explicit source extensions.
import { fastThinkingConfig, INTENT_PROVIDER_TIMEOUT_MS, INTENT_TRANSPORT_TIMEOUT_MS, PLAN_MODEL_TIMEOUT_MS, ENRICHMENT_TIMEOUT_MS, PLAN_RPC_TIMEOUT_MS } from '../lib/ai-policy.ts';
import type { PlanRequest } from '../lib/qadam-types';

const request: PlanRequest = { query: 'a park without coffee', origin: { lat: 51.12828, lon: 71.43055, label: 'Public landmark' }, minutes: 45, interests: [], indoor: false, knownHoursOnly: false, accessible: false, language: 'en' };
const value = { version: 1, desiredCategories: ['park'], excludedCategories: ['cafe'], includeMode: 'any', unsupported: [], needsClarification: false };

test('a valid 12.5-second provider response survives the former 6.5-second cutoff with exclusions intact', async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  let signal: AbortSignal | undefined;
  const result = interpretIntent(request, { apiKey: 'synthetic-test-key', model: 'gemini-3.5-flash', fetcher: async (_url, init) => {
    signal = init?.signal ?? undefined;
    await new Promise(resolve => setTimeout(resolve, 12_500));
    return new Response(JSON.stringify({ candidates: [{ finishReason: 'STOP', content: { parts: [{ text: JSON.stringify(value) }] } }] }));
  } });
  await new Promise(resolve => setImmediate(resolve));
  t.mock.timers.tick(12_500);
  const resolution = await result;
  assert.equal(signal?.aborted, false);
  assert.equal(resolution.mode, 'gemini');
  assert.deepEqual(resolution.contract?.excludedCategories, ['cafe']);
  assert.deepEqual(resolution.contract?.desiredCategories, ['park']);
});

test('cold-start and transport deadlines cannot pre-empt the provider; explanations have a separate small cap', () => {
  assert.ok(INTENT_PROVIDER_TIMEOUT_MS < INTENT_TRANSPORT_TIMEOUT_MS);
  assert.ok(INTENT_TRANSPORT_TIMEOUT_MS + ENRICHMENT_TIMEOUT_MS < PLAN_MODEL_TIMEOUT_MS);
  assert.ok(PLAN_MODEL_TIMEOUT_MS + 5_000 + 5_000 < PLAN_RPC_TIMEOUT_MS);
  assert.deepEqual(fastThinkingConfig('gemini-3.6-flash'), { thinkingConfig: { thinkingLevel: 'MINIMAL' } });
  assert.deepEqual(fastThinkingConfig('gemini-2.5-flash-lite'), {});
  assert.deepEqual(fastThinkingConfig('custom-provider'), {});
});

test('a temporary HTTP503 can recover once with the identical closed input and no provider details leaked', async () => {
  let calls = 0; const bodies: string[] = [];
  const result = await interpretIntent(request, { apiKey: 'synthetic-key', fetcher: async (_url, init) => {
    bodies.push(String(init?.body));
    if (++calls === 1) return new Response('private capacity details', { status: 503 });
    return new Response(JSON.stringify({ candidates: [{ finishReason: 'STOP', content: { parts: [{ text: JSON.stringify(value) }] } }] }));
  } });
  assert.equal(calls, 2);
  assert.equal(bodies[0], bodies[1]);
  assert.equal(result.mode, 'gemini');
  assert.deepEqual(result.contract?.excludedCategories, ['cafe']);
  assert.ok(!JSON.stringify(result).includes('private'));
});

test('persistent HTTP503 gets at most two attempts, and rate limits never trigger a retry', async () => {
  for (const status of [503, 429]) {
    let calls = 0;
    const result = await interpretIntent(request, { apiKey: 'synthetic-key', fetcher: async () => { calls++; return new Response('private detail', { status }); } });
    assert.equal(calls, status === 503 ? 2 : 1);
    assert.equal(result.failure, status === 429 ? 'quota' : 'provider');
    assert.equal(result.contract, null);
  }
});

test('a retry cannot reset the deadline or launch after its parent deadline has expired', async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  let calls = 0;
  const pending = interpretIntent(request, { apiKey: 'synthetic-key', totalTimeoutMs: 50, fetcher: async () => { calls++; return new Response('', { status: 503 }); } });
  await new Promise(resolve => setImmediate(resolve));
  t.mock.timers.tick(151);
  const result = await pending;
  assert.equal(calls, 1);
  assert.equal(result.failure, 'timeout');
  assert.equal(result.contract, null);
});
