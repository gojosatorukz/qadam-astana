import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { createWalkGuide, createGuideProgress, updateWalkGuide, confirmGuideLeg, validLegEndIndices } from '../lib/walk-guide.ts';
import type { SupportedWalkGuide, GuidePoint, GuideProgress } from '../lib/walk-guide';
import type { RoutePlan, PlanStop, PlanRequest, POI } from '../lib/qadam-types';
// @ts-expect-error Native Node TS source extensions.
import { planRoute } from '../lib/planner.ts';
// @ts-expect-error Native Node TS source extensions.
import { isPlanResponse, planSemanticsValid } from '../lib/plan-validation.ts';
// @ts-expect-error Native Node TS source extensions.
import { isPlanResponse as isClientPlanResponse } from '../lib/experience.ts';
// @ts-expect-error Native Node TS source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';

const A:GuidePoint=[71.43,51.128],NOW=1_800_000_000_000;
const point=(east:number,north:number):GuidePoint=>[A[0]+east/(111_195*Math.cos(A[1]*Math.PI/180)),A[1]+north/111_195];
const stop=(p:GuidePoint,id='one'):PlanStop=>({poi:{id,name:`Stop ${id}`,lon:p[0],lat:p[1],category:'park',description:'',tags:{},openingHours:null,website:null,sourceUrl:'https://www.openstreetmap.org/node/1',fetchedAt:'2026-10-20T00:00:00Z',indoor:null,wheelchair:null},visitMinutes:12,travelMinutes:1,why:'',activity:'',hoursStatus:'unknown'});
function guide(points:GuidePoint[],stops:GuidePoint[]=[points.at(-1)!]):SupportedWalkGuide {
 const output=createWalkGuide({routeKind:'walking',routeCoordinates:points,stops:stops.map((p,i)=>stop(p,String(i)))});assert.ok(output.supported);return output;
}
const fix=(p:GuidePoint,t=NOW,accuracy=5)=>({lon:p[0],lat:p[1],timestamp:t,accuracy});
const update=(g:SupportedWalkGuide,s:GuideProgress,p:GuidePoint,t=NOW,accuracy=5)=>updateWalkGuide(g,s,fix(p,t,accuracy),{nowMs:t});
const corners=(g:SupportedWalkGuide)=>g.legs[0].instructions.filter(i=>!['start','straight','arrive'].includes(i.kind));

test('compass turn sign yields left to north and right to south at exact large corners',()=>{
 const left=guide([A,point(100,0),point(100,100)]),right=guide([A,point(100,0),point(100,-100)]);
 assert.equal(corners(left).length,1);assert.equal(corners(right).length,1);assert.equal(corners(left)[0].kind,'left');assert.equal(corners(right)[0].kind,'right');
 assert.ok(corners(left)[0].turnDegrees<-80);assert.ok(corners(right)[0].turnDegrees>80);assert.ok(Math.abs(corners(left)[0].atMeters-100)<1);
 assert.deepEqual(corners(left)[0].point,point(100,0));
});
test('gradual bear directions and U-turns remain closed geometric instructions',()=>{
 const left=guide([A,point(100,0),point(180,60)]),right=guide([A,point(100,0),point(180,-60)]);
 assert.ok(corners(left).some(i=>i.kind==='bear-left'));assert.ok(corners(right).some(i=>i.kind==='bear-right'));
 const uturn=guide([A,point(100,0),A],[point(100,0)]);assert.equal(uturn.legs.length,2);
 const sameLeg=guide([A,point(100,0),A,point(-100,0)]);assert.ok(corners(sameLeg).some(i=>i.kind==='u-turn'));
});
test('tiny noisy vertices, duplicate coordinates and gentle curves do not spam turns',()=>{
 const noisy:GuidePoint[]=Array.from({length:2000},(_,i)=>point(i*0.1,Math.sin(i)*0.05));const flat=guide([A,A,...noisy,noisy.at(-1)!]);assert.equal(corners(flat).length,0);assert.ok(flat.legs[0].coordinates.length<100);
 const curve=guide(Array.from({length:200},(_,i)=>point(800*Math.sin(i/199*Math.PI/4),800*(1-Math.cos(i/199*Math.PI/4)))));assert.ok(corners(curve).length<=1);
});
test('each required stop anchors its own leg and the final endpoint is the last vertex',()=>{
 const S=point(100,0),T=point(100,100),B=point(200,100),g=guide([A,S,T,B],[S,T]);assert.equal(g.legs.length,3);
 assert.deepEqual(g.legs.map(l=>l.kind),['stop','stop','finish']);assert.deepEqual(g.legs.map(l=>l.coordinates.at(-1)),[S,T,B]);assert.deepEqual(g.legs[1].coordinates[0],S);assert.deepEqual(g.legs[2].coordinates[0],T);
});
test('outgoing and returning overlap cannot advance another leg or finish at A',()=>{
 const S=point(100,0),g=guide([A,point(50,0),S,point(50,0),A],[S]);let state=createGuideProgress();
 const start=update(g,state,A);assert.equal(start.status,'tracking');assert.equal(start.state.legIndex,0);assert.equal(start.canConfirmArrival,false);assert.ok(start.remainingGuideMeters>190);
 state=start.state;
 for(let x=10;x<=100;x+=10)state=update(g,state,point(x,0),NOW+x*1000).state;
 const near=update(g,state,S,NOW+101000);assert.equal(near.canConfirmArrival,true);assert.equal(near.state.legIndex,0);
 const next=confirmGuideLeg(g,near.state);assert.equal(next.legIndex,1);assert.equal(next.meters,0);
 const wrongStart=update(g,next,A,NOW+102000);assert.equal(wrongStart.canConfirmArrival,false);assert.equal(wrongStart.state.legIndex,1);assert.ok(wrongStart.state.meters<40);
 let back=update(g,next,S,NOW+103000).state;for(let x=90;x>=0;x-=10)back=update(g,back,point(x,0),NOW+(204-x)*1000).state;
 const end=update(g,back,A,NOW+205000);assert.equal(end.canConfirmArrival,true);assert.equal(end.status,'tracking');assert.equal(end.state.legIndex,1);
 const confirmed=confirmGuideLeg(g,end.state);assert.equal(confirmed.legIndex,2);assert.equal(update(g,confirmed,A,NOW+206000).status,'finished');
});
test('overlap within one leg chooses earlier progress instead of jumping to a later loop',()=>{
 const g=guide([A,point(100,0),A,point(-100,0)]);const first=update(g,createGuideProgress(),A);assert.equal(first.state.meters,0);assert.equal(first.canConfirmArrival,false);
 const projected=update(g,first.state,point(10,0),NOW+10000);assert.ok(projected.state.meters<12);assert.ok(projected.state.segmentIndex<g.legs[0].coordinates.length-2);
});
test('bad GPS values, poor accuracy, stale and excessive future fixes preserve progress',()=>{
 const g=guide([A,point(100,0)]),state=update(g,createGuideProgress(),point(10,0)).state;
 for(const [bad,status] of [[{...fix(point(90,0)),lat:NaN},'invalid-fix'],[{...fix(A),lon:181},'invalid-fix'],[{...fix(A),accuracy:-1},'invalid-fix'],[{...fix(A),timestamp:Infinity},'invalid-fix'],[fix(point(90,0),NOW+1,80),'poor-accuracy'],[fix(point(90,0),NOW-21000),'stale-fix'],[fix(point(90,0),NOW+5001),'stale-fix']] as const){
  const result=updateWalkGuide(g,state,bad,{nowMs:NOW});assert.equal(result.status,status);assert.deepEqual(result.state,state);assert.equal(result.canConfirmArrival,false);
 }
});
test('off-route status uses accuracy without rerouting or teleporting along the route',()=>{
 const g=guide([A,point(200,0)]),state=update(g,createGuideProgress(),A).state;
 const off=update(g,state,point(10,100),NOW+1000);assert.equal(off.status,'off-route');assert.deepEqual(off.state,state);assert.equal(off.canConfirmArrival,false);
 const allowance=update(g,state,point(5,35),NOW+1000,25);assert.equal(allowance.status,'tracking');assert.equal(allowance.canConfirmArrival,false);
 const distant=update(g,state,point(190,0),NOW+1000);assert.equal(distant.status,'off-route');assert.equal(distant.state.meters,0);
});
test('projection is monotonic under backward jitter and reports arc distance, not a crow-flight shortcut',()=>{
 const g=guide([A,point(100,0),point(100,100)]);let state=update(g,createGuideProgress(),A).state;
 for(let x=10;x<=70;x+=10)state=update(g,state,point(x,0),NOW+x*1000).state;
 const jitter=update(g,state,point(63,0),NOW+71000);assert.equal(jitter.status,'tracking');assert.ok(jitter.state.meters>=state.meters);assert.ok(jitter.remainingMeters>120);
 assert.ok(jitter.nextInstruction);assert.ok(jitter.distanceToInstruction>=0);
});
test('a zero-distance terminal leg remains an explicit confirmable boundary',()=>{
 const B=point(50,0),g=guide([A,B],[B]);assert.equal(g.legs.length,2);assert.equal(g.legs[1].totalMeters,0);assert.deepEqual(g.legs[1].coordinates,[B]);
 let state=createGuideProgress();for(let x=0;x<=50;x+=10)state=update(g,state,point(x,0),NOW+x*1000).state;
 const next=confirmGuideLeg(g,state);const terminal=update(g,next,B,NOW+51000);assert.equal(terminal.canConfirmArrival,true);assert.equal(terminal.status,'tracking');assert.equal(terminal.state.legIndex,1);
 assert.equal(confirmGuideLeg(g,terminal.state).legIndex,2);
});
test('estimate, degenerate or missing-anchor geometry is unsupported instead of fabricating a turn',()=>{
 const source={routeKind:'walking' as const,routeCoordinates:[A,point(100,0)],stops:[stop(point(50,50))]};assert.deepEqual(createWalkGuide(source),{supported:false,reason:'missing-stop-anchor'});
 assert.deepEqual(createWalkGuide({...source,routeKind:'estimate'}),{supported:false,reason:'estimate-route'});
 assert.deepEqual(createWalkGuide({...source,routeCoordinates:[A,A],stops:[stop(A)]}),{supported:false,reason:'invalid-geometry'});
 assert.deepEqual(createWalkGuide({...source,routeCoordinates:[A,point(1,0),A],stops:[stop(A)],legEndIndices:[0,2]}),{supported:false,reason:'invalid-geometry'});
 const outside={...source,routeCoordinates:[[181,51],A] as GuidePoint[]};assert.deepEqual(createWalkGuide(outside),{supported:false,reason:'invalid-geometry'});
});
test('dense geometry and progress use compact distance indexes with bounded instruction sampling',()=>{
 const dense=Array.from({length:100000},(_,i)=>point(i*0.01,0)),g=guide(dense);assert.ok(g.legs[0].coordinates.length<500);assert.equal(g.legs[0].cumulativeMeters.length,g.legs[0].coordinates.length);assert.ok(g.legs[0].instructions.length<5);
 const snapshot=JSON.stringify(g);const state=createGuideProgress();const updateResult=update(g,state,point(10,0));assert.ok(updateResult.state.meters<15);assert.equal(JSON.stringify(g),snapshot);assert.deepEqual(state,createGuideProgress());
});

test('explicit leg boundaries survive self-crossing passes before the intended visit',()=>{
 const S=point(100,0),T=point(100,100),B=point(200,0),coordinates=[A,S,T,S,T,B],stops=[stop(S,'S'),stop(T,'T')];
 const raw={routeKind:'walking' as const,routeCoordinates:coordinates,stops};
 assert.deepEqual(createWalkGuide(raw),{supported:false,reason:'ambiguous-stop-anchor'});
 const exact=createWalkGuide({...raw,legEndIndices:[3,4,5]});assert.ok(exact.supported);
 assert.ok(exact.legs[0].totalMeters>290);assert.deepEqual(exact.legs[0].coordinates.at(-1),S);assert.ok(exact.legs[0].coordinates.some(p=>p[0]===T[0]&&p[1]===T[1]));
 assert.deepEqual(exact.legs[1].coordinates,[S,T]);assert.deepEqual(exact.legs[2].coordinates,[T,B]);
 const early=update(exact,createGuideProgress(),T);assert.equal(early.canConfirmArrival,false);assert.equal(early.state.legIndex,0);
});
test('explicit boundary validation rejects tampering but allows equal zero-leg indices',()=>{
 const S=point(100,0),points=[A,S,S],stops=[stop(S)];assert.ok(validLegEndIndices(points,stops,[1,2]));assert.ok(validLegEndIndices([A,S],stops,[1,1]));
 for(const indices of [[],[1],[0,2],[1,1],[2,1],[-1,2],[1.5,2],[1,3],['1',2]])assert.equal(validLegEndIndices(points,stops,indices),false,JSON.stringify(indices));
 assert.ok(validLegEndIndices(points,stops,undefined));
});
test('planner publishes exact leg boundaries, including a true zero final leg at B',()=>{
 const B=point(100,0),venue:POI={...stop(B).poi,category:'food',tags:{amenity:'restaurant',name:'Meal'},openingHours:'24/7'};
 const request:PlanRequest={query:'',origin:{lat:A[1],lon:A[0],label:'A'},destination:{lat:B[1],lon:B[0],label:'B'},minutes:45,interests:['food'],indoor:false,knownHoursOnly:false,accessible:false,language:'en',now:'2026-10-20T12:00:00+05:00'};
 // B snaps to a node 5 m away. A coincident final stop must not invent an out-and-back connector.
 const routing=new WalkingGraph({nodes:[[1,A[1],A[0]],[2,B[1]+0.00005,B[0]]],edges:[[1,2,100]]}),dataset={pois:[venue],fetchedAt:venue.fetchedAt,source:'Synthetic OSM-like source'};
 const intent={version:1 as const,desiredCategories:['food' as const],excludedCategories:[],includeMode:'any' as const,unsupported:[],needsClarification:false};
 const response=planRoute(request,dataset,{routing,intent,withAlternatives:true});assert.ok(response.plan);const plan=response.plan;
 assert.equal(plan.returnMinutes,0);assert.equal(plan.legEndIndices?.length,2);assert.equal(plan.legEndIndices![0],plan.legEndIndices![1]);assert.equal(plan.legEndIndices![1],plan.routeCoordinates.length-1);assert.ok(planSemanticsValid(response,request,dataset,intent));
 const exact=createWalkGuide(plan);assert.ok(exact.supported);assert.equal(exact.legs[1].totalMeters,0);
 for(const indices of [[0,plan.routeCoordinates.length-1],[1],[1.5,plan.routeCoordinates.length-1]]){
  const tampered={...response,plan:{...plan,legEndIndices:indices}};assert.equal(isPlanResponse(tampered),false);assert.equal(isClientPlanResponse(tampered),false);assert.equal(planSemanticsValid(tampered,request,dataset,intent),false);
 }
});

test('replaying the same cached GPS timestamp cannot repeatedly advance toward arrival',()=>{
 const g=guide([A,point(70,0)]),cached=fix(point(65,0),NOW,20);
 const first=updateWalkGuide(g,createGuideProgress(),cached,{nowMs:NOW});assert.equal(first.status,'tracking');assert.ok(first.state.meters<40);assert.equal(first.canConfirmArrival,false);
 for(let replay=1;replay<=5;replay++){
  const repeated=updateWalkGuide(g,first.state,cached,{nowMs:NOW+replay*1000});assert.equal(repeated.status,'stale-fix');assert.deepEqual(repeated.state,first.state);assert.equal(repeated.canConfirmArrival,false);
 }
});

test('a reroute with no remaining venue still guides the complete final leg',()=>{
 const points=[A,point(100,0),point(100,100)];
 const direct=createWalkGuide({routeKind:'walking',routeCoordinates:points,stops:[],legEndIndices:[2]});
 assert.ok(direct.supported);assert.equal(direct.legs.length,1);assert.equal(direct.legs[0].kind,'finish');
 assert.deepEqual(direct.legs[0].coordinates.at(-1),point(100,100));assert.ok(corners(direct).some(c=>c.kind==='left'));
 assert.equal(update(direct,createGuideProgress(),A).canConfirmArrival,false);
});
test('already at the final endpoint after rerouting requires explicit finish confirmation',()=>{
 const direct=createWalkGuide({routeKind:'walking',routeCoordinates:[A,A],stops:[],legEndIndices:[1]});
 assert.ok(direct.supported);const observed=update(direct,createGuideProgress(),A);
 assert.equal(observed.status,'tracking');assert.equal(observed.canConfirmArrival,true);assert.equal(observed.state.legIndex,0);
 assert.equal(confirmGuideLeg(direct,observed.state).legIndex,1);
});
