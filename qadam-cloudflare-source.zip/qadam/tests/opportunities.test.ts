import assert from'node:assert/strict';
import test from'node:test';
import{readFile}from'node:fs/promises';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{createOpportunityEngine,isOpportunityResult}from'../lib/opportunities.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{WalkingGraph}from'../lib/walking-graph.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{planRoute,categoriesOf,visitRange,openingHoursStatus}from'../lib/planner.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{manualIntent}from'../lib/intent.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{applyPlaceFacts}from'../lib/place-facts.ts';
import type{OpportunityRequest}from'../lib/opportunities';
import type{POI}from'../lib/qadam-types';
import type{POIDataset}from'../lib/planner';
import type{RawWalkingGraph}from'../lib/walking-graph';

const at=new Date('2026-10-20T07:00:00Z');
const base:OpportunityRequest={origin:{lat:51.128,lon:71.43,label:'A'},minutes:45,interests:[],indoor:false,knownHoursOnly:false,accessible:false,language:'en',departureAt:at.toISOString()};
const poi=(id:string,lon=71.432,category='food',extra:Partial<POI>={}):POI=>({id,name:id,lat:51.128,lon,category,tags:{amenity:category==='food'?'restaurant':category},description:'Source record',openingHours:'24/7',website:null,sourceUrl:'https://www.openstreetmap.org/node/1',fetchedAt:at.toISOString(),indoor:true,wheelchair:'yes',...extra});
const snapshot=(pois:POI[]):POIDataset=>({pois,source:'OpenStreetMap',fetchedAt:at.toISOString()});
class CountedGraph extends WalkingGraph{searchCalls=0;override search(source:number,steps:boolean){this.searchCalls++;return super.search(source,steps);}}
const graph=()=>new CountedGraph({nodes:[[1,51.128,71.43],[2,51.128,71.432],[3,51.128,71.434]],edges:[[1,2,140],[2,3,140]]});

test('single-stop feasibility matches canonical minimum times, never drops final B, and reuses endpoint trees',()=>{
 const routing=graph(),data=snapshot([poi('food'),poi('coffee',71.434,'cafe'),poi('park',71.43,'park')]),engine=createOpportunityEngine(data,routing),request={...base,destination:{lat:51.128,lon:71.434,label:'B'}};
 let previous:string[]=[];
 for(const minutes of [20,30,45,60]){
  const result=engine.compute({...request,minutes},at);assert.ok(isOpportunityResult(result));assert.equal(result.kind,'ready');assert.equal(result.diagnostics.searches,2);assert.ok(previous.every(id=>result.places.some(place=>place.poi.id===id)));previous=result.places.map(place=>place.poi.id);
  for(const place of result.places){assert.equal(place.totalMinutes,place.outboundMinutes+place.finalLegMinutes+visitRange(place.poi).minimum+place.bufferMinutes);assert.ok(place.totalMinutes<=minutes);const canonicalRequest={...request,minutes,query:'',now:at.toISOString(),localOnly:true};const canonical=planRoute(canonicalRequest,snapshot([place.poi]),{routing:graph(),intent:manualIntent(canonicalRequest)});assert.ok(canonical.plan);assert.equal(place.walkingMinutes,canonical.plan.walkingMinutes);assert.equal(place.bufferMinutes,canonical.plan.bufferMinutes);assert.equal(place.distanceMeters,canonical.plan.distanceMeters);assert.deepEqual(canonical.plan.routeCoordinates.at(-1),[request.destination.lon,request.destination.lat]);}
 }
 assert.equal(routing.searchCalls,2,'dragging the budget does not run more Dijkstra trees');
 const refreshed=engine.compute({...request,minutes:60,interests:['food']},at);assert.equal(refreshed.diagnostics.contextReused,true);assert.equal(routing.searchCalls,2);assert.ok(refreshed.places.every(place=>place.poi.category==='food'));assert.equal(refreshed.places[0].finalLegMinutes,2);
});
test('real visit hours and all hard filters apply to the entire minimum visit',()=>{
 const data=snapshot([poi('meal'),poi('closed',71.432,'food',{openingHours:'12:00-12:18'}),poi('unknown',71.432,'food',{openingHours:null}),poi('outdoor',71.432,'food',{indoor:null}),poi('access-unverified',71.432,'food',{wheelchair:null}),poi('coffee',71.432,'cafe')]);
 const engine=createOpportunityEngine(data,graph());
 const all=engine.compute({...base,interests:['food']},at);assert.ok(all.places.some(p=>p.poi.id==='unknown'));assert.ok(!all.places.some(p=>['coffee','closed'].includes(p.poi.id)));
 const strict=engine.compute({...base,interests:['food'],indoor:true,knownHoursOnly:true,accessible:true},at);assert.deepEqual(strict.places.map(p=>p.poi.id),['meal']);assert.equal(strict.places[0].visitMinutes,20);assert.equal(strict.places[0].hoursStatus,'open');
 assert.equal(engine.compute({...base,interests:['shopping']},at).reason,'invalid-request');
});
test('no estimates or feasible dots are produced outside snapshot, missing coverage or disconnected endpoints',()=>{
 const engine=createOpportunityEngine(snapshot([poi('meal')]),graph());
 assert.equal(engine.compute({...base,origin:{lat:51.3,lon:71.43,label:'outside'}},at).reason,'outside-coverage');
 assert.equal(engine.compute({...base,origin:{lat:51.19,lon:71.5,label:'no graph'}},at).reason,'network-unavailable');
 const disconnected=new WalkingGraph({nodes:[[1,51.128,71.43],[2,51.128,71.432],[3,51.14,71.46],[4,51.14,71.462]],edges:[[1,2,140],[3,4,140]]});
 const result=createOpportunityEngine(snapshot([poi('meal')]),disconnected).compute({...base,destination:{lat:51.14,lon:71.46,label:'B'}},at);assert.equal(result.reason,'endpoint-disconnected');assert.deepEqual(result.places,[]);
});
test('accessible mode removes step edges and reviewed duplicate places remain one source choice',()=>{
 const routing=new WalkingGraph({nodes:[[1,51.128,71.43],[2,51.128,71.432],[3,51.128,71.434]],edges:[[1,2,140],[2,3,140]],stepEdges:[1]});
 const data=snapshot([poi('meal',71.434),poi('osm-way-1381418247',71.432,'museum',{tags:{tourism:'museum'}}),poi('osm-node-4894937300',71.432,'museum',{tags:{tourism:'museum',name:'Named source'}})]),engine=createOpportunityEngine(data,routing);
 assert.ok(engine.compute(base,at).places.some(p=>p.poi.id==='meal'));assert.ok(!engine.compute({...base,accessible:true},at).places.some(p=>p.poi.id==='meal'));
 const museums=engine.compute({...base,interests:['museum']},at);assert.equal(museums.places.length,1);assert.equal(museums.places[0].poi.id,'osm-node-4894937300');
});
test('actual 1204-place corpus supports nested budgets for A return and optional B without new searches',async()=>{
 const [rawPois,rawGraph]=await Promise.all([readFile(new URL('../data/poi.json',import.meta.url),'utf8'),readFile(new URL('../data/walk-graph.json',import.meta.url),'utf8')]);
 const data=applyPlaceFacts(JSON.parse(rawPois)as POIDataset),routing=new CountedGraph(JSON.parse(rawGraph)as RawWalkingGraph),engine=createOpportunityEngine(data,routing);assert.equal(data.pois.length,1204);
 const museum=data.pois.find(p=>p.id==='osm-node-4894937300')!;
 for(const destination of [undefined,{lat:museum.lat,lon:museum.lon,label:'B'}]){
  let ids:string[]=[];const searchesBefore=routing.searchCalls;
  for(const minutes of [30,45,90]){
   const request={...base,destination,minutes,interests:['food']},result=engine.compute(request,at);assert.ok(isOpportunityResult(result));assert.equal(result.kind,'ready');assert.ok(ids.every(id=>result.places.some(p=>p.canonicalId===id)));ids=result.places.map(p=>p.canonicalId);
   for(const p of result.places){assert.ok(categoriesOf(p.poi).includes('food'));assert.equal(p.visitMinutes,20);assert.ok(p.totalMinutes<=minutes);assert.equal(p.walkingMinutes,p.outboundMinutes+p.finalLegMinutes);assert.notEqual(openingHoursStatus(p.poi.openingHours,new Date(at.getTime()+p.outboundMinutes*60_000),p.visitMinutes),'closed');}
  }
  assert.ok(ids.length>=4);assert.ok(routing.searchCalls-searchesBefore<=2);
 }
});
test('worker-result guard rejects missing POIs, altered totals and unbounded diagnostics safely',()=>{
 const result=createOpportunityEngine(snapshot([poi('meal')]),graph()).compute(base,at);assert.ok(isOpportunityResult(result));
 for(const bad of [{...result,places:[{...result.places[0],poi:null}]},{...result,places:[{...result.places[0],totalMinutes:1}]},{...result,diagnostics:{...result.diagnostics,searches:NaN}},{...result,diagnostics:{...result.diagnostics,searches:3}}])assert.equal(isOpportunityResult(bad),false);
});

test('past or invalid departure never produces feasible places; now and future still work',()=>{
 const engine=createOpportunityEngine(snapshot([poi('meal')]),graph());
 for(const departureAt of ['2026-10-19T07:00:00Z','invalid']){
  const result=engine.compute({...base,departureAt},at);assert.equal(result.kind,'unavailable');assert.equal(result.reason,'invalid-request');assert.equal(result.places.length,0);assert.equal(result.diagnostics.searches,0);
 }
 assert.equal(engine.compute({...base,departureAt:undefined},at).kind,'ready');
 assert.equal(engine.compute({...base,departureAt:'2026-10-20T08:00:00Z'},at).kind,'ready');
});
