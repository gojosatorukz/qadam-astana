import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Native Node TypeScript requires the explicit source extension.
import { intentClarification } from '../lib/planning-context.ts';
// @ts-expect-error Native Node TypeScript requires the explicit source extension.
import { buildPlan } from '../lib/build-plan.ts';
import type { PlanRequest, POI } from '../lib/qadam-types';
import type { IntentResolution } from '../lib/intent-types';

const quota: IntentResolution = { mode: 'unavailable', contract: null, failure: 'quota', ms: 50 };
const request: PlanRequest = { query: 'Покушать, без кофе', origin: { lat: 51.128, lon: 71.43, label: 'Public A' }, destination: { lat: 51.128, lon: 71.432, label: 'Public B' }, minutes: 90, interests: [], indoor: true, knownHoursOnly: true, accessible: true, language: 'ru', now: '2026-10-20T13:00:00+05:00', returnBy: '2026-10-20T14:30:00+05:00', departureMode: 'custom' };
const clock = () => new Date('2026-10-20T12:00:00+05:00');
const poi: POI = { id: 'osm:node:42', name: 'Source restaurant', category: 'restaurant', lat: 51.128, lon: 71.431, tags: { amenity: 'restaurant' }, description: 'A restaurant in the source.', openingHours: '24/7', website: null, sourceUrl: 'https://www.openstreetmap.org/node/42', fetchedAt: '2026-10-19T05:00:00Z', indoor: true, wheelchair: 'yes' };
const dataset = { pois: [poi], fetchedAt: poi.fetchedAt, source: 'OpenStreetMap' };

for (const language of ['ru', 'en', 'kk'] as const) test(`quota recovery is explicit, translated and does not offer an immediate retry (${language})`, () => {
  const current = { ...request, language };
  const before = structuredClone(current);
  const response = intentClarification(current, quota);
  assert.equal(response.reason, 'model-unavailable');
  assert.match(response.question, language === 'en' ? /usage limit/i : language === 'kk' ? /лимиті/iu : /лимит/iu);
  assert.equal(response.options.some(option => option.action === 'retry'), false);
  assert.ok(response.options.some(option => option.action === 'manual-category' && option.value === 'food'));
  assert.equal(response.allowFreeText, false);
  assert.deepEqual(current, before);
  assert.ok(response.message?.includes(language === 'en' ? 'explicitly replaces' : language === 'kk' ? 'анық ауыстырады' : 'явно заменит'));
});

test('normal timeout/provider errors keep the retry path rather than being labelled quota', () => {
  for (const failure of ['timeout', 'provider'] as const) {
    const response = intentClarification(request, { ...quota, failure });
    assert.ok(response.options.some(option => option.action === 'retry'));
    assert.doesNotMatch(response.question, /лимит/iu);
  }
});

test('quota never silently substitutes a manual plan or loses the requested controls', async () => {
  const before = structuredClone(request);
  let enrichCalls = 0;
  const response = await buildPlan(request, dataset, { clock, interpret: async () => quota, enrich: async value => { enrichCalls++; return value; } });
  assert.equal(response.plan, null);
  assert.equal(response.intent?.mode, 'unavailable');
  assert.equal(response.intent?.failure, 'quota');
  assert.equal(response.clarification?.reason, 'model-unavailable');
  assert.equal(response.clarification?.options.some(option => option.action === 'retry'), false);
  assert.equal(enrichCalls, 0);
  assert.deepEqual(request, before);
});

test('an explicit manual food choice still builds to B under the same deadline and strict filters without AI', async () => {
  const choice = intentClarification(request, quota).options.find(option => option.action === 'manual-category' && option.value === 'food');
  assert.ok(choice?.value);
  const recovered = { ...request, query: '', interests: [choice.value], localOnly: true };
  let providerCalls = 0;
  const response = await buildPlan(recovered, dataset, { clock, interpret: async () => { providerCalls++; throw new Error('AI must not run'); }, enrich: async value => { providerCalls++; return value; } });
  assert.equal(providerCalls, 0);
  assert.equal(response.intent?.mode, 'manual');
  assert.ok(response.plan);
  assert.equal(response.plan.stops[0].poi.id, poi.id);
  assert.deepEqual(response.plan.routeCoordinates.at(-1), [request.destination!.lon, request.destination!.lat]);
  assert.ok(response.plan.totalMinutes <= request.minutes);
  assert.equal(response.plan.stops[0].hoursStatus, 'open');
  assert.equal(response.plan.stops[0].poi.indoor, true);
  assert.equal(response.plan.stops[0].poi.wheelchair, 'yes');
  assert.equal(Date.parse(response.returnBy!), Date.parse(request.returnBy!));
  assert.deepEqual(recovered.origin, request.origin);
  assert.deepEqual(recovered.destination, request.destination);
});
