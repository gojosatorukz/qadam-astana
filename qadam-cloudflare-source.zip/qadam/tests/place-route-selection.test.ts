import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Node's native TypeScript runner needs the explicit extension.
import { hasPlaceRouteWish, placeRouteSelection } from '../lib/place-route-selection.ts';
// @ts-expect-error Node's native TypeScript runner needs the explicit extension.
import { planRoute } from '../lib/planner.ts';
import type { PlanRequest, POI } from '../lib/qadam-types';

const cafe = { id: 'osm:node:42', category: 'cafe' };

test('a map pin preserves negative and ambiguous wishes verbatim when the user keeps them', () => {
  for (const query of ['парк, без кафе', 'nature, no coffee', 'Кофесіз саябақ', 'Something quiet, maybe food']) {
    const wish = { query, interests: [], localOnly: false, contextConfirmed: true };
    assert.equal(hasPlaceRouteWish(wish), true);
    assert.deepEqual(placeRouteSelection(cafe, wish, 'keep-wish'), { query, interests: [], localOnly: false, contextConfirmed: true, requiredPoiId: cafe.id });
  }
});

test('only an explicit replacement clears an existing wish and selects the pin category', () => {
  const wish = { query: 'парк, без кафе', interests: ['park'], localOnly: false, contextConfirmed: true };
  assert.deepEqual(placeRouteSelection(cafe, wish, 'replace-wish'), { query: '', interests: ['cafe'], localOnly: true, contextConfirmed: false, requiredPoiId: cafe.id });
  assert.equal(wish.query, 'парк, без кафе');
  assert.deepEqual(wish.interests, ['park']);
});

test('manual categories also require a decision and remain intact when kept', () => {
  const wish = { query: '', interests: ['park', 'museum'], localOnly: true };
  assert.equal(hasPlaceRouteWish(wish), true);
  const selection = placeRouteSelection(cafe, wish, 'keep-wish');
  assert.deepEqual(selection.interests, ['park', 'museum']);
  assert.equal(selection.localOnly, true);
  assert.notEqual(selection.interests, wish.interests);
});

test('empty wishes do not need a confirmation; text never enters local-only recovery', () => {
  assert.equal(hasPlaceRouteWish({ query: '   ', interests: [] }), false);
  assert.equal(placeRouteSelection(cafe, { query: 'парк', interests: [], localOnly: true }, 'keep-wish').localOnly, false);
});

test('pin overrides preserve A, optional B, absolute deadline and strict filters for both choices', () => {
  const controls = { origin: { lat: 51.128, lon: 71.43, label: 'A' }, destination: { lat: 51.12, lon: 71.44, label: 'B' }, minutes: 90, now: '2026-10-21T07:00:00Z', departureMode: 'custom', returnBy: '2026-10-21T08:30:00Z', indoor: true, accessible: true, knownHoursOnly: true };
  for (const choice of ['keep-wish', 'replace-wish'] as const) {
    const override = placeRouteSelection(cafe, { query: 'парк, без кафе', interests: [] }, choice);
    assert.deepEqual(Object.keys(override).sort(), ['contextConfirmed', 'interests', 'localOnly', 'query', 'requiredPoiId']);
    const merged = { ...controls, ...override };
    for (const key of Object.keys(controls) as (keyof typeof controls)[]) assert.deepEqual(merged[key], controls[key]);
    assert.equal(merged.requiredPoiId, cafe.id);
  }
});

test('a future-to-now replan can preserve the selected pin without carrying a new deadline', () => {
  const chosen = placeRouteSelection(cafe, { query: 'eat', interests: [] }, 'keep-wish');
  const request = { ...chosen, departureMode: 'now', now: '2026-10-20T12:00:00Z', returnBy: '2026-10-20T13:00:00Z' };
  assert.equal(request.requiredPoiId, cafe.id);
  assert.equal(request.query, 'eat');
  assert.equal(request.returnBy, '2026-10-20T13:00:00Z');
});

test('keeping a no-cafe wish rejects its cafe pin; explicit replacement permits that exact pin', () => {
  const poi: POI = { ...cafe, name: 'Chosen café', lat: 51.128, lon: 71.431, description: 'A source café', tags: { amenity: 'cafe' }, openingHours: '24/7', website: null, sourceUrl: 'https://www.openstreetmap.org/node/42', fetchedAt: '2026-10-19T05:00:00Z', indoor: true, wheelchair: 'yes' };
  const dataset = { pois: [poi], fetchedAt: poi.fetchedAt, source: 'OpenStreetMap' };
  const controls: PlanRequest = { query: 'парк, без кафе', interests: [], origin: { lat: 51.128, lon: 71.43, label: 'A' }, destination: { lat: 51.128, lon: 71.432, label: 'B' }, minutes: 45, indoor: true, accessible: true, knownHoursOnly: true, language: 'ru', now: '2026-10-20T12:00:00Z' };
  const preserved = planRoute({ ...controls, ...placeRouteSelection(cafe, controls, 'keep-wish') }, dataset, { intent: { version: 1, desiredCategories: ['park'], excludedCategories: ['cafe'], includeMode: 'any', unsupported: [], needsClarification: false } });
  assert.equal(preserved.plan, null);
  assert.ok(preserved.warnings.some((warning: string) => warning.includes('Выбранное место')));
  const replaced = planRoute({ ...controls, ...placeRouteSelection(cafe, controls, 'replace-wish') }, dataset);
  assert.ok(replaced.plan);
  assert.equal(replaced.plan.stops[0].poi.id, cafe.id);
  assert.deepEqual(replaced.plan.routeCoordinates.at(-1), [controls.destination!.lon, controls.destination!.lat]);
  assert.ok(replaced.plan.totalMinutes <= controls.minutes);
  const stillStrict = planRoute({ ...controls, ...placeRouteSelection(cafe, controls, 'replace-wish') }, { ...dataset, pois: [{ ...poi, indoor: false }] });
  assert.equal(stillStrict.plan, null);
});
