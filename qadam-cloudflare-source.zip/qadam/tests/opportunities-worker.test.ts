import assert from'node:assert/strict';
import test from'node:test';
import{readFile}from'node:fs/promises';
import'../lib/opportunities.worker.ts';
import type{OpportunityWorkerReply,OpportunityWorkerRequest}from'../lib/opportunities.worker';

test('actual worker coalesces loading-time slider changes and reuses raw assets for later budgets',async t=>{
 t.mock.timers.enable({apis:['Date'],now:new Date('2026-10-20T07:00:00Z')});
 const[poi,graph]=await Promise.all([readFile(new URL('../data/poi.json',import.meta.url),'utf8'),readFile(new URL('../data/walk-graph.json',import.meta.url),'utf8')]);
 const scope=globalThis as unknown as{postMessage:(message:OpportunityWorkerReply)=>void;onmessage:(event:MessageEvent<OpportunityWorkerRequest>)=>void};
 const descriptor=Object.getOwnPropertyDescriptor(globalThis,'postMessage');let release:((value:Response)=>void)|null=null,calls=0,broken=true;const replies:OpportunityWorkerReply[]=[];
 let resolveReply:((value:OpportunityWorkerReply)=>void)|null=null;
 Object.defineProperty(globalThis,'postMessage',{configurable:true,value:(reply:OpportunityWorkerReply)=>{replies.push(reply);resolveReply?.(reply);resolveReply=null;}});
 t.mock.method(globalThis,'fetch',async(input:RequestInfo|URL,init?:RequestInit)=>{calls++;const url=new URL(String(input));assert.equal(init?.mode,'same-origin');assert.equal(init?.redirect,'error');if(broken)throw new Error('private token query GPS');if(url.pathname.endsWith('/poi.json'))return new Promise<Response>(resolve=>{release=resolve;});assert.ok(url.pathname.endsWith('/walk-graph.json'));return new Response(graph);});
 const request:OpportunityWorkerRequest['request']={origin:{lat:51.128,lon:71.43,label:'A'},minutes:45,interests:['food'],indoor:false,knownHoursOnly:false,accessible:false,language:'en',departureAt:'2026-10-20T07:00:00Z'};
 const send=(id:number,minutes:number)=>scope.onmessage({data:{type:'opportunities',id,request:{...request,minutes}}}as MessageEvent<OpportunityWorkerRequest>);
 try{
  const failed=new Promise<OpportunityWorkerReply>(resolve=>{resolveReply=resolve;});send(1,30);assert.deepEqual(await failed,{type:'opportunities-error',id:1,code:'POI_LOAD'});assert.doesNotMatch(JSON.stringify(replies),/private token|query GPS/);broken=false;for(let i=0;i<8;i++)await Promise.resolve();
  send(2,30);send(3,45);const loaded=new Promise<OpportunityWorkerReply>(resolve=>{resolveReply=resolve;});release!(new Response(poi));const first=await loaded;assert.equal(first.id,3);assert.equal(first.type,'opportunities-result');if(first.type!=='opportunities-result')throw new Error('Expected opportunities');assert.ok(first.result.places.length>=4);assert.equal(first.result.diagnostics.searches,1);assert.equal(calls,3);assert.equal(replies.length,2);
  for(let i=0;i<8;i++)await Promise.resolve();const changed=new Promise<OpportunityWorkerReply>(resolve=>{resolveReply=resolve;});send(4,60);const second=await changed;assert.equal(second.type,'opportunities-result');if(second.type!=='opportunities-result')throw new Error('Expected opportunities');assert.equal(second.result.diagnostics.contextReused,true);assert.equal(second.result.diagnostics.searches,1);assert.equal(calls,3);assert.ok(first.result.places.every(place=>second.result.places.some(next=>next.canonicalId===place.canonicalId)));
 }finally{if(descriptor)Object.defineProperty(globalThis,'postMessage',descriptor);else Reflect.deleteProperty(globalThis,'postMessage');}
});
