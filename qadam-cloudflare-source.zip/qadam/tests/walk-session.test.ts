import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extension.
import { createLocationWatch, walkStartBlock, walkGPSStartBlock, walkPositionBlock } from '../lib/walk-session.ts';
test('a delayed permission result cannot start an expired or future plan',()=>{
  const now=Date.parse('2026-10-20T07:00:00Z'),iso=(delta:number)=>new Date(now+delta).toISOString();
  const base={nowMs:now,departureMode:'now' as const,computedAt:iso(0),deadlineAt:iso(45*60_000),hasStarted:false};
  assert.equal(walkStartBlock(base),null);
  assert.equal(walkStartBlock({...base,nowMs:now+61_000}),'expired');
  assert.equal(walkStartBlock({...base,departureMode:'custom',departureAt:iso(120_000)}),'future');
  assert.equal(walkStartBlock({...base,departureMode:'custom',departureAt:iso(-61_000)}),'future');
  assert.equal(walkStartBlock({...base,departureMode:'custom',departureAt:iso(0),hasStarted:true}),'future');
});
test('an accepted walk keeps return guidance after the original time window',()=>{
  const now=Date.parse('2026-10-20T07:00:00Z');
  assert.equal(walkStartBlock({nowMs:now,departureMode:'now',computedAt:new Date(now-3_600_000).toISOString(),deadlineAt:new Date(now-60_000).toISOString(),hasStarted:true}),null);
});
test('stopping GPS rejects late position/error callbacks and clears only its own watch',()=>{
  const success:PositionCallback[]=[],errors:PositionErrorCallback[]=[],cleared:number[]=[];
  const watcher=createLocationWatch({watchPosition(ok,fail,options){assert.equal(options?.enableHighAccuracy,true);assert.equal(options?.maximumAge,0);success.push(ok);errors.push(fail!);return 7;},clearWatch(id){cleared.push(id);}});
  let fixes=0,failures=0;watcher.start(()=>fixes++,()=>failures++);success[0]({} as GeolocationPosition);assert.equal(fixes,1);
  watcher.stop();success[0]({} as GeolocationPosition);errors[0]({} as GeolocationPositionError);watcher.stop();
  assert.equal(fixes,1);assert.equal(failures,0);assert.deepEqual(cleared,[7]);
});
test('restarting a GPS session does not let the old callback revive its progress',()=>{
  const callbacks:PositionCallback[]=[],cleared:number[]=[];let count=0;
  const watcher=createLocationWatch({watchPosition(ok){callbacks.push(ok);return callbacks.length;},clearWatch(id){cleared.push(id);}});
  watcher.start(()=>count+=100,()=>{});watcher.start(()=>count++,()=>{});
  callbacks[0]({} as GeolocationPosition);callbacks[1]({} as GeolocationPosition);assert.equal(count,1);assert.deepEqual(cleared,[1]);watcher.stop();assert.deepEqual(cleared,[1,2]);
});
test('synchronous denial cannot leave the newly returned GPS watch running',()=>{
  const cleared:number[]=[];
  const watcher=createLocationWatch({watchPosition(_ok,fail){fail!({code:1} as GeolocationPositionError);return 9;},clearWatch(id){cleared.push(id);}});
  watcher.start(()=>assert.fail('unexpected fix'),()=>watcher.stop());assert.deepEqual(cleared,[9]);
});
test('GPS startup requires fresh accurate coordinates near A; a resume may be farther along',()=>{
  const nowMs=1_800_000_000_000,origin={lat:51.128,lon:71.43},fix={...origin,accuracy:10,timestamp:nowMs};
  const gate=(value:typeof fix|null,hasStarted=false)=>walkGPSStartBlock({fix:value,origin,nowMs,hasStarted});
  assert.equal(gate(null),'invalid-fix');assert.equal(gate(fix),null);
  assert.equal(gate({...fix,accuracy:26}),'poor-accuracy');
  assert.equal(gate({...fix,timestamp:nowMs-20_001}),'stale-fix');
  assert.equal(gate({...fix,timestamp:nowMs+5001}),'stale-fix');
  assert.equal(gate({...fix,lat:NaN}),'invalid-fix');
  const distant={...fix,lat:fix.lat+.001};
  assert.equal(gate(distant),'origin-mismatch');assert.equal(gate(distant,true),null);
  assert.equal(gate({...distant,accuracy:80},true),'poor-accuracy');
});
test('poor or stale accuracy cannot expand the origin match radius or poison a later valid fix',()=>{
  const nowMs=1_800_000_000_000,origin={lat:51.128,lon:71.43},fix={...origin,lat:origin.lat+.001,accuracy:100,timestamp:nowMs};
  assert.equal(walkGPSStartBlock({fix,origin,nowMs,hasStarted:false}),'poor-accuracy');
  assert.equal(walkGPSStartBlock({fix:{...fix,...origin,accuracy:5,timestamp:nowMs+1},origin,nowMs:nowMs+1,hasStarted:false}),null);
  assert.equal(walkPositionBlock({...fix,accuracy:5,timestamp:NaN},nowMs),'invalid-fix');
});
