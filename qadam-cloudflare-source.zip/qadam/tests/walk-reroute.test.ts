import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { rerouteWalk } from '../lib/walk-reroute.ts';
// @ts-expect-error Native Node TS source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
// @ts-expect-error Native Node TS source extensions.
import { validLegEndIndices } from '../lib/walk-guide.ts';
import type { RerouteRequest, RerouteResult } from '../lib/walk-reroute';
import type { PlanStop } from '../lib/qadam-types';

const NOW=Date.parse('2026-10-20T07:00:00Z');
const A={lat:51.128,lon:71.43,label:'Original A'},B={lat:51.128,lon:71.438,label:'Original B'};
const vertex=(index:number)=>({lat:51.128,lon:71.43+index*0.002});
function stop(index:number):PlanStop {return {poi:{id:`source-${index}`,name:`Source ${index}`,...vertex(index),category:'park',tags:{leisure:'park',name:`Source ${index}`},description:'Source park',openingHours:'24/7',website:null,sourceUrl:`https://www.openstreetmap.org/node/${index}`,fetchedAt:'2026-10-20T00:00:00Z',indoor:null,wheelchair:'yes'},visitMinutes:12,travelMinutes:90,why:'Old time explanation',activity:'A short walk',hoursStatus:'open',facts:[{id:`fact-${index}`,text:'Sourced fact',sourceUrl:'https://example.com/source',checkedAt:'2026-10-20T00:00:00Z',rights:'Paraphrase'}]};}
function graph(stepEdges:number[]=[],shortcut=false){return new WalkingGraph({nodes:Array.from({length:5},(_,i)=>[i+1,vertex(i).lat,vertex(i).lon]),edges:[...Array.from({length:4},(_,i)=>[i+1,i+2,140]),...(shortcut?[[1,5,70]]:[])],stepEdges});}
const request=(overrides:Partial<RerouteRequest>={}):RerouteRequest=>({fix:{lat:A.lat,lon:A.lon,accuracy:5,timestamp:NOW},endpoint:B,remainingStops:[stop(1),stop(2),stop(3)],deadlineAt:new Date(NOW+70*60000).toISOString(),nowMs:NOW,accessible:false,knownHoursOnly:false,language:'en',...overrides});
function route(result:RerouteResult):Extract<RerouteResult,{kind:'route'}>{assert.equal(result.kind,'route');return result as Extract<RerouteResult,{kind:'route'}>;}
function invariants(result:Extract<RerouteResult,{kind:'route'}>,input:RerouteRequest){
 const p=result.plan;assert.equal(result.deadlineAt,input.deadlineAt);assert.equal(result.computedAt,new Date(input.nowMs).toISOString());assert.equal(p.routeKind,'walking');assert.equal(p.totalMinutes,p.walkingMinutes+p.visitMinutes+p.bufferMinutes);assert.equal(p.visitMinutes,p.stops.reduce((n,s)=>n+s.visitMinutes,0));assert.equal(p.walkingMinutes,p.stops.reduce((n,s)=>n+s.travelMinutes,0)+p.returnMinutes);assert.deepEqual(p.routeCoordinates[0],[input.fix.lon,input.fix.lat]);assert.deepEqual(p.routeCoordinates.at(-1),[input.endpoint.lon,input.endpoint.lat]);assert.ok(validLegEndIndices(p.routeCoordinates,p.stops,p.legEndIndices));assert.equal(p.legEndIndices?.length,p.stops.length+1);assert.ok(result.searchCount<=5);assert.ok(result.maxConnectorMeters<=200);
}

test('local reroute keeps exact original B, order, visit durations and complete leg geometry',()=>{
 const input=request();const result=route(rerouteWalk(input,graph()));invariants(result,input);assert.deepEqual(result.plan.stops.map(s=>s.poi.id),['source-1','source-2','source-3']);assert.deepEqual(result.plan.stops.map(s=>s.visitMinutes),[12,12,12]);assert.deepEqual(result.removedPoiIds,[]);assert.equal(result.overBudget,false);assert.equal(result.lateByMinutes,0);assert.equal(result.plan.walkingMinutes,8);assert.equal(result.plan.visitMinutes,36);
});
test('return-to-A endpoint is preserved instead of silently selecting B or the new fix',()=>{
 const input=request({fix:{...vertex(4),accuracy:5,timestamp:NOW},endpoint:A,remainingStops:[stop(3),stop(1)]});const result=route(rerouteWalk(input,graph()));invariants(result,input);assert.deepEqual(result.plan.destination,A);assert.deepEqual(result.plan.stops.map(s=>s.poi.id),['source-3','source-1']);assert.equal(result.plan.routeMode,'one-way');
});
test('elapsed time reduces the original window and drops visits without resetting the deadline',()=>{
 const initial=request(),later=NOW+35*60000,input={...initial,nowMs:later,fix:{...initial.fix,timestamp:later}};const result=route(rerouteWalk(input,graph()));invariants(result,input);assert.deepEqual(result.plan.stops.map(s=>s.poi.id),['source-1','source-2']);assert.deepEqual(result.removedPoiIds,['source-3']);assert.equal(result.plan.totalMinutes,35);assert.equal(result.deadlineAt,initial.deadlineAt);
 const last=NOW+50*60000,direct=route(rerouteWalk({...initial,nowMs:last,fix:{...initial.fix,timestamp:last}},graph()));assert.equal(direct.plan.stops.length,0);assert.deepEqual(direct.removedPoiIds,['source-1','source-2','source-3']);assert.equal(direct.deadlineAt,initial.deadlineAt);assert.equal(direct.overBudget,false);
});
test('direct-only late route is returned honestly for expired or insufficient deadlines',()=>{
 for(const minutes of [-10,5]){
  const input=request({deadlineAt:new Date(NOW+minutes*60000).toISOString()}),result=route(rerouteWalk(input,graph()));invariants(result,input);assert.equal(result.plan.stops.length,0);assert.equal(result.overBudget,true);assert.equal(result.plan.totalMinutes,11);assert.equal(result.lateByMinutes,11-minutes);assert.ok(!result.plan.summary.includes('on time'));
 }
});
test('only supplied remaining stops can reappear; a confirmed old stop is never invented',()=>{
 const input=request({remainingStops:[stop(3)]}),result=route(rerouteWalk(input,graph()));assert.deepEqual(result.plan.stops.map(s=>s.poi.id),['source-3']);assert.ok(!result.plan.stops.some(s=>s.poi.id==='source-1'));assert.deepEqual(result.removedPoiIds,[]);
});
test('opening hours are checked at new arrival after earlier retained visits',()=>{
 const early=stop(1),later={...stop(3),poi:{...stop(3).poi,openingHours:'Mo-Su 12:15-13:00'}},input=request({remainingStops:[early,later],knownHoursOnly:true}),result=route(rerouteWalk(input,graph()));assert.equal(result.plan.stops.length,2);assert.equal(result.plan.stops[1].hoursStatus,'open');assert.equal(result.plan.stops[1].travelMinutes,4);
 const closed={...early,poi:{...early.poi,openingHours:'Mo-Su 12:00-12:10'}},next=NOW+15*60000,dropped=route(rerouteWalk(request({remainingStops:[closed,later],nowMs:next,fix:{lat:A.lat,lon:A.lon,accuracy:5,timestamp:next},knownHoursOnly:true}),graph()));assert.deepEqual(dropped.plan.stops.map(s=>s.poi.id),['source-3']);assert.deepEqual(dropped.removedPoiIds,['source-1']);
});
test('unknown and closed hours are not turned into verified open venues',()=>{
 const unknown={...stop(1),poi:{...stop(1).poi,openingHours:null}},closed={...stop(2),poi:{...stop(2).poi,openingHours:'off'}};
 const loose=route(rerouteWalk(request({remainingStops:[unknown,closed]}),graph()));assert.deepEqual(loose.plan.stops.map(s=>s.hoursStatus),['unknown']);assert.deepEqual(loose.removedPoiIds,['source-2']);
 const strict=route(rerouteWalk(request({remainingStops:[unknown,closed],knownHoursOnly:true}),graph()));assert.equal(strict.plan.stops.length,0);assert.deepEqual(strict.removedPoiIds,['source-1','source-2']);
});
test('missing graph coverage and disconnected endpoints never fabricate geometric routing',()=>{
 const disconnected=new WalkingGraph({nodes:[[1,A.lat,A.lon],[2,A.lat,A.lon+0.001],[3,B.lat,B.lon],[4,B.lat,B.lon+0.001]],edges:[[1,2,70],[3,4,70]]});
 assert.deepEqual(rerouteWalk(request(),disconnected),{kind:'unavailable',reason:'disconnected'});
 assert.deepEqual(rerouteWalk(request({endpoint:{lat:51.3,lon:71.7,label:'No coverage'}}),graph()),{kind:'unavailable',reason:'network-unavailable'});
 assert.deepEqual(rerouteWalk(request({fix:{lat:51.3,lon:71.7,accuracy:5,timestamp:NOW}}),graph()),{kind:'unavailable',reason:'network-unavailable'});
});
test('accessible reroute avoids stairs, rejects disconnected accessible routes and unverified venues',()=>{
 const steps=graph([4],true),normal=route(rerouteWalk(request({remainingStops:[]}),steps)),accessible=route(rerouteWalk(request({remainingStops:[],accessible:true}),steps));assert.equal(normal.plan.walkingMinutes,1);assert.equal(accessible.plan.walkingMinutes,8);
 const onlyStairs=new WalkingGraph({nodes:[[1,A.lat,A.lon],[2,B.lat,B.lon]],edges:[[1,2,70]],stepEdges:[0]});assert.deepEqual(rerouteWalk(request({accessible:true}),onlyStairs),{kind:'unavailable',reason:'disconnected'});
 const unknown={...stop(1),poi:{...stop(1).poi,wheelchair:null}},filtered=route(rerouteWalk(request({remainingStops:[unknown],accessible:true}),graph()));assert.equal(filtered.plan.stops.length,0);assert.deepEqual(filtered.removedPoiIds,['source-1']);
});
test('bounded quality and input validation reject stale, poor or malformed requests',()=>{
 const valid=request();for(const overrides of [{nowMs:NaN},{deadlineAt:'2026-02-31T12:00:00+05:00'},{deadlineAt:'2026-10-20T12:00:00'},{remainingStops:Array(4).fill(stop(1))},{remainingStops:[{...stop(1),visitMinutes:0}]},{endpoint:{lat:91,lon:71,label:'Invalid'}},{fix:{...valid.fix,accuracy:-1}},{fix:{...valid.fix,timestamp:Infinity}}])assert.deepEqual(rerouteWalk({...valid,...overrides} as RerouteRequest,graph()),{kind:'unavailable',reason:'invalid-request'});
 assert.deepEqual(rerouteWalk({...valid,fix:{...valid.fix,accuracy:41}},graph()),{kind:'unavailable',reason:'poor-accuracy'});
 for(const timestamp of [NOW-20001,NOW+5001])assert.deepEqual(rerouteWalk({...valid,fix:{...valid.fix,timestamp}},graph()),{kind:'unavailable',reason:'stale-fix'});
 const aliases=['osm-node-4894937300','osm-way-1381418247'].map(id=>({...stop(1),poi:{...stop(1).poi,id}}));assert.deepEqual(rerouteWalk({...valid,remainingStops:aliases},graph()),{kind:'unavailable',reason:'invalid-request'});
});
test('at most five actual Dijkstra trees cover all subsets and output reconstruction',()=>{
 class CountingGraph extends WalkingGraph {calls=0;override search(...args:Parameters<WalkingGraph['search']>){this.calls++;return super.search(...args);}}
 const routing=new CountingGraph({nodes:Array.from({length:5},(_,i)=>[i+1,vertex(i).lat,vertex(i).lon]),edges:Array.from({length:4},(_,i)=>[i+1,i+2,140])}),result=route(rerouteWalk(request(),routing));assert.equal(result.searchCount,routing.calls);assert.ok(routing.calls<=5);assert.equal(result.plan.stops.length,3);
});
test('rerouting and mutating the result do not mutate the request or source records',()=>{
 const input=request(),before=JSON.stringify(input);const freeze=(v:unknown)=>{if(v&&typeof v==='object'){Object.freeze(v);for(const child of Object.values(v))freeze(child);}};freeze(input);
 const result=route(rerouteWalk(input,graph()));assert.equal(JSON.stringify(input),before);result.plan.stops[0].poi.tags.name='Changed result';result.plan.stops[0].facts![0].text='Changed result fact';assert.equal(JSON.stringify(input),before);
});
test('coincident endpoint uses a real zero-length path, never a snap-connector detour',()=>{
 const input=request({endpoint:A,remainingStops:[]}),result=route(rerouteWalk(input,graph()));invariants(result,input);assert.equal(result.plan.walkingMinutes,0);assert.equal(result.plan.distanceMeters,0);assert.deepEqual(result.plan.routeCoordinates,[[A.lon,A.lat],[A.lon,A.lat]]);assert.deepEqual(result.plan.legEndIndices,[1]);
});
