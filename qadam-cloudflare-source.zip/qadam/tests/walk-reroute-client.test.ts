import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { createWalkRerouter } from '../lib/walk-reroute-client.ts';
import type { WalkRerouteWorker } from '../lib/walk-reroute-client';
import type { RerouteRequest, RerouteResult } from '../lib/walk-reroute';

class FakeWorker implements WalkRerouteWorker {
  onmessage: WalkRerouteWorker['onmessage'] = null;
  onerror: WalkRerouteWorker['onerror'] = null;
  onmessageerror: WalkRerouteWorker['onmessageerror'] = null;
  requests: { type: string; id: number; request: RerouteRequest }[] = [];
  terminations = 0;
  postMessage(message: unknown) { this.requests.push(message as typeof this.requests[number]); }
  terminate() { this.terminations++; }
  reply(data: unknown) { this.onmessage?.call(this as unknown as Worker, { data } as MessageEvent); }
  fail() { this.onerror?.call(this as unknown as Worker, {} as ErrorEvent); }
}
const request: RerouteRequest = { fix: { lat: 51.128, lon: 71.43, accuracy: 10, timestamp: 100_000 }, endpoint: { lat: 51.13, lon: 71.44, label: 'B' }, remainingStops: [], deadlineAt: '2026-10-20T12:00:00.000Z', nowMs: 100_000, accessible: false, knownHoursOnly: false, language: 'ru' };
const unavailable = { kind: 'unavailable', reason: 'network-unavailable' } as RerouteResult;
function harness(timeoutMs = 1000) {
  const workers: FakeWorker[] = [];
  const client = createWalkRerouter({ timeoutMs, workerFactory: () => { const worker = new FakeWorker(); workers.push(worker); return worker; } });
  return { client, workers };
}
test('worker creation is lazy, one request runs at a time, and the graph worker is reused', async () => {
  const { client, workers } = harness(); assert.equal(workers.length, 0);
  const first = client.reroute(request); assert.equal(workers.length, 1); assert.equal(workers[0].requests.length, 1);
  assert.deepEqual(await client.reroute(request), { ok: false, reason: 'busy' });
  const id = workers[0].requests[0].id;
  workers[0].reply({ type: 'reroute-result', id: id + 100, result: unavailable });
  workers[0].reply({ type: 'reroute-result', id, result: unavailable });
  assert.deepEqual(await first, { ok: true, result: unavailable });
  const second = client.reroute(request); assert.equal(workers.length, 1); assert.equal(workers[0].requests.length, 2);
  workers[0].reply({ type: 'reroute-result', id: workers[0].requests[1].id, result: unavailable });
  assert.equal((await second).ok, true); client.dispose(); assert.equal(workers[0].terminations, 1);
});
test('dispose settles pending work and old callbacks cannot deliver a result to a later session', async () => {
  const { client, workers } = harness(); const pending = client.reroute(request), worker = workers[0], callback = worker.onmessage!;
  client.dispose(); assert.deepEqual(await pending, { ok: false, reason: 'cancelled' }); assert.equal(worker.terminations, 1);
  callback.call(worker as unknown as Worker, { data: { type: 'reroute-result', id: worker.requests[0].id, result: unavailable } } as MessageEvent);
  assert.deepEqual(await client.reroute(request), { ok: false, reason: 'disposed' });
  client.dispose(); assert.equal(worker.terminations, 1);
});
test('AbortSignal terminates the old epoch and a captured late callback cannot settle a new request', async () => {
  const { client, workers } = harness(), controller = new AbortController();
  const first = client.reroute(request, { signal: controller.signal }), old = workers[0], oldCallback = old.onmessage!;
  controller.abort(); assert.deepEqual(await first, { ok: false, reason: 'cancelled' }); assert.equal(old.terminations, 1);
  const second = client.reroute(request), next = workers[1];
  oldCallback.call(old as unknown as Worker, { data: { type: 'reroute-result', id: next.requests[0].id, result: unavailable } } as MessageEvent);
  assert.deepEqual(await client.reroute(request), { ok: false, reason: 'busy' });
  next.reply({ type: 'reroute-result', id: next.requests[0].id, result: unavailable }); assert.equal((await second).ok, true); client.dispose();
});
test('timeouts and worker errors return honest failures and recreate workers only on a later attempt', async () => {
  const { client, workers } = harness(5);
  assert.deepEqual(await client.reroute(request), { ok: false, reason: 'timeout' }); assert.equal(workers[0].terminations, 1);
  const pending = client.reroute(request); assert.equal(workers.length, 2); workers[1].fail();
  assert.deepEqual(await pending, { ok: false, reason: 'worker-error' }); assert.equal(workers[1].terminations, 1); client.dispose();
});
test('pre-aborted calls do not create a worker; missing Worker has no synchronous fallback', { skip: typeof Worker !== 'undefined' }, async () => {
  const { client, workers } = harness(), controller = new AbortController(); controller.abort();
  assert.deepEqual(await client.reroute(request, { signal: controller.signal }), { ok: false, reason: 'cancelled' }); assert.equal(workers.length, 0); client.dispose();
  const unsupported = createWalkRerouter(); assert.deepEqual(await unsupported.reroute(request), { ok: false, reason: 'unsupported' }); unsupported.dispose();
});
test('async factory loading is busy, cancellable, and late construction cannot post GPS', async () => {
  let create: ((worker: FakeWorker) => void) | undefined;
  const client = createWalkRerouter({ workerFactory: () => new Promise<FakeWorker>(resolve => { create = resolve; }) });
  const controller = new AbortController(), pending = client.reroute(request, { signal: controller.signal });
  assert.deepEqual(await client.reroute(request), { ok: false, reason: 'busy' });
  controller.abort(); assert.deepEqual(await pending, { ok: false, reason: 'cancelled' });
  const lateWorker = new FakeWorker(); create!(lateWorker); await Promise.resolve(); await Promise.resolve();
  assert.equal(lateWorker.terminations, 1); assert.equal(lateWorker.requests.length, 0); client.dispose();
});
test('timeout covers lazy module loading; a late rejected factory cannot cancel the next attempt', async () => {
  let rejectFirst: ((reason?: unknown) => void) | undefined, calls = 0;
  const nextWorker = new FakeWorker();
  const client = createWalkRerouter({ timeoutMs: 5, workerFactory: () => ++calls === 1 ? new Promise<FakeWorker>((_resolve, reject) => { rejectFirst = reject; }) : nextWorker });
  assert.deepEqual(await client.reroute(request), { ok: false, reason: 'timeout' });
  const second = client.reroute(request); rejectFirst!(new Error('old lazy import failed')); await Promise.resolve(); await Promise.resolve();
  nextWorker.reply({ type: 'reroute-result', id: nextWorker.requests[0].id, result: unavailable });
  assert.deepEqual(await second, { ok: true, result: unavailable }); client.dispose();
});
test('dispose while an async worker factory is loading terminates its eventual worker', async () => {
  let create: ((worker: FakeWorker) => void) | undefined;
  const client = createWalkRerouter({ workerFactory: () => new Promise<FakeWorker>(resolve => { create = resolve; }) });
  const pending = client.reroute(request); client.dispose(); assert.deepEqual(await pending, { ok: false, reason: 'cancelled' });
  const lateWorker = new FakeWorker(); create!(lateWorker); await Promise.resolve(); await Promise.resolve();
  assert.equal(lateWorker.terminations, 1); assert.equal(lateWorker.requests.length, 0);
});
