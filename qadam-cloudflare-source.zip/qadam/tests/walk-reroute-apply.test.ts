import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { rerouteApplyBlock } from '../lib/walk-reroute-apply.ts';
import type { RerouteRequest, RerouteResult } from '../lib/walk-reroute';
const now=Date.parse('2026-10-20T10:00:00Z'),fix={lat:51.128,lon:71.43,accuracy:8,timestamp:now};
const request:RerouteRequest={fix,endpoint:{lat:51.13,lon:71.44,label:'B'},remainingStops:[],deadlineAt:new Date(now+10*60_000).toISOString(),nowMs:now,accessible:false,knownHoursOnly:false,language:'ru'};
const route:RerouteResult={kind:'route',plan:{title:'',summary:'',stops:[],totalMinutes:10,walkingMinutes:7,visitMinutes:0,bufferMinutes:3,distanceMeters:490,returnMinutes:7,routeCoordinates:[[fix.lon,fix.lat],[71.44,51.13]],routeKind:'walking',legEndIndices:[1]},removedPoiIds:[],deadlineAt:request.deadlineAt,computedAt:new Date(now).toISOString(),overBudget:false,lateByMinutes:0,searchCount:1,maxConnectorMeters:0};
test('worker time consumes the fixed deadline instead of extending the window',()=>{
  assert.equal(rerouteApplyBlock(route,request,fix,now),null);
  assert.equal(rerouteApplyBlock(route,request,{...fix,timestamp:now+5_000},now+5_000),'deadline-changed');
  assert.equal(rerouteApplyBlock({...route,overBudget:true,lateByMinutes:1},request,{...fix,timestamp:now+5_000},now+5_000),null);
});
test('a route from an obsolete position cannot replace the current walk',()=>{
  assert.equal(rerouteApplyBlock(route,request,{...fix,lat:fix.lat+.001,timestamp:now+1000},now+1000),'position-changed');
  assert.equal(rerouteApplyBlock(route,request,{...fix,accuracy:90},now),'position-changed');
  assert.equal(rerouteApplyBlock(route,request,fix,now+20_001),'position-changed');
  assert.equal(rerouteApplyBlock(route,request,{...fix,timestamp:now-1},now),'position-changed');
  assert.equal(rerouteApplyBlock(route,request,{...fix,lon:fix.lon+360},now),'position-changed');
});
test('the original final point and absolute deadline remain immutable at apply',()=>{
  assert.equal(rerouteApplyBlock({...route,deadlineAt:new Date(now+99*60_000).toISOString()},request,fix,now),'deadline-changed');
  assert.equal(rerouteApplyBlock({...route,plan:{...route.plan,routeCoordinates:[[fix.lon,fix.lat],[fix.lon,fix.lat]]}},request,fix,now),'deadline-changed');
});
