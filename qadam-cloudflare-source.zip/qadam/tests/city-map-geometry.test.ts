import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { balancedViewportPOIs, centerMapPointInViewport, coordinateAtMapPixel, fitMapPoints, isMapTap, MAX_MAP_ZOOM, MIN_MAP_ZOOM, navigationMarkerGeometry, pinchMapView, pointOnMap, projectMapPoint, resolveMapViewportInsets, snapshotCorners, unprojectMapPoint } from '../components/city-map-geometry.ts';
import type { MapPoint, MapSize, MapView } from '../components/city-map-geometry';
const origin = { lat: 51.12828, lon: 71.43055 };
const padding = { top: 86, right: 64, bottom: 88, left: 32 };
function assertVisible(points: MapPoint[], view: MapView, size: MapSize) {
  for (const point of points) {
    const screen = pointOnMap(point, view, size);
    assert.ok(screen.x >= padding.left - .001 && screen.x <= size.width - padding.right + .001, `Clipped x=${screen.x}`);
    assert.ok(screen.y >= padding.top - .001 && screen.y <= size.height - padding.bottom + .001, `Clipped y=${screen.y}`);
  }
}
test('Mercator round trip preserves Astana coordinates and remains finite at the poles', () => {
  for (const zoom of [10, 14, 18]) {
    const p = projectMapPoint(origin, zoom), restored = unprojectMapPoint(p.x, p.y, zoom);
    assert.ok(Math.abs(restored.lat - origin.lat) < 1e-9); assert.ok(Math.abs(restored.lon - origin.lon) < 1e-9);
  }
  for (const lat of [-90, 90]) assert.ok(Number.isFinite(projectMapPoint({ lat, lon: 71.4 }, 14).y));
});
test('fit includes a far intermediate route vertex rather than only nearby stops and origin', () => {
  const geometry = [origin, { lat: 51.129, lon: 71.431 }, { lat: 51.192, lon: 71.503 }, { lat: 51.1288, lon: 71.432 }, origin];
  const size = { width: 900, height: 650 }, view = fitMapPoints(geometry, size, { padding });
  assertVisible(geometry, view, size);
  const stopsOnly = fitMapPoints([geometry[0], geometry[1], geometry[3]], size, { padding });
  assert.ok(view.zoom < stopsOnly.zoom, 'The graph detour must affect zoom.');
});
test('resize refits full geometry on a narrow mobile viewport', () => {
  const geometry = [origin, { lat: 51.16, lon: 71.49 }, { lat: 51.18, lon: 71.40 }, origin];
  const desktop = fitMapPoints(geometry, { width: 1200, height: 700 }, { padding });
  const mobileSize = { width: 390, height: 420 }, mobile = fitMapPoints(geometry, mobileSize, { padding });
  assertVisible(geometry, mobile, mobileSize); assert.ok(mobile.zoom <= desktop.zoom);
});
test('the stated POI snapshot rectangle fits without claiming graph connectivity', () => {
  const points = snapshotCorners(), size = { width: 390, height: 500 }, view = fitMapPoints(points, size, { padding });
  assert.deepEqual(points[0], { lat: 51.065, lon: 71.35 });
  assert.deepEqual(points[2], { lat: 51.205, lon: 71.515 });
  assertVisible(points, view, size); assert.ok(view.zoom >= 10);
});
test('tap coordinate matches the displayed point; dragging does not qualify as a pin tap', () => {
  const size = { width: 800, height: 600 }, view = { center: origin, zoom: 15 };
  const point = { lat: 51.13, lon: 71.435 }, screen = pointOnMap(point, view, size);
  const selected = coordinateAtMapPixel(screen.x, screen.y, view, size);
  assert.ok(Math.abs(selected.lat - point.lat) < 1e-9); assert.ok(Math.abs(selected.lon - point.lon) < 1e-9);
  assert.equal(isMapTap(3, 4), true); assert.equal(isMapTap(0, 7), true);
  assert.equal(isMapTap(0, 8), false); assert.equal(isMapTap(-6, 6), false);
});
test('pinching zooms around the fingers rather than jumping to the map centre', () => {
  const size = { width: 390, height: 650 }, view = { center: origin, zoom: 14 };
  const start: [{ x: number; y: number }, { x: number; y: number }] = [{ x: 50, y: 200 }, { x: 150, y: 200 }];
  const anchor = coordinateAtMapPixel(100, 200, view, size);
  const next = pinchMapView(view, size, start, [{ x: 10, y: 240 }, { x: 210, y: 240 }]);
  assert.equal(next.zoom, 15);
  const after = pointOnMap(anchor, next, size);
  assert.ok(Math.abs(after.x - 110) < 1e-6); assert.ok(Math.abs(after.y - 240) < 1e-6);
});
test('two-finger movement pans even with unchanged distance and supports a fractional zoom', () => {
  const size = { width: 390, height: 650 }, view = { center: origin, zoom: 14.25 };
  const start: [{ x: number; y: number }, { x: number; y: number }] = [{ x: 50, y: 200 }, { x: 150, y: 200 }];
  const anchor = coordinateAtMapPixel(100, 200, view, size);
  const next = pinchMapView(view, size, start, [{ x: 90, y: 230 }, { x: 190, y: 230 }]);
  assert.equal(next.zoom, 14.25);
  const after = pointOnMap(anchor, next, size);
  assert.ok(Math.abs(after.x - 140) < 1e-6); assert.ok(Math.abs(after.y - 230) < 1e-6);
});
test('pinch zoom clamps to supported tile levels and degenerate touches cannot produce NaN', () => {
  const size = { width: 390, height: 650 }, view = { center: origin, zoom: 14 };
  const start: [{ x: number; y: number }, { x: number; y: number }] = [{ x: 0, y: 0 }, { x: 10, y: 0 }];
  assert.equal(pinchMapView(view, size, start, [{ x: 0, y: 0 }, { x: 1_000, y: 0 }]).zoom, MAX_MAP_ZOOM);
  assert.equal(pinchMapView(view, size, [{ x: 0, y: 0 }, { x: 1_000, y: 0 }], [{ x: 0, y: 0 }, { x: 1, y: 0 }]).zoom, MIN_MAP_ZOOM);
  assert.equal(pinchMapView(view, size, [{ x: 0, y: 0 }, { x: 0, y: 0 }], start), view);
  assert.equal(pinchMapView(view, size, start, [{ x: 0, y: 0 }, { x: 0, y: 0 }]), view);
});
test('GPS accuracy circle uses the local projection scale and doubles with one zoom level', () => {
  const size = { width: 390, height: 650 }, view = { center: origin, zoom: 17 }, position = { ...origin, accuracy: 25 };
  const marker = navigationMarkerGeometry(position, view, size)!;
  assert.ok(marker); assert.ok(Math.abs(marker.x - 195) < 1e-8); assert.ok(Math.abs(marker.y - 325) < 1e-8);
  const longitudeOffset = 25 / (40_075_016.686 / 360 * Math.cos(origin.lat * Math.PI / 180));
  const east = pointOnMap({ lat: origin.lat, lon: origin.lon + longitudeOffset }, view, size);
  assert.ok(Math.abs(marker.radius - (east.x - marker.x)) < 1e-6);
  assert.ok(Math.abs(navigationMarkerGeometry(position, { ...view, zoom: 18 }, size)!.radius - 2 * marker.radius) < 1e-8);
});
test('invalid GPS values cannot produce marker CSS coordinates or accuracy radii', () => {
  const size = { width: 390, height: 650 }, view = { center: origin, zoom: 17 }, valid = { ...origin, accuracy: 15 };
  for (const value of [undefined, { ...valid, lat: NaN }, { ...valid, lon: Infinity }, { ...valid, lat: 86 }, { ...valid, lon: 181 }, { ...valid, accuracy: -1 }, { ...valid, accuracy: NaN }, { ...valid, accuracy: Infinity }]) assert.equal(navigationMarkerGeometry(value, view, size), null);
  assert.equal(navigationMarkerGeometry(valid, { ...view, center: { lat: NaN, lon: 71 } }, size), null);
  assert.equal(navigationMarkerGeometry(valid, { ...view, zoom: NaN }, size), null);
  assert.equal(navigationMarkerGeometry(valid, view, { width: Infinity, height: 650 }), null);
});
test('very coarse GPS fixes remain finite; only a finite actual heading gets an arrow', () => {
  const size = { width: 390, height: 650 }, view = { center: origin, zoom: 17 }, position = { ...origin, accuracy: Number.MAX_VALUE };
  const marker = navigationMarkerGeometry(position, view, size)!;
  assert.equal(marker.radius, 1300); assert.equal(marker.heading, null);
  assert.ok([marker.x, marker.y, marker.radius].every(Number.isFinite));
  for (const heading of [null, undefined, NaN, Infinity]) assert.equal(navigationMarkerGeometry({ ...position, heading }, view, size)!.heading, null);
  assert.equal(navigationMarkerGeometry({ ...position, heading: 0 }, view, size)!.heading, 0);
  assert.equal(navigationMarkerGeometry({ ...position, heading: 450 }, view, size)!.heading, 90);
  assert.equal(navigationMarkerGeometry({ ...position, heading: -90 }, view, size)!.heading, 270);
});
test('GPS follow centres the fix above a phone drawer and clear of right-side controls', () => {
  const size = { width: 390, height: 844 }, insets = { top: 140, right: 64, bottom: 400, left: 0 };
  const view = centerMapPointInViewport(origin, 17, size, insets), point = pointOnMap(origin, view, size);
  assert.ok(Math.abs(point.x - 163) < 1e-6); assert.ok(Math.abs(point.y - 292) < 1e-6);
  assert.equal(view.zoom, 17);
  const unchanged = centerMapPointInViewport(origin, 17, size);
  assert.ok(Math.abs(unchanged.center.lat - origin.lat) < 1e-9); assert.ok(Math.abs(unchanged.center.lon - origin.lon) < 1e-9);
});
test('bad or oversized panel insets leave finite values and at least 80 px of visible map', () => {
  const size = { width: 390, height: 844 };
  const padding = resolveMapViewportInsets(size, { top: 2000, bottom: 10_000, left: Number.MAX_VALUE, right: Number.MAX_VALUE });
  assert.ok(Object.values(padding).every(value => Number.isFinite(value) && value >= 0));
  assert.ok(size.width - padding.left - padding.right >= 80 - 1e-8); assert.ok(size.height - padding.top - padding.bottom >= 80 - 1e-8);
  assert.deepEqual(resolveMapViewportInsets(size, { top: NaN, bottom: Infinity, left: -12, right: -Infinity }), { top: 0, right: 0, bottom: 0, left: 0 });
  assert.deepEqual(resolveMapViewportInsets({ width: 50, height: 60 }, { top: 300, right: 300, bottom: 300, left: 300 }), { top: 0, right: 0, bottom: 0, left: 0 });
});
test('route fitting keeps the whole leg inside the portion not covered by panels', () => {
  const size = { width: 390, height: 844 }, insets = resolveMapViewportInsets(size, { top: 120 + 16, right: 64 + 16, bottom: 360 + 16, left: 16 });
  const route = [origin, { lat: 51.132, lon: 71.436 }, { lat: 51.129, lon: 71.44 }];
  const view = fitMapPoints(route, size, { padding: insets });
  for (const coordinate of route) {
    const point = pointOnMap(coordinate, view, size);
    assert.ok(point.x >= insets.left - 1e-6 && point.x <= size.width - insets.right + 1e-6);
    assert.ok(point.y >= insets.top - 1e-6 && point.y <= size.height - insets.bottom + 1e-6);
  }
});
const size = { width: 800, height: 600 }, view = { center: origin, zoom: 15 };
function poiAt(id: string, x: number, y: number, category = 'cafe', name = `Place ${id}`) { return { id, ...coordinateAtMapPixel(x, y, view, size), category, name }; }
test('viewport sampling retains rare categories after many café records and is row-order independent', () => {
  const cafes = Array.from({ length: 100 }, (_, i) => poiAt(`c${i}`, 60 + i % 10 * 68, 80 + Math.floor(i / 10) * 47));
  const park = poiAt('park-last-row', 718, 510, 'park', 'Named park');
  const input = [...cafes, park];
  const sampled = balancedViewportPOIs(input, view, size, 15);
  assert.ok(sampled.some(poi => poi.id === park.id)); assert.ok(sampled.some(poi => poi.category === 'cafe'));
  assert.ok(sampled.length <= 15);
  assert.deepEqual(sampled.map(poi => poi.id), balancedViewportPOIs([...input].reverse(), view, size, 15).map(poi => poi.id));
});
test('spatial selection spreads markers and excludes outside/invalid points', () => {
  const grid = [100, 300, 500, 700].flatMap((x, i) => [100, 300, 500].map((y, j) => poiAt(`${i}-${j}`, x, y)));
  const input = [...grid, poiAt('outside', -10, 100), { ...grid[0], id: 'invalid', lat: NaN }];
  const selected = balancedViewportPOIs(input, view, size, 8), positions = selected.map(poi => pointOnMap(poi, view, size));
  assert.equal(selected.length, 8); assert.ok(!selected.some(poi => ['outside', 'invalid'].includes(poi.id)));
  assert.ok(Math.max(...positions.map(p => p.x)) - Math.min(...positions.map(p => p.x)) > 500);
  assert.ok(Math.max(...positions.map(p => p.y)) - Math.min(...positions.map(p => p.y)) > 300);
  for (let i = 0; i < positions.length; i++) for (let j = i + 1; j < positions.length; j++) assert.ok(Math.hypot(positions[i].x - positions[j].x, positions[i].y - positions[j].y) >= 44);
});
test('same-cell discovery prefers a named record over a generated OSM label', () => {
  const generic = poiAt('generic', 200, 200, 'park', 'Парк — OSM 7'), named = poiAt('named', 205, 205, 'park', 'Сквер шахматистов');
  assert.deepEqual(balancedViewportPOIs([generic, named], view, size, 10).map(poi => poi.id), ['named']);
  assert.deepEqual(balancedViewportPOIs([named, generic], view, size, 10).map(poi => poi.id), ['named']);
});
