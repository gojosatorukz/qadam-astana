import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { createEmptyPassport, PASSPORT_STORAGE_KEY, readPassport, writePassport, resetPassport, validatePassport, recordCompletedWalk, updatePlacePreference, getPassportStats, getVisitedPoiIds, getPlacePreference, scoreLocalPOI, recommendationSnapshot, validateRecommendationSnapshot, rerankPlanOptions } from '../lib/passport.ts';
import type { PassportState, PassportStorage, WalkCompletion } from '../lib/passport-types';
import type { POI, RoutePlan } from '../lib/qadam-types';

const NOW=Date.parse('2026-10-20T12:00:00Z');
const A='osm-node-100',B='osm-node-200',C='osm-way-300';
const catalog=[{id:A,category:'park'},{id:B,category:'food'},{id:C,category:'museum'}];
const walk=(overrides:Partial<WalkCompletion>={}):WalkCompletion=>({walkId:'walk-test-0001',visitedPoiIds:[A],minutes:15,completedAt:new Date(NOW).toISOString(),...overrides});
function completed(event=walk()):PassportState {const result=recordCompletedWalk(createEmptyPassport(),event,catalog,NOW);assert.equal(result.result.ok,true);return result.passport;}
class MemoryStorage implements PassportStorage {
  values=new Map<string,string>();failure:'quota'|'blocked'|null=null;
  getItem(key:string){if(this.failure==='blocked')throw new Error('Blocked');return this.values.get(key)??null;}
  setItem(key:string,value:string){if(this.failure==='quota')throw new DOMException('Full','QuotaExceededError');if(this.failure==='blocked')throw new Error('Blocked');this.values.set(key,value);}
  removeItem(key:string){if(this.failure)throw new Error('Blocked');this.values.delete(key);}
}
const poi=(id:string,category='park'):POI=>({id,category,name:'Public place',lat:51.13,lon:71.43,tags:{},description:'',openingHours:null,website:null,sourceUrl:'https://www.openstreetmap.org/node/100',fetchedAt:'2026-10-20T00:00:00Z',indoor:null,wheelchair:null});
function option(id:string,ids:string[],minutes=45) {
 const plan:RoutePlan={title:id,summary:'',stops:ids.map(id=>({poi:poi(id),visitMinutes:12,travelMinutes:5,why:'Source reason',activity:'Walk',hoursStatus:'unknown' as const})),totalMinutes:minutes,walkingMinutes:18,visitMinutes:24,bufferMinutes:3,distanceMeters:1260,returnMinutes:8,routeKind:'walking',routeCoordinates:[[71.43,51.13],[71.44,51.13]]};
 return {id,label:id,tradeoff:'45 min',plan};
}

test('empty local passport has honest zero progress and neutral recommendations',()=>{
 const passport=createEmptyPassport(),stats=getPassportStats(passport);
 assert.equal(stats.xp,0);assert.equal(stats.completedWalks,0);assert.equal(stats.uniquePlaces,0);assert.equal(stats.minutes,0);assert.equal(stats.level,1);assert.equal(stats.progress,0);
 assert.equal(scoreLocalPOI(poi(A),passport),0);assert.deepEqual(readPassport(new MemoryStorage()).passport,passport);
});
test('completion awards progress once per walk and once per new canonical public place',()=>{
 let passport=completed();assert.equal(getPassportStats(passport).xp,30);
 const replay=recordCompletedWalk(passport,walk({visitedPoiIds:[B],minutes:90}),catalog,NOW);
 assert.deepEqual(replay.result,{ok:true,changed:false});assert.equal(replay.passport,passport);assert.equal(getPassportStats(replay.passport).xp,30);
 passport=recordCompletedWalk(passport,walk({walkId:'walk-test-0002',visitedPoiIds:[A,B]}),catalog,NOW).passport;
 const stats=getPassportStats(passport);assert.equal(stats.xp,60);assert.equal(stats.completedWalks,2);assert.equal(stats.uniquePlaces,2);assert.equal(stats.level,2);assert.equal(stats.minutes,30);
});
test('zero-minute completion is not fabricated into one minute and yields no empty-walk XP',()=>{
 const passport=completed(walk({minutes:0,visitedPoiIds:[]})),stats=getPassportStats(passport);
 assert.equal(stats.completedWalks,1);assert.equal(stats.minutes,0);assert.equal(stats.xp,0);assert.equal(stats.uniquePlaces,0);
});
test('reviewed museum node and way aliases make one place stamp and one preference',()=>{
 const node='osm-node-4894937300',way='osm-way-1381418247';
 let passport=recordCompletedWalk(createEmptyPassport(),walk({visitedPoiIds:[node,way]}),[],NOW).passport;
 assert.equal(passport.walks[0].visitedPoiIds.length,1);assert.equal(getPassportStats(passport).uniquePlaces,1);assert.equal(getPassportStats(passport).xp,30);
 passport=updatePlacePreference(passport,node,{rating:5,avoid:false}).passport;
 passport=updatePlacePreference(passport,way,{rating:1,avoid:true}).passport;
 assert.equal(Object.keys(passport.placePreferences).length,1);assert.equal(getPlacePreference(passport,node)?.rating,1);assert.equal(scoreLocalPOI(poi(node,'museum'),passport),-6);
});
test('feedback and repeated public IDs never mint visits or XP',()=>{
 let passport=createEmptyPassport();passport=updatePlacePreference(passport,A,{sentiment:'liked',avoid:false},catalog).passport;
 assert.equal(getPassportStats(passport).xp,0);assert.deepEqual(getVisitedPoiIds(passport),[]);
 const premature=updatePlacePreference(passport,A,{rating:5},catalog);assert.deepEqual(premature.result,{ok:false,error:'not-visited'});
 passport=recordCompletedWalk(passport,walk({visitedPoiIds:[A,A]}),catalog,NOW).passport;
 assert.equal(passport.walks[0].visitedPoiIds.length,1);const before=getPassportStats(passport).xp;
 passport=updatePlacePreference(passport,A,{rating:5},catalog).passport;assert.equal(getPassportStats(passport).xp,before);
});
test('ratings and completion changes are immutable, including result nested records',()=>{
 const input=createEmptyPassport(),event=walk();const before=JSON.stringify({input,event});
 const output=recordCompletedWalk(input,event,catalog,NOW);output.passport.walks[0].visitedPoiIds.push(B);
 assert.equal(JSON.stringify({input,event}),before);
 const passport=completed(),rating=updatePlacePreference(passport,A,{rating:4,avoid:true},catalog);assert.deepEqual(passport.placePreferences,{});assert.ok(rating.passport!==passport);
});
test('completion shape rejects raw coordinates, personal data and malformed timestamps/IDs',()=>{
 for(const event of [walk({visitedPoiIds:['person@example.com']}),walk({walkId:'home@address'}),walk({minutes:NaN}),walk({minutes:-1}),walk({minutes:1441}),walk({completedAt:'2026-02-31T12:00:00Z'}),walk({completedAt:'2026-10-20T12:00:00'}),walk({completedAt:new Date(NOW+300001).toISOString()}),{...walk(),lat:51.1},{...walk(),query:'my home'},{...walk(),gps:[[71.4,51.1]]}]) {
  const passport=createEmptyPassport(),result=recordCompletedWalk(passport,event,catalog,NOW);assert.equal(result.result.ok,false);assert.equal(result.passport,passport);
 }
});
test('strict stored schema rejects unknown fields and invalid rating/weight/counter payloads',()=>{
 const good=completed();assert.ok(validatePassport(good));
 for(const value of [{...good,version:2},{...good,home:{lat:51,lon:71}},{...good,email:'x@y.kz'},{...good,walks:[...good.walks,...good.walks]},{...good,interestWeights:{park:7}},{...good,interestWeights:{home:1}},{...good,placePreferences:{[A]:{avoid:false,rating:6}}},{...good,placePreferences:{[A]:{avoid:false,query:'private'}}},{...createEmptyPassport(),placePreferences:{[A]:{avoid:false,rating:5}}}])assert.equal(validatePassport(value),null);
});
test('corrupt/unknown/oversized browser storage is not used or silently overwritten',()=>{
 const storage=new MemoryStorage();
 for(const raw of ['broken-json','null','[]','{"version":99}','x'.repeat(512001)]) {
  storage.values.set(PASSPORT_STORAGE_KEY,raw);const view=readPassport(storage);assert.equal(view.status,'corrupt');assert.equal(view.error,'corrupt-data');assert.equal(getPassportStats(view.passport).xp,0);assert.equal(storage.values.get(PASSPORT_STORAGE_KEY),raw);
 }
});
test('quota and denied storage are explicit failures; an earlier saved passport survives',()=>{
 const storage=new MemoryStorage(),passport=completed();assert.equal(writePassport(storage,passport).ok,true);const old=storage.values.get(PASSPORT_STORAGE_KEY);
 storage.failure='quota';assert.deepEqual(writePassport(storage,createEmptyPassport()),{ok:false,error:'storage-full'});assert.equal(storage.values.get(PASSPORT_STORAGE_KEY),old);
 storage.failure='blocked';assert.equal(readPassport(storage).error,'storage-unavailable');assert.equal(writePassport(storage,passport).ok,false);assert.equal(resetPassport(storage).ok,false);
 assert.equal(readPassport(null).status,'unavailable');assert.equal(writePassport(null,passport).ok,false);
});
test('reset removes every passport impression/history/weight and leaves unrelated favorites alone',()=>{
 const storage=new MemoryStorage();let passport=completed();passport=updatePlacePreference(passport,A,{rating:5,avoid:true},catalog).passport;
 writePassport(storage,passport);storage.values.set('qadam:saved','["osm-node-200"]');assert.equal(resetPassport(storage).ok,true);
 assert.equal(storage.getItem(PASSPORT_STORAGE_KEY),null);assert.equal(storage.getItem('qadam:saved'),'["osm-node-200"]');assert.deepEqual(readPassport(storage).passport,createEmptyPassport());
});
test('category habits come only from confirmed visited places, not unvisited feedback',()=>{
 let passport=updatePlacePreference(createEmptyPassport(),B,{sentiment:'liked',avoid:false},catalog).passport;assert.deepEqual(passport.interestWeights,{});
 passport=recordCompletedWalk(passport,walk({visitedPoiIds:[A]}),catalog,NOW).passport;assert.ok(passport.interestWeights.park>0);assert.equal(passport.interestWeights.food,undefined);
 passport=updatePlacePreference(passport,A,{sentiment:'disliked',rating:1,avoid:true},catalog).passport;assert.ok(passport.interestWeights.park<0);assert.ok(Math.abs(passport.interestWeights.park)<=3);
});
test('personal scores are bounded soft preferences and OFF returns exact neutral',()=>{
 let passport=completed();passport=updatePlacePreference(passport,A,{rating:1,sentiment:'disliked',avoid:true},catalog).passport;
 assert.equal(scoreLocalPOI(poi(A),passport),-6);assert.equal(scoreLocalPOI(poi(A),{...passport,personalizationEnabled:false}),0);
 passport=updatePlacePreference(passport,A,{rating:5,sentiment:'liked',avoid:false},catalog).passport;assert.equal(scoreLocalPOI(poi(A),passport),6);
 assert.equal(scoreLocalPOI(poi(B,'food'),passport),0);
});
test('worker recommendation snapshot excludes all walk IDs/times/history and makes defensive copies',()=>{
 let passport=completed();passport=updatePlacePreference(passport,A,{rating:5,avoid:false},catalog).passport;
 const snapshot=recommendationSnapshot(passport),serialized=JSON.stringify(snapshot);assert.deepEqual(Object.keys(snapshot).sort(),['interestWeights','personalizationEnabled','placePreferences']);
 for(const forbidden of ['walkId','minutes','completedAt','visitedPoiIds','lat','lon','query','email'])assert.ok(!serialized.includes('"'+forbidden+'"'));
 snapshot.placePreferences[A].rating=1;snapshot.interestWeights.park=-3;assert.equal(passport.placePreferences[A].rating,5);assert.ok(passport.interestWeights.park>0);
 assert.ok(validateRecommendationSnapshot(recommendationSnapshot(passport)));assert.equal(validateRecommendationSnapshot({...snapshot,walks:passport.walks}),null);assert.equal(validateRecommendationSnapshot({...snapshot,interestWeights:{park:99}}),null);
});
test('reranking preserves every option/plan, hard budget and source object; only order changes',()=>{
 const options=[option('low',[A]),option('neutral',[B]),option('liked',[C])],before=JSON.stringify(options);
 let passport=completed(walk({visitedPoiIds:[A,C]}));passport=updatePlacePreference(passport,A,{rating:1,avoid:true},catalog).passport;passport=updatePlacePreference(passport,C,{rating:5,avoid:false},catalog).passport;
 const ranked=rerankPlanOptions(options,passport);assert.deepEqual(ranked.map(o=>o.id),['liked','neutral','low']);assert.equal(ranked[0],options[2]);assert.equal(ranked.length,options.length);assert.equal(JSON.stringify(options),before);assert.ok(ranked.every(o=>o.plan.totalMinutes===45));
});
test('no preferences/OFF/ties retain original order; required POI cannot be bypassed',()=>{
 const options=[option('first',[A]),option('second',[B])];assert.deepEqual(rerankPlanOptions(options,createEmptyPassport()),options);
 let passport=completed(walk({visitedPoiIds:[B]}));passport=updatePlacePreference(passport,B,{rating:5,avoid:false},catalog).passport;
 assert.deepEqual(rerankPlanOptions(options,passport,{requiredPoiId:A}),options);assert.deepEqual(rerankPlanOptions(options,passport,{enabled:false}),options);assert.deepEqual(rerankPlanOptions(options,{...passport,personalizationEnabled:false}),options);
 const required=[option('one',[A,B]),option('two',[A,C])];const ranked=rerankPlanOptions(required,passport,{requiredPoiId:A});assert.ok(ranked.every(o=>o.plan.stops.some(s=>s.poi.id===A)));
});
test('stored serialized state contains only public IDs, private impressions and completion statistics',()=>{
 const storage=new MemoryStorage(),passport=completed();assert.equal(writePassport(storage,passport).ok,true);const raw=storage.getItem(PASSPORT_STORAGE_KEY)!;
 assert.ok(!raw.includes('51.13')&&!raw.includes('71.43')&&!raw.includes('Public place'));assert.deepEqual(readPassport(storage).passport,passport);
 const invalid={...passport,poi:poi(A)};assert.equal(writePassport(storage,invalid).ok,false);
});
