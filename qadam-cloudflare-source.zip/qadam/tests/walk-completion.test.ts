import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { createWalkGuide, createGuideProgress, updateWalkGuide, confirmGuideLeg } from '../lib/walk-guide.ts';
// @ts-expect-error Native Node TS source extensions.
import { canConfirmWalkArrival, confirmWalkAchievement, createWalkAchievements, startWalkAchievements } from '../lib/walk-completion.ts';
import type { GuideFix, GuidePoint, GuideProgress, SupportedWalkGuide } from '../lib/walk-guide';
import type { PlanStop } from '../lib/qadam-types';

const NOW=1_800_000_000_000,A:GuidePoint=[71.43,51.128];
const point=(east:number):GuidePoint=>[A[0]+east/(111_195*Math.cos(A[1]*Math.PI/180)),A[1]];
const fix=(east:number,timestamp=NOW,accuracy=5):GuideFix=>({lon:point(east)[0],lat:A[1],accuracy,timestamp});
function guide():SupportedWalkGuide{
  const p=point(100),stop={poi:{id:'node/42',name:'Public place',lat:p[1],lon:p[0]}} as PlanStop;
  const result=createWalkGuide({routeKind:'walking',routeCoordinates:[A,p,point(200)],stops:[stop],legEndIndices:[1,2]});
  assert.ok(result.supported);return result;
}
function arrive(g:SupportedWalkGuide,state:GuideProgress,from:number,to:number,start=NOW){
  let result=updateWalkGuide(g,state,fix(from,start),{nowMs:start});
  for(let x=from+10;x<=to;x+=10)result=updateWalkGuide(g,result.state,fix(x,start+(x-from)*1000),{nowMs:start+(x-from)*1000});
  assert.equal(result.canConfirmArrival,true);return result;
}
test('preview/manual finish and a teleport to the endpoint cannot complete a walk',()=>{
  const g=guide(),state=createWalkAchievements('stable-id'),arrival=arrive(g,createGuideProgress(),0,100);
  assert.equal(confirmWalkAchievement(state,{guide:g,update:arrival,fix:fix(100,NOW+100_000),nowMs:NOW+100_000,poiId:'node/42'}).accepted,false);
  const jumped=updateWalkGuide(g,createGuideProgress(),fix(100,NOW+1000),{nowMs:NOW+1000});
  assert.equal(canConfirmWalkArrival(g,jumped,fix(100,NOW+1000),NOW+1000),false);
});
test('confirmation rechecks actual fix age, accuracy and matching endpoint/progress at click time',()=>{
  const g=guide(),arrival=arrive(g,createGuideProgress(),0,100),current=fix(100,NOW+100_000);
  assert.equal(canConfirmWalkArrival(g,arrival,current,NOW+100_000),true);
  assert.equal(canConfirmWalkArrival(g,arrival,current,NOW+120_001),false);
  assert.equal(canConfirmWalkArrival(g,arrival,{...current,accuracy:26},NOW+100_000),false);
  assert.equal(canConfirmWalkArrival(g,arrival,{...current,lat:NaN},NOW+100_000),false);
  assert.equal(canConfirmWalkArrival(g,{...arrival,state:{...arrival.state,meters:0}},current,NOW+100_000),false);
  assert.equal(canConfirmWalkArrival(g,arrival,{...current,timestamp:current.timestamp+1},NOW+100_000),false);
});
test('only confirmed public POIs and final GPS arrival emit one location-free completion with stable identity',()=>{
  const g=guide(),start=startWalkAchievements(createWalkAchievements('stable-id'),NOW),stopArrival=arrive(g,createGuideProgress(),0,100);
  const stop=confirmWalkAchievement(start,{guide:g,update:stopArrival,fix:fix(100,NOW+100_000),nowMs:NOW+100_000,poiId:'node/42'});
  assert.equal(stop.accepted,true);assert.equal(stop.completion,undefined);assert.deepEqual(stop.state.visitedPoiIds,['node/42']);
  assert.equal(confirmWalkAchievement(start,{guide:g,update:stopArrival,fix:fix(100,NOW+100_000),nowMs:NOW+100_000,poiId:'node/other'}).accepted,false);
  const resumed=startWalkAchievements(stop.state,NOW+110_000);assert.equal(resumed.startedAt,NOW);assert.equal(resumed.walkId,'stable-id');
  const final=arrive(g,confirmGuideLeg(g,stopArrival.state),100,200,NOW+110_000),lastFix=fix(200,NOW+210_000);
  const done=confirmWalkAchievement(resumed,{guide:g,update:final,fix:lastFix,nowMs:NOW+210_000});
  assert.deepEqual(done.completion,{walkId:'stable-id',visitedPoiIds:['node/42'],minutes:4,completedAt:new Date(NOW+210_000).toISOString()});
  assert.deepEqual(Object.keys(done.completion!).sort(),['completedAt','minutes','visitedPoiIds','walkId']);
  assert.equal(confirmWalkAchievement(done.state,{guide:g,update:final,fix:lastFix,nowMs:NOW+210_001}).accepted,false);
});
