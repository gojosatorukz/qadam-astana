import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { createWalkGuide, createGuideProgress, updateWalkGuide, confirmGuideLeg } from '../lib/walk-guide.ts';
// @ts-expect-error Native Node TS source extensions.
import { canConfirmWalkArrival, confirmWalkAchievement, createWalkAchievements, startWalkAchievements } from '../lib/walk-completion.ts';
// @ts-expect-error Native Node TS source extensions.
import { createEmptyPassport, recordCompletedWalk, getPassportStats } from '../lib/passport.ts';
import type { GuideFix, GuidePoint, GuideProgress, SupportedWalkGuide } from '../lib/walk-guide';
import type { PlanStop } from '../lib/qadam-types';

const NOW=1_800_000_000_000,A:GuidePoint=[71.43,51.128];
const point=(east:number):GuidePoint=>[A[0]+east/(111_195*Math.cos(A[1]*Math.PI/180)),A[1]];
const fix=(east:number,timestamp=NOW,accuracy=5):GuideFix=>({lon:point(east)[0],lat:A[1],accuracy,timestamp});
function guide():SupportedWalkGuide{
  const p=point(100),stop={poi:{id:'node/42',name:'Public place',lat:p[1],lon:p[0]}} as PlanStop;
  const result=createWalkGuide({routeKind:'walking',routeCoordinates:[A,p,point(200)],stops:[stop],legEndIndices:[1,2]});
  assert.ok(result.supported);return result;
}
function arrive(g:SupportedWalkGuide,state:GuideProgress,from:number,to:number,start=NOW){
  let result=updateWalkGuide(g,state,fix(from,start),{nowMs:start});
  for(let x=from+10;x<=to;x+=10)result=updateWalkGuide(g,result.state,fix(x,start+(x-from)*1000),{nowMs:start+(x-from)*1000});
  assert.equal(result.canConfirmArrival,true);return result;
}
test('preview/manual finish and a teleport to the endpoint cannot complete a walk',()=>{
  const g=guide(),state=createWalkAchievements('stable-id'),arrival=arrive(g,createGuideProgress(),0,100);
  assert.equal(confirmWalkAchievement(state,{guide:g,update:arrival,fix:fix(100,NOW+100_000),nowMs:NOW+100_000,poiId:'node/42'}).accepted,false);
  const jumped=updateWalkGuide(g,createGuideProgress(),fix(100,NOW+1000),{nowMs:NOW+1000});
  assert.equal(canConfirmWalkArrival(g,jumped,fix(100,NOW+1000),NOW+1000),false);
});
test('confirmation rechecks actual fix age, accuracy and matching endpoint/progress at click time',()=>{
  const g=guide(),arrival=arrive(g,createGuideProgress(),0,100),current=fix(100,NOW+100_000);
  assert.equal(canConfirmWalkArrival(g,arrival,current,NOW+100_000),true);
  assert.equal(canConfirmWalkArrival(g,arrival,current,NOW+120_001),false);
  assert.equal(canConfirmWalkArrival(g,arrival,{...current,accuracy:26},NOW+100_000),false);
  assert.equal(canConfirmWalkArrival(g,arrival,{...current,lat:NaN},NOW+100_000),false);
  assert.equal(canConfirmWalkArrival(g,{...arrival,state:{...arrival.state,meters:0}},current,NOW+100_000),false);
  assert.equal(canConfirmWalkArrival(g,arrival,{...current,timestamp:current.timestamp+1},NOW+100_000),false);
});
test('only confirmed public POIs and final GPS arrival emit one location-free completion with stable identity',()=>{
  const g=guide(),start=startWalkAchievements(createWalkAchievements('stable-id'),NOW),stopArrival=arrive(g,createGuideProgress(),0,100);
  const stop=confirmWalkAchievement(start,{guide:g,update:stopArrival,fix:fix(100,NOW+100_000),nowMs:NOW+100_000,poiId:'node/42'});
  assert.equal(stop.accepted,true);assert.equal(stop.completion,undefined);assert.deepEqual(stop.state.visitedPoiIds,['node/42']);
  assert.equal(confirmWalkAchievement(start,{guide:g,update:stopArrival,fix:fix(100,NOW+100_000),nowMs:NOW+100_000,poiId:'node/other'}).accepted,false);
  const resumed=startWalkAchievements(stop.state,NOW+110_000);assert.equal(resumed.startedAt,NOW);assert.equal(resumed.walkId,'stable-id');
  const final=arrive(g,confirmGuideLeg(g,stopArrival.state),100,200,NOW+110_000),lastFix=fix(200,NOW+210_000);
  const done=confirmWalkAchievement(resumed,{guide:g,update:final,fix:lastFix,nowMs:NOW+210_000});
  assert.deepEqual(done.completion,{walkId:'stable-id',visitedPoiIds:['node/42'],minutes:3,completedAt:new Date(NOW+210_000).toISOString()});
  assert.deepEqual(Object.keys(done.completion!).sort(),['completedAt','minutes','visitedPoiIds','walkId']);
  assert.equal(confirmWalkAchievement(done.state,{guide:g,update:final,fix:lastFix,nowMs:NOW+210_001}).accepted,false);
});
test('real completion never rounds sub-minute elapsed time across the walk-XP threshold',()=>{
  const direct=createWalkGuide({routeKind:'walking',routeCoordinates:[A,point(20)],stops:[],legEndIndices:[1]});
  assert.ok(direct.supported);
  for(const elapsed of [29_999,30_000,35_000,59_999,60_000]){
    const first=updateWalkGuide(direct,createGuideProgress(),fix(0,NOW),{nowMs:NOW});
    const middleAt=NOW+Math.floor(elapsed/3),middle=updateWalkGuide(direct,first.state,fix(10,middleAt),{nowMs:middleAt});
    const last=fix(20,NOW+elapsed),arrival=updateWalkGuide(direct,middle.state,last,{nowMs:NOW+elapsed});
    const state=startWalkAchievements(createWalkAchievements('walk-duration-'+elapsed),NOW);
    const confirmed=confirmWalkAchievement(state,{guide:direct,update:arrival,fix:last,nowMs:NOW+elapsed});
    assert.equal(confirmed.accepted,true);assert.ok(confirmed.completion);
    assert.equal(confirmed.completion.minutes,elapsed<60_000?0:1,`elapsed ${elapsed}ms`);
    const saved=recordCompletedWalk(createEmptyPassport(),confirmed.completion,[],NOW+elapsed);
    assert.equal(saved.result.ok,true);assert.equal(getPassportStats(saved.passport).xp,elapsed<60_000?0:20,`elapsed ${elapsed}ms`);
    const duplicate=recordCompletedWalk(saved.passport,confirmed.completion,[],NOW+elapsed);
    assert.deepEqual(duplicate.result,{ok:true,changed:false});assert.equal(getPassportStats(duplicate.passport).xp,getPassportStats(saved.passport).xp);
    assert.equal(confirmWalkAchievement(confirmed.state,{guide:direct,update:arrival,fix:last,nowMs:NOW+elapsed}).accepted,false);
    assert.equal(confirmWalkAchievement(createWalkAchievements('preview-'+elapsed),{guide:direct,update:arrival,fix:last,nowMs:NOW+elapsed}).completion,undefined);
  }
});
test('a GPS-confirmed new POI keeps its separate XP even during a sub-minute completed walk',()=>{
  const at=point(10),poiId='osm-node-4242',stop={poi:{id:poiId,name:'Public place',lat:at[1],lon:at[0]}} as PlanStop;
  const route=createWalkGuide({routeKind:'walking',routeCoordinates:[A,at,point(20)],stops:[stop],legEndIndices:[1,2]});
  assert.ok(route.supported);
  const initial=updateWalkGuide(route,createGuideProgress(),fix(0,NOW),{nowMs:NOW});
  const atStop=updateWalkGuide(route,initial.state,fix(10,NOW+5000),{nowMs:NOW+5000});
  const visited=confirmWalkAchievement(startWalkAchievements(createWalkAchievements('walk-short-place'),NOW),{guide:route,update:atStop,fix:fix(10,NOW+5000),nowMs:NOW+5000,poiId});
  assert.equal(visited.accepted,true);assert.deepEqual(visited.state.visitedPoiIds,[poiId]);
  const next=updateWalkGuide(route,confirmGuideLeg(route,atStop.state),fix(10,NOW+6000),{nowMs:NOW+6000});
  const final=updateWalkGuide(route,next.state,fix(20,NOW+35_000),{nowMs:NOW+35_000});
  const done=confirmWalkAchievement(visited.state,{guide:route,update:final,fix:fix(20,NOW+35_000),nowMs:NOW+35_000});
  assert.ok(done.completion);assert.equal(done.completion.minutes,0);
  const saved=recordCompletedWalk(createEmptyPassport(),done.completion,[],NOW+35_000);
  assert.equal(saved.result.ok,true);assert.equal(getPassportStats(saved.passport).xp,10);assert.equal(getPassportStats(saved.passport).uniquePlaces,1);
  const revisit=recordCompletedWalk(saved.passport,{...done.completion,walkId:'walk-short-revisit'},[],NOW+35_000);
  assert.equal(getPassportStats(revisit.passport).xp,10);assert.equal(getPassportStats(revisit.passport).uniquePlaces,1);
});
