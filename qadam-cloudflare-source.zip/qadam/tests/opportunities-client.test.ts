import assert from'node:assert/strict';
import test from'node:test';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{createOpportunityClient}from'../lib/opportunities-client.ts';
import type{OpportunityWorker}from'../lib/opportunities-client';
import type{OpportunityRequest,OpportunityResult}from'../lib/opportunities';
class FakeWorker implements OpportunityWorker{
 onmessage:OpportunityWorker['onmessage']=null;onerror:OpportunityWorker['onerror']=null;onmessageerror:OpportunityWorker['onmessageerror']=null;requests:{id:number;request:OpportunityRequest}[]=[];terminations=0;
 postMessage(value:unknown){this.requests.push(value as typeof this.requests[number]);}terminate(){this.terminations++;}
 reply(id:number,result:unknown){this.onmessage?.call(this as unknown as Worker,{data:{type:'opportunities-result',id,result}}as MessageEvent);}
}
const request:OpportunityRequest={origin:{lat:51.128,lon:71.43,label:'A'},minutes:45,interests:['food'],indoor:false,knownHoursOnly:false,accessible:false,language:'en'};
const result=(minutes=45):OpportunityResult=>({kind:'ready',places:[],minutes,computedAt:'2026-10-20T12:00:00Z',departureAt:'2026-10-20T12:00:00Z',dataset:{count:1204,source:'OpenStreetMap',fetchedAt:'2026-10-20T00:00:00Z'},diagnostics:{searches:1,contextReused:false,evaluated:1204}});
const flush=async()=>{for(let i=0;i<10;i++)await Promise.resolve();};
function harness(timeoutMs=1000){const workers:FakeWorker[]=[];return{workers,client:createOpportunityClient({timeoutMs,workerFactory:()=>{const worker=new FakeWorker();workers.push(worker);return worker;}})};}
test('live requests lazily reuse one worker until explicit disposal',async()=>{
 const{client,workers}=harness();assert.equal(workers.length,0);const first=client.compute(request);await flush();assert.equal(workers.length,1);workers[0].reply(workers[0].requests[0].id,result());assert.equal((await first).ok,true);
 const second=client.compute({...request,minutes:60});await flush();assert.equal(workers.length,1);workers[0].reply(workers[0].requests[1].id,result(60));assert.equal((await second).ok,true);assert.equal(workers[0].terminations,0);client.dispose();assert.equal(workers[0].terminations,1);assert.deepEqual(await client.compute(request),{ok:false,reason:'disposed'});
});
test('superseded slider replies cannot overwrite the current budget',async()=>{
 const{client,workers}=harness();const first=client.compute(request);await flush();const firstId=workers[0].requests[0].id;const second=client.compute({...request,minutes:60});assert.deepEqual(await first,{ok:false,reason:'superseded'});await flush();let complete=false;void second.then(()=>{complete=true;});workers[0].reply(firstId,result());await flush();assert.equal(complete,false);workers[0].reply(workers[0].requests[1].id,result(60));assert.equal((await second).ok,true);client.dispose();
});
test('cancelling a request preserves the cached worker and ignores the cancelled reply',async()=>{
 const{client,workers}=harness(),controller=new AbortController();const first=client.compute(request,{signal:controller.signal});await flush();controller.abort();assert.deepEqual(await first,{ok:false,reason:'cancelled'});assert.equal(workers[0].terminations,0);
 const second=client.compute({...request,minutes:30});await flush();workers[0].reply(workers[0].requests[0].id,result());workers[0].reply(workers[0].requests[1].id,result(30));assert.equal((await second).ok,true);client.dispose();
});
test('one lazy factory serves rapid input changes; disposing terminates a late worker',async()=>{
 let resolve:((worker:FakeWorker)=>void)|null=null,calls=0;const client=createOpportunityClient({workerFactory:()=>{calls++;return new Promise<FakeWorker>(done=>{resolve=done;});}});
 const first=client.compute(request),second=client.compute({...request,minutes:60});assert.deepEqual(await first,{ok:false,reason:'superseded'});const worker=new FakeWorker();resolve!(worker);await flush();assert.equal(calls,1);assert.equal(worker.requests.length,1);assert.equal(worker.requests[0].request.minutes,60);worker.reply(worker.requests[0].id,result(60));await second;client.dispose();
 let finish:((worker:FakeWorker)=>void)|null=null;const other=createOpportunityClient({workerFactory:()=>new Promise<FakeWorker>(done=>{finish=done;})});const pending=other.compute(request);other.dispose();assert.deepEqual(await pending,{ok:false,reason:'cancelled'});const late=new FakeWorker();finish!(late);await flush();assert.equal(late.terminations,1);assert.equal(late.requests.length,0);
});
test('timeout and invalid replies terminate the worker while safe stage failures can retry',async()=>{
 const timed=harness(5);assert.deepEqual(await timed.client.compute(request),{ok:false,reason:'timeout'});assert.equal(timed.workers[0].terminations,1);timed.client.dispose();
 const{client,workers}=harness();const first=client.compute(request);await flush();workers[0].reply(workers[0].requests[0].id,result(60));assert.deepEqual(await first,{ok:false,reason:'invalid-reply'});assert.equal(workers[0].terminations,1);
 const second=client.compute(request);await flush();workers[1].onmessage?.call(workers[1]as unknown as Worker,{data:{type:'opportunities-error',id:workers[1].requests[0].id,code:'GRAPH_LOAD'}}as MessageEvent);assert.deepEqual(await second,{ok:false,reason:'worker-error',code:'GRAPH_LOAD'});assert.equal(workers[1].terminations,0);
 const third=client.compute(request);await flush();workers[1].onmessage?.call(workers[1]as unknown as Worker,{data:{type:'opportunities-error',id:workers[1].requests[1].id,code:'raw private query'}}as MessageEvent);assert.deepEqual(await third,{ok:false,reason:'invalid-reply'});client.dispose();
});
