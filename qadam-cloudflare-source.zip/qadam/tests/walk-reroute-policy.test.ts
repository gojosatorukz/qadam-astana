import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { beginOffRouteAttempt, createOffRoutePolicy, finishOffRouteAttempt, observeOffRoute, resetOffRoutePolicy } from '../lib/walk-reroute-policy.ts';
import type { OffRoutePolicyState } from '../lib/walk-reroute-policy';
import type { GuideStatus } from '../lib/walk-guide';
function observe(state: OffRoutePolicyState, nowMs: number, status: GuideStatus = 'off-route', crossTrackMeters = 70, accuracy = 10, timestamp = nowMs) {
  return observeOffRoute(state, { fix: { lat: 51.128, lon: 71.43, accuracy, timestamp }, status, crossTrackMeters, nowMs });
}
function confirmed() {
  let state = createOffRoutePolicy();
  for (const time of [100_000, 103_000]) { const next = observe(state, time); assert.equal(next.shouldReroute, false); state = next.state; }
  const next = observe(state, 106_000); assert.equal(next.shouldReroute, true); return next.state;
}
test('off-route rerouting needs three increasing fresh fixes spanning six observed seconds', () => {
  confirmed();
  let state = createOffRoutePolicy();
  for (const time of [100_000, 101_000, 102_000]) { const next = observe(state, time); assert.equal(next.shouldReroute, false); state = next.state; }
  assert.equal(observe(state, 106_000).shouldReroute, true, 'Frequent fixes must not forever slide a three-item window.');
  state = observe(createOffRoutePolicy(), 100_000).state;
  state = observe(state, 101_000, 'off-route', 70, 10, 106_000).state;
  assert.equal(observe(state, 102_000, 'off-route', 70, 10, 107_000).shouldReroute, false, 'Future-tolerated timestamps cannot fake six elapsed seconds.');
});
test('jitter, same-leg cross-track zero, tracking and poor fixes reset the off-route streak', () => {
  const seed = observe(observe(createOffRoutePolicy(), 100_000).state, 103_000).state;
  for (const [status, distance, accuracy] of [['tracking', 0, 10], ['off-route', 0, 10], ['off-route', 45, 10], ['off-route', 50, 25], ['poor-accuracy', 100, 26], ['off-route', 100, 26], ['stale-fix', 100, 10]] as const) {
    const next = observe(seed, 106_000, status, distance, accuracy);
    assert.equal(next.shouldReroute, false); assert.equal(next.state.qualifyingFixes, 0);
    assert.equal(observe(next.state, 109_000).shouldReroute, false);
  }
});
test('duplicate/out-of-order timestamps and stale or invalid coordinates cannot confirm an attempt', () => {
  const seed = observe(observe(createOffRoutePolicy(), 100_000).state, 103_000).state;
  for (const timestamp of [103_000, 102_000, 80_000, 120_000]) {
    const next = observe(seed, 106_000, 'off-route', 70, 10, timestamp);
    assert.equal(next.shouldReroute, false); assert.equal(next.state.qualifyingFixes, 0); assert.equal(next.state.lastFixTimestamp, 103_000);
  }
  assert.equal(observeOffRoute(seed, { fix: { lat: NaN, lon: 71.43, accuracy: 10, timestamp: 106_000 }, status: 'off-route', crossTrackMeters: 70, nowMs: 106_000 }).shouldReroute, false);
  const afterGap = observe(seed, 130_000); assert.equal(afterGap.shouldReroute, false); assert.equal(afterGap.state.qualifyingFixes, 1);
});
test('one in-flight attempt and a failed attempt both enforce the thirty-second cooldown', () => {
  let state = beginOffRouteAttempt(confirmed(), 106_000);
  assert.equal(state.inFlight, true); assert.equal(state.lastAttemptAt, 106_000);
  for (const time of [109_000, 112_000, 115_000]) { const next = observe(state, time); assert.equal(next.shouldReroute, false); state = next.state; }
  state = finishOffRouteAttempt(state); // failure and success deliberately share this path
  assert.equal(state.inFlight, false); assert.equal(state.lastAttemptAt, 106_000);
  state = resetOffRoutePolicy(state); assert.equal(state.lastAttemptAt, 106_000);
  assert.equal(observe(state, 135_999).shouldReroute, false);
  state = observe(state, 136_000).state;
  state = observe(state, 139_000).state;
  assert.equal(observe(state, 142_000).shouldReroute, true);
});
test('policy operations are immutable and a cancelled session cannot erase its attempt cooldown', () => {
  const original = createOffRoutePolicy(), snapshot = { ...original };
  observe(original, 100_000); assert.deepEqual(original, snapshot);
  const inFlight = beginOffRouteAttempt(confirmed(), 106_000), cancelled = resetOffRoutePolicy(inFlight);
  assert.equal(inFlight.inFlight, true); assert.equal(cancelled.inFlight, false); assert.equal(cancelled.qualifyingFixes, 0);
  assert.equal(cancelled.lastAttemptAt, 106_000); assert.equal(beginOffRouteAttempt(cancelled, 110_000).inFlight, false);
});
