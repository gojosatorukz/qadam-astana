import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Native Node TypeScript requires the explicit source extension.
import { buildPlan } from '../lib/build-plan.ts';
// @ts-expect-error Native Node TypeScript requires the explicit source extension.
import { isPlanResponse as clientGuard } from '../lib/experience.ts';
// @ts-expect-error Native Node TypeScript requires the explicit source extension.
import { isPlanResponse as semanticGuard } from '../lib/plan-validation.ts';
import type { IntentContract, IntentResolution } from '../lib/intent-types';
import type { PlanRequest, POI } from '../lib/qadam-types';

const request: PlanRequest = { query: 'Хочу парк, без кафе', origin: { lat: 51.128, lon: 71.43, label: 'Public A' }, destination: { lat: 51.128, lon: 71.432, label: 'Public B' }, minutes: 90, interests: ['cafe'], indoor: false, knownHoursOnly: true, accessible: true, language: 'ru', now: '2026-10-20T13:00:00+05:00', returnBy: '2026-10-20T14:30:00+05:00', departureMode: 'custom' };
const clock = () => new Date('2026-10-20T12:00:00+05:00');
function poi(category: string, id: string): POI {
  return { id, category, name: `Source ${category}`, lat: 51.128, lon: 71.431, tags: {}, description: 'Source record', openingHours: '24/7', website: null, sourceUrl: 'https://www.openstreetmap.org/node/42', fetchedAt: '2026-10-19T05:00:00Z', indoor: category === 'cafe', wheelchair: 'yes' };
}
const dataset = { pois: [poi('park', 'osm:node:42'), poi('cafe', 'osm:node:43')], fetchedAt: '2026-10-19T05:00:00Z', source: 'OpenStreetMap' };
const contract: IntentContract = { version: 1, desiredCategories: ['park'], excludedCategories: ['cafe'], includeMode: 'any', unsupported: [], needsClarification: false };
const resolve = (value: IntentContract, mode: IntentResolution['mode'] = 'cloudflare'): IntentResolution => ({ mode, contract: value, ms: 12 });
const localEnrichment = async (value: import('../lib/qadam-types').PlanResponse) => value;

for (const [language, query, quote] of [
  ['ru', 'Хочу парк, без кафе', 'без кафе'],
  ['en', 'A park, no cafes', 'no cafes'],
  ['kk', 'Саябақ, кофе емес', 'кофе емес'],
] as const) test(`Cloudflare intent keeps negation and uses the same contract checks as Gemini (${language})`, async () => {
  const current = { ...request, language, query };
  const before = structuredClone(current);
  // A redundant exclusion quote is repaired only because cafe is already excluded.
  const raw: IntentContract = { ...contract, unsupported: [{ text: quote, reason: 'not-supported' }] };
  const response = await buildPlan(current, dataset, { clock, interpret: async () => resolve(raw), enrich: localEnrichment });
  assert.equal(response.intent?.mode, 'cloudflare');
  assert.equal(response.diagnostics?.intent, 'cloudflare');
  assert.equal(response.generationMode, 'retrieval', 'Intent provider must not become an explanation generation mode.');
  assert.deepEqual(response.intent?.contract?.excludedCategories, ['cafe']);
  assert.deepEqual(response.intent?.contract?.unsupported, []);
  assert.equal(response.intent?.status, 'matched');
  assert.deepEqual(response.plan?.stops.map(stop => stop.poi.category), ['park']);
  assert.deepEqual(response.plan?.routeCoordinates.at(-1), [current.destination!.lon, current.destination!.lat]);
  assert.equal(Date.parse(response.returnBy!), Date.parse(current.returnBy!));
  assert.ok(clientGuard(response));
  assert.ok(semanticGuard(response));
  assert.deepEqual(current, before);
});

test('Cloudflare unknown attributes stay visible and cannot become a fully matched claim', async () => {
  const current = { ...request, query: 'Хочу парк с Wi-Fi, без кафе' };
  const value: IntentContract = { ...contract, unsupported: [{ text: 'Wi-Fi', reason: 'no-data' }] };
  const response = await buildPlan(current, dataset, { clock, interpret: async () => resolve(value), enrich: localEnrichment });
  assert.ok(response.plan);
  assert.equal(response.intent?.mode, 'cloudflare');
  assert.equal(response.intent?.status, 'partial');
  assert.deepEqual(response.intent?.contract?.unsupported, value.unsupported);
  assert.ok(response.plan.stops.every(stop => stop.poi.category !== 'cafe'));
});

test('Cloudflare malformed quotes and contradictory categories are rejected before planning', async () => {
  const invalid: IntentContract[] = [
    { ...contract, unsupported: [{ text: 'a phrase the user never wrote', reason: 'no-data' }] },
    { ...contract, desiredCategories: ['cafe'] },
  ];
  for (const value of invalid) {
    let enrichCalls = 0;
    const response = await buildPlan(request, dataset, { clock, interpret: async () => resolve(value), enrich: async result => { enrichCalls++; return result; } });
    assert.equal(response.plan, null);
    assert.equal(response.intent?.mode, 'unavailable');
    assert.equal(response.intent?.failure, 'invalid-output');
    assert.equal(enrichCalls, 0);
  }
});

test('wire guards accept Cloudflare intent provenance while rejecting invented modes', async () => {
  const response = await buildPlan(request, dataset, { clock, interpret: async () => resolve(contract), enrich: localEnrichment });
  for (const guard of [clientGuard, semanticGuard]) {
    assert.equal(guard(response), true);
    assert.equal(guard({ ...response, intent: { ...response.intent, mode: 'invented-provider' } }), false);
    assert.equal(guard({ ...response, diagnostics: { ...response.diagnostics, intent: 'invented-provider' } }), false);
    assert.equal(guard({ ...response, generationMode: 'cloudflare' }), false);
  }
});

test('an unrecognized interpreter mode cannot pass normalization merely with a valid contract', async () => {
  const invalid = { ...resolve(contract), mode: 'retrieval' } as unknown as IntentResolution;
  const response = await buildPlan(request, dataset, { clock, interpret: async () => invalid, enrich: localEnrichment });
  assert.equal(response.plan, null);
  assert.equal(response.intent?.mode, 'unavailable');
  assert.equal(response.intent?.failure, 'invalid-output');
});

test('Cloudflare support leaves explicit manual mode fully local', async () => {
  let calls = 0;
  const manual = { ...request, query: '', interests: ['park'], localOnly: true };
  const response = await buildPlan(manual, dataset, { clock, interpret: async () => { calls++; return resolve(contract); }, enrich: async value => { calls++; return value; } });
  assert.equal(calls, 0);
  assert.equal(response.intent?.mode, 'manual');
  assert.equal(response.diagnostics?.intent, 'manual');
  assert.equal(response.generationMode, 'retrieval');
  assert.ok(response.plan);
});
