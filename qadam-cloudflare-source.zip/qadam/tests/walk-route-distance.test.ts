import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { activeLegCrossTrackMeters } from '../lib/walk-route-distance.ts';
// @ts-expect-error Native Node TS source extensions.
import { createWalkGuide, createGuideProgress, updateWalkGuide } from '../lib/walk-guide.ts';
import type { GuideFix, GuideLeg, GuidePoint, GuideProgress, SupportedWalkGuide, WalkGuide } from '../lib/walk-guide';

const A:GuidePoint = [71.43, 51.128];
const NOW = 1_800_000_000_000;
const point = (east:number, north:number):GuidePoint => [
  A[0] + east / (111_195 * Math.cos(A[1] * Math.PI / 180)),
  A[1] + north / 111_195,
];
const fix = (p:GuidePoint) => ({lon:p[0], lat:p[1]});
function leg(coordinates:GuidePoint[], index=0):GuideLeg {
  return {id:`leg-${index}`, index, label:'Geometry fixture', kind:'finish', coordinates,
    totalMeters:0, cumulativeMeters:[], instructions:[]};
}
function guide(...legs:GuidePoint[][]):SupportedWalkGuide {
  return {supported:true, legs:legs.map((points, index)=>leg(points, index)), totalMeters:0};
}
function near(actual:number|null, expected:number, tolerance=0.2) {
  assert.notEqual(actual, null);
  assert.ok(Math.abs(actual! - expected) < tolerance, `${actual} should be within ${tolerance} m of ${expected}`);
}

test('200 m farther along the active leg is on-line even outside the progress window', () => {
  const route = createWalkGuide({routeKind:'walking', routeCoordinates:[A, point(400, 0)], stops:[], legEndIndices:[1]});
  assert.ok(route.supported);
  const state = createGuideProgress(), position = {...fix(point(200, 0)), timestamp:NOW, accuracy:5};
  const progress = updateWalkGuide(route, state, position, {nowMs:NOW});
  assert.equal(progress.status, 'off-route');
  assert.ok(progress.crossTrackMeters! > 150);
  near(activeLegCrossTrackMeters(route, state, position), 0, 0.001);
  assert.deepEqual(state, createGuideProgress());
  assert.deepEqual(progress.state, state);
});

test('distance is lateral to every active segment with endpoints clamped', () => {
  const route = guide([A, point(100, 0), point(100, 100)]);
  near(activeLegCrossTrackMeters(route, {legIndex:0}, fix(point(50, -60))), 60);
  near(activeLegCrossTrackMeters(route, {legIndex:0}, fix(point(130, 70))), 30);
  near(activeLegCrossTrackMeters(route, {legIndex:0}, fix(point(-50, 0))), 50);
  near(activeLegCrossTrackMeters(route, {legIndex:0}, fix(point(100, 150))), 50);
});

test('a circular future leg cannot conceal deviation from the active leg', () => {
  const S = point(200, 0), futurePoint = point(100, 100);
  const route = guide([A, S], [S, point(200, 100), futurePoint, point(0, 100), A]);
  near(activeLegCrossTrackMeters(route, {legIndex:0}, fix(futurePoint)), 100);
  near(activeLegCrossTrackMeters(route, {legIndex:1}, fix(futurePoint)), 0, 0.001);
});

test('overlapping return geometry never changes leg, progress, guide or fix', () => {
  const S = point(300, 0), route = guide([A, S], [S, A]);
  const state:GuideProgress = {legIndex:0, meters:0, segmentIndex:0};
  const position = fix(point(200, 0));
  const before = JSON.stringify({route, state, position});
  for (const activeLeg of route.legs) {
    for (const coordinate of activeLeg.coordinates) Object.freeze(coordinate);
    Object.freeze(activeLeg.coordinates); Object.freeze(activeLeg);
  }
  Object.freeze(route.legs); Object.freeze(route); Object.freeze(state); Object.freeze(position);
  near(activeLegCrossTrackMeters(route, state, position), 0, 0.001);
  assert.equal(JSON.stringify({route, state, position}), before);
  assert.equal(state.legIndex, 0); assert.equal(state.meters, 0);
});

test('single-point and repeated-vertex legs have finite point distances', () => {
  near(activeLegCrossTrackMeters(guide([A]), {legIndex:0}, fix(point(0, 40))), 40);
  near(activeLegCrossTrackMeters(guide([A, A, A]), {legIndex:0}, fix(point(0, 40))), 40);
  near(activeLegCrossTrackMeters(guide([A, A, point(100, 0)]), {legIndex:0}, fix(point(50, 0))), 0, 0.001);
});

test('unsupported, finished and invalid leg selection yield no off-route evidence', () => {
  const route = guide([A, point(100, 0)]);
  assert.equal(activeLegCrossTrackMeters({supported:false, reason:'estimate-route'}, {legIndex:0}, fix(A)), null);
  for (const index of [-1, 0.5, 1, Infinity, NaN]) {
    assert.equal(activeLegCrossTrackMeters(route, {legIndex:index}, fix(A)), null);
  }
  assert.equal(activeLegCrossTrackMeters(null as unknown as WalkGuide, {legIndex:0}, fix(A)), null);
  assert.equal(activeLegCrossTrackMeters(route, null as unknown as GuideProgress, fix(A)), null);
});

test('malformed fixes and active vertices are rejected, including after an exact match', () => {
  const route = guide([A, point(100, 0)]);
  for (const bad of [{lat:NaN, lon:A[0]}, {lat:A[1], lon:Infinity}, {lat:91, lon:0}, {lat:0, lon:181}, {lat:-91, lon:0}, {lat:0, lon:-181}, null]) {
    assert.equal(activeLegCrossTrackMeters(route, {legIndex:0}, bad as unknown as GuideFix), null);
  }
  for (const coordinates of [[], [A, [NaN, A[1]]], [A, [181, 0]], [A, [71, 91]], [A, [71]], [A, undefined]]) {
    assert.equal(activeLegCrossTrackMeters(guide(coordinates as GuidePoint[]), {legIndex:0}, fix(A)), null);
  }
});

test('only the active leg is inspected and its scan has an explicit point bound', () => {
  const route = guide([A, point(100, 0)], [[NaN, NaN]]);
  near(activeLegCrossTrackMeters(route, {legIndex:0}, fix(point(50, 10))), 10);
  assert.equal(activeLegCrossTrackMeters(route, {legIndex:1}, fix(A)), null);
  assert.equal(activeLegCrossTrackMeters(guide(Array.from({length:200_001}, ()=>A)), {legIndex:0}, fix(A)), null);
});

test('valid global coordinate boundaries remain finite without antimeridian shortcuts', () => {
  const route = guide([[179.999, 0], [-179.999, 0]]);
  near(activeLegCrossTrackMeters(route, {legIndex:0}, {lon:180, lat:0}), 0, 0.001);
  const opposite = activeLegCrossTrackMeters(route, {legIndex:0}, {lon:0, lat:0});
  assert.ok(opposite !== null && opposite > 20_000_000);
  assert.ok(Number.isFinite(activeLegCrossTrackMeters(guide([[180, 90], [-180, 90]]), {legIndex:0}, {lon:-180, lat:-90})));
});
