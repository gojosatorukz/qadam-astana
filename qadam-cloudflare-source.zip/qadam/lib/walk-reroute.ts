import type { PlanStop, RoutePlan } from './qadam-types';
import type { WalkingGraph } from './walking-graph';
// @ts-expect-error Native Node TS source extensions.
import { openingHoursStatus, WALKING_METERS_PER_MINUTE } from './planner.ts';
// @ts-expect-error Native Node TS source extensions.
import { parseIsoInstant } from './time-context.ts';
// @ts-expect-error Native Node TS source extensions.
import { getCanonicalId } from './place-facts.ts';

export type RerouteRequest = {
  fix:{lat:number;lon:number;accuracy:number;timestamp:number};
  endpoint:{lat:number;lon:number;label:string}; remainingStops:PlanStop[];
  deadlineAt:string; nowMs:number; accessible:boolean; knownHoursOnly:boolean;
  language:'ru'|'en'|'kk';
};
export type RerouteResult = {
  kind:'route'; plan:RoutePlan; removedPoiIds:string[]; deadlineAt:string;
  computedAt:string; overBudget:boolean; lateByMinutes:number;
  searchCount:number; maxConnectorMeters:number;
}|{kind:'unavailable';reason:'invalid-request'|'stale-fix'|'poor-accuracy'|'network-unavailable'|'disconnected'|'search-limit'};

type Point={lat:number;lon:number};
type Itinerary={indices:number[];stops:PlanStop[];legs:number[];walking:number;visiting:number;distance:number;total:number};
const object=(v:unknown):v is Record<string,unknown>=>!!v&&typeof v==='object'&&!Array.isArray(v);
const text=(v:unknown,max:number):v is string=>typeof v==='string'&&v.length<=max;
const finite=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
const point=(v:unknown):v is Point=>object(v)&&finite(v.lat)&&finite(v.lon)&&Math.abs(v.lat)<=90&&Math.abs(v.lon)<=180;
const same=(a:Point,b:Point)=>a.lat===b.lat&&a.lon===b.lon;
const keys=(v:Record<string,unknown>,allowed:string[])=>Object.keys(v).every(k=>allowed.includes(k));
function sourceStop(v:unknown):v is PlanStop {
  if(!object(v)||!keys(v,['poi','visitMinutes','travelMinutes','why','activity','hoursStatus','canonicalId','facts','observation'])
    ||!Number.isInteger(v.visitMinutes)||(v.visitMinutes as number)<1||(v.visitMinutes as number)>360
    ||!finite(v.travelMinutes)||v.travelMinutes<0||!text(v.why,10_000)||!text(v.activity,10_000)
    ||!['open','closed','unknown'].includes(v.hoursStatus as string)||!point(v.poi))return false;
  const p=v.poi as unknown as Record<string,unknown>;
  if(!keys(p,['id','name','lat','lon','category','description','tags','openingHours','website','sourceUrl','fetchedAt','indoor','wheelchair'])
    ||!text(p.id,200)||!p.id||!text(p.name,500)||!p.name||!text(p.category,100)||!text(p.description,10_000)
    ||!text(p.sourceUrl,2000)||!/^https:\/\//u.test(p.sourceUrl)||!text(p.fetchedAt,64)||!Number.isFinite(Date.parse(p.fetchedAt))
    ||!object(p.tags)||Object.keys(p.tags).length>80||!Object.entries(p.tags).every(([k,value])=>k.length<=100&&text(value,4096))
    ||!(p.openingHours===null||text(p.openingHours,1000))||!(p.website===null||text(p.website,2000))
    ||!(p.wheelchair===null||text(p.wheelchair,100))||!(p.indoor===null||typeof p.indoor==='boolean'))return false;
  if(v.canonicalId!==undefined&&(!text(v.canonicalId,200)||!v.canonicalId))return false;
  if(v.observation!==undefined&&!text(v.observation,10_000))return false;
  return v.facts===undefined||(Array.isArray(v.facts)&&v.facts.length<=4&&v.facts.every(f=>object(f)&&keys(f,['id','text','sourceUrl','checkedAt','rights'])&&text(f.id,200)&&text(f.text,10_000)&&text(f.sourceUrl,2000)&&text(f.checkedAt,64)&&text(f.rights,2000)));
}
function validRequest(v:unknown):v is RerouteRequest {
  if(!object(v)||!keys(v,['fix','endpoint','remainingStops','deadlineAt','nowMs','accessible','knownHoursOnly','language'])||!point(v.fix)||!keys(v.fix,['lat','lon','accuracy','timestamp'])||!finite((v.fix as Record<string,unknown>).accuracy)||((v.fix as Record<string,unknown>).accuracy as number)<0
    ||!finite((v.fix as Record<string,unknown>).timestamp)||((v.fix as Record<string,unknown>).timestamp as number)<0
    ||!point(v.endpoint)||!keys(v.endpoint,['lat','lon','label'])||!text((v.endpoint as Record<string,unknown>).label,200)||!(v.endpoint as Record<string,unknown>).label
    ||!finite(v.nowMs)||v.nowMs<0||v.nowMs>8.64e15||!parseIsoInstant(v.deadlineAt)
    ||typeof v.accessible!=='boolean'||typeof v.knownHoursOnly!=='boolean'||!['ru','en','kk'].includes(v.language as string)
    ||!Array.isArray(v.remainingStops)||v.remainingStops.length>3||!v.remainingStops.every(sourceStop))return false;
  const ids=v.remainingStops.map(s=>getCanonicalId(s.poi));
  return new Set(ids).size===ids.length;
}
function cloneStop(stop:PlanStop):PlanStop {
  return {...stop,poi:{...stop.poi,tags:{...stop.poi.tags}},...(stop.facts?{facts:stop.facts.map(f=>({...f}))}:{})};
}
const copy={
  ru:{title:'Маршрут перестроен',summary:(label:string,n:number)=>`К цели «${label}»; осталось остановок: ${n}. Исходный срок сохранён.`,why:(n:number)=>`Путь пересчитан локально; исходное время посещения ${n} мин сохранено.`},
  en:{title:'Route recalculated',summary:(label:string,n:number)=>`To ${label}; ${n} stops remain. The original deadline is preserved.`,why:(n:number)=>`Recalculated locally; the original ${n}-minute visit is preserved.`},
  kk:{title:'Бағыт қайта есептелді',summary:(label:string,n:number)=>`Мақсат — «${label}»; ${n} аялдама қалды. Бастапқы мерзім сақталды.`,why:(n:number)=>`Жол жергілікті есептелді; бастапқы ${n} минуттық сапар сақталды.`},
};

/** Pure synchronous worker engine: GPS, graph and stops remain local; no I/O. */
export function rerouteWalk(request:RerouteRequest,graph:WalkingGraph):RerouteResult {
  if(!validRequest(request))return {kind:'unavailable',reason:'invalid-request'};
  const {fix,endpoint,nowMs}=request;
  if(nowMs-fix.timestamp>20_000||fix.timestamp-nowMs>5000)return {kind:'unavailable',reason:'stale-fix'};
  if(fix.accuracy>40)return {kind:'unavailable',reason:'poor-accuracy'};
  const deadline=parseIsoInstant(request.deadlineAt)!.getTime(),remaining=(deadline-nowMs)/60_000;
  const buffer=Math.max(3,Math.min(10,Math.ceil(remaining*0.08))),language=copy[request.language];
  try {
    const session=graph.createSession(fix,{avoidSteps:request.accessible,maxSnapMeters:200});
    if(!session||!graph.snap(endpoint,200))return {kind:'unavailable',reason:'network-unavailable'};
    const distance=(from:Point,to:Point):number|null=>same(from,to)?0:session.distanceBetween(from,to);
    const direct=distance(fix,endpoint);
    if(direct===null)return {kind:'unavailable',reason:'disconnected'};
    const finalDistance=(from:Point)=>same(from,endpoint)?0:session.distanceBetween(endpoint,from);
    const evaluate=(indices:number[]):Itinerary|null=>{
      let position:Point=fix,elapsed=0,walking=0,visiting=0,distanceMeters=0;const stops:PlanStop[]=[],legs:number[]=[];
      for(const index of indices){
        const original=request.remainingStops[index];
        if(request.accessible&&!['yes','designated'].includes((original.poi.wheelchair??'').toLowerCase()))return null;
        const meters=distance(position,original.poi);if(meters===null)return null;
        const travelMinutes=Math.ceil(meters/WALKING_METERS_PER_MINUTE);elapsed+=travelMinutes;walking+=travelMinutes;distanceMeters+=meters;legs.push(travelMinutes);
        const hoursStatus=openingHoursStatus(original.poi.openingHours,new Date(nowMs+elapsed*60_000),original.visitMinutes);
        if(hoursStatus==='closed'||(request.knownHoursOnly&&hoursStatus!=='open'))return null;
        stops.push({...cloneStop(original),canonicalId:getCanonicalId(original.poi),travelMinutes,hoursStatus,why:language.why(original.visitMinutes)});
        elapsed+=original.visitMinutes;visiting+=original.visitMinutes;position=original.poi;
      }
      const last=indices.length?finalDistance(position):direct;if(last===null)return null;
      const finalMinutes=Math.ceil(last/WALKING_METERS_PER_MINUTE);legs.push(finalMinutes);walking+=finalMinutes;distanceMeters+=last;
      return {indices:[...indices],stops,legs,walking,visiting,distance:distanceMeters,total:walking+visiting+buffer};
    };
    let selected=evaluate([])!;
    // All eight order-preserving subsets at most; ties retain earlier original
    // stops. Trees are cached by A, B and at most three original stop sources.
    for(let mask=1;mask<(1<<request.remainingStops.length);mask++){
      const indices=request.remainingStops.map((_,i)=>i).filter(i=>mask&(1<<i));const candidate=evaluate(indices);
      if(!candidate||candidate.total>remaining)continue;
      const lexEarlier=(a:number[],b:number[])=>a.some((value,i)=>value!==b[i]&&a.slice(0,i).every((p,j)=>p===b[j])&&value<b[i]);
      if(candidate.indices.length>selected.indices.length||(candidate.indices.length===selected.indices.length&&lexEarlier(candidate.indices,selected.indices)))selected=candidate;
    }
    const points:Point[]=[fix,...selected.stops.map(s=>s.poi),endpoint],routeCoordinates:[number,number][]=[],legEndIndices:number[]=[];
    for(let i=1;i<points.length;i++){
      if(same(points[i-1],points[i])){if(!routeCoordinates.length)routeCoordinates.push([points[i].lon,points[i].lat]);}
      else {
        const final=i===points.length-1,leg=final?session.leg(endpoint,points[i-1]):session.leg(points[i-1],points[i]);
        if(!leg)return {kind:'unavailable',reason:'disconnected'};
        const path=final?[...leg.coordinates].reverse():leg.coordinates;
        routeCoordinates.push(...(routeCoordinates.length?path.slice(1):path));
      }
      legEndIndices.push(routeCoordinates.length-1);
    }
    if(routeCoordinates.length===1){routeCoordinates.push([...routeCoordinates[0]]);legEndIndices[legEndIndices.length-1]=1;}
    const plan:RoutePlan={title:language.title,summary:language.summary(endpoint.label,selected.stops.length),stops:selected.stops,totalMinutes:selected.total,
      walkingMinutes:selected.walking,visitMinutes:selected.visiting,bufferMinutes:buffer,distanceMeters:Math.ceil(selected.distance),returnMinutes:selected.legs.at(-1)!,routeCoordinates,legEndIndices,routeKind:'walking',routeMode:'one-way',destination:{...endpoint}};
    const kept=new Set(selected.indices);
    return {kind:'route',plan,removedPoiIds:request.remainingStops.filter((_,i)=>!kept.has(i)).map(s=>s.poi.id),deadlineAt:request.deadlineAt,computedAt:new Date(nowMs).toISOString(),overBudget:selected.total>remaining,lateByMinutes:Math.max(0,Math.ceil(selected.total-remaining)),searchCount:session.searchCount,maxConnectorMeters:session.maxConnectorMeters};
  }catch(error){return {kind:'unavailable',reason:error instanceof Error&&/search limit/iu.test(error.message)?'search-limit':'network-unavailable'};}
}
