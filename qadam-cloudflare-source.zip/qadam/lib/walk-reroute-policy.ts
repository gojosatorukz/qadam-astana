import type { GuideFix, GuideStatus } from './walk-guide';

export type OffRoutePolicyState = {
  firstOffRouteTimestamp: number | null;
  firstObservedAt: number | null;
  qualifyingFixes: number;
  lastFixTimestamp: number | null;
  lastAttemptAt: number | null;
  inFlight: boolean;
};
export type OffRouteObservation = { fix: GuideFix; status: GuideStatus; crossTrackMeters: number | null; nowMs: number };
export const REROUTE_COOLDOWN_MS = 30_000;
const FRESH_FIX_MS = 20_000, FUTURE_TOLERANCE_MS = 5000, MIN_OFF_ROUTE_MS = 6000;

export function createOffRoutePolicy(): OffRoutePolicyState {
  return { firstOffRouteTimestamp: null, firstObservedAt: null, qualifyingFixes: 0, lastFixTimestamp: null, lastAttemptAt: null, inFlight: false };
}
function clearStreak(state: OffRoutePolicyState): OffRoutePolicyState {
  return { ...state, firstOffRouteTimestamp: null, firstObservedAt: null, qualifyingFixes: 0 };
}
/** Pause/reset does not let an interrupted attempt evade its cooldown. */
export function resetOffRoutePolicy(state: OffRoutePolicyState = createOffRoutePolicy()): OffRoutePolicyState {
  return { ...clearStreak(state), inFlight: false };
}
const coolingDown = (state: OffRoutePolicyState, nowMs: number) => state.lastAttemptAt !== null && nowMs - state.lastAttemptAt < REROUTE_COOLDOWN_MS;

/** Pure gate: the caller supplies distance to the complete ACTIVE leg. */
export function observeOffRoute(state: OffRoutePolicyState, observation: OffRouteObservation): { state: OffRoutePolicyState; shouldReroute: boolean } {
  const { fix, status, crossTrackMeters, nowMs } = observation;
  const valid = fix && Number.isFinite(fix.lat) && Math.abs(fix.lat) <= 90 && Number.isFinite(fix.lon) && Math.abs(fix.lon) <= 180
    && Number.isFinite(fix.accuracy) && fix.accuracy >= 0 && Number.isFinite(fix.timestamp) && fix.timestamp >= 0 && Number.isFinite(nowMs);
  if (!valid || nowMs - fix.timestamp > FRESH_FIX_MS || fix.timestamp - nowMs > FUTURE_TOLERANCE_MS
    || (state.lastFixTimestamp !== null && fix.timestamp <= state.lastFixTimestamp)) return { state: clearStreak(state), shouldReroute: false };
  const next = { ...state, lastFixTimestamp: fix.timestamp };
  if (status !== 'off-route' || fix.accuracy > 25 || crossTrackMeters === null || !Number.isFinite(crossTrackMeters)
    || crossTrackMeters <= Math.max(45, fix.accuracy * 2) || state.inFlight || coolingDown(state, nowMs)) return { state: clearStreak(next), shouldReroute: false };
  const restart = state.firstOffRouteTimestamp === null || state.firstObservedAt === null || nowMs - state.firstObservedAt > FRESH_FIX_MS
    || (state.lastFixTimestamp !== null && fix.timestamp - state.lastFixTimestamp > FRESH_FIX_MS);
  const firstOffRouteTimestamp = restart ? fix.timestamp : state.firstOffRouteTimestamp!;
  const firstObservedAt = restart ? nowMs : state.firstObservedAt!;
  const qualifyingFixes = restart ? 1 : Math.min(1_000_000, state.qualifyingFixes + 1);
  const result = { ...next, firstOffRouteTimestamp, firstObservedAt, qualifyingFixes };
  return { state: result, shouldReroute: qualifyingFixes >= 3 && fix.timestamp - firstOffRouteTimestamp >= MIN_OFF_ROUTE_MS && nowMs - firstObservedAt >= MIN_OFF_ROUTE_MS };
}

/** Call synchronously before starting the worker, including an attempt that fails. */
export function beginOffRouteAttempt(state: OffRoutePolicyState, nowMs: number): OffRoutePolicyState {
  if (!Number.isFinite(nowMs) || state.inFlight || coolingDown(state, nowMs)) return state;
  return { ...clearStreak(state), lastAttemptAt: nowMs, inFlight: true };
}
export function finishOffRouteAttempt(state: OffRoutePolicyState): OffRoutePolicyState {
  return { ...clearStreak(state), inFlight: false };
}
