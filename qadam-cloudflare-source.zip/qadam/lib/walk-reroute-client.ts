import type { RerouteRequest, RerouteResult } from './walk-reroute';

export type WalkRerouteClientResult = { ok: true; result: RerouteResult } | { ok: false; reason: 'unsupported' | 'worker-error' | 'timeout' | 'cancelled' | 'busy' | 'disposed' };
export type WalkRerouteWorker = Pick<Worker, 'postMessage' | 'terminate' | 'onmessage' | 'onerror' | 'onmessageerror'>;
export type WalkRerouter = {
  reroute(request: RerouteRequest, options?: { signal?: AbortSignal }): Promise<WalkRerouteClientResult>;
  dispose(): void;
};
type WorkerReply = { type: 'reroute-result'; id: number; result: RerouteResult } | { type: 'reroute-error'; id: number };
type Pending = { id: number; epoch: number; resolve: (result: WalkRerouteClientResult) => void; timer: ReturnType<typeof setTimeout>; removeAbort: () => void };

/** Lazy, memory-only browser computation. No GPS is sent to an API or a model. */
export function createWalkRerouter(options: { workerFactory?: () => WalkRerouteWorker | Promise<WalkRerouteWorker>; timeoutMs?: number } = {}): WalkRerouter {
  let worker: WalkRerouteWorker | null = null, pending: Pending | null = null, epoch = 0, nextId = 0, disposed = false;
  const timeoutMs = typeof options.timeoutMs === 'number' && Number.isFinite(options.timeoutMs) ? Math.min(60_000, Math.max(1, options.timeoutMs)) : 12_000;
  function settle(result: WalkRerouteClientResult) {
    const current = pending;
    if (!current) return;
    pending = null; clearTimeout(current.timer); current.removeAbort(); current.resolve(result);
  }
  function terminate() {
    epoch++;
    const previous = worker; worker = null;
    if (!previous) return;
    previous.onmessage = null; previous.onerror = null; previous.onmessageerror = null;
    try { previous.terminate(); } catch { /* Already stopped. */ }
  }
  function fail(reason: 'worker-error' | 'timeout' | 'cancelled') { terminate(); settle({ ok: false, reason }); }
  const currentRequest = (id: number, requestEpoch: number) => !disposed && epoch === requestEpoch && pending?.id === id && pending.epoch === requestEpoch;
  function attachWorker(instance: WalkRerouteWorker, instanceEpoch: number) {
    worker = instance;
    instance.onmessage = event => {
      if (worker !== instance || epoch !== instanceEpoch || !pending || pending.epoch !== instanceEpoch) return;
      const data: unknown = event.data;
      if (!data || typeof data !== 'object' || !('id' in data) || data.id !== pending.id) return;
      const reply = data as WorkerReply;
      if (reply.type === 'reroute-result' && reply.result && typeof reply.result === 'object' && (reply.result.kind === 'route' || reply.result.kind === 'unavailable')) settle({ ok: true, result: reply.result });
      else fail('worker-error');
    };
    instance.onerror = () => { if (worker === instance && epoch === instanceEpoch) fail('worker-error'); };
    instance.onmessageerror = () => { if (worker === instance && epoch === instanceEpoch) fail('worker-error'); };
  }
  return {
    reroute(request, requestOptions = {}) {
      if (disposed) return Promise.resolve({ ok: false, reason: 'disposed' });
      if (requestOptions.signal?.aborted) return Promise.resolve({ ok: false, reason: 'cancelled' });
      if (pending) return Promise.resolve({ ok: false, reason: 'busy' });
      if (!options.workerFactory && typeof Worker === 'undefined') return Promise.resolve({ ok: false, reason: 'unsupported' });
      return new Promise(resolve => {
        const id = ++nextId, requestEpoch = epoch, signal = requestOptions.signal;
        const abort = () => { if (pending?.id === id && pending.epoch === requestEpoch) fail('cancelled'); };
        pending = { id, epoch: requestEpoch, resolve, timer: setTimeout(() => { if (pending?.id === id && pending.epoch === requestEpoch) fail('timeout'); }, timeoutMs), removeAbort: () => signal?.removeEventListener('abort', abort) };
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted) { abort(); return; }
        const start = (instance: WalkRerouteWorker | null) => {
          if (!instance) return;
          if (!currentRequest(id, requestEpoch)) { try { instance.terminate(); } catch { /* Cancelled during loading. */ } return; }
          if (worker !== instance) attachWorker(instance, requestEpoch);
          try { instance.postMessage({ type: 'reroute', id, request }); } catch { fail('worker-error'); }
        };
        try {
          if (worker) { start(worker); return; }
          // Vite owns the browser URL and worker format. A direct import.meta.url
          // constructor is unsafe here because Vinext's RSC transform rewrites
          // that URL to file://. The wrapper is loaded only for a real attempt.
          const candidate = options.workerFactory ? options.workerFactory() : import('./walk-reroute.worker.ts?worker').then(module => currentRequest(id, requestEpoch) ? new module.default({ name: 'qadam-local-reroute' }) : null);
          if (candidate && typeof (candidate as Promise<WalkRerouteWorker | null>).then === 'function') {
            Promise.resolve(candidate).then(start, () => { if (currentRequest(id, requestEpoch)) fail('worker-error'); });
          } else start(candidate as WalkRerouteWorker);
        } catch { if (currentRequest(id, requestEpoch)) fail('worker-error'); }
      });
    },
    dispose() { if (disposed) return; disposed = true; terminate(); settle({ ok: false, reason: 'cancelled' }); },
  };
}
