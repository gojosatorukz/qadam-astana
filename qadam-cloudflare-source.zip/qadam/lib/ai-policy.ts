/** Measured provider latency is not a guarantee. All layers remain bounded. */
export const DEFAULT_GEMINI_MODEL = 'gemini-3.1-flash-lite';
export const INTENT_PROVIDER_TIMEOUT_MS = 20_000;
// Leave transport/body parsing slack outside the server's provider deadline.
export const INTENT_TRANSPORT_TIMEOUT_MS = 21_000;
export const PLAN_MODEL_TIMEOUT_MS = 26_000;
export const ENRICHMENT_TIMEOUT_MS = 4_000;
// Includes server clock, cold graph loading and the model stages on a phone.
export const PLAN_RPC_TIMEOUT_MS = 40_000;

/** Explicit supported controls; never send Gemini 3 thinkingLevel to 2.x/custom models. */
export function fastThinkingConfig(model: string): { thinkingConfig?: { thinkingLevel: 'LOW' | 'MINIMAL' } } {
  if (model === 'gemini-3.6-flash' || model === 'gemini-3.5-flash') return { thinkingConfig: { thinkingLevel: 'MINIMAL' } };
  if (model === 'gemini-3.5-flash-lite') return { thinkingConfig: { thinkingLevel: 'MINIMAL' } };
  return {};
}
