// @ts-expect-error Native Node verification uses explicit source extensions.
import{isOpportunityResult}from'./opportunities.ts';
import type{OpportunityRequest,OpportunityResult}from'./opportunities';
import type{OpportunityWorkerReply,OpportunityWorkerError}from'./opportunities.worker';
export type OpportunityWorker=Pick<Worker,'postMessage'|'terminate'|'onmessage'|'onerror'|'onmessageerror'>;
export type OpportunityClientResult={ok:true;result:OpportunityResult}|{ok:false;reason:'unsupported'|'worker-error'|'invalid-reply'|'timeout'|'cancelled'|'superseded'|'disposed';code?:OpportunityWorkerError};
type Pending={id:number;request:OpportunityRequest;resolve:(value:OpportunityClientResult)=>void;timer:ReturnType<typeof setTimeout>;removeAbort:()=>void};

/** One long-lived local worker. Superseded slider requests never replace newer results. */
export function createOpportunityClient(options:{workerFactory?:()=>OpportunityWorker|Promise<OpportunityWorker>;timeoutMs?:number}={}){
 let worker:OpportunityWorker|null=null,loading:Promise<OpportunityWorker|null>|null=null,pending:Pending|null=null,disposed=false,id=0,epoch=0;
 const timeoutMs=Number.isFinite(options.timeoutMs)?Math.min(25_000,Math.max(1,options.timeoutMs!)):25_000;
 function settle(value:OpportunityClientResult){const current=pending;if(!current)return;pending=null;clearTimeout(current.timer);current.removeAbort();current.resolve(value);}
 function terminate(){epoch++;loading=null;const previous=worker;worker=null;if(previous){previous.onmessage=null;previous.onerror=null;previous.onmessageerror=null;try{previous.terminate();}catch{/* Already stopped. */}}}
 function fail(reason:'worker-error'|'invalid-reply'|'timeout'){terminate();settle({ok:false,reason});}
 function attach(instance:OpportunityWorker,instanceEpoch:number){
  worker=instance;
  instance.onmessage=event=>{
   if(worker!==instance||epoch!==instanceEpoch||!pending)return;const value=event.data as Partial<OpportunityWorkerReply>|null;
   if(!value||typeof value!=='object'||value.id!==pending.id)return;
   if(value.type==='opportunities-result'&&isOpportunityResult(value.result)&&value.result.minutes===pending.request.minutes)settle({ok:true,result:value.result});
   else if(value.type==='opportunities-error'&&typeof value.code==='string'&&['POI_LOAD','POI_INIT','GRAPH_LOAD','GRAPH_INIT','COMPUTE'].includes(value.code))settle({ok:false,reason:'worker-error',code:value.code});
   else fail('invalid-reply');
  };
  instance.onerror=()=>{if(worker===instance&&epoch===instanceEpoch)fail('worker-error');};instance.onmessageerror=()=>{if(worker===instance&&epoch===instanceEpoch)fail('invalid-reply');};
 }
 async function ensureWorker():Promise<OpportunityWorker|null>{
  if(worker)return worker;if(loading)return loading;
  const currentEpoch=epoch;
  const start=(async()=>{
   let instance:OpportunityWorker;
   if(options.workerFactory)instance=await options.workerFactory();
   else{if(typeof Worker==='undefined')return null;const module=await import('./opportunities.worker.ts?worker');if(disposed||currentEpoch!==epoch)return null;instance=new module.default({name:'qadam-live-opportunities'});}
   if(disposed||currentEpoch!==epoch){try{instance.terminate();}catch{/* Already stopped. */}return null;}
   attach(instance,currentEpoch);return instance;
  })();
  loading=start;try{return await start;}finally{if(loading===start)loading=null;}
 }
 return {
  compute(request:OpportunityRequest,{signal}:{signal?:AbortSignal}={}):Promise<OpportunityClientResult>{
   if(disposed)return Promise.resolve({ok:false,reason:'disposed'});if(signal?.aborted)return Promise.resolve({ok:false,reason:'cancelled'});
   settle({ok:false,reason:'superseded'});
   return new Promise(resolve=>{
    const requestId=++id;
    const abort=()=>{if(pending?.id===requestId)settle({ok:false,reason:'cancelled'});};
    pending={id:requestId,request,resolve,timer:setTimeout(()=>{if(pending?.id===requestId)fail('timeout');},timeoutMs),removeAbort:()=>signal?.removeEventListener('abort',abort)};
    signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted){abort();return;}
    void ensureWorker().then(instance=>{if(disposed||pending?.id!==requestId)return;if(!instance){settle({ok:false,reason:'unsupported'});return;}try{instance.postMessage({type:'opportunities',id:requestId,request});}catch{fail('worker-error');}},()=>{if(pending?.id===requestId)fail('worker-error');});
   });
  },
  dispose(){if(disposed)return;disposed=true;terminate();settle({ok:false,reason:'cancelled'});},
 };
}
