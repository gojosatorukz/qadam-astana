/** Closed vocabulary from the collected POI corpus. The model cannot add places. */
export const SUPPORTED_CATEGORIES = ['art', 'attraction', 'cafe', 'food', 'library', 'museum', 'park', 'playground', 'viewpoint'] as const;
export type SupportedCategory = typeof SUPPORTED_CATEGORIES[number];
export const INTENT_MODES = ['gemini', 'cloudflare', 'manual', 'unavailable'] as const;
export type IntentMode = typeof INTENT_MODES[number];
export function isIntentMode(value: unknown): value is IntentMode {
  return typeof value === 'string' && INTENT_MODES.some(mode => mode === value);
}
export type UnsupportedWish = { text: string; reason: 'no-data' | 'use-controls' | 'not-supported' };
export type IntentContract = {
  version: 1;
  desiredCategories: SupportedCategory[];
  excludedCategories: SupportedCategory[];
  includeMode: 'all' | 'any';
  unsupported: UnsupportedWish[];
  needsClarification: boolean;
};
export type IntentResolution = {
  mode: IntentMode;
  contract: IntentContract | null;
  failure?: 'not-configured' | 'timeout' | 'provider' | 'quota' | 'invalid-output';
  ms: number;
};
export type IntentFeedback = IntentResolution & {
  status: 'matched' | 'partial' | 'empty' | 'needs-clarification';
  achievedCategories: SupportedCategory[];
  unmetCategories: SupportedCategory[];
};
