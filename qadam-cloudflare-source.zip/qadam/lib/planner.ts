import type { POI, PlanRequest, PlanResponse, PlanStop, RoutePlan } from './qadam-types';
// @ts-expect-error Native Node TS verification uses source extensions.
import { parseIsoInstant } from './time-context.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { MAX_QUERY_LENGTH } from './query-policy.ts';
// @ts-expect-error Native Node TS verification uses source extensions.
import { getCanonicalId } from './place-facts.ts';
import type { WalkingGraph, WalkingSession } from './walking-graph';
import type { IntentContract, SupportedCategory } from './intent-types';

export type POIDataset = {
  pois: POI[]; fetchedAt: string; source: string; license?: string; query?: unknown;
};

// Estimates are conservative, not street routing. Every itinerary includes
// the final leg to the requested destination (or origin) and a time buffer.
export const DETOUR_FACTOR = 1.35;
export const WALKING_METERS_PER_MINUTE = 70;
const MAX_CANDIDATES = 18;
const MAX_STOPS = 3;
const TIME_ZONE = 'Asia/Almaty';
type HoursStatus = PlanStop['hoursStatus'];
type Point = { lat: number; lon: number };
type Language = PlanRequest['language'];

const copy = {
  ru: {
    title: 'Ваш маршрут Qadam',
    summary: 'Короткий круговой маршрут с возвращением к начальной точке.',
    estimate: 'Путь оценён по прямому расстоянию × 1,35 при скорости 4,2 км/ч. Это не навигация: переходы, входы и обходы могут увеличить время.',
    hours: 'Для некоторых остановок часы работы неизвестны или не распознаны. Уточните их у места до выхода.',
    fallback: 'Режим поиска: пояснения составлены локально из данных POI и расчёта.',
    none: 'По этим условиям не найден выполнимый маршрут с возвращением. Увеличьте время или ослабьте фильтры.',
    why: 'Подходит к вашим интересам; сведения взяты из карточки POI.',
    near: 'Рядом с начальной точкой; включено в доступный бюджет времени.',
    food: 'Идея: остановитесь поесть; время на заказ включите в посещение, меню и цены уточните у заведения.',
    cafe: 'Идея: сделайте короткую остановку на кофе; меню и цены уточните на месте.',
    museum: 'Идея: начните с основной экспозиции; билеты и доступность уточните у места.',
    park: 'Идея: пройдите небольшой участок и вернитесь тем же знакомым путём.',
    other: 'Идея: осмотритесь и сделайте короткую остановку; доступность уточните на месте.',
    invalid: 'Часть записей POI исключена из-за неполных координат или источника.',
    walking: 'Линия следует графу пешеходных путей OpenStreetMap. Короткие соединения до ближайшего узла (не более 200 м) оценены по прямой и не проверены на препятствия. Переходы, входы и состояние путей могут отличаться; это не официальная навигация.',
    graphFallback: 'Пешеходный граф не покрывает старт, конечную точку или подходящие остановки. Использована явно обозначенная оценка расстояний.',
    steps: 'Из графа исключены лестницы; наличие пандусов, бордюров и качество покрытия остальных участков не подтверждены.',
    clarify: 'Уточните, какие места вы хотите посетить. Маршрут не построен, чтобы не подменять ваш запрос.',
  },
  en: {
    title: 'Your Qadam route',
    summary: 'A short round trip that returns to your starting point.',
    estimate: 'Travel is estimated from straight-line distance × 1.35 at 4.2 km/h. This is not navigation: crossings, entrances and detours may add time.',
    hours: 'Opening hours are missing or unsupported for some stops. Confirm with the venue before leaving.',
    fallback: 'Retrieval mode: explanations use POI records and the local calculation.',
    none: 'No feasible round trip matches these constraints. Add time or relax the filters.',
    why: 'Matches your interests, based on the POI record.',
    near: 'Near your starting point and fits within the time budget.',
    food: 'Suggested activity: stop for a meal; allow for ordering during the visit and confirm the menu and prices with the venue.',
    cafe: 'Suggested activity: take a short coffee break; confirm the menu and prices at the venue.',
    museum: 'Suggested activity: start with the main exhibition; confirm tickets and access with the venue.',
    park: 'Suggested activity: walk a short section and return along the same familiar path.',
    other: 'Suggested activity: explore briefly and take a short break; confirm access on arrival.',
    invalid: 'Some POI records were excluded because coordinates or source information were incomplete.',
    walking: 'The line follows the OpenStreetMap walking graph. Short connections to the nearest node (at most 200 m) use straight-line estimates and are unverified for obstacles. Crossings, entrances and path conditions may differ; this is not official navigation.',
    graphFallback: 'The walking graph does not cover the start, destination or suitable stops. Explicit distance estimates are used instead.',
    steps: 'Stair edges are excluded; ramps, kerbs and surface conditions on the remaining paths are unverified.',
    clarify: 'Clarify which places you want to visit. No route was selected so your request is not silently replaced.',
  },
  kk: {
    title: 'Сіздің Qadam бағытыңыз',
    summary: 'Бастапқы нүктеге қайта оралатын қысқа бағыт.',
    estimate: 'Жол түзу қашықтық × 1,35 және 4,2 км/сағ жылдамдықпен бағаланды. Бұл навигация емес: өткелдер мен айналма жолдар уақытты ұзарта алады.',
    hours: 'Кейбір орындардың жұмыс уақыты белгісіз немесе танылмады. Жолға шығар алдында нақтылаңыз.',
    fallback: 'Іздеу режимі: түсіндірмелер POI деректері мен жергілікті есептен құрастырылды.',
    none: 'Осы шарттармен қайтып келуге жеткілікті уақыт жоқ. Уақытты көбейтіңіз немесе сүзгілерді өзгертіңіз.',
    why: 'POI деректеріне сәйкес қызығушылығыңызға сай келеді.',
    near: 'Бастапқы нүктеге жақын және уақыт шегіне сай келеді.',
    food: 'Идея: тамақтануға тоқтаңыз; тапсырыс уақытын сапарға қосып, мәзір мен бағаны орнында нақтылаңыз.',
    cafe: 'Идея: кофе ішуге қысқа үзіліс жасаңыз; мәзір мен бағаны орнында нақтылаңыз.',
    museum: 'Идея: негізгі экспозициядан бастаңыз; билет пен қолжетімділікті нақтылаңыз.',
    park: 'Идея: қысқа серуен жасап, сол жолмен қайта оралыңыз.',
    other: 'Идея: айналаны қарап, қысқа аялдаңыз; кіруге болатынын орнында нақтылаңыз.',
    invalid: 'Координаттары немесе дереккөзі толық емес POI жазбалары алынып тасталды.',
    walking: 'Сызық OpenStreetMap жаяу жолдар графын көрсетеді. Ең жақын түйінге дейінгі қысқа қосылу (200 м-ден аспайды) түзу қашықтықпен бағаланады, кедергілер тексерілмеген. Бұл ресми навигация емес.',
    graphFallback: 'Жаяу жолдар графында бастау, соңғы нүкте немесе сәйкес орындар жоқ. Қашықтықтың анық белгіленген бағасы қолданылды.',
    steps: 'Баспалдақтар алынып тасталды; қалған жолдардың пандустары, жиектері мен жабыны расталмаған.',
    clarify: 'Қандай орындарға барғыңыз келетінін нақтылаңыз. Сұрауыңызды алмастырмас үшін бағыт құрылмады.',
  },
} as const;

const categoryTerms: Record<SupportedCategory, string[]> = {
  food: ['food', 'restaurant', 'restaurants', 'fast_food', 'food_court', 'eat', 'eating', 'lunch', 'dinner', 'meal', 'покуш', 'поесть', 'поем', 'обед', 'ужин', 'ресторан', 'перекус', 'тамақ', 'түскі', 'кешкі'],
  cafe: ['cafe', 'cafes', 'café', 'cafés', 'coffee', 'coffee_shop', 'кафе', 'кофе', 'кофехана', 'кафехана'],
  park: ['park', 'parks', 'garden', 'nature', 'парк', 'сквер', 'природ', 'саябақ', 'табиғат'],
  museum: ['museum', 'museums', 'музе', 'мұражай'],
  art: ['gallery', 'galleries', 'art', 'artwork', 'галере', 'искусств', 'картин', 'өнер'],
  library: ['library', 'libraries', 'библиотек', 'кітапхана'],
  attraction: ['attraction', 'landmark', 'monument', 'sight', 'достопримеч', 'монумент', 'памятник', 'көрікті', 'ескерткіш'],
  playground: ['playground', 'children', 'child', 'kids', 'ребен', 'детск', 'баламен', 'балалар'],
  viewpoint: ['viewpoint', 'view', 'панорам', 'смотров', 'көрініс'],
};

function normalized(value: string): string { return value.toLocaleLowerCase().replace(/ё/g, 'е'); }

function includesTerm(text: string, term: string): boolean {
  // English keywords are whole tokens: "small" is not "mall", and "start"
  // is not "art". Russian/Kazakh stems intentionally allow word endings.
  if (/^[a-z_]+$/.test(term)) return text.split(/[^\p{L}\p{N}_]+/u).includes(term);
  return text.includes(term);
}

export function inferInterests(query: string, explicit: string[] = []): string[] {
  const text = normalized(query);
  const excluded = inferExcludedInterests(query);
  const fromText = Object.entries(categoryTerms).filter(([, terms]) => terms.some(term => includesTerm(text, term))).map(([category]) => category);
  // Recognised text describes the current request. Default UI chips must not
  // add coffee to an explicit museum request or revive a negated category.
  const desired = fromText.length ? fromText : Object.entries(categoryTerms)
    .filter(([, terms]) => terms.some(term => includesTerm(normalized(explicit.join(' ')), term))).map(([category]) => category);
  return desired.filter(category => !excluded.includes(category));
}

type CategoryMention = { category: string; start: number; end: number };
function categoryMentions(text: string): CategoryMention[] {
  const mentions: CategoryMention[] = [];
  for (const [category, terms] of Object.entries(categoryTerms)) for (const term of terms) {
    const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const ending = /^[a-z_]+$/.test(term) ? '(?![\\p{L}\\p{N}_])' : '[\\p{L}]*';
    const pattern = new RegExp(`(^|[^\\p{L}\\p{N}_])(${escaped}${ending})`, 'gu');
    for (const match of text.matchAll(pattern)) {
      const start = match.index! + match[1].length;
      const end = start + match[2].length;
      if (!mentions.some(item => item.category === category && item.start === start)) mentions.push({ category, start, end });
    }
  }
  return mentions.sort((a, b) => a.start - b.start || b.end - a.end || a.category.localeCompare(b.category));
}

/** Deliberately bounded RU/EN/KK clauses and lists, not general semantics. */
export function inferExcludedInterests(query: string): string[] {
  const text = normalized(query).replace(/[’]/g, "'");
  const excluded = new Set<string>();
  const listSeparator = /^\s*(?:(?:,\s*)?(?:и|или|and|or|мен|және)\s*(?:(?:a|an|the)\s+)?|,)\s*(?:(?:без|никаких|любых|no|not|without|any)\s+)?$/u;
  const words = (value: string) => value.match(/[\p{L}\p{N}']+/gu)?.length ?? 0;
  // A positive restart ends a negative list. Commas alone may continue a list.
  const clauses = text.split(/[;.!?]|\b(?:but|instead|only)\b|(?:^|\s)(?:но|только|однако)(?=\s)|,\s*(?=(?:хочу|i\s+want|want|табиғат|саябақта\s+серуен))/u);
  for (const clause of clauses) {
    const mentions = categoryMentions(clause);
    const prefix = /(?:^|[^\p{L}])(?:без|никаких|не(?:\s+(?:хочу|хотим|нужно|нужна|нужен|надо|предлагай(?:те)?|показывай(?:те)?|рекомендуй(?:те)?))?|without|no|not|don't\s+want|do\s+not\s+want|don't\s+(?:suggest|recommend)|do\s+not\s+(?:suggest|recommend))(?=$|[^\p{L}])/gu;
    for (const match of clause.matchAll(prefix)) {
      const after = match.index! + match[0].length;
      let index = mentions.findIndex(item => item.start >= after);
      if (index < 0 || words(clause.slice(after, mentions[index].start)) > 6) continue;
      excluded.add(mentions[index].category);
      while (index + 1 < mentions.length && listSeparator.test(clause.slice(mentions[index].end, mentions[index + 1].start))) {
        index++; excluded.add(mentions[index].category);
      }
    }
    // Postposed Russian/Kazakh negatives can apply to the preceding list.
    const postfix = /(?:не\s+(?:хочу|нужно|нужна|нужен|надо|предлагай(?:те)?|показывай(?:те)?|рекомендуй(?:те)?)|(?:керек|қажет)\s+емес|емес|болмасын|барғым\s+келмейді|барғымыз\s+келмейді)(?=$|[^\p{L}])/gu;
    for (const match of clause.matchAll(postfix)) {
      let index = mentions.findLastIndex(item => item.end <= match.index!);
      if (index < 0) continue;
      const gap = clause.slice(mentions[index].end, match.index!);
      if (/[,;.!?]/u.test(gap) || words(gap) > 3) continue;
      excluded.add(mentions[index].category);
      while (index > 0 && listSeparator.test(clause.slice(mentions[index - 1].end, mentions[index].start))) {
        // "Хочу парк, кофе не предлагайте" contains a positive first clause,
        // rather than a single postposed negative list of both categories.
        if (/(?:хочу|хотим|want|келеді)\s+[^,;.!?]*$/u.test(clause.slice(0, mentions[index - 1].start))) break;
        index--; excluded.add(mentions[index].category);
      }
    }
    // Direct Kazakh privative suffixes: кофесіз, саябақсыз.
    for (const mention of mentions) if (/(?:сіз|сыз)$/u.test(clause.slice(mention.start, mention.end))) excluded.add(mention.category);
  }
  return Object.keys(categoryTerms).filter(category => excluded.has(category));
}

export function categoriesOf(poi: POI): string[] {
  // Name/description keyword search is separate: a museum named "Park" is not
  // categorised as a park, and a café description mentioning a museum isn't one.
  const value = normalized([poi.category, poi.tags.amenity, poi.tags.tourism, poi.tags.leisure, poi.tags.shop].filter(Boolean).join(' '));
  return Object.entries(categoryTerms).filter(([, terms]) => terms.some(term => includesTerm(value, term))).map(([key]) => key);
}

function primaryCategory(poi: POI): string {
  return poi.category === 'gallery' ? 'art' : ['restaurant','fast_food','food_court'].includes(poi.category) ? 'food' : poi.category;
}

const categoryLabels: Record<Language, Record<SupportedCategory, string>> = {
  ru: { art: 'Искусство', attraction: 'Достопримечательность', cafe: 'Кафе', food: 'Поесть', library: 'Библиотека', museum: 'Музей', park: 'Парк', playground: 'Детская площадка', viewpoint: 'Смотровая площадка' },
  en: { art: 'Art', attraction: 'Attraction', cafe: 'Café', food: 'Food', library: 'Library', museum: 'Museum', park: 'Park', playground: 'Playground', viewpoint: 'Viewpoint' },
  kk: { art: 'Өнер', attraction: 'Көрікті орын', cafe: 'Кафе', food: 'Тамақтану', library: 'Кітапхана', museum: 'Мұражай', park: 'Саябақ', playground: 'Балалар алаңы', viewpoint: 'Көрініс алаңы' },
};

function factualWhy(poi: POI, language: Language, matches: boolean, hours: HoursStatus, total: number, budget: number, returnMinutes: number, oneWay=false, destinationLabel=''): string {
  const label = categoryLabels[language][primaryCategory(poi) as SupportedCategory] ?? poi.category;
  if (language === 'en') return `${label}: OSM category${matches ? ' matches your request' : ''}. ${oneWay ? 'Route to destination' : 'Round trip'} ${total}/${budget} min; ${oneWay ? `final leg to ${destinationLabel}` : 'return'} ${returnMinutes} min. ${hours === 'open' ? 'OSM hours cover the visit.' : 'OSM hours are unknown or unsupported.'}`;
  if (language === 'kk') return `${label}: OSM санаты${matches ? ' сұрауыңызға сай' : ''}. ${oneWay ? 'Соңғы нүктеге бағыт' : 'Қайтуы бар бағыт'} ${total}/${budget} мин; ${oneWay ? `${destinationLabel} дейін` : 'кері жол'} ${returnMinutes} мин. ${hours === 'open' ? 'OSM кестесі сапар уақытын қамтиды.' : 'OSM жұмыс уақыты белгісіз не танылмады.'}`;
  return `${label}: категория OSM${matches ? ' соответствует запросу' : ''}. ${oneWay ? 'Маршрут до цели' : 'Маршрут с возвратом'} ${total}/${budget} мин; ${oneWay ? `до «${destinationLabel}»` : 'обратно'} ${returnMinutes} мин. ${hours === 'open' ? 'Часы OSM покрывают посещение.' : 'Часы OSM неизвестны или не распознаны.'}`;
}

export function haversineMeters(a: Point, b: Point): number {
  const rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad;
  const dLon = (b.lon - a.lon) * rad;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLon / 2) ** 2;
  return 6_371_000 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(Math.max(0, 1 - x)));
}

function travel(a: Point, b: Point): { minutes: number; meters: number } {
  const meters = haversineMeters(a, b) * DETOUR_FACTOR;
  return { minutes: Math.ceil(meters / WALKING_METERS_PER_MINUTE), meters };
}

const weekdayIndex: Record<string, number> = { Su: 0, Mo: 1, Tu: 2, We: 3, Th: 4, Fr: 5, Sa: 6 };
type HoursRule = { days: Set<number>; intervals: [number, number][]; off: boolean };

function parseHours(value: string | null): HoursRule[] | null {
  if (!value?.trim()) return null;
  if (value.trim() === '24/7') return [{ days: new Set([0, 1, 2, 3, 4, 5, 6]), intervals: [[0, 1440]], off: false }];
  const rules: HoursRule[] = [];
  for (const part of value.trim().split(';')) {
    const match = part.trim().match(/^(?:((?:Mo|Tu|We|Th|Fr|Sa|Su)(?:-(?:Mo|Tu|We|Th|Fr|Sa|Su))?(?:,(?:Mo|Tu|We|Th|Fr|Sa|Su)(?:-(?:Mo|Tu|We|Th|Fr|Sa|Su))?)*)\s+)?(off|closed|\d{2}:\d{2}-\d{2}:\d{2}(?:\s*,\s*\d{2}:\d{2}-\d{2}:\d{2})*)$/);
    if (!match) return null; // PH, seasonal dates, solar times and prose stay unknown.
    const days = new Set<number>();
    if (!match[1]) [0, 1, 2, 3, 4, 5, 6].forEach(day => days.add(day));
    else for (const group of match[1].split(',')) {
      const [first, last] = group.split('-');
      let day = weekdayIndex[first];
      const end = last ? weekdayIndex[last] : day;
      for (let n = 0; n < 7; n++) { days.add(day); if (day === end) break; day = (day + 1) % 7; }
    }
    const off = match[2] === 'off' || match[2] === 'closed';
    const intervals: [number, number][] = [];
    if (!off) for (const range of match[2].split(',')) {
      const [from, to] = range.trim().split('-').map(time => {
        const [hours, minutes] = time.split(':').map(Number);
        return hours <= 24 && minutes < 60 && (hours < 24 || minutes === 0) ? hours * 60 + minutes : NaN;
      });
      if (!Number.isFinite(from) || !Number.isFinite(to) || from === to || from === 1440) return null;
      intervals.push([from, to]);
    }
    rules.push({ days, intervals, off });
  }
  return rules.length ? rules : null;
}

const localFormatter = new Intl.DateTimeFormat('en-US', {
  timeZone: TIME_ZONE, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});

function isOpenAt(rules: HoursRule[], day: number, minute: number): boolean {
  let open = false;
  for (const rule of rules) {
    if (rule.days.has(day)) {
      // Later matching weekday rules replace earlier weekday schedules.
      open = !rule.off && rule.intervals.some(([from, to]) => to > from ? minute >= from && minute < to : minute >= from || (rule.days.has((day + 6) % 7) && minute < to));
    } else if (rule.days.has((day + 6) % 7) && !rule.off) {
      // Overnight intervals also belong to the preceding day's rule.
      if (rule.intervals.some(([from, to]) => to < from && minute < to)) open = true;
    }
  }
  return open;
}

export function openingHoursStatus(value: string | null, arrival: Date, visitMinutes = 0): HoursStatus {
  const rules = parseHours(value);
  if (!rules || !Number.isFinite(arrival.getTime())) return 'unknown';
  const parts = localFormatter.formatToParts(arrival);
  const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(parts.find(p => p.type === 'weekday')!.value);
  const minute = Number(parts.find(p => p.type === 'hour')!.value) * 60 + Number(parts.find(p => p.type === 'minute')!.value);
  // Evaluate the entire visit, so an arrival one minute before closing cannot
  // result in a museum visit marked as open. The closing instant is exclusive.
  const fractionalMinute = arrival.getUTCSeconds() / 60 + arrival.getUTCMilliseconds() / 60_000;
  for (let n = 0; n < Math.max(1, Math.ceil(visitMinutes + fractionalMinute)); n++) {
    const current = minute + n;
    if (!isOpenAt(rules, (day + Math.floor(current / 1440)) % 7, current % 1440)) return 'closed';
  }
  return 'open';
}

export function visitRange(poi: POI): { minimum: number; preferred: number } {
  const cats = categoriesOf(poi);
  if (cats.includes('museum')) return { minimum: 25, preferred: 45 };
  if (cats.includes('art')) return { minimum: 15, preferred: 30 };
  if (cats.includes('food')) return { minimum: 20, preferred: 35 };
  if (cats.includes('cafe')) return { minimum: 12, preferred: 25 };
  if (cats.includes('park')) return { minimum: 12, preferred: 25 };
  return { minimum: 8, preferred: 15 };
}

function activity(poi: POI, language: Language): string {
  const cats = categoriesOf(poi);
  const text = copy[language];
  return cats.includes('food') ? text.food : cats.includes('cafe') ? text.cafe : cats.includes('museum') || cats.includes('art') ? text.museum : cats.includes('park') ? text.park : text.other;
}

type Candidate = { poi: POI; categories: string[]; quality:number; score: number; min: number; preferred: number };
type Itinerary = { entries: Candidate[]; visits: number[]; legs: number[]; returnMinutes: number; walking: number; meters: number; total: number; utility: number };

function diverseShortlist(candidates: Candidate[]): Candidate[] {
  const selected: Candidate[] = [];
  const categories = new Set<string>();
  // Preserve at least one option per category before filling additional slots.
  // Otherwise abundant cafés with recorded hours crowd every park out of RAG.
  for (const candidate of candidates) if (!categories.has(primaryCategory(candidate.poi))) {
    selected.push(candidate); categories.add(primaryCategory(candidate.poi));
    if (selected.length === MAX_CANDIDATES) return selected;
  }
  // Give each category up to three alternatives before abundant categories
  // consume spare slots. A far-away 24/7 park must not hide a nearer park with
  // unknown hours when a mixed route is feasible.
  const counts = new Map<string, number>();
  for (const candidate of selected) counts.set(primaryCategory(candidate.poi), (counts.get(primaryCategory(candidate.poi)) ?? 0) + 1);
  for (const candidate of candidates) if (!selected.includes(candidate) && (counts.get(primaryCategory(candidate.poi)) ?? 0) < 3) {
    selected.push(candidate); counts.set(primaryCategory(candidate.poi), (counts.get(primaryCategory(candidate.poi)) ?? 0) + 1);
    if (selected.length === MAX_CANDIDATES) return selected;
  }
  for (const candidate of candidates) if (!selected.includes(candidate)) {
    selected.push(candidate); if (selected.length === MAX_CANDIDATES) break;
  }
  return selected;
}

function validPOI(poi: POI): boolean {
  return !!poi.id && !!poi.name && !!poi.sourceUrl && Number.isFinite(poi.lat) && Number.isFinite(poi.lon) && poi.lat >= 50.9 && poi.lat <= 51.35 && poi.lon >= 71.15 && poi.lon <= 71.75;
}

/** Resolve only explicit source IDs and reviewed aliases, never proximity/name matches. */
export function resolvePoiSelection(request:PlanRequest,dataset:POIDataset,canonicalId:(poi:POI)=>string=getCanonicalId):{excludedCanonical:Set<string>;requiredCanonical:string|null|undefined} {
 const rawIds=new Map(dataset.pois.map(p=>[p.id,canonicalId(p)]));
 const canonicalIds=new Set(rawIds.values());
 const resolve=(id:string)=>rawIds.get(id)??(canonicalIds.has(id)?id:null);
 const excludedCanonical=new Set((request.excludePoiIds??[]).map(id=>resolve(id)??id));
 return {excludedCanonical,requiredCanonical:request.requiredPoiId===undefined?undefined:resolve(request.requiredPoiId)};
}

export function planRoute(request: PlanRequest, dataset: POIDataset, options: { routing?: WalkingGraph; intent?: IntentContract; canonicalId?: (poi:POI)=>string; withAlternatives?:boolean; retrievalQuality?:(poi:POI)=>number; personalScore?:(poi:POI)=>number } = {}): PlanResponse {
  const started = performance.now();
  const text = copy[request.language] ?? copy.ru;
  const now = request.now ? new Date(request.now) : new Date();
  const endpoint = request.destination ?? request.origin;
  const samePoint=(a:Point,b:Point)=>a.lat===b.lat&&a.lon===b.lon;
  const oneWay = !!request.destination;
  const canonicalOf=options.canonicalId??getCanonicalId;
  const selection=resolvePoiSelection(request,dataset,canonicalOf);
  const includesRequired=(entries:Candidate[])=>request.requiredPoiId===undefined||entries.some(entry=>canonicalOf(entry.poi)===selection.requiredCanonical);
  if (options.intent?.needsClarification) return {
    plan: null, candidates: 0, excluded: [],
    trace: [{ step: 'intent', detail: text.clarify, ms: Math.round(performance.now() - started) }],
    generationMode: 'retrieval', warnings: [text.clarify],
    dataset: { count: dataset.pois.length, fetchedAt: dataset.fetchedAt, source: dataset.source },
  };
  let walkingSession: WalkingSession | null = null;
  try { walkingSession = options.routing?.createSession(request.origin, { avoidSteps: request.accessible, maxSnapMeters: 200 }) ?? null; } catch { /* Safe, explicit estimate fallback below. */ }
  // A safe snap to a different component is known to be unreachable: never
  // replace a proven impossible A→B journey with a geometric estimate.
  const destinationSnapped = oneWay && walkingSession && options.routing?.snap(endpoint, 200);
  const directMeters = oneWay && walkingSession && destinationSnapped ? (samePoint(request.origin,endpoint)?0:walkingSession.distanceBetween(request.origin, endpoint)) : null;
  const disconnectedDestination = !!destinationSnapped && directMeters === null;
  const endpointMissing = oneWay && walkingSession && !destinationSnapped;
  if (endpointMissing) walkingSession = null;
  const interests = options.intent ? [...new Set(options.intent.desiredCategories)] : inferInterests(request.query, request.interests);
  const excludedInterests = options.intent ? [...new Set(options.intent.excludedCategories)] : inferExcludedInterests(request.query);
  const coverAll = options.intent?.includeMode === 'all';
  const queryTerms = normalized(request.query).split(/[^\p{L}\p{N}]+/u).filter(term => term.length >= 3);
  const excluded = new Map<string, number>();
  const exclude = (reason: string) => excluded.set(reason, (excluded.get(reason) ?? 0) + 1);
  const seen = new Set<string>();
  const candidates: Candidate[] = [];
  let hadInvalid = false;
  // Reviewed identity mappings only. Prefer named source records to anonymous
  // footprint aliases; a nearby coordinate alone never merges two venues.
  const sourcePois = options.canonicalId ? [...dataset.pois].sort((a,b) =>
    Number(Boolean(b.tags?.name)) - Number(Boolean(a.tags?.name)) || a.id.localeCompare(b.id)) : dataset.pois;
  for (const poi of sourcePois) {
    if (!validPOI(poi)) { exclude('invalid-or-duplicate'); hadInvalid = true; continue; }
    const identity = options.canonicalId?.(poi) ?? poi.id;
    if(selection.excludedCanonical.has(canonicalOf(poi))){exclude('previously-shown');continue;}
    if (seen.has(identity)) { exclude(options.canonicalId ? 'canonical-duplicate' : 'invalid-or-duplicate'); if(!options.canonicalId)hadInvalid=true; continue; }
    seen.add(identity);
    if (request.indoor && poi.indoor !== true) { exclude('indoor-unverified'); continue; }
    if (request.accessible && !['yes', 'designated'].includes(normalized(poi.wheelchair ?? ''))) { exclude('wheelchair-unverified'); continue; }
    const cats = categoriesOf(poi);
    if (cats.some(category => excludedInterests.includes(category))) { exclude('interest-excluded'); continue; }
    const matched = interests.filter(category => cats.includes(category));
    if (interests.length && matched.length === 0) { exclude('interest-mismatch'); continue; }
    const nearest = travel(request.origin, poi);
    const range = visitRange(poi);
    const hours = openingHoursStatus(poi.openingHours, new Date(now.getTime() + nearest.minutes * 60_000), range.minimum);
    if (!walkingSession && hours === 'closed') { exclude('closed-during-visit'); continue; }
    if (!walkingSession && request.knownHoursOnly && hours === 'unknown') { exclude('hours-unverified'); continue; }
    // Graph routes may be shorter OR longer than the detour-factor fallback.
    // Only a straight-line lower bound can exclude a graph candidate here.
    const lowerBound = walkingSession ? Math.ceil(haversineMeters(request.origin, poi) / WALKING_METERS_PER_MINUTE) : nearest.minutes;
    const finalLowerBound = walkingSession ? Math.ceil(haversineMeters(poi, endpoint) / WALKING_METERS_PER_MINUTE) : travel(poi, endpoint).minutes;
    if (lowerBound + finalLowerBound + range.minimum + Math.max(3, Math.min(10, Math.ceil(request.minutes * 0.08))) > request.minutes) { exclude('time-budget'); continue; }
    const searchText = normalized([poi.name, poi.description, ...Object.values(poi.tags)].join(' '));
    const overlap = queryTerms.filter(term => searchText.includes(term)).length;
    const suppliedQuality=options.retrievalQuality?.(poi)??0;
    const quality=Number.isFinite(suppliedQuality)?Math.max(0,Math.min(2,Math.floor(suppliedQuality))):0;
    // At most four bonus points. Source richness never changes hard filters.
    let suppliedPersonal=0;try{suppliedPersonal=options.personalScore?.(poi)??0;}catch{/* Personalization is optional. */}
    const personal=Number.isFinite(suppliedPersonal)?Math.max(-6,Math.min(6,suppliedPersonal)):0;
    const score = 4 + matched.length * 5 + Math.min(3, overlap) + (hours === 'open' ? 0.5 : 0) + quality*2 + personal;
    candidates.push({ poi, categories: cats, quality, score, min: range.minimum, preferred: range.preferred });
  }
  // Source quality stays the same first-order criterion with or without a
  // preference callback. A neutral/OFF/unrelated profile must not change which
  // candidates survive the bounded shortlist. Personal scores only reorder
  // comparable source-quality candidates through the already-clamped score.
  candidates.sort((a, b) => b.quality - a.quality || b.score - a.score || haversineMeters(request.origin, a.poi) - haversineMeters(request.origin, b.poi) || a.poi.id.localeCompare(b.poi.id));
  const chooseShortlist=(entries:Candidate[]):Candidate[]=>{
    const list=diverseShortlist(entries);
    if(request.requiredPoiId===undefined)return list;
    const required=entries.find(entry=>canonicalOf(entry.poi)===selection.requiredCanonical);
    return required?[required,...list.filter(entry=>entry!==required)].slice(0,MAX_CANDIDATES):[];
  };
  let shortlist = chooseShortlist(candidates);
  const retrievedAt = performance.now();
  const buffer = Math.max(3, Math.min(10, Math.ceil(request.minutes * 0.08)));
  let best: Itinerary | null = null;
  let usedGraph = false;
  let hasGraphCoverage = disconnectedDestination;

  function coverage(entries: Candidate[]): number {
    return interests.filter(category => entries.some(entry => entry.categories.includes(category))).length;
  }

  function sourceRichness(entries:Candidate[]):number{return entries.reduce((sum,entry)=>sum+entry.quality,0);}
  function isBetter(option: Itinerary, previous: Itinerary | null): boolean {
    if (!previous) return true;
    if (coverAll && coverage(option.entries) !== coverage(previous.entries)) return coverage(option.entries) > coverage(previous.entries);
    if (sourceRichness(option.entries)!==sourceRichness(previous.entries))return sourceRichness(option.entries)>sourceRichness(previous.entries);
    if (option.utility !== previous.utility) return option.utility > previous.utility;
    if (option.total !== previous.total) return option.total < previous.total;
    return option.entries.map(entry => entry.poi.id).join('\u0000') < previous.entries.map(entry => entry.poi.id).join('\u0000');
  }

  function legDistance(from: Point, to: Point): { minutes: number; meters: number } | null {
    if(samePoint(from,to))return {minutes:0,meters:0};
    if (!usedGraph || !walkingSession) return travel(from, to);
    // The undirected graph lets all tentative final legs reuse B's tree.
    const meters = to === endpoint ? walkingSession.distanceBetween(endpoint, from) : walkingSession.distanceBetween(from, to);
    return meters === null ? null : { meters, minutes: Math.ceil(meters / WALKING_METERS_PER_MINUTE) };
  }

  function evaluate(entries: Candidate[], visits: number[]): Itinerary | null {
    if(!includesRequired(entries))return null;
    let position: Point = request.origin;
    let elapsed = 0;
    let meters = 0;
    let walking = 0;
    const legs: number[] = [];
    for (let i = 0; i < entries.length; i++) {
      const leg = legDistance(position, entries[i].poi);
      if (!leg) return null;
      elapsed += leg.minutes;
      walking += leg.minutes;
      meters += leg.meters;
      legs.push(leg.minutes);
      const status = openingHoursStatus(entries[i].poi.openingHours, new Date(now.getTime() + elapsed * 60_000), visits[i]);
      if (status === 'closed' || (request.knownHoursOnly && status !== 'open')) return null;
      elapsed += visits[i];
      position = entries[i].poi;
    }
    const back = legDistance(position, endpoint);
    if (!back) return null;
    const total = elapsed + back.minutes + buffer;
    if (total > request.minutes) return null;
    walking += back.minutes;
    meters += back.meters;
    const diversity = new Set(entries.map(entry => primaryCategory(entry.poi))).size;
    const coverageBonus = coverAll ? coverage(entries) * 100 : 0;
    return { entries: [...entries], visits: [...visits], legs, returnMinutes: back.minutes, walking, meters, total, utility: entries.reduce((sum, entry) => sum + entry.score, 0) + diversity * 0.4 + coverageBonus - walking * 0.09 };
  }

  function search(entries: Candidate[]): void {
    if (entries.length) {
      const option = evaluate(entries, entries.map(entry => entry.min));
      // Budget-infeasible prefixes cannot become feasible by adding stops.
      // Hours-infeasible prefixes could only improve by waiting; waiting is not
      // part of this product, so they are intentionally excluded too.
      if (!option) return;
      if (isBetter(option, best)) best = option;
    }
    if (entries.length === MAX_STOPS) return;
    // One useful café/playground is preferable to filling the clock with three
    // interchangeable venues. Mixed interests can still form a three-stop trip.
    for (const candidate of shortlist) if (!entries.includes(candidate) && !entries.some(entry => primaryCategory(entry.poi) === primaryCategory(candidate.poi))) search([...entries, candidate]);
  }
  if (walkingSession) {
    usedGraph = true;
    // Retrieve using origin shortest-path distances before selecting any stops.
    // A candidate with an inaccessible network or unsafe snap is not called a
    // walking route. The estimate fallback remains available when none qualify.
    const reachable = candidates.filter(candidate => {
      const meters = samePoint(request.origin,candidate.poi)?0:walkingSession!.distanceBetween(request.origin, candidate.poi);
      const finalMeters = samePoint(endpoint,candidate.poi)?0:walkingSession!.distanceBetween(endpoint, candidate.poi);
      if (meters === null || finalMeters === null) { exclude('walking-network-unavailable'); return false; }
      hasGraphCoverage = true;
      const minutes = Math.ceil(meters / WALKING_METERS_PER_MINUTE);
      const finalMinutes = Math.ceil(finalMeters / WALKING_METERS_PER_MINUTE);
      if (minutes + finalMinutes + candidate.min + buffer > request.minutes) { exclude('walking-time-budget'); return false; }
      const hours = openingHoursStatus(candidate.poi.openingHours, new Date(now.getTime() + minutes * 60_000), candidate.min);
      if (hours === 'closed') { exclude('closed-during-visit'); return false; }
      if (request.knownHoursOnly && hours === 'unknown') { exclude('hours-unverified'); return false; }
      return true;
    });
    shortlist = chooseShortlist(reachable);
    // With an "all" request, begin with a scarcer / longer requested visit.
    // A short high-scoring coffee stop must not consume the museum's budget.
    // This remains a bounded heuristic, not an optimal all-pairs graph search:
    // only A, B and selected stop sources obtain Dijkstra trees.
    const categoryPriority = [...interests].sort((a, b) => {
      const optionsA = shortlist.filter(entry => entry.categories.includes(a));
      const optionsB = shortlist.filter(entry => entry.categories.includes(b));
      return optionsA.length - optionsB.length
        || Math.max(0, ...optionsB.map(entry => entry.min)) - Math.max(0, ...optionsA.map(entry => entry.min))
        || a.localeCompare(b);
    });
    function priority(entries: Candidate[]): number {
      return Math.min(...entries.at(-1)!.categories.map(category => {
        const index = categoryPriority.indexOf(category);
        return index < 0 ? Number.MAX_SAFE_INTEGER : index;
      }));
    }
    let chosen: Candidate[] = [];
    while (chosen.length < MAX_STOPS) {
      let next: Itinerary | null = null;
      for (const candidate of shortlist) {
        if(!chosen.length&&request.requiredPoiId!==undefined&&!includesRequired([candidate]))continue;
        if (chosen.some(entry => entry.poi.id === candidate.poi.id || primaryCategory(entry.poi) === primaryCategory(candidate.poi))) continue;
        const option = evaluate([...chosen, candidate], [...chosen, candidate].map(entry => entry.min));
        if (!option) continue;
        if (coverAll && interests.length > 1) {
          if (!next
            || coverage(option.entries) > coverage(next.entries)
            || (coverage(option.entries) === coverage(next.entries) && (
              (!chosen.length && priority(option.entries) < priority(next.entries))
              || ((chosen.length > 0 || priority(option.entries) === priority(next.entries))
                && (sourceRichness(option.entries)>sourceRichness(next.entries)
                  ||(sourceRichness(option.entries)===sourceRichness(next.entries)&&(option.total < next.total || (option.total === next.total && isBetter(option, next))))))
            ))) next = option;
        } else if (isBetter(option, next)) next = option;
      }
      if (!next) break;
      best = next; chosen = next.entries;
    }
  }
  // A known graph route that exceeds the budget must NEVER be replaced by a
  // shorter geometric estimate. Fallback is only for missing network coverage.
  if (!best && !hasGraphCoverage) {
    usedGraph = false;
    shortlist = chooseShortlist(candidates);
    search([]);
  }
  // Up to three alternatives replace only the final stop. Their shared prefix
  // uses selected trees and final legs reuse B/origin; no extra graph searches.
  // No arbitrary all-pairs search or permutations are presented as variety.
  const selected = best as Itinerary | null;
  function expand(itinerary:Itinerary):Itinerary {
    for (let i=0;i<itinerary.entries.length;i++) for(let duration=itinerary.entries[i].preferred;duration>itinerary.visits[i];duration--) {
      const visits=[...itinerary.visits]; visits[i]=duration;
      const expanded=evaluate(itinerary.entries,visits);
      if(expanded){Object.assign(itinerary,expanded);break;}
    }
    return itinerary;
  }
  const identity=(entry:Candidate)=>options.canonicalId?.(entry.poi)??entry.poi.id;
  const signature=(entries:Candidate[])=>entries.map(identity).sort().join('|');
  if(selected)expand(selected);
  const alternatives:Itinerary[]=[];
  if(selected&&options.withAlternatives){
    const prefix=selected.entries.slice(0,-1), last=selected.entries.at(-1)!;
    for(const candidate of shortlist){
      // Do not pad a named venue's choices with generated anonymous labels.
      if(last.poi.tags.name&&!candidate.poi.tags.name&&candidate.quality===0)continue;
      if(candidate===last||primaryCategory(candidate.poi)!==primaryCategory(last.poi)
        ||prefix.some(entry=>identity(entry)===identity(candidate)))continue;
      const entries=[...prefix,candidate];
      if(signature(entries)===signature(selected.entries))continue;
      const option=evaluate(entries,entries.map(entry=>entry.min));
      if(!option||(coverAll&&coverage(option.entries)<coverage(selected.entries)))continue;
      expand(option);
      // An identical-cost alias-like option must not hide a later useful one.
      if(Math.ceil(option.meters)===Math.ceil(selected.meters)&&option.total===selected.total&&option.walking===selected.walking)continue;
      if(!alternatives.some(other=>signature(other.entries)===signature(option.entries)))alternatives.push(option);
    }
  }
  alternatives.sort((a,b)=>sourceRichness(b.entries)-sourceRichness(a.entries)||a.walking-b.walking||a.total-b.total||signature(a.entries).localeCompare(signature(b.entries)));
  const warnings:string[]=[usedGraph?text.walking:text.estimate,...(selected?[text.fallback]:[])];
  if(options.routing&&!usedGraph&&candidates.length>0&&!hasGraphCoverage)warnings.push(text.graphFallback);
  if(usedGraph&&request.accessible)warnings.push(text.steps);
  if(hadInvalid)warnings.push(text.invalid);
  function render(itinerary:Itinerary, reverseReturn=false):RoutePlan {
    let elapsed=0;
    const stops:PlanStop[]=itinerary.entries.map((entry,i)=>{
      elapsed+=itinerary.legs[i];
      const hoursStatus=openingHoursStatus(entry.poi.openingHours,new Date(now.getTime()+elapsed*60_000),itinerary.visits[i]);
      elapsed+=itinerary.visits[i];
      return {poi:entry.poi,canonicalId:identity(entry),visitMinutes:itinerary.visits[i],travelMinutes:itinerary.legs[i],
        why:factualWhy(entry.poi,request.language,interests.some(category=>entry.categories.includes(category)),hoursStatus,itinerary.total,request.minutes,itinerary.returnMinutes,oneWay,endpoint.label),
        activity:activity(entry.poi,request.language),hoursStatus};
    });
    let routeCoordinates:[number,number][]=[[request.origin.lon,request.origin.lat],...stops.map(stop=>[stop.poi.lon,stop.poi.lat] as [number,number]),[endpoint.lon,endpoint.lat]];
    let legEndIndices=stops.map((_,i)=>i+1).concat(stops.length+1);
    if(usedGraph&&walkingSession){
      legEndIndices=[];
      const points:Point[]=[request.origin,...stops.map(stop=>stop.poi),endpoint], coordinates:[number,number][]=[];
      for(let i=1;i<points.length;i++){
        const reversed=(oneWay||reverseReturn)&&i===points.length-1;
        if(samePoint(points[i-1],points[i])){if(!coordinates.length)coordinates.push([points[i].lon,points[i].lat]);}
        else {
          const leg=reversed?walkingSession.leg(endpoint,points[i-1]):walkingSession.leg(points[i-1],points[i]);
          if(leg){const path=reversed?[...leg.coordinates].reverse():leg.coordinates;coordinates.push(...(coordinates.length?path.slice(1):path));}
        }
        legEndIndices.push(coordinates.length-1);
      }
      if(coordinates.length===1){coordinates.push([...coordinates[0]]);legEndIndices[legEndIndices.length-1]=1;}
      routeCoordinates=coordinates;
    }
    return {title:text.title,summary:oneWay?(request.language==='en'?`A walk from ${request.origin.label} to ${endpoint.label}, including stops and arrival time.`:request.language==='kk'?`${request.origin.label} → ${endpoint.label}: аялдамалар мен жету уақыты есептелген.`:`Прогулка от «${request.origin.label}» до «${endpoint.label}»: остановки и путь до цели учтены.`):text.summary,stops,totalMinutes:itinerary.total,walkingMinutes:itinerary.walking,
      visitMinutes:itinerary.visits.reduce((sum,n)=>sum+n,0),bufferMinutes:buffer,distanceMeters:Math.ceil(itinerary.meters),returnMinutes:itinerary.returnMinutes,
      routeCoordinates,legEndIndices,routeKind:usedGraph?'walking':'estimate',routeMode:oneWay?'one-way':'round-trip',...(oneWay?{destination:{...request.destination!}}:{})};
  }
  const plan=selected?render(selected):null;
  const alternatePlans=alternatives.slice(0,3).map(option=>render(option,true));
  const alternatePlan=alternatePlans[0]??null;
  if([plan,...alternatePlans].some(p=>p?.stops.some(stop=>stop.hoursStatus==='unknown')))warnings.push(text.hours);
  if(!selected)warnings.push(oneWay?(request.language==='en'?'No feasible venue stop fits before your destination. Add time, move the endpoints or change the filters.':request.language==='kk'?'Соңғы нүктеге дейін орынға кіруге уақыт жетпейді. Уақытты, нүктелерді не сүзгілерді өзгертіңіз.':'До точки Б не нашлось остановки, которая помещается во время. Увеличьте время, измените точки или фильтры.'):text.none);
  let directRoute:PlanResponse['directRoute'];
  if(oneWay&&!disconnectedDestination){
    const meters=walkingSession&&directMeters!==null?directMeters:travel(request.origin,endpoint).meters;
    const minutes=Math.ceil(meters/WALKING_METERS_PER_MINUTE), minimumMinutes=minutes+buffer;
    const graphLeg=walkingSession&&directMeters!==null?(samePoint(request.origin,endpoint)?{coordinates:[[request.origin.lon,request.origin.lat],[endpoint.lon,endpoint.lat]] as [number,number][]}:walkingSession.leg(request.origin,endpoint)):null;
    directRoute={minutes,distanceMeters:Math.ceil(meters),routeKind:graphLeg?'walking':'estimate',feasible:minimumMinutes<=request.minutes,minimumMinutes,routeCoordinates:graphLeg?.coordinates??[[request.origin.lon,request.origin.lat],[endpoint.lon,endpoint.lat]]};
  }
  if(request.requiredPoiId!==undefined&&!selected){
    const blocked=typeof selection.requiredCanonical==='string'&&selection.excludedCanonical.has(selection.requiredCanonical);
    exclude(selection.requiredCanonical===null?'required-place-not-found':blocked?'required-place-excluded':'required-place-unavailable');
    warnings.push(request.language==='en'?'The selected place cannot be included under these constraints. The time, filters and exclusions were not changed.':request.language==='kk'?'Таңдалған орынды осы шарттармен қосу мүмкін емес. Уақыт, сүзгілер мен алып тастаулар өзгерген жоқ.':'Выбранное место нельзя включить при этих условиях. Время, фильтры и исключения не изменены.');
  }
  if(disconnectedDestination)warnings.push(request.language==='en'?'A and B are disconnected in the current walking graph. Choose different points; a straight-line estimate would hide this gap.':request.language==='kk'?'А мен Б нүктелері жаяу жолдар графында қосылмаған. Басқа нүктелерді таңдаңыз.':'Точки А и Б не соединены в текущем пешеходном графе. Выберите другие точки: оценка по прямой скрыла бы разрыв.');
  const stopCount=(count:number)=>{
    if(request.language==='en')return `${count} ${count===1?'stop':'stops'}`;
    if(request.language==='kk')return `${count} аялдама`;
    const last=count%10, hundred=count%100;
    return `${count} ${last===1&&hundred!==11?'остановка':last>=2&&last<=4&&(hundred<12||hundred>14)?'остановки':'остановок'}`;
  };
  const tradeoff=(p:RoutePlan)=>request.language==='en'?`${stopCount(p.stops.length)} · ${p.walkingMinutes} min walking · ${p.totalMinutes}/${request.minutes} min total · ${p.distanceMeters} m`:
    request.language==='kk'?`${stopCount(p.stops.length)} · ${p.walkingMinutes} мин жаяу · барлығы ${p.totalMinutes}/${request.minutes} мин · ${p.distanceMeters} м`:
    `${stopCount(p.stops.length)} · ${p.walkingMinutes} мин пешком · всего ${p.totalMinutes}/${request.minutes} мин · ${p.distanceMeters} м`;
  const choice=(p:RoutePlan,label:string)=>({id:`route:${JSON.stringify(p.stops.map(stop=>stop.canonicalId??stop.poi.id).sort())}`,label,plan:p,tradeoff:tradeoff(p)});
  const comparisonLabel=(p:RoutePlan,other:RoutePlan|null,primary:boolean)=>{
    if(other&&p.walkingMinutes!==other.walkingMinutes){
      const closer=p.walkingMinutes<other.walkingMinutes;
      return request.language==='en'?(closer?(oneWay?'Less walking':'Closer to the start'):'A longer walk'):
        request.language==='kk'?(closer?(oneWay?'Жаяу жол азырақ':'Бастауға жақынырақ'):'Ұзағырақ серуен'):
        closer?(oneWay?'Меньше пути':'Ближе к старту'):'Больше прогулки';
    }
    return request.language==='en'?(primary?'Primary route':'Another place'):
      request.language==='kk'?(primary?'Негізгі бағыт':'Басқа орын'):
      primary?'Основной маршрут':'Другое место';
  };
  const choices=plan?[choice(plan,comparisonLabel(plan,alternatePlan,true)),
    ...alternatePlans.map(other=>choice(other,comparisonLabel(other,plan,false)))]:[];
  return {
    plan,
    ...(directRoute?{directRoute}:{}),
    ...(options.withAlternatives?{options:choices}:{}),
    candidates: candidates.length,
    excluded: Array.from(excluded, ([reason, count]) => ({ reason, count })),
    trace: [
      ...(options.intent ? [{ step: 'intent', detail: `mode=${options.intent.includeMode}; desired=${interests.join(', ') || 'nearby'}; excluded=${excludedInterests.join(', ') || 'none'}`, ms: 0 }] : []),
      { step: 'retrieve', detail: `${dataset.pois.length} POI → ${candidates.length}; ${interests.join(', ') || 'nearby'}`, ms: Math.round(retrievedAt - started) },
      ...(options.retrievalQuality?[{step:'source-ranking',detail:'Reviewed facts=2, original OSM name=1, generated label=0; bounded bonus≤4. Hard filters and feasibility remain mandatory; all-category coverage ranks ahead of content. This preference is not a venue rating.',ms:0}]:[]),
      ...(options.personalScore?[{step:'personalization',detail:'Bounded local preference bonus ±6. Explicit categories, exclusions, required places and complete route/time checks still apply. No personal profile is sent to the model or a city authority.',ms:0}]:[]),
      { step: 'constraints', detail: `${shortlist.length} candidates; indoor=${request.indoor}; verifiedHours=${request.knownHoursOnly}; wheelchair=${request.accessible}`, ms: 0 },
      ...(walkingSession ? [{ step: 'walking-graph', detail: `${options.routing!.nodeCount} nodes; ${walkingSession.searchCount} Dijkstra searches; max connector ${Math.ceil(walkingSession.maxConnectorMeters)} m; ${usedGraph ? (oneWay?'network A→B costs used before selection':'network round-trip costs used before selection') : 'explicit estimate fallback'}`, ms: 0 }] : []),
      { step: oneWay?'point-to-point':'round-trip', detail: selected ? `${selected.entries.length} stops; ${selected.walking} walk + ${selected.visits.reduce((a, b) => a + b, 0)} visit + ${buffer} buffer ≤ ${request.minutes} min; ${oneWay?'final-leg':'return'}=${selected.returnMinutes}` : oneWay?'No feasible stop before destination':'No feasible round trip', ms: Math.round(performance.now() - retrievedAt) },
    ],
    generationMode: 'retrieval', warnings,
    dataset: { count: dataset.pois.length, fetchedAt: dataset.fetchedAt, source: dataset.source },
  };
}

export function validatePlanRequest(input: unknown): { value: PlanRequest } | { error: string } {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return { error: 'Expected a JSON object.' };
  const data = input as Record<string, unknown>;
  const origin = data.origin as Record<string, unknown> | undefined;
  const destination = data.destination as Record<string, unknown> | undefined;
  if (data.destination !== undefined && (!destination || typeof destination !== 'object' || Array.isArray(destination) || typeof destination.lat !== 'number' || typeof destination.lon !== 'number' || !Number.isFinite(destination.lat) || !Number.isFinite(destination.lon) || destination.lat < 50.9 || destination.lat > 51.35 || destination.lon < 71.15 || destination.lon > 71.75 || (destination.label !== undefined && (typeof destination.label !== 'string' || destination.label.length > 200)))) return {error:'Destination must be within Astana with a label of at most 200 characters.'};
  if (!origin || typeof origin !== 'object' || typeof origin.lat !== 'number' || typeof origin.lon !== 'number' || !Number.isFinite(origin.lat) || !Number.isFinite(origin.lon) || origin.lat < 50.9 || origin.lat > 51.35 || origin.lon < 71.15 || origin.lon > 71.75) return { error: 'Origin must be within Astana (lat 50.9–51.35, lon 71.15–71.75).' };
  if (typeof data.minutes !== 'number' || !Number.isInteger(data.minutes) || data.minutes < 5 || data.minutes > 360) return { error: 'Minutes must be an integer from 5 to 360.' };
  if (data.query !== undefined && (typeof data.query !== 'string' || data.query.length > MAX_QUERY_LENGTH)) return { error: `Query must be text of at most ${MAX_QUERY_LENGTH} characters.` };
  if (origin.label !== undefined && (typeof origin.label !== 'string' || origin.label.length > 200)) return { error: 'Origin label must be text of at most 200 characters.' };
  const validId=(value:unknown):value is string=>typeof value==='string'&&value.length>0&&value.length<=200&&!/[\s\u0000-\u001f\u007f]/u.test(value);
  if(data.requiredPoiId!==undefined&&!validId(data.requiredPoiId))return {error:'requiredPoiId must be a nonempty POI ID of at most 200 characters without whitespace.'};
  if(data.excludePoiIds!==undefined&&(!Array.isArray(data.excludePoiIds)||data.excludePoiIds.length>80||!data.excludePoiIds.every(validId)||new Set(data.excludePoiIds).size!==data.excludePoiIds.length))return {error:'excludePoiIds must contain at most 80 unique nonempty POI IDs, each at most 200 characters.'};
  if (data.interests !== undefined && (!Array.isArray(data.interests) || data.interests.length > 10 || data.interests.some(value => typeof value !== 'string' || value.length > 40))) return { error: 'Provide at most 10 interests, each at most 40 characters.' };
  for (const key of ['indoor', 'knownHoursOnly', 'accessible', 'contextConfirmed', 'localOnly']) if (data[key] !== undefined && typeof data[key] !== 'boolean') return { error: `${key} must be a boolean.` };
  if (data.language !== undefined && !['ru', 'kk', 'en'].includes(data.language as string)) return { error: 'Language must be ru, kk or en.' };
  if (data.now !== undefined && !parseIsoInstant(data.now)) return { error: 'now must be a valid calendar ISO date-time with Z or an explicit ±HH:MM offset.' };
  if (data.returnBy !== undefined && !parseIsoInstant(data.returnBy)) return {error:'returnBy must be a valid calendar ISO date-time with Z or an explicit ±HH:MM offset.'};
  if(data.departureMode!==undefined&&!['now','custom'].includes(data.departureMode as string))return {error:'departureMode must be now or custom.'};
  if(data.departureMode==='custom'&&data.now===undefined)return {error:'Custom departure requires now.'};
  if(data.localOnly===true&&typeof data.query==='string'&&data.query.trim())return {error:'Local-only recovery requires an empty query and explicit manual categories.'};
  return { value: {
    query: (data.query as string | undefined)?.trim() ?? '',
    origin: { lat: origin.lat, lon: origin.lon, label: (origin.label as string | undefined)?.trim() || 'Astana' },
    ...(destination ? {destination:{lat:destination.lat as number,lon:destination.lon as number,label:(destination.label as string|undefined)?.trim()||'Destination'}} : {}),
    minutes: data.minutes, interests: (data.interests as string[] | undefined) ?? [],
    indoor: (data.indoor as boolean | undefined) ?? false,
    knownHoursOnly: (data.knownHoursOnly as boolean | undefined) ?? false,
    accessible: (data.accessible as boolean | undefined) ?? false,
    language: (data.language as Language | undefined) ?? 'ru',
    ...(data.now === undefined ? {} : { now: data.now as string }),
    ...(data.returnBy === undefined ? {} : { returnBy: data.returnBy as string }),
    ...(data.departureMode === undefined ? {} : { departureMode: data.departureMode as 'now'|'custom' }),
    ...(data.contextConfirmed === undefined ? {} : { contextConfirmed: data.contextConfirmed as boolean }),
    ...(data.localOnly === undefined ? {} : { localOnly: data.localOnly as boolean }),
    ...(data.requiredPoiId===undefined?{}:{requiredPoiId:data.requiredPoiId as string}),
    ...(data.excludePoiIds===undefined?{}:{excludePoiIds:[...(data.excludePoiIds as string[])]}),
  } };
}
