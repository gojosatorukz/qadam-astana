import type { RoutePlan } from './qadam-types';

export type GuidePoint = [lon:number,lat:number];
export type GuideInstructionKind = 'start'|'straight'|'bear-left'|'left'|'bear-right'|'right'|'u-turn'|'arrive';
export type GuideInstruction = {
  id:string; atMeters:number; point:GuidePoint; kind:GuideInstructionKind;
  /** Signed change in compass bearing: positive is right, negative is left. */
  turnDegrees:number;
};
export type GuideLeg = {
  id:string; index:number; label:string; kind:'stop'|'finish';
  coordinates:GuidePoint[]; totalMeters:number; instructions:GuideInstruction[];
  /** Precomputed distance index keeps each GPS projection local and bounded. */
  cumulativeMeters:number[];
};
export type SupportedWalkGuide = {supported:true;legs:GuideLeg[];totalMeters:number};
export type WalkGuide = SupportedWalkGuide|{supported:false;reason:'estimate-route'|'invalid-geometry'|'missing-stop-anchor'|'ambiguous-stop-anchor'};
export type GuideFix = {lat:number;lon:number;accuracy:number;timestamp:number};
export type GuideProgress = {
  legIndex:number; meters:number; segmentIndex:number;
  /** Memory-only accepted fix. The core performs no storage or network I/O. */
  lastFix?:{lat:number;lon:number;timestamp:number};
};
export type GuideStatus = 'tracking'|'off-route'|'stale-fix'|'poor-accuracy'|'invalid-fix'|'finished';
export type GuideUpdate = {
  state:GuideProgress; status:GuideStatus; remainingMeters:number;
  remainingGuideMeters:number; nextInstruction:GuideInstruction|null;
  distanceToInstruction:number; canConfirmArrival:boolean; crossTrackMeters:number|null;
};
export type GuideOptions = {nowMs:number;maxAccuracyMeters?:number;staleAfterMs?:number;futureToleranceMs?:number};

const R=6_371_000,RAD=Math.PI/180;
const MAX_POINTS=200_000,MAX_WINDOW_SEGMENTS=96,MAX_TURN_SAMPLES=4000;
const clamp=(n:number,low:number,high:number)=>Math.max(low,Math.min(high,n));
const coordinate=(p:unknown):p is GuidePoint=>Array.isArray(p)&&p.length===2&&p.every(n=>typeof n==='number'&&Number.isFinite(n))&&Math.abs(p[0])<=180&&Math.abs(p[1])<=90;
const same=(a:GuidePoint,b:GuidePoint)=>Math.abs(a[0]-b[0])<=1e-8&&Math.abs(a[1]-b[1])<=1e-8;
function meters(a:GuidePoint,b:GuidePoint):number {
  const v=Math.sin((b[1]-a[1])*RAD/2)**2+Math.cos(a[1]*RAD)*Math.cos(b[1]*RAD)*Math.sin((b[0]-a[0])*RAD/2)**2;
  return R*2*Math.atan2(Math.sqrt(v),Math.sqrt(Math.max(0,1-v)));
}
function bearing(a:GuidePoint,b:GuidePoint):number {
  const x=Math.sin((b[0]-a[0])*RAD)*Math.cos(b[1]*RAD);
  const y=Math.cos(a[1]*RAD)*Math.sin(b[1]*RAD)-Math.sin(a[1]*RAD)*Math.cos(b[1]*RAD)*Math.cos((b[0]-a[0])*RAD);
  return Math.atan2(x,y)/RAD;
}
const signedTurn=(incoming:number,outgoing:number)=>((outgoing-incoming+540)%360)-180;
function cumulative(points:GuidePoint[]):number[]{const out=[0];for(let i=1;i<points.length;i++)out.push(out[i-1]+meters(points[i-1],points[i]));return out;}
function segmentAt(distances:number[],at:number):number {
  if(distances.length<2)return 0;
  let lo=0,hi=distances.length-1;
  while(lo+1<hi){const mid=(lo+hi)>>>1;if(distances[mid]<=at)lo=mid;else hi=mid;}
  return Math.min(lo,distances.length-2);
}
function pointAt(points:GuidePoint[],distances:number[],at:number):GuidePoint {
  if(points.length===1)return [...points[0]];
  const i=segmentAt(distances,clamp(at,0,distances.at(-1)!));
  const span=distances[i+1]-distances[i],t=span?clamp((at-distances[i])/span,0,1):0;
  return [points[i][0]+(points[i+1][0]-points[i][0])*t,points[i][1]+(points[i+1][1]-points[i][1])*t];
}
/** Suppress sub-metre noise and dense vertices; retain exact leg endpoints. */
function compact(raw:GuidePoint[]):GuidePoint[]{
  const result:GuidePoint[]=[[...raw[0]]];
  for(let i=1;i<raw.length-1;i++)if(meters(result.at(-1)!,raw[i])>=2.5)result.push([...raw[i]]);
  const last=raw.at(-1)!;
  if(!same(result.at(-1)!,last)){if(result.length>1&&meters(result.at(-1)!,last)<0.25)result[result.length-1]=[...last];else result.push([...last]);}
  return result;
}
function turnKind(angle:number):GuideInstructionKind {
  if(Math.abs(angle)>=145)return 'u-turn';
  if(angle>0)return angle>=55?'right':'bear-right';
  return angle<=-55?'left':'bear-left';
}
function instructions(id:string,points:GuidePoint[],distances:number[]):GuideInstruction[]{
  const total=distances.at(-1)!;
  const make=(kind:GuideInstructionKind,atMeters:number,turnDegrees=0):GuideInstruction=>({id:`${id}:${kind}:${Math.round(atMeters)}`,kind,atMeters,turnDegrees,point:pointAt(points,distances,atMeters)});
  const result=[make('start',0)];
  // Fixed arc-length samples and binary lookup bound work independently of raw
  // vertex density. Short oscillations are smoothed over 22 m on either side.
  const step=Math.max(8,total/(MAX_TURN_SAMPLES*0.75)),samples=new Set<number>(),candidates:{at:number;angle:number}[]=[];
  for(let at=8;at<total-8;at+=step)samples.add(at);
  // Preserve a substantial sharp corner at its actual vertex rather than
  // moving an instruction beyond that corner to the next regular sample.
  for(let i=1;i<points.length-1&&samples.size<MAX_TURN_SAMPLES;i++)if(distances[i]-distances[i-1]>=8&&distances[i+1]-distances[i]>=8&&Math.abs(signedTurn(bearing(points[i-1],points[i]),bearing(points[i],points[i+1])))>=35)samples.add(distances[i]);
  for(const at of [...samples].sort((a,b)=>a-b)){
    const before=pointAt(points,distances,Math.max(0,at-22)),center=pointAt(points,distances,at),after=pointAt(points,distances,Math.min(total,at+22));
    if(meters(before,center)<4||meters(center,after)<4)continue;
    const angle=signedTurn(bearing(before,center),bearing(center,after));
    if(Math.abs(angle)>=27)candidates.push({at,angle});
  }
  // One sustained bend produces one instruction, not one per noisy vertex.
  for(let i=0;i<candidates.length;){let best=candidates[i],last=candidates[i],j=i+1;
    while(j<candidates.length&&candidates[j].at-last.at<=32&&Math.sign(candidates[j].angle)===Math.sign(last.angle)){
      if(Math.abs(candidates[j].angle)>Math.abs(best.angle))best=candidates[j];last=candidates[j++];
    }
    result.push(make(turnKind(best.angle),best.at,best.angle));i=j;
  }
  if(!candidates.length&&total>30)result.push(make('straight',Math.min(total/2,80)));
  result.push(make('arrive',total));return result;
}

/** Optional legacy field; explicit boundaries must name every exact stop vertex. */
export function validLegEndIndices(coordinates:unknown,stops:unknown,indices:unknown):boolean {
  if(indices===undefined)return true;
  if(!Array.isArray(coordinates)||!coordinates.length||!Array.isArray(stops)||!Array.isArray(indices)||indices.length!==stops.length+1||indices.at(-1)!==coordinates.length-1)return false;
  let previous=0;
  for(let i=0;i<indices.length;i++){
    const end=indices[i];if(!Number.isInteger(end)||end<previous||end>=coordinates.length||!coordinate(coordinates[end]))return false;
    if(i<stops.length){const stop=stops[i];if(!stop||typeof stop!=='object'||!stop.poi||typeof stop.poi!=='object'||!same(coordinates[end],[stop.poi.lon,stop.poi.lat]))return false;}
    previous=end;
  }
  return true;
}

/** Geometry-only directions. No street, entrance, crossing or live-safety claims. */
export function createWalkGuide(plan:Pick<RoutePlan,'routeKind'|'routeCoordinates'|'stops'|'legEndIndices'>):WalkGuide {
  if(plan.routeKind!=='walking')return {supported:false,reason:'estimate-route'};
  const points=plan.routeCoordinates;
  if(!Array.isArray(points)||points.length<2||points.length>MAX_POINTS||!points.every(coordinate)||!Array.isArray(plan.stops)||plan.stops.length>3)return {supported:false,reason:'invalid-geometry'};
  const rawDistances=cumulative(points);if(rawDistances.at(-1)!<0.5&&plan.stops.length>0)return {supported:false,reason:'invalid-geometry'};
  if(!validLegEndIndices(points,plan.stops,plan.legEndIndices))return {supported:false,reason:'invalid-geometry'};
  const legs:GuideLeg[]=[];let cursor=0;
  const add=(end:number,kind:'stop'|'finish',label:string,id:string)=>{
    const coordinates=compact(points.slice(cursor,end+1)),distances=cumulative(coordinates),totalMeters=distances.at(-1)!;
    legs.push({id,index:legs.length,label,kind,coordinates,totalMeters,cumulativeMeters:distances,instructions:instructions(id,coordinates,distances)});cursor=end;
  };
  for(let i=0;i<plan.stops.length;i++){
    const stop=plan.stops[i];if(!stop?.poi||!coordinate([stop.poi.lon,stop.poi.lat]))return {supported:false,reason:'missing-stop-anchor'};
    const target:GuidePoint=[stop.poi.lon,stop.poi.lat];let end=plan.legEndIndices?.[i]??cursor;
    if(plan.legEndIndices===undefined){
      while(end<points.length&&!same(points[end],target))end++;
      if(end===points.length)return {supported:false,reason:'missing-stop-anchor'};
      let seenGap=false;for(let later=end+1;later<points.length;later++){if(!same(points[later],target))seenGap=true;else if(seenGap)return {supported:false,reason:'ambiguous-stop-anchor'};}
    }
    add(end,'stop',stop.poi.name,`stop:${i}:${stop.poi.id}`);
  }
  // Always use the FINAL vertex, even when A occurs earlier on the return path.
  add(points.length-1,'finish','Finish','finish');
  const totalMeters=legs.reduce((sum,leg)=>sum+leg.totalMeters,0);
  return totalMeters<0.5&&plan.stops.length>0?{supported:false,reason:'invalid-geometry'}:{supported:true,legs,totalMeters};
}
export function createGuideProgress():GuideProgress{return {legIndex:0,meters:0,segmentIndex:0};}

/** Only call in response to an explicit visitor confirmation, never a GPS tick. */
export function confirmGuideLeg(guide:SupportedWalkGuide,state:GuideProgress):GuideProgress {
  return {legIndex:clamp(Math.trunc(state.legIndex)+1,0,guide.legs.length),meters:0,segmentIndex:0};
}
function result(guide:SupportedWalkGuide,state:GuideProgress,status:GuideStatus,crossTrackMeters:number|null=null,canConfirmArrival=false):GuideUpdate {
  const leg=guide.legs[state.legIndex],remainingMeters=leg?Math.max(0,leg.totalMeters-state.meters):0;
  const nextInstruction=leg?.instructions.find(i=>i.atMeters>=state.meters-3&&(i.kind!=='start'||state.meters<=1))??leg?.instructions.at(-1)??null;
  return {state,status,remainingMeters,remainingGuideMeters:remainingMeters+guide.legs.slice(state.legIndex+1).reduce((n,l)=>n+l.totalMeters,0),nextInstruction,distanceToInstruction:nextInstruction?Math.max(0,nextInstruction.atMeters-state.meters):0,canConfirmArrival,crossTrackMeters};
}
function projection(fix:GuidePoint,a:GuidePoint,b:GuidePoint,minT:number,maxT:number):{point:GuidePoint;t:number;distance:number}{
  const lonScale=111_195*Math.cos((a[1]+b[1])*RAD/2),dx=(b[0]-a[0])*lonScale,dy=(b[1]-a[1])*111_195;
  const x=(fix[0]-a[0])*lonScale,y=(fix[1]-a[1])*111_195,den=dx*dx+dy*dy;
  const t=clamp(den?(x*dx+y*dy)/den:0,minT,maxT),point:GuidePoint=[a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])];
  return {point,t,distance:meters(fix,point)};
}

/** Bounded local projection; never advances a leg or reroutes the itinerary. */
export function updateWalkGuide(guide:SupportedWalkGuide,state:GuideProgress,fix:GuideFix,options:GuideOptions):GuideUpdate {
  if(state.legIndex>=guide.legs.length)return result(guide,state,'finished');
  const leg=guide.legs[state.legIndex];
  if(!leg||!Number.isFinite(state.meters)||!coordinate([fix?.lon,fix?.lat])||!Number.isFinite(fix.accuracy)||fix.accuracy<0||!Number.isFinite(fix.timestamp)||fix.timestamp<0||!Number.isFinite(options.nowMs))return result(guide,state,'invalid-fix');
  const staleAfter=clamp(options.staleAfterMs??20_000,1000,60_000),futureTolerance=clamp(options.futureToleranceMs??5000,0,5000);
  if(options.nowMs-fix.timestamp>staleAfter||fix.timestamp-options.nowMs>futureTolerance||(state.lastFix&&fix.timestamp<=state.lastFix.timestamp))return result(guide,state,'stale-fix');
  if(fix.accuracy>clamp(options.maxAccuracyMeters??40,1,60))return result(guide,state,'poor-accuracy');
  const distances=leg.cumulativeMeters,current=clamp(state.meters,0,leg.totalMeters),position:GuidePoint=[fix.lon,fix.lat];
  const movement=state.lastFix?meters([state.lastFix.lon,state.lastFix.lat],position):0;
  const elapsed=state.lastFix?clamp((fix.timestamp-state.lastFix.timestamp)/1000,0,20):0;
  const advance=state.lastFix?Math.max(12,Math.min(80,movement+Math.max(8,fix.accuracy/2),elapsed*2.5+fix.accuracy)):Math.min(35,15+fix.accuracy);
  const from=Math.max(0,current-20),to=Math.min(leg.totalMeters,current+advance),first=segmentAt(distances,from);
  let best:{at:number;distance:number}|null=null;
  if(leg.coordinates.length===1)best={at:0,distance:meters(position,leg.coordinates[0])};
  else for(let i=first;i<Math.min(leg.coordinates.length-1,first+MAX_WINDOW_SEGMENTS);i++){
    if(distances[i]>to)break;
    const length=distances[i+1]-distances[i];if(!length)continue;
    const candidate=projection(position,leg.coordinates[i],leg.coordinates[i+1],clamp((from-distances[i])/length,0,1),clamp((to-distances[i])/length,0,1));
    const at=distances[i]+candidate.t*length;
    // Ties choose earlier progress, so overlapping outgoing/return paths cannot
    // teleport to their later occurrence on the same piece of pavement.
    if(!best||candidate.distance<best.distance-0.05||(Math.abs(candidate.distance-best.distance)<=0.05&&at<best.at))best={at,distance:candidate.distance};
  }
  const offRoute=Math.max(30,fix.accuracy*1.6);
  if(!best||best.distance>offRoute)return result(guide,state,'off-route',best?.distance??null);
  const progress=Math.max(current,best.at),next:GuideProgress={legIndex:state.legIndex,meters:progress,segmentIndex:segmentAt(distances,progress),lastFix:{lat:fix.lat,lon:fix.lon,timestamp:fix.timestamp}};
  const endpointDistance=meters(position,leg.coordinates.at(-1)!);
  const arrival=fix.accuracy<=25&&leg.totalMeters-progress<=Math.max(8,Math.min(12,fix.accuracy/2))&&endpointDistance<=Math.max(10,Math.min(18,fix.accuracy*1.2));
  return result(guide,next,'tracking',best.distance,arrival);
}
