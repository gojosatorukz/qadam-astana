import type { RerouteRequest, RerouteResult } from './walk-reroute';
import type { GuideFix } from './walk-guide';

function distance(a:Pick<GuideFix,'lat'|'lon'>,b:Pick<GuideFix,'lat'|'lon'>){
  const rad=Math.PI/180,y=Math.sin((b.lat-a.lat)*rad/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin((b.lon-a.lon)*rad/2)**2;
  return 6_371_000*2*Math.atan2(Math.sqrt(y),Math.sqrt(Math.max(0,1-y)));
}
/** A lazy worker result is a proposal until position and wall-clock still agree. */
export function rerouteApplyBlock(result:RerouteResult,request:RerouteRequest,latestFix:GuideFix|null,nowMs:number):'unavailable'|'position-changed'|'deadline-changed'|null {
  if(result.kind!=='route')return 'unavailable';
  const points=result.plan.routeCoordinates,first=points[0],last=points.at(-1);
  if(!latestFix||!Number.isFinite(nowMs)||Math.abs(latestFix.lat)>90||Math.abs(latestFix.lon)>180||!Number.isFinite(latestFix.accuracy)||latestFix.accuracy>25||latestFix.accuracy<0||nowMs-latestFix.timestamp>20_000||latestFix.timestamp-nowMs>5000||latestFix.timestamp<request.fix.timestamp
    ||![latestFix.lat,latestFix.lon,latestFix.timestamp].every(Number.isFinite)||!first||!last||distance(request.fix,latestFix)>30)return 'position-changed';
  if(result.deadlineAt!==request.deadlineAt||Math.abs(first[0]-request.fix.lon)>1e-7||Math.abs(first[1]-request.fix.lat)>1e-7||Math.abs(last[0]-request.endpoint.lon)>1e-7||Math.abs(last[1]-request.endpoint.lat)>1e-7)return 'deadline-changed';
  if(!result.overBudget&&result.plan.totalMinutes*60_000>Date.parse(request.deadlineAt)-nowMs)return 'deadline-changed';
  return null;
}
