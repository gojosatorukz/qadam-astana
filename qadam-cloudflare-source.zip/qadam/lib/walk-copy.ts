import type { GuideInstructionKind } from './walk-guide';
export type WalkLanguage = 'ru' | 'kk' | 'en';
const labels: Record<GuideInstructionKind,[string,string,string]> = {
  start:['Следуй линии маршрута','Follow the route line','Бағыт сызығымен жүр'],
  straight:['Продолжай прямо','Continue straight','Тіке жүр'],
  left:['Поверни налево','Turn left','Солға бұрыл'],
  right:['Поверни направо','Turn right','Оңға бұрыл'],
  'bear-left':['Держись левее','Keep left','Сол жақты ұстан'],
  'bear-right':['Держись правее','Keep right','Оң жақты ұстан'],
  'u-turn':['Развернись по линии маршрута','Turn back along the route','Бағыт сызығымен кері бұрыл'],
  arrive:['Точка остановки','Stop location','Аялдама нүктесі'],
};
export function walkDirection(kind:GuideInstructionKind,language:WalkLanguage):string {
  return labels[kind][language==='en'?1:language==='kk'?2:0];
}
export function walkDistance(meters:number,language:WalkLanguage):string {
  const km=language==='en'?'km':'км',m=language==='en'?'m':'м';
  if(!Number.isFinite(meters)||meters<0)return '—';
  return meters>=1000?(meters/1000).toFixed(1)+' '+km:Math.max(0,Math.round(meters/10)*10)+' '+m;
}
