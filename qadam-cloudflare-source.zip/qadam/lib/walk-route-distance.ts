import type { GuideFix, GuidePoint, GuideProgress, GuideUpdate, WalkGuide } from './walk-guide';

const EARTH_RADIUS_METERS = 6_371_000;
const RADIANS = Math.PI / 180;
const METERS_PER_DEGREE = EARTH_RADIUS_METERS * RADIANS;
// Match the guide's geometry bound; do not scan arbitrary-size input per fix.
const MAX_ACTIVE_LEG_POINTS = 200_000;
const clamp = (value:number, lower:number, upper:number) => Math.max(lower, Math.min(upper, value));
const longitudeDelta = (degrees:number) => ((degrees + 540) % 360) - 180;

function isCoordinate(value:unknown):value is GuidePoint {
  return Array.isArray(value) && value.length === 2
    && typeof value[0] === 'number' && Number.isFinite(value[0]) && Math.abs(value[0]) <= 180
    && typeof value[1] === 'number' && Number.isFinite(value[1]) && Math.abs(value[1]) <= 90;
}

function distanceMeters(a:GuidePoint, b:GuidePoint):number {
  const haversine = Math.sin((b[1] - a[1]) * RADIANS / 2) ** 2
    + Math.cos(a[1] * RADIANS) * Math.cos(b[1] * RADIANS)
    * Math.sin(longitudeDelta(b[0] - a[0]) * RADIANS / 2) ** 2;
  const bounded = clamp(haversine, 0, 1);
  return EARTH_RADIUS_METERS * 2 * Math.atan2(Math.sqrt(bounded), Math.sqrt(1 - bounded));
}

/** Local tangent projection onto a clamped geometry segment, then metre distance. */
function segmentDistanceMeters(fix:GuidePoint, a:GuidePoint, b:GuidePoint):number {
  const lonScale = METERS_PER_DEGREE * Math.cos((a[1] + b[1]) * RADIANS / 2);
  const deltaLon = longitudeDelta(b[0] - a[0]);
  const dx = deltaLon * lonScale, dy = (b[1] - a[1]) * METERS_PER_DEGREE;
  const x = longitudeDelta(fix[0] - a[0]) * lonScale, y = (fix[1] - a[1]) * METERS_PER_DEGREE;
  const squaredLength = dx * dx + dy * dy;
  const fraction = squaredLength ? clamp((x * dx + y * dy) / squaredLength, 0, 1) : 0;
  const nearest:GuidePoint = [longitudeDelta(a[0] + deltaLon * fraction), a[1] + (b[1] - a[1]) * fraction];
  return distanceMeters(fix, nearest);
}

/**
 * Nearest geometric distance to the WHOLE active leg, independent of the
 * progress projection's limited forward window. Never inspects future legs or
 * changes progress. GPS freshness/accuracy and reroute policy belong to callers.
 * Invalid, finished, unsupported or oversized input returns null (no evidence
 * for an off-route trigger). This is not an entrance/crossing safety check.
 */
export function activeLegCrossTrackMeters(
  guide:WalkGuide,
  state:Pick<GuideProgress, 'legIndex'>,
  fix:Pick<GuideFix, 'lat'|'lon'>,
):number|null {
  if (guide?.supported !== true || !Array.isArray(guide.legs)) return null;
  const index = state?.legIndex;
  if (!Number.isInteger(index) || index < 0 || index >= guide.legs.length) return null;
  const position:GuidePoint = [fix?.lon, fix?.lat];
  if (!isCoordinate(position)) return null;
  const coordinates = guide.legs[index]?.coordinates;
  if (!Array.isArray(coordinates) || coordinates.length < 1 || coordinates.length > MAX_ACTIVE_LEG_POINTS) return null;
  // Validate every active vertex before returning even an exact match. A later
  // malformed vertex must not turn corrupted geometry into a confident zero.
  for (const point of coordinates) if (!isCoordinate(point)) return null;
  if (coordinates.length === 1) return distanceMeters(position, coordinates[0]);
  let nearest = Infinity;
  for (let i = 1; i < coordinates.length; i++) {
    nearest = Math.min(nearest, segmentDistanceMeters(position, coordinates[i - 1], coordinates[i]));
  }
  return Number.isFinite(nearest) ? nearest : null;
}

/**
 * A fix can be close to a later part of the active line while being outside the
 * guide's deliberately bounded progress window (for example after a GPS gap).
 * Offer an explicit route rebuild from that position, rather than teleporting
 * progress or repeatedly promising an off-route automatic trigger. This flag
 * never confirms an arrival, chooses an occurrence on a loop, or mutates state.
 */
export function walkPositionReplanNeeded(
  update:GuideUpdate|null|undefined,
  fix:GuideFix|null|undefined,
  wholeActiveLegCrossTrackMeters:number|null,
  nowMs:number,
):boolean {
  if(!update||!fix||update.status!=='off-route'||update.canConfirmArrival
    ||![fix.lat,fix.lon,fix.accuracy,fix.timestamp,nowMs].every(Number.isFinite)
    ||Math.abs(fix.lat)>90||Math.abs(fix.lon)>180||fix.accuracy<0||fix.accuracy>25||fix.timestamp<0
    ||nowMs-fix.timestamp>20_000||fix.timestamp-nowMs>5000
    ||wholeActiveLegCrossTrackMeters===null||!Number.isFinite(wholeActiveLegCrossTrackMeters)||wholeActiveLegCrossTrackMeters<0
    ||update.crossTrackMeters===null||!Number.isFinite(update.crossTrackMeters))return false;
  return update.crossTrackMeters>Math.max(30,fix.accuracy*1.6)
    // Match the auto-reroute policy's near-line boundary: none of these fixes
    // can trigger its lateral-deviation streak, so offer an honest action.
    &&wholeActiveLegCrossTrackMeters<=Math.max(45,fix.accuracy*2);
}
