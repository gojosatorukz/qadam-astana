import type { PassportError } from './passport-types';
type Language='ru'|'en'|'kk';
const choose=(language:Language,ru:string,en:string,kk:string)=>language==='en'?en:language==='kk'?kk:ru;
export function getPersonalizationLabels(language:Language) {
  return {
    on:choose(language,'С учётом моих впечатлений','Use my preferences','Қалауымды ескеру'),
    off:choose(language,'Без персонализации','Personalization off','Жекелеу өшірулі'),
    description:choose(language,'Только личный порядок подходящих мест. Время, фильтры и выбранная цель важнее.','Only your order of suitable places changes. Time, filters and a required place come first.','Тек сәйкес орындардың жеке реті өзгереді. Уақыт, сүзгілер және таңдалған орын басым.'),
    privateOnly:choose(language,'Только в этом браузере','Only in this browser','Тек осы браузерде'),
    softAvoid:choose(language,'Реже предлагать мне','Suggest less often to me','Маған сирек ұсыну'),
    notGlobal:choose(language,'Это твоё предпочтение, не публичный рейтинг места.','Your preference, not a public venue rating.','Бұл — жеке қалауың, орынның қоғамдық рейтингі емес.'),
  };
}
export function passportErrorMessage(error:PassportError|null,language:Language):string {
  if(!error)return '';
  const messages:Record<PassportError,[string,string,string]>={
    'storage-unavailable':['Браузер не разрешил сохранить паспорт. Планирование работает, изменения не сохранены.','The browser could not save the passport. Planning still works; changes were not saved.','Браузер паспортты сақтай алмады. Жоспарлау жұмыс істейді, өзгерістер сақталмады.'],
    'storage-full':['В хранилище браузера нет места. Изменения не сохранены; можно удалить данные паспорта и повторить.','Browser storage is full. Changes were not saved; clear passport data and retry.','Браузер жады толы. Өзгерістер сақталмады; паспорт деректерін тазалап, қайтала.'],
    'corrupt-data':['Данные паспорта повреждены или имеют неизвестный формат. Они не использованы. Удали данные паспорта, чтобы начать заново.','Passport data is corrupt or uses an unknown format and was not used. Clear it to start again.','Паспорт деректері бүлінген не пішімі белгісіз. Олар қолданылмады. Қайта бастау үшін тазала.'],
    'invalid-input':['Не удалось принять эти данные. Паспорт не изменён.','These details could not be accepted. The passport is unchanged.','Бұл деректер қабылданбады. Паспорт өзгермеді.'],
    'not-visited':['Оценка доступна после подтверждённого посещения во время прогулки.','Rate this place after a confirmed visit during a walk.','Орынды серуенде барғаның расталғаннан кейін бағала.'],
    'capacity-reached':['Достигнут предел локального паспорта. Данные не обрезаны; можно удалить паспорт и начать заново.','The local passport limit is reached. Data was not truncated; clear the passport to start again.','Жергілікті паспорт шегіне жетті. Деректер қысқартылмады; қайта бастау үшін тазала.'],
  };
  const [ru,en,kk]=messages[error];return choose(language,ru,en,kk);
}
export function passportLevelName(level:number,language:Language):string {
  const names=[['Первый шаг','First step','Алғашқы қадам'],['Исследователь','Explorer','Зерттеуші'],['Знаток кварталов','Neighborhood regular','Аудандарды білуші'],['Городской следопыт','City pathfinder','Қала ізкесері'],['Свой в городе','At home in the city','Қалада өз адамың']];
  const [ru,en,kk]=names[Math.max(0,Math.min(names.length-1,level-1))];return choose(language,ru,en,kk);
}
