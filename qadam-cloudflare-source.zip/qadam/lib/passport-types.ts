/** Only explicitly confirmed completed walks may emit this event. No location data. */
export type WalkCompletion = { walkId:string; visitedPoiIds:string[]; minutes:number; completedAt:string };
export type PassportRating = 1|2|3|4|5;
/** `avoid` is a SOFT personal preference: offer less often, never a hard filter. */
export type PlacePreference = { sentiment?:'liked'|'disliked'; rating?:PassportRating; avoid:boolean };
export type PassportState = {
  version:1;
  personalizationEnabled:boolean;
  walks:WalkCompletion[];
  placePreferences:Record<string,PlacePreference>;
  interestWeights:Record<string,number>;
};
/** Minimal browser-worker input: no walk IDs, dates, durations, coordinates or query. */
export type PassportRecommendation = Pick<PassportState,'personalizationEnabled'|'placePreferences'|'interestWeights'>;
export type PassportError = 'storage-unavailable'|'storage-full'|'corrupt-data'|'invalid-input'|'not-visited'|'capacity-reached';
export type PassportMutation = {ok:true;changed:boolean}|{ok:false;error:PassportError};
export type PassportStorage = Pick<Storage,'getItem'|'setItem'|'removeItem'>;
export type PassportPlace = {id:string;category:string};
