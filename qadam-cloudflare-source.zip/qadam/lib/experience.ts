import type { POI, PlanResponse } from './qadam-types';
// @ts-expect-error Native Node TS verification uses source extensions.
import { validLegEndIndices } from './walk-guide.ts';
export type Language = 'ru' | 'en' | 'kk';
export type Origin = { lat: number; lon: number; label: string };
export type CityDataset = { pois: POI[]; count: number; fetchedAt: string; generationAvailable?: boolean };
/** Request-validation bounds, not a promise of POI or walking-network coverage. */
export function isAstanaCoordinate(point: { lat: number; lon: number }): boolean {
  return Number.isFinite(point.lat) && Number.isFinite(point.lon)
    && point.lat >= 50.9 && point.lat <= 51.35 && point.lon >= 71.15 && point.lon <= 71.75;
}
export function hasExpiredCustomDeparture(response: PlanResponse | null, departureMode: 'now' | 'custom', now: number): boolean {
  return departureMode === 'custom' && !!response?.plan && !!response.departureAt
    && now > Date.parse(response.departureAt);
}
export const ORIGINS = [
  { lat: 51.12828, lon: 71.43055, labels: { ru: 'Байтерек', en: 'Baiterek', kk: 'Бәйтерек' } },
  { lat: 51.08915, lon: 71.41293, labels: { ru: 'EXPO · Mega Silk Way', en: 'EXPO · Mega Silk Way', kk: 'EXPO · Mega Silk Way' } },
  { lat: 51.11862, lon: 71.46919, labels: { ru: 'Национальный музей', en: 'National Museum', kk: 'Ұлттық музей' } },
  { lat: 51.16430, lon: 71.42580, labels: { ru: 'Набережная Есиля', en: 'Yesil riverfront', kk: 'Есіл жағалауы' } },
];
/** Input values are always Almaty wall time, independent of the device timezone. */
export function almatyInput(value: Date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Almaty', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(value);
  const p = (key: string) => parts.find(part => part.type === key)?.value ?? '';
  return p('year') + '-' + p('month') + '-' + p('day') + 'T' + p('hour') + ':' + p('minute');
}
export function inputInstant(value: string): string | null {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) return null;
  const date = new Date(value + ':00+05:00');
  if (!Number.isFinite(date.getTime()) || almatyInput(date) !== value) return null;
  return date.toISOString();
}
export function isPOI(value: unknown): value is POI {
  if (!value || typeof value !== 'object') return false;
  const p = value as Record<string, unknown>;
  return typeof p.id === 'string' && typeof p.name === 'string' && typeof p.category === 'string'
    && typeof p.lat === 'number' && Number.isFinite(p.lat) && typeof p.lon === 'number' && Number.isFinite(p.lon)
    && !!p.tags && typeof p.tags === 'object' && !Array.isArray(p.tags) && Object.values(p.tags).every(item => typeof item === 'string') && typeof p.sourceUrl === 'string'
    && typeof p.description === 'string' && (p.openingHours === null || typeof p.openingHours === 'string')
    && (p.wheelchair === null || typeof p.wheelchair === 'string') && (p.indoor === null || typeof p.indoor === 'boolean')
    && typeof p.fetchedAt === 'string' && Number.isFinite(Date.parse(p.fetchedAt));
}
const strings = (value: unknown): value is string[] => Array.isArray(value) && value.every(item => typeof item === 'string');
const instant = (value: unknown): boolean => typeof value === 'string' && Number.isFinite(Date.parse(value));
export function isCityDataset(value: unknown): value is CityDataset {
  if (!value || typeof value !== 'object') return false;
  const data = value as Record<string, unknown>;
  return Array.isArray(data.pois) && data.pois.length > 0 && data.pois.every(isPOI)
    && typeof data.count === 'number' && data.count === data.pois.length && instant(data.fetchedAt);
}
function isPlan(value: unknown): boolean {
  if (!value || typeof value !== 'object') return false;
  const p = value as Record<string, unknown>;
  if(p.destination!==undefined){const point=p.destination as Record<string,unknown>;if(!point||!isAstanaCoordinate({lat:point.lat as number,lon:point.lon as number})||typeof point.label!=='string')return false;}
  if(p.routeMode!==undefined&&!['one-way','round-trip'].includes(p.routeMode as string))return false;
  const numeric = ['totalMinutes', 'walkingMinutes', 'visitMinutes', 'bufferMinutes', 'distanceMeters', 'returnMinutes'];
  return validLegEndIndices(p.routeCoordinates,p.stops,p.legEndIndices)&&numeric.every(key => typeof p[key] === 'number' && Number.isFinite(p[key]) && (p[key] as number) >= 0)
    && Array.isArray(p.stops) && p.stops.length >= 1 && p.stops.length <= 3
    && p.stops.every(stop => stop && isPOI(stop.poi) && typeof stop.visitMinutes === 'number' && Number.isFinite(stop.visitMinutes) && stop.visitMinutes >= 0 && typeof stop.travelMinutes === 'number' && Number.isFinite(stop.travelMinutes) && stop.travelMinutes >= 0 && typeof stop.why === 'string' && typeof stop.activity === 'string'
      && ['open', 'closed', 'unknown'].includes(stop.hoursStatus) && (stop.observation === undefined || typeof stop.observation === 'string')
      && (stop.facts === undefined || (Array.isArray(stop.facts) && stop.facts.every((fact: Record<string, unknown>) => fact && typeof fact.id === 'string' && typeof fact.text === 'string' && typeof fact.sourceUrl === 'string' && instant(fact.checkedAt)))))
    && Array.isArray(p.routeCoordinates) && p.routeCoordinates.every(point => Array.isArray(point) && point.length === 2 && point.every(Number.isFinite))
    && ['walking', 'estimate'].includes(p.routeKind as string);
}
/** Guard network JSON before it reaches React/map renderers. */
export function isPlanResponse(value: unknown): value is PlanResponse {
  if (!value || typeof value !== 'object') return false;
  const r = value as Record<string, unknown>;
  if (!['gemini', 'retrieval'].includes(r.generationMode as string)) return false;
  if (r.intent !== undefined) {
    if (!r.intent || typeof r.intent !== 'object') return false;
    const intent = r.intent as Record<string, unknown>;
    if (!strings(intent.achievedCategories) || !strings(intent.unmetCategories)) return false;
    if (intent.contract !== null) {
      if (!intent.contract || typeof intent.contract !== 'object') return false;
      const contract = intent.contract as Record<string, unknown>;
      if (!strings(contract.desiredCategories) || !strings(contract.excludedCategories) || !Array.isArray(contract.unsupported)
        || !contract.unsupported.every(wish => wish && typeof wish.text === 'string')) return false;
    }
  }
  if(r.directRoute!==undefined){const d=r.directRoute as Record<string,unknown>;if(!d||typeof d!=='object'||!['minutes','distanceMeters','minimumMinutes'].every(k=>typeof d[k]==='number'&&Number.isFinite(d[k])&&(d[k] as number)>=0)||typeof d.feasible!=='boolean'||!['walking','estimate'].includes(d.routeKind as string)||!Array.isArray(d.routeCoordinates)||d.routeCoordinates.length<2||!d.routeCoordinates.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)))return false;}
  for (const key of ['departureAt', 'planComputedAt', 'returnBy']) if (r[key] !== undefined && !instant(r[key])) return false;
  if (r.effectiveMinutes !== undefined && (typeof r.effectiveMinutes !== 'number' || !Number.isFinite(r.effectiveMinutes) || r.effectiveMinutes < 0)) return false;
  if (!(r.plan === null || isPlan(r.plan)) || !Array.isArray(r.trace) || !Array.isArray(r.warnings) || !r.warnings.every(item => typeof item === 'string')) return false;
  if (!r.trace.every(item => item && typeof item.step === 'string' && typeof item.detail === 'string' && typeof item.ms === 'number')) return false;
  if (r.options !== undefined && (!Array.isArray(r.options) || r.options.length > 4 || !r.options.every(option => option && typeof option.id === 'string' && typeof option.label === 'string' && typeof option.tradeoff === 'string' && isPlan(option.plan)))) return false;
  if (r.clarification !== undefined) {
    const c = r.clarification as Record<string, unknown>;
    if (!c || typeof c.question !== 'string' || (c.message !== undefined && typeof c.message !== 'string') || !Array.isArray(c.options) || !c.options.every(option => option && typeof option.id === 'string' && typeof option.label === 'string'
      && ['manual-category','set-origin','external-search','retry','edit-query'].includes(option.action)
      && (option.origin === undefined || (typeof option.origin.lat === 'number' && Number.isFinite(option.origin.lat) && typeof option.origin.lon === 'number' && Number.isFinite(option.origin.lon) && typeof option.origin.label === 'string'))
      && (option.action !== 'external-search' || safeExternalURL(option.value) !== null))) return false;
  }
  return true;
}
/** Only documented, explicit map/search handoffs are accepted from network JSON. */
export function safeExternalURL(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password && !url.port
      && ['www.google.com', 'google.com', '2gis.kz'].includes(url.hostname) ? url.href : null;
  } catch { return null; }
}
/** Public destination only. 2GIS uses its documented lon,lat map-point link, not a firm ID. */
export function publicMapLink(poi: POI, provider: 'google' | '2gis' = 'google'): string {
  if (provider === '2gis') {
    const point = poi.lon + ',' + poi.lat;
    return 'https://2gis.kz/astana/geo/' + point + '?m=' + encodeURIComponent(point + '/16');
  }
  return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(poi.lat + ',' + poi.lon);
}
export function scrollToElement(element: HTMLElement | null): void {
  element?.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
}
