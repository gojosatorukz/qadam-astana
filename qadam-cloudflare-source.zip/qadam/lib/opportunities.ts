// @ts-expect-error Native Node verification uses explicit source extensions.
import {categoriesOf,inferInterests,visitRange,openingHoursStatus,validatePlanRequest,WALKING_METERS_PER_MINUTE}from'./planner.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import {getCanonicalId}from'./place-facts.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import {POI_COVERAGE}from'./planning-context.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import {resolvePlanTime}from'./time-context.ts';
import type{POIDataset}from'./planner';
import type{WalkingGraph,WalkingSession}from'./walking-graph';
import type{PlanRequest,POI}from'./qadam-types';

export type OpportunityRequest=Pick<PlanRequest,'origin'|'destination'|'minutes'|'interests'|'indoor'|'knownHoursOnly'|'accessible'|'language'>&{departureAt?:string};
export type Opportunity={poi:POI;canonicalId:string;totalMinutes:number;walkingMinutes:number;outboundMinutes:number;finalLegMinutes:number;visitMinutes:number;bufferMinutes:number;distanceMeters:number;connectorMeters:number;hoursStatus:'open'|'unknown'};
export type OpportunityReason='invalid-request'|'outside-coverage'|'network-unavailable'|'endpoint-disconnected';
export type OpportunityResult={kind:'ready'|'unavailable';reason?:OpportunityReason;places:Opportunity[];minutes:number;departureAt:string;computedAt:string;dataset:{count:number;source:string;fetchedAt:string};diagnostics:{searches:number;contextReused:boolean;evaluated:number};direct?:{walkingMinutes:number;minimumMinutes:number;distanceMeters:number}};
type Point={lat:number;lon:number};
type Metrics={outbound:number;final:number;meters:number;connectorMeters:number};
type Context={key:string;a:WalkingSession|null;b:WalkingSession|null;endpoint:Point;startConnector:number;endConnector:number;direct:number|null;metrics:Map<string,Metrics|null>};
const same=(a:Point,b:Point)=>a.lat===b.lat&&a.lon===b.lon;
const bufferFor=(minutes:number)=>Math.max(3,Math.min(10,Math.ceil(minutes*0.08)));
const inSnapshot=(p:Point)=>p.lat>=POI_COVERAGE.south&&p.lat<=POI_COVERAGE.north&&p.lon>=POI_COVERAGE.west&&p.lon<=POI_COVERAGE.east;
const validPoi=(poi:POI)=>!!poi&&typeof poi.id==='string'&&!!poi.id&&typeof poi.name==='string'&&!!poi.name&&typeof poi.category==='string'&&!!poi.tags&&typeof poi.tags==='object'&&!Array.isArray(poi.tags)&&typeof poi.sourceUrl==='string'&&!!poi.sourceUrl&&Number.isFinite(poi.lat)&&Number.isFinite(poi.lon)&&poi.lat>=50.9&&poi.lat<=51.35&&poi.lon>=71.15&&poi.lon<=71.75;

/** Single-stop possibilities only. No query interpretation, estimates or new venues. */
export function createOpportunityEngine(dataset:POIDataset,graph:WalkingGraph){
 let context:Context|null=null;
 // Match the canonical planner's reviewed identity and named-source preference.
 const seen=new Set<string>();
 const pois=[...dataset.pois].sort((a,b)=>Number(Boolean(b.tags?.name))-Number(Boolean(a.tags?.name))||a.id.localeCompare(b.id)).filter(poi=>{if(!validPoi(poi))return false;const id=getCanonicalId(poi);if(seen.has(id))return false;seen.add(id);return true;});
 return {compute(input:OpportunityRequest,clock=new Date()):OpportunityResult{
  const computedAt=Number.isFinite(clock.getTime())?clock.toISOString():new Date(0).toISOString();
  const initial:OpportunityResult={kind:'unavailable',reason:'invalid-request',places:[],minutes:input?.minutes??0,departureAt:computedAt,computedAt,dataset:{count:dataset.pois.length,source:dataset.source,fetchedAt:dataset.fetchedAt},diagnostics:{searches:0,contextReused:false,evaluated:0}};
  if(!input||!Number.isFinite(clock.getTime()))return initial;
  const parsed=validatePlanRequest({...input,query:'',now:input.departureAt??computedAt,departureMode:'custom',localOnly:true});
  if('error'in parsed)return initial;
  const request=parsed.value,departure=new Date(request.now!),endpoint=request.destination??request.origin;
  if('error'in resolvePlanTime(request,clock,true))return initial;
  initial.departureAt=departure.toISOString();initial.minutes=request.minutes;
  const interests=inferInterests('',request.interests);
  if(request.interests.length&&!interests.length)return initial;
  if(!inSnapshot(request.origin))return {...initial,reason:'outside-coverage'};
  const key=JSON.stringify([request.origin.lat,request.origin.lon,endpoint.lat,endpoint.lon,request.accessible]);
  const reused=context?.key===key;
  if(!reused){
   const a=graph.createSession(request.origin,{avoidSteps:request.accessible,maxSnapMeters:200});
   const b=same(request.origin,endpoint)?a:graph.createSession(endpoint,{avoidSteps:request.accessible,maxSnapMeters:200});
   context={key,a,b,endpoint,startConnector:graph.snap(request.origin,200)?.meters??0,endConnector:graph.snap(endpoint,200)?.meters??0,direct:a&&b?(same(request.origin,endpoint)?0:a.distanceBetween(request.origin,endpoint)):null,metrics:new Map()};
  }
  const current=context!;
  const diagnostics=()=>({searches:(current.a?.searchCount??0)+(current.b&&current.b!==current.a?current.b.searchCount:0),contextReused:reused,evaluated:pois.length});
  if(!current.a||!current.b)return {...initial,reason:'network-unavailable',diagnostics:diagnostics()};
  if(current.direct===null)return {...initial,reason:'endpoint-disconnected',diagnostics:diagnostics()};
  const buffer=bufferFor(request.minutes),places:Opportunity[]=[];
  for(const poi of pois){
   if(request.indoor&&poi.indoor!==true)continue;
   if(request.accessible&&!['yes','designated'].includes((poi.wheelchair??'').toLowerCase()))continue;
   const categories=categoriesOf(poi);
   if(interests.length&&!interests.some(category=>categories.includes(category)))continue;
   let metrics=current.metrics.get(poi.id);
   if(metrics===undefined){
    const outbound=same(request.origin,poi)?0:current.a.distanceBetween(request.origin,poi);
    const final=same(endpoint,poi)?0:current.b.distanceBetween(endpoint,poi);
    const poiSnap=graph.snap(poi,200);
    metrics=outbound===null||final===null||!poiSnap?null:{outbound:Math.ceil(outbound/WALKING_METERS_PER_MINUTE),final:Math.ceil(final/WALKING_METERS_PER_MINUTE),meters:outbound+final,connectorMeters:(same(request.origin,poi)?0:current.startConnector+poiSnap.meters)+(same(endpoint,poi)?0:current.endConnector+poiSnap.meters)};
    current.metrics.set(poi.id,metrics);
   }
   if(!metrics)continue;
   const visitMinutes=visitRange(poi).minimum,walkingMinutes=metrics.outbound+metrics.final,totalMinutes=walkingMinutes+visitMinutes+buffer;
   if(totalMinutes>request.minutes)continue;
   const hoursStatus=openingHoursStatus(poi.openingHours,new Date(departure.getTime()+metrics.outbound*60_000),visitMinutes);
   if(hoursStatus==='closed'||(request.knownHoursOnly&&hoursStatus==='unknown'))continue;
   places.push({poi,canonicalId:getCanonicalId(poi),totalMinutes,walkingMinutes,outboundMinutes:metrics.outbound,finalLegMinutes:metrics.final,visitMinutes,bufferMinutes:buffer,distanceMeters:Math.ceil(metrics.meters),connectorMeters:Math.ceil(metrics.connectorMeters),hoursStatus});
  }
  places.sort((a,b)=>a.totalMinutes-b.totalMinutes||Number(b.hoursStatus==='open')-Number(a.hoursStatus==='open')||a.poi.id.localeCompare(b.poi.id));
  const directMinutes=Math.ceil(current.direct/WALKING_METERS_PER_MINUTE);
  return {...initial,kind:'ready',reason:undefined,places,diagnostics:diagnostics(),direct:{walkingMinutes:directMinutes,minimumMinutes:directMinutes+buffer,distanceMeters:Math.ceil(current.direct)}};
 }};
}

/** Guard the bounded, worker-local result before displaying it. */
export function isOpportunityResult(value:unknown):value is OpportunityResult{
 if(!value||typeof value!=='object')return false;const v=value as OpportunityResult;
 if(!['ready','unavailable'].includes(v.kind)||!Array.isArray(v.places)||v.places.length>1204||!Number.isInteger(v.minutes)||v.minutes<5||v.minutes>360||typeof v.departureAt!=='string'||!Number.isFinite(Date.parse(v.departureAt))||typeof v.computedAt!=='string'||!Number.isFinite(Date.parse(v.computedAt))||!v.dataset||!Number.isInteger(v.dataset.count)||v.dataset.count<0||typeof v.dataset.source!=='string'||typeof v.dataset.fetchedAt!=='string'||!v.diagnostics||!Number.isInteger(v.diagnostics.searches)||v.diagnostics.searches<0||v.diagnostics.searches>2||typeof v.diagnostics.contextReused!=='boolean'||!Number.isInteger(v.diagnostics.evaluated)||v.diagnostics.evaluated<0||v.diagnostics.evaluated>1204)return false;
 if(v.kind==='unavailable'&&(!['invalid-request','outside-coverage','network-unavailable','endpoint-disconnected'].includes(v.reason??'')||v.places.length))return false;
 const ids=new Set<string>();
 return v.places.every(p=>{if(!p||!validPoi(p.poi)||typeof p.canonicalId!=='string'||ids.has(p.canonicalId)||!['open','unknown'].includes(p.hoursStatus))return false;ids.add(p.canonicalId);return [p.totalMinutes,p.walkingMinutes,p.outboundMinutes,p.finalLegMinutes,p.visitMinutes,p.bufferMinutes,p.distanceMeters,p.connectorMeters].every(n=>Number.isFinite(n)&&n>=0)&&p.totalMinutes<=v.minutes&&p.totalMinutes===p.walkingMinutes+p.visitMinutes+p.bufferMinutes&&p.walkingMinutes===p.outboundMinutes+p.finalLegMinutes;});
}
