// @ts-expect-error Native Node verification uses explicit source extensions.
import{createOpportunityEngine}from'./opportunities.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{WalkingGraph}from'./walking-graph.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import{applyPlaceFacts}from'./place-facts.ts';
import type{POIDataset}from'./planner';
import type{RawWalkingGraph}from'./walking-graph';
import type{OpportunityRequest,OpportunityResult}from'./opportunities';

export type OpportunityWorkerRequest={type:'opportunities';id:number;request:OpportunityRequest};
export type OpportunityWorkerError='POI_LOAD'|'POI_INIT'|'GRAPH_LOAD'|'GRAPH_INIT'|'COMPUTE';
export type OpportunityWorkerReply={type:'opportunities-result';id:number;result:OpportunityResult}|{type:'opportunities-error';id:number;code:OpportunityWorkerError};
const scope=globalThis as unknown as{onmessage:((event:MessageEvent<OpportunityWorkerRequest>)=>void)|null;postMessage(message:OpportunityWorkerReply):void};
let engine:ReturnType<typeof createOpportunityEngine>|null=null,latest:OpportunityWorkerRequest|null=null,running=false;
async function read(url:URL){const response=await fetch(url,{headers:{Accept:'application/json'},mode:'same-origin',credentials:'same-origin',redirect:'error',cache:'force-cache'});if(!response.ok)throw new Error('Data unavailable');return response.json()as Promise<unknown>;}
scope.onmessage=event=>{
 const message=event.data;if(!message||message.type!=='opportunities'||!Number.isSafeInteger(message.id)||message.id<1)return;
 latest=message;if(running)return;running=true;
 void(async()=>{
  while(latest){let current=latest;latest=null;let stage:OpportunityWorkerError='COMPUTE';
   try{
    if(!engine){stage='POI_LOAD';const raw=await read(new URL('../data/poi.json',import.meta.url));stage='POI_INIT';const dataset=applyPlaceFacts(raw as POIDataset);stage='GRAPH_LOAD';const rawGraph=await read(new URL('../data/walk-graph.json',import.meta.url));stage='GRAPH_INIT';engine=createOpportunityEngine(dataset,new WalkingGraph(rawGraph as RawWalkingGraph));}
    // While raw assets loaded, use only the most recent slider position.
    if(latest){current=latest;latest=null;}
    stage='COMPUTE';const result=engine.compute(current.request);
    scope.postMessage({type:'opportunities-result',id:current.id,result});
   }catch{scope.postMessage({type:'opportunities-error',id:current.id,code:stage});}
  }
 })().finally(()=>{running=false;});
};
