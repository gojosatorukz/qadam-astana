/** Recheck at permission resolution, since the browser prompt can remain open. */
export function walkStartBlock(options: {nowMs:number; departureMode:'now'|'custom'; departureAt?:string; computedAt?:string; deadlineAt:string; hasStarted:boolean}):'future'|'expired'|null {
  const {nowMs,departureAt,computedAt,departureMode,deadlineAt,hasStarted}=options;
  // A scheduled itinerary stays a preview even when its time arrives. Only an
  // explicit fresh "leave now" calculation can become a walking session.
  if(departureMode!=='now')return 'future';
  if(!Number.isFinite(nowMs)||!Number.isFinite(Date.parse(deadlineAt))||(departureAt&&!Number.isFinite(Date.parse(departureAt)))||(computedAt&&!Number.isFinite(Date.parse(computedAt))))return 'expired';
  if(departureAt&&Date.parse(departureAt)>nowMs+30_000)return 'future';
  // A real walk may continue home beyond its original window. An old plan must
  // be refreshed before its first accepted position, not during that walk.
  if(!hasStarted&&((computedAt&&nowMs-Date.parse(computedAt)>60_000)||Date.parse(deadlineAt)<=nowMs))return 'expired';
  return null;
}

export type WalkPosition={lat:number;lon:number;accuracy:number;timestamp:number};
export const WALK_FIX_MAX_AGE_MS=20_000;
export const WALK_START_MAX_ACCURACY_METERS=25;
/** No coordinate is persisted or requested by these pure gates. */
export function walkPositionBlock(fix:WalkPosition|null|undefined,nowMs:number):'invalid-fix'|'stale-fix'|'poor-accuracy'|null{
  if(!fix||![fix.lat,fix.lon,fix.accuracy,fix.timestamp,nowMs].every(Number.isFinite)||Math.abs(fix.lat)>90||Math.abs(fix.lon)>180||fix.accuracy<0||fix.timestamp<0)return 'invalid-fix';
  if(nowMs-fix.timestamp>WALK_FIX_MAX_AGE_MS||fix.timestamp>nowMs+5000)return 'stale-fix';
  return fix.accuracy>WALK_START_MAX_ACCURACY_METERS?'poor-accuracy':null;
}
export function walkPointDistance(a:{lat:number;lon:number},b:{lat:number;lon:number}):number{
  if(![a.lat,a.lon,b.lat,b.lon].every(Number.isFinite)||Math.abs(a.lat)>90||Math.abs(b.lat)>90||Math.abs(a.lon)>180||Math.abs(b.lon)>180)return Infinity;
  const rad=Math.PI/180,v=Math.sin((b.lat-a.lat)*rad/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin((b.lon-a.lon)*rad/2)**2;
  return 6_371_000*2*Math.atan2(Math.sqrt(v),Math.sqrt(Math.max(0,1-v)));
}
/** Resume can occur farther along the walk; its first start must match A. */
export function walkGPSStartBlock(options:{fix:WalkPosition|null|undefined;origin:{lat:number;lon:number};nowMs:number;hasStarted:boolean}):'invalid-fix'|'stale-fix'|'poor-accuracy'|'origin-mismatch'|null{
  const quality=walkPositionBlock(options.fix,options.nowMs);if(quality)return quality;
  if(!options.hasStarted&&walkPointDistance(options.fix!,options.origin)>Math.max(35,options.fix!.accuracy*1.5))return 'origin-mismatch';
  return null;
}

/** An ephemeral browser watch. Stopped/replaced sessions ignore late callbacks. */
export function createLocationWatch(api: Pick<Geolocation, 'watchPosition' | 'clearWatch'>) {
  let epoch = 0;
  let id: number | null = null;
  function stop() {
    epoch++;
    if (id !== null) api.clearWatch(id);
    id = null;
  }
  function start(success: PositionCallback, failure: PositionErrorCallback) {
    stop();
    const session = epoch;
    const next = api.watchPosition(
      position => { if (session === epoch) success(position); },
      error => { if (session === epoch) failure(error); },
      { enableHighAccuracy: true, maximumAge: 0, timeout: 15_000 },
    );
    // Covers a synchronous denial followed by a caller's stop() as well.
    if (session === epoch) id = next;
    else api.clearWatch(next);
  }
  return { start, stop };
}
