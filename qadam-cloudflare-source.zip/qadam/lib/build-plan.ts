// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { interpretIntent, manualIntent, validateIntentContract } from './intent.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { planRoute } from './planner.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { retrievalQuality } from './place-ranking.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { enrichWithGemini } from './rag.ts';
// @ts-expect-error Native Node TS verification uses source extensions.
import { PLAN_MODEL_TIMEOUT_MS, INTENT_TRANSPORT_TIMEOUT_MS, ENRICHMENT_TIMEOUT_MS } from './ai-policy.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { buildIntentFeedback } from './intent-feedback.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { resolvePlanTime } from './time-context.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { preflightContext, intentClarification, timeClarification } from './planning-context.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { boundedOperation, isAbortError, StageTimeout, throwIfAborted } from './request-abort.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { planSemanticsValid } from './plan-validation.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { getCanonicalId, getPlaceEditorial, getPlaceName, getFactText } from './place-facts.ts';
import type { POIDataset } from './planner';
import type { Clarification, PlanDiagnostics, PlanRequest, PlanResponse } from './qadam-types';
import type { WalkingGraph } from './walking-graph';
import type { IntentContract, IntentResolution } from './intent-types';
// @ts-expect-error Native Node TS verification uses source extensions.
import { isIntentMode } from './intent-types.ts';
import type { CoverageBounds } from './planning-context';

const clarification: IntentContract = { version: 1, desiredCategories: [], excludedCategories: [], includeMode: 'any', unsupported: [], needsClarification: true };
export type BuildPlanOptions = {
  routing?: WalkingGraph; totalTimeoutMs?: number; signal?:AbortSignal;
  coverageBounds?:CoverageBounds; clock?:()=>Date;
  personalScore?:(poi:import('./qadam-types').POI)=>number;
  interpret?: typeof interpretIntent; enrich?: typeof enrichWithGemini;
  intentOptions?: Parameters<typeof interpretIntent>[1];
  generationOptions?: Parameters<typeof enrichWithGemini>[2];
};
function empty(dataset:POIDataset,question:Clarification,diagnostics:PlanDiagnostics):PlanResponse {
 return {plan:null,options:[],clarification:question,diagnostics,candidates:0,excluded:[],trace:[{step:diagnostics.stage,detail:question.question,ms:0}],
 generationMode:'retrieval',warnings:[question.message??question.question],dataset:{count:dataset.pois.length,fetchedAt:dataset.fetchedAt,source:dataset.source}};
}
function localFacts(response:PlanResponse,request:PlanRequest):PlanResponse {
 const plans=new Set([...(response.plan?[response.plan]:[]),...(response.options?.map(o=>o.plan)??[])]);
 for(const plan of plans)for(const stop of plan.stops){
  const editorial=getPlaceEditorial(stop.poi.id);
  stop.canonicalId=getCanonicalId(stop.poi);
  stop.poi={...stop.poi,name:getPlaceName(stop.poi,request.language)};
  if(!editorial)continue;
  stop.facts=editorial.facts.map(f=>({id:f.id,text:getFactText(f,request.language),sourceUrl:f.sourceUrl,checkedAt:f.checkedAt,rights:f.rights}));
  if(editorial.observation)stop.observation=editorial.observation[request.language];
 }
 return response;
}
function normalizeResolution(value:unknown,request:PlanRequest):IntentResolution {
 if(value&&typeof value==='object'){
  const v=value as IntentResolution;
  if(isIntentMode(v.mode)&&typeof v.ms==='number'&&Number.isFinite(v.ms)&&v.ms>=0){
   if(v.mode==='unavailable'&&v.contract===null&&(!v.failure||['not-configured','timeout','provider','quota','invalid-output'].includes(v.failure)))return v;
   const contract=validateIntentContract(v.contract,request);
   if(contract&&v.mode!=='unavailable')return {...v,contract};
  }
 }
 return {mode:'unavailable',contract:null,failure:'invalid-output',ms:0};
}
/** Both model stages share a deadline. Context is reconciled before any model call. */
export async function buildPlan(request:PlanRequest,dataset:POIDataset,options:BuildPlanOptions={}):Promise<PlanResponse> {
 throwIfAborted(options.signal);
 const started=performance.now(), total=Math.max(1,Math.min(PLAN_MODEL_TIMEOUT_MS,options.totalTimeoutMs??PLAN_MODEL_TIMEOUT_MS)), clock=options.clock??(()=>new Date());
 const contextDiagnostics:PlanDiagnostics={stage:'context',intent:'not-attempted',enrichment:'not-attempted',coverage:'unknown',codes:[]};
 const initialTime=resolvePlanTime(request,clock());
 if('error' in initialTime)return empty(dataset,timeClarification(request),{...contextDiagnostics,codes:[initialTime.error]});
 const preflight=preflightContext(request,options.coverageBounds);
 if(preflight)return {...empty(dataset,preflight,{...contextDiagnostics,coverage:preflight.reason==='outside-coverage'?'outside':'unknown',codes:[preflight.reason]}),...initialTime};
 let resolution:IntentResolution;
 // Explicit manual recovery is fully local, including explanations. Empty text
 // in normal manual mode also does not need a provider to interpret categories.
 if(request.localOnly&&!request.query.trim())resolution={mode:'manual',contract:manualIntent(request),ms:0};
 else {
  try{
   const budget=Math.min(INTENT_TRANSPORT_TIMEOUT_MS,total);
   const raw=await boundedOperation(signal=>(options.interpret??interpretIntent)(request,{...options.intentOptions,totalTimeoutMs:budget,signal}),budget,options.signal);
   resolution=normalizeResolution(raw,request);
  }catch(error){
   if(isAbortError(error))throw error;
   resolution={mode:'unavailable',contract:null,failure:error instanceof StageTimeout?'timeout':'provider',ms:Math.round(performance.now()-started)};
  }
 }
 throwIfAborted(options.signal);
 // For 'now', time spent interpreting consumes a return deadline. Fixed custom
 // departures retain their chosen instant; legacy now fixtures remain fixed.
 const time=resolvePlanTime(request,clock(),request.departureMode==='custom');
 if('error' in time){const result=empty(dataset,timeClarification(request,true),{...contextDiagnostics,intent:resolution.mode,codes:[time.error]});result.intent=buildIntentFeedback(result,resolution);return result;}
 const effectiveRequest={...request,minutes:time.effectiveMinutes,now:time.departureAt};
 const contract=resolution.contract??clarification;
 let result=planRoute(effectiveRequest,dataset,{routing:options.routing,intent:contract,canonicalId:getCanonicalId,withAlternatives:true,retrievalQuality,personalScore:options.personalScore});
 result.intent=buildIntentFeedback(result,resolution);
 result.trace.unshift({step:'intent',detail:`${resolution.mode}${resolution.failure?`; ${resolution.failure}`:''}; ${contract.desiredCategories.join(', ')||'nearby'}; exclusions=${contract.excludedCategories.join(', ')||'none'}; ${result.intent.status}`,ms:resolution.ms});
 result={...result,...time,diagnostics:{stage:'complete',intent:resolution.mode,enrichment:'not-attempted',coverage:result.plan?.routeKind??'unknown',codes:[],...(request.departureMode==='now'?{recomputeAfterSeconds:60}:{})}};
 // Explanation generation can consume a chosen departure or return deadline.
 // Revalidate once at the final boundary, including every alternative, without
 // another model call or silently substituting a different itinerary.
 const finalize=(candidate:PlanResponse):PlanResponse=>{
  throwIfAborted(options.signal);
  const completedAt=clock();
  const finalTime=resolvePlanTime(request,completedAt,request.departureMode==='custom');
  const finalRequest='error' in finalTime?null:{...request,minutes:finalTime.effectiveMinutes,now:finalTime.departureAt};
  if('error' in finalTime||!finalRequest||!planSemanticsValid(candidate,finalRequest,dataset,contract)){
   const question=timeClarification(request,true);
   const stale=empty(dataset,question,{...candidate.diagnostics!,stage:'context',coverage:'unknown',codes:[...candidate.diagnostics!.codes,'error' in finalTime?finalTime.error:'time-context-changed']});
   stale.intent=buildIntentFeedback(stale,resolution);
   stale.trace=[...candidate.trace,{step:'time-recheck',detail:question.message??question.question,ms:0}];
   return {...stale,...time,planComputedAt:completedAt.toISOString()};
  }
  return localFacts({...candidate,...finalTime},finalRequest);
 };
 if(result.intent?.status==='needs-clarification'){
  result.clarification=intentClarification(request,resolution);result.diagnostics!.stage='intent';result.diagnostics!.codes=[resolution.failure??'clarification-required'];return result;
 }
 if(!planSemanticsValid(result,effectiveRequest,dataset,contract)){
  const failed=empty(dataset,intentClarification(request,{mode:'unavailable',contract:null,failure:'invalid-output',ms:0}),{...contextDiagnostics,intent:resolution.mode,codes:['planner-invalid-output']});return {...failed,...time};
 }
 if(!result.plan){result.diagnostics!.stage='planning';result.diagnostics!.codes=[request.requiredPoiId?'required-place-unavailable':result.candidates===0?'no-candidates':(request.destination?'no-feasible-stop-before-destination':'no-feasible-round-trip'),...result.excluded.filter(x=>x.count>0).map(x=>x.reason)];return result;}
 if((result.options?.length??0)>1){result.diagnostics!.codes.push('alternative-local-explanation');result.trace.push({step:'alternatives',detail:`${result.options!.length} distinct canonical place sets; identical hard filters and independent full route checks to the configured endpoint. Primary may use closed AI codes; alternative explanations are local.`,ms:0});}
 const remaining=Math.min(ENRICHMENT_TIMEOUT_MS,total-(performance.now()-started));
 if(request.localOnly){
  result.diagnostics!.enrichment='local';result.diagnostics!.codes=['explicit-local-recovery'];
  result.trace.push({step:'local-explanations',detail:'Explicit manual recovery; neither AI stage required',ms:0});
  return finalize(result);
 }
 if(remaining<50){
  result.trace.push({step:'gemini-fallback',detail:'Shared model deadline reached; deterministic source explanations preserved',ms:0});
  result.diagnostics!.enrichment='local';result.diagnostics!.codes=['shared-deadline'];return finalize(result);
 }
 throwIfAborted(options.signal);
 try{
  const enriched=await boundedOperation(signal=>(options.enrich??enrichWithGemini)(structuredClone(result),effectiveRequest,{...options.generationOptions,totalTimeoutMs:remaining,signal}),remaining,options.signal);
  throwIfAborted(options.signal);
  // The renderer can select closed reason keys, never alter itinerary facts.
  if(planSemanticsValid(enriched,effectiveRequest,dataset,contract)&&JSON.stringify(enriched.plan?.stops.map(s=>[s.poi.id,s.visitMinutes,s.travelMinutes]))===JSON.stringify(result.plan.stops.map(s=>[s.poi.id,s.visitMinutes,s.travelMinutes]))){
   // Copy only the renderer's display outputs and provider trace. Route facts,
   // alternatives, context and diagnostics remain owned by the local planner.
   result={...result,generationMode:enriched.generationMode,warnings:enriched.warnings,trace:enriched.trace,
     plan:{...result.plan,summary:enriched.plan!.summary,stops:result.plan.stops.map((stop,i)=>({...stop,why:enriched.plan!.stops[i].why,activity:enriched.plan!.stops[i].activity}))}};
   if(result.options?.[0]&&result.plan)result.options[0].plan=result.plan;
   const attempted=result.generationMode==='gemini'||result.trace.some(t=>/^gemini-(?:unavailable|grounding|fallback)$/.test(t.step));
   result.diagnostics={...result.diagnostics!,enrichment:result.generationMode==='gemini'?'gemini':attempted?'unavailable':'local'};
   if(result.diagnostics.enrichment==='unavailable')result.diagnostics.codes.push('enrichment-unavailable');
  }else{result.diagnostics!.enrichment='local';result.diagnostics!.codes.push('enrichment-invalid-output');}
 }catch(error){if(isAbortError(error))throw error;result.diagnostics!.enrichment='unavailable';result.diagnostics!.codes.push(error instanceof StageTimeout?'enrichment-timeout':'enrichment-unavailable');
  result.trace.push({step:'gemini-unavailable',detail:'Provider stage unavailable; source-backed local explanations preserved',ms:0});}
 return finalize(result);
}
