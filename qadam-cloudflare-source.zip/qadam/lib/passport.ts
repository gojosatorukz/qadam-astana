import type { POI, RoutePlan } from './qadam-types';
import type { PassportError, PassportMutation, PassportPlace, PassportRecommendation, PassportState, PassportStorage, PlacePreference, WalkCompletion } from './passport-types';
// @ts-expect-error Native Node TS verification uses source extensions.
import { getCanonicalId } from './place-facts.ts';
// @ts-expect-error Native Node TS verification uses source extensions.
import { parseIsoInstant } from './time-context.ts';

export const PASSPORT_STORAGE_KEY = 'qadam:city-passport:v1';
export const PASSPORT_CHANGE_EVENT = 'qadam:city-passport-change';
export const PASSPORT_CATEGORIES = ['park','cafe','food','museum','art','attraction','library','playground','viewpoint'] as const;
const MAX_WALKS=1000,MAX_PREFERENCES=2000,MAX_BYTES=512_000;
const object=(v:unknown):v is Record<string,unknown>=>!!v&&typeof v==='object'&&!Array.isArray(v);
const keys=(v:Record<string,unknown>,allowed:readonly string[])=>Object.keys(v).every(k=>allowed.includes(k));
const publicId=(v:unknown):v is string=>typeof v==='string'&&/^osm-(?:node|way|relation)-[1-9]\d{0,18}$/u.test(v);
const walkId=(v:unknown):v is string=>typeof v==='string'&&/^[A-Za-z0-9:_-]{8,100}$/u.test(v);
const canonical=(id:string)=>getCanonicalId({id} as POI);
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
const category=(value:string)=>PASSPORT_CATEGORIES.includes(value as typeof PASSPORT_CATEGORIES[number]);
export type PassportRead = {passport:PassportState;status:'ready'|'corrupt'|'unavailable';error:PassportError|null};
export type PassportUpdate = {passport:PassportState;result:PassportMutation};

export function createEmptyPassport():PassportState {
  return {version:1,personalizationEnabled:true,walks:[],placePreferences:{},interestWeights:{}};
}
function isCompletion(v:unknown):v is WalkCompletion {
  return object(v)&&keys(v,['walkId','visitedPoiIds','minutes','completedAt'])&&walkId(v.walkId)
    &&Array.isArray(v.visitedPoiIds)&&v.visitedPoiIds.length<=3&&v.visitedPoiIds.every(publicId)
    &&new Set(v.visitedPoiIds.map(canonical)).size===v.visitedPoiIds.length
    &&typeof v.minutes==='number'&&Number.isFinite(v.minutes)&&v.minutes>=0&&v.minutes<=1440
    &&typeof v.completedAt==='string'&&!!parseIsoInstant(v.completedAt);
}
function isPreference(v:unknown):v is PlacePreference {
  return object(v)&&keys(v,['sentiment','rating','avoid'])&&typeof v.avoid==='boolean'
    &&(v.sentiment===undefined||v.sentiment==='liked'||v.sentiment==='disliked')
    &&(v.rating===undefined||(Number.isInteger(v.rating)&&(v.rating as number)>=1&&(v.rating as number)<=5));
}
/** Strict allowlist: unknown fields (including coordinates/query/contact data) are rejected. */
export function validatePassport(value:unknown):PassportState|null {
  if(!object(value)||!keys(value,['version','personalizationEnabled','walks','placePreferences','interestWeights'])
    ||value.version!==1||typeof value.personalizationEnabled!=='boolean'||!Array.isArray(value.walks)
    ||value.walks.length>MAX_WALKS||!value.walks.every(isCompletion)
    ||new Set(value.walks.map(w=>w.walkId)).size!==value.walks.length
    ||!object(value.placePreferences)||Object.keys(value.placePreferences).length>MAX_PREFERENCES
    ||!Object.entries(value.placePreferences).every(([id,pref])=>publicId(id)&&isPreference(pref))
    ||!object(value.interestWeights)||!Object.entries(value.interestWeights).every(([key,weight])=>category(key)&&typeof weight==='number'&&Number.isFinite(weight)&&Math.abs(weight)<=3))return null;
  const visited=new Set(value.walks.flatMap(w=>w.visitedPoiIds.map(canonical)));
  if(Object.entries(value.placePreferences).some(([id,pref])=>(pref as PlacePreference).rating!==undefined&&!visited.has(canonical(id))))return null;
  return {version:1,personalizationEnabled:value.personalizationEnabled,
    walks:value.walks.map(w=>({...w,visitedPoiIds:[...w.visitedPoiIds]})),
    placePreferences:Object.fromEntries(Object.entries(value.placePreferences).map(([id,pref])=>[id,{...(pref as PlacePreference)}])),
    interestWeights:{...value.interestWeights} as Record<string,number>};
}
export function readPassport(storage:PassportStorage|null):PassportRead {
  if(!storage)return {passport:createEmptyPassport(),status:'unavailable',error:'storage-unavailable'};
  try {
    const raw=storage.getItem(PASSPORT_STORAGE_KEY);
    if(raw===null)return {passport:createEmptyPassport(),status:'ready',error:null};
    if(raw.length>MAX_BYTES)return {passport:createEmptyPassport(),status:'corrupt',error:'corrupt-data'};
    const passport=validatePassport(JSON.parse(raw));
    return passport?{passport,status:'ready',error:null}:{passport:createEmptyPassport(),status:'corrupt',error:'corrupt-data'};
  }catch(error){return {passport:createEmptyPassport(),status:error instanceof SyntaxError?'corrupt':'unavailable',error:error instanceof SyntaxError?'corrupt-data':'storage-unavailable'};}
}
export function writePassport(storage:PassportStorage|null,passport:PassportState):PassportMutation {
  if(!storage)return {ok:false,error:'storage-unavailable'};
  const valid=validatePassport(passport);if(!valid)return {ok:false,error:'invalid-input'};
  const body=JSON.stringify(valid);if(body.length>MAX_BYTES)return {ok:false,error:'capacity-reached'};
  try {storage.setItem(PASSPORT_STORAGE_KEY,body);return {ok:true,changed:true};}
  catch(error){return {ok:false,error:object(error)&&['QuotaExceededError','NS_ERROR_DOM_QUOTA_REACHED'].includes(String(error.name))?'storage-full':'storage-unavailable'};}
}
export function resetPassport(storage:PassportStorage|null):PassportMutation {
  if(!storage)return {ok:false,error:'storage-unavailable'};
  try {storage.removeItem(PASSPORT_STORAGE_KEY);return {ok:true,changed:true};}
  catch {return {ok:false,error:'storage-unavailable'};}
}

export function getVisitedPoiIds(passport:PassportState):string[] {
  const seen=new Set<string>(),ids:string[]=[];
  for(const walk of passport.walks)for(const id of walk.visitedPoiIds){const key=canonical(id);if(!seen.has(key)){seen.add(key);ids.push(id);}}
  return ids;
}
export function hasVisitedPlace(passport:PassportState,poiId:string):boolean {
  const key=canonical(poiId);return passport.walks.some(w=>w.visitedPoiIds.some(id=>canonical(id)===key));
}
export function getPlacePreference(passport:PassportRecommendation,poiId:string):PlacePreference|undefined {
  const key=canonical(poiId);const entry=Object.entries(passport.placePreferences).find(([id])=>canonical(id)===key);return entry?.[1];
}
function habits(passport:PassportState,places:readonly PassportPlace[]):Record<string,number> {
  const categories=new Map(places.filter(p=>publicId(p.id)&&category(p.category)).map(p=>[canonical(p.id),p.category]));
  const weights:Record<string,number>={};
  for(const id of getVisitedPoiIds(passport)){
    const cat=categories.get(canonical(id));if(!cat)continue;
    const pref=getPlacePreference(passport,id);
    const impression=(pref?.sentiment==='liked'?1:pref?.sentiment==='disliked'?-1:0)+(pref?.rating===undefined?0:(pref.rating-3)*0.3)-(pref?.avoid?1:0);
    weights[cat]=clamp((weights[cat]??0)+0.35+impression,-3,3);
  }
  return weights;
}
/** Call only with a GPS-qualified, explicitly confirmed completion, never a preview/generation. */
export function recordCompletedWalk(passport:PassportState,event:WalkCompletion,places:readonly PassportPlace[]=[],nowMs=Date.now()):PassportUpdate {
  // Duplicate POI IDs in a valid completion are harmless; aliases count once.
  if(!object(event)||!Array.isArray(event.visitedPoiIds))return {passport,result:{ok:false,error:'invalid-input'}};
  const seen=new Set<string>();const normalized={...event,visitedPoiIds:event.visitedPoiIds.filter(id=>{if(!publicId(id))return true;const key=canonical(id);if(seen.has(key))return false;seen.add(key);return true;})};
  if(event.visitedPoiIds.length>3||!isCompletion(normalized)||!Number.isFinite(nowMs)||Date.parse(event.completedAt)>nowMs+300_000)return {passport,result:{ok:false,error:'invalid-input'}};
  if(passport.walks.some(w=>w.walkId===event.walkId))return {passport,result:{ok:true,changed:false}};
  if(passport.walks.length>=MAX_WALKS)return {passport,result:{ok:false,error:'capacity-reached'}};
  const next:PassportState={...passport,walks:[...passport.walks,{...normalized,visitedPoiIds:[...normalized.visitedPoiIds]}]};
  next.interestWeights=places.length?habits(next,places):{...passport.interestWeights};
  return {passport:next,result:{ok:true,changed:true}};
}
export function updatePlacePreference(passport:PassportState,poiId:string,patch:Partial<PlacePreference>,places:readonly PassportPlace[]=[]):PassportUpdate {
  if(!publicId(poiId)||!object(patch)||!keys(patch,['sentiment','rating','avoid']))return {passport,result:{ok:false,error:'invalid-input'}};
  const previous=getPlacePreference(passport,poiId),nextPreference={avoid:false,...previous,...patch};
  if(!isPreference(nextPreference))return {passport,result:{ok:false,error:'invalid-input'}};
  if(nextPreference.rating!==undefined&&!hasVisitedPlace(passport,poiId))return {passport,result:{ok:false,error:'not-visited'}};
  const preferences={...passport.placePreferences};for(const id of Object.keys(preferences))if(canonical(id)===canonical(poiId))delete preferences[id];
  if(Object.keys(preferences).length>=MAX_PREFERENCES)return {passport,result:{ok:false,error:'capacity-reached'}};
  if(nextPreference.sentiment!==undefined||nextPreference.rating!==undefined||nextPreference.avoid)preferences[poiId]=nextPreference;
  const next={...passport,placePreferences:preferences};next.interestWeights=places.length?habits(next,places):{...passport.interestWeights};
  return {passport:next,result:{ok:true,changed:true}};
}

const LEVELS=[{level:1,xp:0},{level:2,xp:60},{level:3,xp:160},{level:4,xp:320},{level:5,xp:600}];
/** Derived only from the completion ledger: feedback/generation cannot award XP. */
export function getPassportStats(passport:PassportState) {
  const places=getVisitedPoiIds(passport),rewardedWalks=passport.walks.filter(w=>w.minutes>=1);
  const xp=rewardedWalks.length*20+places.length*10;
  const current=[...LEVELS].reverse().find(l=>xp>=l.xp)!,next=LEVELS.find(l=>l.xp>xp)??null;
  return {completedWalks:passport.walks.length,uniquePlaces:places.length,minutes:passport.walks.reduce((n,w)=>n+w.minutes,0),xp,level:current.level,nextLevelXP:next?.xp??null,levelStartXP:current.xp,progress:next?clamp((xp-current.xp)/(next.xp-current.xp),0,1):1,places};
}
/** Bounded SOFT local bias only. No quality claim, filtering, model call or mutation. */
export function recommendationSnapshot(passport:PassportState):PassportRecommendation {
  return {personalizationEnabled:passport.personalizationEnabled,placePreferences:Object.fromEntries(Object.entries(passport.placePreferences).map(([id,pref])=>[id,{...pref}])),interestWeights:{...passport.interestWeights}};
}
export function validateRecommendationSnapshot(value:unknown):PassportRecommendation|null {
  if(!object(value)||!keys(value,['personalizationEnabled','placePreferences','interestWeights'])||typeof value.personalizationEnabled!=='boolean'
    ||!object(value.placePreferences)||Object.keys(value.placePreferences).length>MAX_PREFERENCES||!Object.entries(value.placePreferences).every(([id,pref])=>publicId(id)&&isPreference(pref))
    ||!object(value.interestWeights)||!Object.entries(value.interestWeights).every(([key,weight])=>category(key)&&typeof weight==='number'&&Number.isFinite(weight)&&Math.abs(weight)<=3))return null;
  return {personalizationEnabled:value.personalizationEnabled,placePreferences:Object.fromEntries(Object.entries(value.placePreferences).map(([id,pref])=>[id,{...(pref as PlacePreference)}])),interestWeights:{...value.interestWeights} as Record<string,number>};
}
export function scoreLocalPOI(poi:Pick<POI,'id'|'category'>,passport:PassportRecommendation):number {
  if(!passport.personalizationEnabled)return 0;
  const pref=getPlacePreference(passport,poi.id);
  const rating=pref?.rating===undefined?0:(pref.rating-3)*1.5;
  const sentiment=pref?.sentiment==='liked'?2:pref?.sentiment==='disliked'?-3:0;
  return clamp((passport.interestWeights[poi.category]??0)+rating+sentiment-(pref?.avoid?4:0),-6,6);
}
/** Reorders existing valid option objects only. Hard constraints remain the planner's authority. */
export function rerankPlanOptions<T extends {plan:RoutePlan}>(options:readonly T[],passport:PassportRecommendation,settings:{requiredPoiId?:string;enabled?:boolean}={}):T[] {
  if(settings.enabled===false||!passport.personalizationEnabled)return [...options];
  if(settings.requiredPoiId&&options.some(option=>!option.plan.stops.some(stop=>canonical(stop.poi.id)===canonical(settings.requiredPoiId!))))return [...options];
  return options.map((option,index)=>({option,index,score:option.plan.stops.length?option.plan.stops.reduce((sum,stop)=>sum+scoreLocalPOI(stop.poi,passport),0)/option.plan.stops.length:0}))
    .sort((a,b)=>b.score-a.score||a.index-b.index).map(item=>item.option);
}
