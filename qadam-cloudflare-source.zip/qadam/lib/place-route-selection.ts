import type { POI, PlanRequest } from './qadam-types';

export type PlaceRouteWish = Pick<PlanRequest, 'query' | 'interests' | 'localOnly' | 'contextConfirmed'>;
export type PlaceRouteChoice = 'keep-wish' | 'replace-wish';

/** Map categories are a separate view: choosing a pin must not erase a wish silently. */
export function hasPlaceRouteWish(wish: PlaceRouteWish): boolean {
  return Boolean(wish.query.trim() || wish.interests.length);
}

/** Overrides contain only wish/selection fields, never the user's route or time controls. */
export function placeRouteSelection(poi: Pick<POI, 'id' | 'category'>, wish: PlaceRouteWish, choice: PlaceRouteChoice): Pick<PlanRequest, 'query' | 'interests' | 'localOnly' | 'contextConfirmed' | 'requiredPoiId'> {
  if (choice === 'keep-wish') return {
    query: wish.query,
    interests: [...wish.interests],
    localOnly: !wish.query.trim() && Boolean(wish.localOnly),
    contextConfirmed: Boolean(wish.contextConfirmed),
    requiredPoiId: poi.id,
  };
  const category = ['restaurant', 'fast_food', 'food_court'].includes(poi.category) ? 'food' : poi.category === 'gallery' ? 'art' : poi.category;
  return { query: '', interests: [category], localOnly: true, contextConfirmed: false, requiredPoiId: poi.id };
}
