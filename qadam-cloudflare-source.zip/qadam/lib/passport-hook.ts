'use client';
import { useCallback, useEffect, useState } from 'react';
import type { POI } from './qadam-types';
import type { PassportMutation, PassportPlace, PassportState, PassportStorage, PlacePreference, WalkCompletion } from './passport-types';
import { createEmptyPassport, PASSPORT_CHANGE_EVENT, PASSPORT_STORAGE_KEY, readPassport, recordCompletedWalk, resetPassport, updatePlacePreference, writePassport } from './passport';
import type { PassportRead, PassportUpdate } from './passport';

// Public catalog metadata in memory only; never retain POI coordinates or names.
let catalog:PassportPlace[]=[];
function storage():PassportStorage|null {try{return typeof window==='undefined'?null:window.localStorage;}catch{return null;}}
export function getLocalPassportSnapshot():PassportState {return readPassport(storage()).passport;}

/** Local-only state. Same-tab custom events and other-tab storage events keep consumers coherent. */
export function usePassport(datasetPOIs?:readonly POI[]) {
  const [view,setView]=useState<PassportRead&{loading:boolean}>(()=>({passport:createEmptyPassport(),status:'ready',error:null,loading:true}));
  const refresh=useCallback(()=>setView({...readPassport(storage()),loading:false}),[]);
  useEffect(()=>{
    if(datasetPOIs)catalog=datasetPOIs.map(({id,category})=>({id,category}));
  },[datasetPOIs]);
  useEffect(()=>{
    refresh();
    const changed=(event:StorageEvent)=>{if(event.key===PASSPORT_STORAGE_KEY||event.key===null)refresh();};
    window.addEventListener('storage',changed);window.addEventListener(PASSPORT_CHANGE_EVENT,refresh);
    return()=>{window.removeEventListener('storage',changed);window.removeEventListener(PASSPORT_CHANGE_EVENT,refresh);};
  },[refresh]);
  const mutate=useCallback((update:(passport:PassportState)=>PassportUpdate):PassportMutation=>{
    const localStorage=storage(),current=readPassport(localStorage);
    if(current.error){setView({...current,loading:false});return {ok:false,error:current.error};}
    const next=update(current.passport);
    if(!next.result.ok){setView({...current,error:next.result.error,loading:false});return next.result;}
    if(!next.result.changed){setView({...current,loading:false});return next.result;}
    const result=writePassport(localStorage,next.passport);
    if(result.ok){setView({passport:next.passport,status:'ready',error:null,loading:false});window.dispatchEvent(new Event(PASSPORT_CHANGE_EVENT));}
    else setView({...current,error:result.error,loading:false});
    return result;
  },[]);
  const completeWalk=useCallback((event:WalkCompletion)=>mutate(passport=>recordCompletedWalk(passport,event,catalog)),[mutate]);
  const setPlacePreference=useCallback((poiId:string,patch:Partial<PlacePreference>)=>mutate(passport=>updatePlacePreference(passport,poiId,patch,catalog)),[mutate]);
  const setPersonalization=useCallback((enabled:boolean)=>mutate(passport=>typeof enabled==='boolean'?{passport:{...passport,personalizationEnabled:enabled},result:{ok:true,changed:passport.personalizationEnabled!==enabled}}:{passport,result:{ok:false,error:'invalid-input'}}),[mutate]);
  const reset=useCallback(()=>{
    const result=resetPassport(storage());
    if(result.ok){setView({passport:createEmptyPassport(),status:'ready',error:null,loading:false});window.dispatchEvent(new Event(PASSPORT_CHANGE_EVENT));}
    else setView(previous=>({...previous,error:result.error,loading:false}));
    return result;
  },[]);
  const clearError=useCallback(()=>setView(previous=>({...previous,error:null})),[]);
  return {...view,completeWalk,setPlacePreference,setPersonalization,reset,clearError};
}
