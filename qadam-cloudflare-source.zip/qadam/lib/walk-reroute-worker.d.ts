/** Vite's ?worker wrapper selects module dev / matching production format. */
declare module '*?worker' {
  const WorkerConstructor: { new(options?: { name?: string }): Worker };
  export default WorkerConstructor;
}
