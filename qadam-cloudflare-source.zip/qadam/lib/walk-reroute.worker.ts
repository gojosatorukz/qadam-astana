import rawGraph from '../data/walk-graph.json';
import { WalkingGraph } from './walking-graph';
import type { RawWalkingGraph } from './walking-graph';
import { rerouteWalk } from './walk-reroute';
import type { RerouteRequest, RerouteResult } from './walk-reroute';

type WorkerRequest = { type: 'reroute'; id: number; request: RerouteRequest };
type WorkerReply = { type: 'reroute-result'; id: number; result: RerouteResult } | { type: 'reroute-error'; id: number };
// Keep worker typing local; do not merge DOM and WebWorker global libraries.
const scope = globalThis as unknown as { onmessage: ((event: MessageEvent<WorkerRequest>) => void) | null; postMessage(message: WorkerReply): void };
let graph: WalkingGraph | null = null;
scope.onmessage = event => {
  const message = event.data;
  if (!message || message.type !== 'reroute' || !Number.isSafeInteger(message.id) || message.id < 1) return;
  try {
    graph ??= new WalkingGraph(rawGraph as RawWalkingGraph);
    // Lazy initialization can take time. Preserve the deadline and let the
    // engine recheck fix freshness against wall time immediately before work.
    const result = rerouteWalk({ ...message.request, nowMs: Date.now() }, graph);
    scope.postMessage({ type: 'reroute-result', id: message.id, result });
  } catch { scope.postMessage({ type: 'reroute-error', id: message.id }); }
};
