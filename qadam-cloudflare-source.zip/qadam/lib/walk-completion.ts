import type { WalkCompletion } from './passport-types';
import type { GuideFix, GuideUpdate, SupportedWalkGuide } from './walk-guide';
// @ts-expect-error Native Node TS verification uses source extensions.
import { walkPointDistance, walkPositionBlock } from './walk-session.ts';

/** In-memory ledger. Only the public completion event leaves this session. */
export type WalkAchievements={walkId:string;startedAt:number|null;visitedPoiIds:string[];completed:boolean};
export function createWalkAchievements(walkId:string):WalkAchievements{return {walkId,startedAt:null,visitedPoiIds:[],completed:false};}
export function startWalkAchievements(state:WalkAchievements,nowMs:number):WalkAchievements{
  return state.startedAt!==null||!Number.isFinite(nowMs)?state:{...state,startedAt:nowMs};
}
export function canConfirmWalkArrival(guide:SupportedWalkGuide,update:GuideUpdate|null|undefined,fix:GuideFix|null|undefined,nowMs:number):boolean{
  if(!update||!fix||walkPositionBlock(fix,nowMs)||update.status!=='tracking'||!update.canConfirmArrival)return false;
  const leg=guide.legs[update.state.legIndex],last=update.state.lastFix;
  if(!leg||!last||last.timestamp!==fix.timestamp||last.lat!==fix.lat||last.lon!==fix.lon)return false;
  const endpoint=leg.coordinates.at(-1);
  return !!endpoint&&Number.isFinite(update.state.meters)&&leg.totalMeters-update.state.meters<=Math.max(8,Math.min(12,fix.accuracy/2))
    &&walkPointDistance(fix,{lat:endpoint[1],lon:endpoint[0]})<=Math.max(10,Math.min(18,fix.accuracy*1.2));
}
/** A preview button or manual finish without fresh GPS can never earn credit. */
export function confirmWalkAchievement(state:WalkAchievements,options:{guide:SupportedWalkGuide;update:GuideUpdate|null|undefined;fix:GuideFix|null|undefined;nowMs:number;poiId?:string}):{accepted:boolean;state:WalkAchievements;completion?:WalkCompletion}{
  const {guide,update,fix,nowMs,poiId}=options;
  if(state.completed||state.startedAt===null||nowMs<state.startedAt||!canConfirmWalkArrival(guide,update,fix,nowMs))return {accepted:false,state};
  const leg=guide.legs[update!.state.legIndex];
  if(leg.kind==='stop'){
    if(!poiId||!leg.id.endsWith(':'+poiId))return {accepted:false,state};
    return {accepted:true,state:state.visitedPoiIds.includes(poiId)?state:{...state,visitedPoiIds:[...state.visitedPoiIds,poiId]}};
  }
  if(update!.state.legIndex!==guide.legs.length-1)return {accepted:false,state};
  const next={...state,completed:true};
  return {accepted:true,state:next,completion:{walkId:state.walkId,visitedPoiIds:[...state.visitedPoiIds],minutes:Math.max(0,Math.round((nowMs-state.startedAt)/60_000)),completedAt:new Date(nowMs).toISOString()}};
}
