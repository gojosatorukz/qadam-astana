import type { Metadata } from "next";
import "./globals.css";
import "./mobile-journey.css";
import "./route-choice.css";
import "./mobile-shell.css";

export const metadata: Metadata = {
  title: "Qadam — маленькое открытие между делами",
  description: "От точки А до точки Б: места и прогулки по пути с учётом твоего времени. Реальные места Астаны, понятный расчёт и источники.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
