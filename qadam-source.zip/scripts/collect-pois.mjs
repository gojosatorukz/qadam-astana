#!/usr/bin/env node
/** Rebuild the public POI snapshot. No location history or user data is collected. */
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const bbox = [51.065, 71.35, 51.205, 71.515]; // south, west, north, east; central Astana, including EXPO
const bboxText = bbox.join(',');
const foodOnly = process.argv.includes('--food-only');
const query = foodOnly ? `[out:json][timeout:70];
nwr["amenity"~"^(restaurant|fast_food|food_court)$"](${bboxText});
out center meta;` : `[out:json][timeout:70];
(
  nwr["amenity"~"^(cafe|restaurant|fast_food|food_court)$"](${bboxText});
  nwr["leisure"~"^(park|garden|playground)$"](${bboxText});
  nwr["tourism"~"^(museum|attraction|viewpoint|artwork)$"](${bboxText});
  nwr["historic"~"^(monument|memorial)$"](${bboxText});
  nwr["amenity"="library"](${bboxText});
);
out center meta;`;
const endpoints = process.env.OVERPASS_URL
  ? [process.env.OVERPASS_URL]
  : ['https://overpass-api.de/api/interpreter', 'https://overpass.private.coffee/api/interpreter'];
const categoryNames = {
  cafe: 'Кафе', food: 'Ресторан или место для еды', park: 'Парк или сад', museum: 'Музей', attraction: 'Достопримечательность',
  viewpoint: 'Смотровая точка', playground: 'Детская площадка', library: 'Библиотека', art: 'Публичное искусство',
};

async function collectWalkGraph() {
  // A smaller graph still covers the four demo areas, reducing public-server load.
  const graphBbox = [51.075, 71.385, 51.178, 71.49];
  const graphQuery = `[out:json][timeout:100];
way["highway"~"^(footway|pedestrian|path|steps|living_street|residential|service|unclassified|tertiary|secondary|primary)$"](${graphBbox.join(',')});
out body;
>;
out skel qt;`;
  let graphResponse, graphEndpoint;
  const failures = [];
  for (const candidate of endpoints) {
    try {
      console.log(`Collecting public OSM walking-network extract from ${candidate} ...`);
      const body = execFileSync('curl', [
        '--fail-with-body', '--silent', '--show-error', '--compressed', '--max-time', '120',
        '--user-agent', 'QadamHackathonPOICollector/1.0 (central Astana educational prototype)',
        '--data-urlencode', `data=${graphQuery}`, candidate,
      ], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, timeout: 125000 });
      graphResponse = JSON.parse(body);
      if (!Array.isArray(graphResponse.elements) || !graphResponse.elements.length || graphResponse.remark) {
        throw new Error(graphResponse.remark || 'Empty graph response');
      }
      graphEndpoint = candidate;
      break;
    } catch (error) { failures.push(`${candidate}: ${error.message}`); }
  }
  if (!graphEndpoint) throw new Error(`No graph was overwritten. Collection failed:\n${failures.join('\n')}`);
  const allNodes = new Map(graphResponse.elements.filter(element => element.type === 'node').map(element => [element.id, element]));
  const usedNodes = new Set(), edgeMap = new Map(), excluded = {};
  const exclude = reason => { excluded[reason] = (excluded[reason] || 0) + 1; };
  let includedWays = 0;
  for (const way of graphResponse.elements.filter(element => element.type === 'way')) {
    const tags = way.tags || {};
    const footPermitted = ['yes', 'designated', 'permissive', 'official'].includes(tags.foot);
    if (['no', 'private'].includes(tags.foot)) { exclude('foot forbidden'); continue; }
    if (!footPermitted && ['no', 'private', 'customers', 'delivery'].includes(tags.access)) { exclude('restricted access'); continue; }
    if (tags.sidewalk === 'no' && ['primary', 'secondary', 'tertiary'].includes(tags.highway) && !footPermitted) { exclude('main road without sidewalk'); continue; }
    if (tags.construction || tags.proposed || tags.area === 'yes') { exclude('construction/proposed/area'); continue; }
    if (['yes', '-1', '1'].includes(tags['oneway:foot']) || ['yes', 'forward', 'backward', 'reversible'].includes(tags.conveying)) { exclude('directional pedestrian facility omitted'); continue; }
    includedWays++;
    for (let index = 1; index < (way.nodes?.length || 0); index++) {
      const a = allNodes.get(way.nodes[index - 1]), b = allNodes.get(way.nodes[index]);
      if (!a || !b) continue;
      const length = Math.round(metres(a, b) * 10) / 10;
      if (length <= 0) continue;
      const lo = Math.min(a.id, b.id), hi = Math.max(a.id, b.id), key = `${lo}:${hi}`;
      usedNodes.add(lo); usedNodes.add(hi);
      const existing = edgeMap.get(key);
      const edge = { edge: [lo, hi, length], steps: tags.highway === 'steps' };
      if (!existing || (existing.steps && !edge.steps)) edgeMap.set(key, edge);
    }
  }
  const edgesAndFlags = [...edgeMap.values()];
  const nodes = [...usedNodes].sort((a, b) => a - b).map(id => [id, allNodes.get(id).lat, allNodes.get(id).lon]);
  // Component sizes expose disconnected extracts rather than imply every destination is routable.
  const parent = new Map(nodes.map(([id]) => [id, id]));
  function find(id) { let p = id; while (parent.get(p) !== p) p = parent.get(p); while (parent.get(id) !== id) { const next = parent.get(id); parent.set(id, p); id = next; } return p; }
  for (const { edge: [a, b] } of edgesAndFlags) { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); }
  const components = new Map();
  for (const [id] of nodes) { const component = find(id); components.set(component, (components.get(component) || 0) + 1); }
  const fetchedAt = new Date().toISOString();
  const graph = {
    schemaVersion: 1, fetchedAt, source: 'OpenStreetMap via Overpass API',
    license: 'ODbL 1.0; © OpenStreetMap contributors',
    endpoint: graphEndpoint, query: graphQuery, bbox: graphBbox,
    osmBaseTimestamp: graphResponse.osm3s?.timestamp_osm_base || null,
    format: { nodes: '[OSM node ID, latitude, longitude]', edges: '[from node ID, to node ID, length metres]; undirected', stepEdges: 'Indexes in edges whose source highway=steps' },
    directed: false, nodes, edges: edgesAndFlags.map(entry => entry.edge),
    stepEdges: edgesAndFlags.flatMap((entry, index) => entry.steps ? [index] : []),
    stats: { nodes: nodes.length, edges: edgesAndFlags.length, includedWays, excludedWays: excluded, components: components.size, largestComponentNodes: Math.max(0, ...components.values()) },
    limitations: [
      'Prototype OSM street/path network, not a safety-verified pedestrian navigation service.',
      'Roads without an explicit foot prohibition can be included; their pavement quality, lighting and accessibility are unknown.',
      'Explicitly forbidden/private ways and main roads explicitly tagged sidewalk=no are omitted unless foot access is explicitly permitted.',
      'Directional pedestrian facilities are omitted; edges are undirected. Steps are indexed separately.',
      'POI centers are not entrances. Snapping to a network node does not establish that the approach is physically accessible.',
      'Paths can be disconnected; use an explicitly labelled distance estimate when no connected route exists.',
    ],
  };
  await mkdir(resolve(root, 'data'), { recursive: true });
  await writeFile(resolve(root, 'data/walk-graph.json'), `${JSON.stringify(graph)}\n`);
  try {
    const provenancePath = resolve(root, 'data/provenance.json');
    const existingProvenance = JSON.parse(await readFile(provenancePath, 'utf8'));
    existingProvenance.walkGraph = {
      file: 'data/walk-graph.json', fetchedAt: graph.fetchedAt, source: graph.source,
      endpoint: graph.endpoint, license: graph.license, bbox: graph.bbox,
      osmBaseTimestamp: graph.osmBaseTimestamp, stats: graph.stats,
      stepEdges: graph.stepEdges.length, limitations: graph.limitations,
    };
    await writeFile(provenancePath, `${JSON.stringify(existingProvenance, null, 2)}\n`);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  console.log(JSON.stringify(graph.stats, null, 2));
}

if (process.argv.includes('--graph-only')) {
  await collectWalkGraph();
  process.exit(0);
}

function categoryFor(tags) {
  if (tags.tourism === 'museum') return 'museum';
  if (tags.amenity === 'library') return 'library';
  if (tags.leisure === 'playground') return 'playground';
  if (['park', 'garden'].includes(tags.leisure)) return 'park';
  if (tags.tourism === 'viewpoint') return 'viewpoint';
  if (tags.tourism === 'artwork') return 'art';
  if (tags.tourism === 'attraction' || ['monument', 'memorial'].includes(tags.historic)) return 'attraction';
  if (tags.amenity === 'cafe') return 'cafe';
  if (['restaurant', 'fast_food', 'food_court'].includes(tags.amenity)) return 'food';
  return null;
}

function metres(a, b) {
  const rad = Math.PI / 180;
  const dlat = (b.lat - a.lat) * rad, dlon = (b.lon - a.lon) * rad;
  const x = Math.sin(dlat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dlon / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function safeWebsite(value) {
  if (!value) return null;
  try { const url = new URL(value); return ['http:', 'https:'].includes(url.protocol) ? url.href : null; }
  catch { return null; }
}

function descriptionFor(tags, category) {
  const facts = [`Категория в OpenStreetMap: ${categoryNames[category].toLowerCase()}.`];
  if (tags.description) facts.push(`Описание из OSM: ${tags.description}`);
  else if (tags['description:ru']) facts.push(`Описание из OSM: ${tags['description:ru']}`);
  const address = [tags['addr:street'], tags['addr:housenumber']].filter(Boolean).join(', ');
  if (address) facts.push(`Адрес из OSM: ${address}.`);
  if (tags.cuisine) facts.push(`Кухня (тег OSM): ${tags.cuisine}.`);
  if (tags.artwork_type) facts.push(`Вид объекта (тег OSM): ${tags.artwork_type}.`);
  if (tags.memorial) facts.push(`Вид мемориала (тег OSM): ${tags.memorial}.`);
  if (tags.operator) facts.push(`Оператор по OSM: ${tags.operator}.`);
  if (!tags.name && !tags['name:ru'] && !tags['name:kk'] && !tags['name:en']) {
    facts.push('Собственное название в источнике не указано; показана категория и идентификатор OSM.');
  }
  return facts.join(' ');
}

function normalize(element, fetchedAt) {
  const tags = element.tags || {};
  const category = categoryFor(tags);
  const lat = element.lat ?? element.center?.lat, lon = element.lon ?? element.center?.lon;
  if (!category || !Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  if (lat < bbox[0] || lon < bbox[1] || lat > bbox[2] || lon > bbox[3]) return null;
  if (['private', 'no'].includes(tags.access) || tags.disused === 'yes' || tags.abandoned === 'yes') return null;
  const name = tags['name:ru'] || tags.name || tags['name:kk'] || tags['name:en'] || `${categoryNames[category]} · OSM ${element.id}`;
  // Indoor status is evidence, not a guess based on category or building footprint.
  const indoor = tags.indoor === 'yes' ? true : tags.indoor === 'no' ? false : null;
  return {
    id: `osm-${element.type}-${element.id}`, name, lat, lon, category,
    description: descriptionFor(tags, category), tags,
    openingHours: tags.opening_hours || null,
    website: safeWebsite(tags.website || tags['contact:website'] || tags.url),
    sourceUrl: `https://www.openstreetmap.org/${element.type}/${element.id}`,
    fetchedAt, indoor, wheelchair: tags.wheelchair || null,
  };
}

function canonicalName(poi) {
  // Unnamed places are distinct; do not collapse nearby playgrounds or park entrances.
  if (!poi.tags.name && !poi.tags['name:ru'] && !poi.tags['name:kk'] && !poi.tags['name:en']) return null;
  return poi.name.toLocaleLowerCase('ru').replace(/[\p{P}\p{S}\s]/gu, '');
}

function richness(poi) {
  return Object.keys(poi.tags).length + (poi.openingHours ? 10 : 0) + (poi.website ? 5 : 0);
}

let raw, endpoint;
const inputIndex = process.argv.indexOf('--input');
if (inputIndex !== -1) {
  if (!process.argv[inputIndex + 1]) throw new Error('--input requires a saved Overpass JSON path');
  raw = await readFile(resolve(process.argv[inputIndex + 1]), 'utf8');
  endpoint = 'saved Overpass response (--input)';
} else {
  const failures = [];
  for (const candidate of endpoints) {
    try {
      console.log(`Collecting public OpenStreetMap POIs from ${candidate} ...`);
      raw = execFileSync('curl', [
        '--fail-with-body', '--silent', '--show-error', '--compressed', '--max-time', '90',
        '--user-agent', 'QadamHackathonPOICollector/1.0 (central Astana educational prototype)',
        '--data-urlencode', `data=${query}`, candidate,
      ], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024, timeout: 95000 });
      const check = JSON.parse(raw);
      if (!Array.isArray(check.elements) || !check.elements.length || check.remark) {
        throw new Error(check.remark || 'Empty or invalid Overpass response');
      }
      endpoint = candidate;
      break;
    } catch (error) { failures.push(`${candidate}: ${error.message}`); }
  }
  if (!raw || !endpoint) throw new Error(`No dataset was overwritten. Collection failed:\n${failures.join('\n')}`);
}

const response = JSON.parse(raw);
if (!Array.isArray(response.elements) || !response.elements.length || response.remark) {
  throw new Error(`No dataset was overwritten. Invalid response: ${response.remark || 'no elements'}`);
}
const responseOutIndex = process.argv.indexOf('--response-out');
if (responseOutIndex !== -1) {
  if (!process.argv[responseOutIndex + 1]) throw new Error('--response-out requires a path');
  const responsePath = resolve(process.argv[responseOutIndex + 1]);
  await mkdir(dirname(responsePath), { recursive: true });
  await writeFile(responsePath, raw);
}
const fetchedAt = new Date().toISOString();
const normalized = response.elements.map(element => normalize(element, fetchedAt)).filter(Boolean);
const deduplicated = [], duplicates = [];
for (const poi of normalized.sort((a, b) => richness(b) - richness(a))) {
  const key = canonicalName(poi);
  const existing = key && deduplicated.find(other => other.category === poi.category && canonicalName(other) === key && metres(other, poi) < 65);
  if (existing) duplicates.push({ kept: existing.id, removed: poi.id, name: poi.name, distanceMetres: Math.round(metres(existing, poi)) });
  else deduplicated.push(poi);
}
let pois = deduplicated.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name, 'ru') || a.id.localeCompare(b.id));
const source = 'OpenStreetMap via Overpass API';
const license = 'ODbL 1.0; © OpenStreetMap contributors';
let dataset = { pois, fetchedAt, source, license, query };
let previousProvenance = null;
let collection = null;
if (foodOnly) {
  // A bounded food expansion must not refresh or delete previously frozen places.
  // Their own fetchedAt and tags remain untouched, including any absent fields.
  const previous = JSON.parse(await readFile(resolve(root, 'data/poi.json'), 'utf8'));
  previousProvenance = JSON.parse(await readFile(resolve(root, 'data/provenance.json'), 'utf8'));
  const existingIds = new Set(previous.pois.map(poi => poi.id));
  const additions = pois.filter(poi => !existingIds.has(poi.id));
  collection = {
    kind: 'food-expansion', fetchedAt, source, endpoint, license, query,
    osmBaseTimestamp: response.osm3s?.timestamp_osm_base || null,
    responseSha256: createHash('sha256').update(raw).digest('hex'),
    rawElements: response.elements.length,
    normalizedBeforeDeduplication: normalized.length,
    rejected: response.elements.length - normalized.length,
    duplicatesRemoved: duplicates.length, duplicates,
    retainedExisting: previous.pois.length,
    added: additions.length,
    addedIds: additions.map(poi => poi.id),
    normalization: 'Only restaurant, fast_food and food_court in the same bounding box; source tags retained. Existing POI records remain unchanged.',
  };
  pois = [...previous.pois, ...additions].sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name, 'ru') || a.id.localeCompare(b.id));
  dataset = {
    ...previous, pois,
    supplementalCollections: [...(previous.supplementalCollections || []), collection],
  };
}
const count = field => pois.filter(field).length;
const anchors = [
  { name: 'EXPO / AITU area', lat: 51.089, lon: 71.413 },
  { name: 'Bayterek', lat: 51.128, lon: 71.430 },
  { name: 'National Museum area', lat: 51.118, lon: 71.469 },
  { name: 'Ishim embankment area', lat: 51.166, lon: 71.425 },
];
let provenance = {
  generatedAt: fetchedAt, source, endpoint, license,
  attribution: '© OpenStreetMap contributors',
  licenseUrl: 'https://www.openstreetmap.org/copyright',
  sourceDocumentationUrl: 'https://wiki.openstreetmap.org/wiki/Overpass_API',
  bbox: { south: bbox[0], west: bbox[1], north: bbox[2], east: bbox[3] },
  coverage: 'Central Astana bounding box, not the entire administrative city. Includes the EXPO, Bayterek, National Museum and Ishim embankment areas.',
  osmBaseTimestamp: response.osm3s?.timestamp_osm_base || null,
  query, responseSha256: createHash('sha256').update(raw).digest('hex'),
  stats: {
    rawElements: response.elements.length, normalizedBeforeDeduplication: normalized.length,
    rejected: response.elements.length - normalized.length,
    duplicatesRemoved: duplicates.length, total: pois.length,
    namedInSource: count(p => Boolean(p.tags.name || p.tags['name:ru'] || p.tags['name:kk'] || p.tags['name:en'])),
    byCategory: Object.fromEntries(Object.keys(categoryNames).map(category => [category, count(p => p.category === category)])),
    withOpeningHours: count(p => Boolean(p.openingHours)), unknownOpeningHours: count(p => !p.openingHours),
    withWebsite: count(p => Boolean(p.website)),
    explicitIndoorYes: count(p => p.indoor === true), explicitIndoorNo: count(p => p.indoor === false),
    unknownIndoor: count(p => p.indoor === null), withWheelchairTag: count(p => p.wheelchair !== null),
    withSourceDescription: count(p => Boolean(p.tags.description || p.tags['description:ru'])),
  },
  anchorCoverage: anchors.map(anchor => ({
    ...anchor,
    within1500m: count(p => metres(anchor, p) <= 1500),
    byCategoryWithin1500m: Object.fromEntries(Object.keys(categoryNames).map(category => [category, count(p => p.category === category && metres(anchor, p) <= 1500)])),
    nearest: [...pois].sort((a, b) => metres(anchor, a) - metres(anchor, b)).slice(0, 3).map(p => ({ id: p.id, name: p.name, distanceMetres: Math.round(metres(anchor, p)) })),
  })),
  deduplication: { rule: 'Same normalized display name and category, less than 65 metres apart; retain the record with more source metadata. Unnamed records remain distinct.', duplicates },
  fieldPolicy: {
    name: 'OSM name:ru, name, name:kk or name:en. Otherwise an explicitly marked category + OSM ID display label.',
    coordinates: 'OSM node position or Overpass center of a way/relation. A center may not be a building entrance.',
    description: 'Deterministic template of source category, source description and optional address/cuisine/artwork/operator tags. No generated travel claims.',
    tags: 'Unmodified source tags.',
    openingHours: 'Raw opening_hours, otherwise null. This is source data, not verification that the venue is open now.',
    indoor: 'True or false only when OSM indoor=yes/no explicitly says so; otherwise null.',
    wheelchair: 'Raw wheelchair tag, otherwise null. A venue tag does not verify the whole pedestrian approach.',
    website: 'HTTP(S) website/contact:website/url tag only, otherwise null.',
  },
  limitations: [
    'Community-maintained data may be incomplete or outdated. Collection time is not venue verification time.',
    'No ratings, ticket prices, event schedules, opening status or accessibility claims are invented.',
    'OSM timestamps indicate map edits and must not be presented as the date someone verified a venue.',
    'No user coordinates or personal data are included in this public POI snapshot.',
  ],
};
if (foodOnly) {
  const baselineCollection = previousProvenance.baselineCollection || {
    generatedAt: previousProvenance.generatedAt,
    query: previousProvenance.query, endpoint: previousProvenance.endpoint,
    responseSha256: previousProvenance.responseSha256,
    osmBaseTimestamp: previousProvenance.osmBaseTimestamp,
    stats: previousProvenance.stats, deduplication: previousProvenance.deduplication,
  };
  provenance = {
    ...previousProvenance,
    generatedAt: fetchedAt,
    baselineCollection,
    supplementalCollections: [...(previousProvenance.supplementalCollections || []), collection],
    // These collection-input counts are kept separately because the input queries
    // have different collection times. They are not a single raw response.
    stats: {
      ...provenance.stats,
      rawElements: undefined, normalizedBeforeDeduplication: undefined,
      rejected: undefined, duplicatesRemoved: undefined,
    },
    anchorCoverage: provenance.anchorCoverage,
    fieldPolicy: { ...previousProvenance.fieldPolicy,
      fetchedAt: 'Per-POI collection time; the original snapshot timestamp is retained for original records. See supplementalCollections for later bounded additions.',
      images: 'Raw image/wikimedia_commons tags are provenance only, not permission to embed or a verified venue photo. No photo is invented.',
    },
  };
}
await mkdir(resolve(root, 'data'), { recursive: true });
await writeFile(resolve(root, 'data/poi.json'), `${JSON.stringify(dataset, null, 2)}\n`);
await writeFile(resolve(root, 'data/provenance.json'), `${JSON.stringify(provenance, null, 2)}\n`);
console.log(JSON.stringify({ ...provenance.stats, anchorCoverage: provenance.anchorCoverage }, null, 2));
if (process.argv.includes('--graph')) await collectWalkGraph();
