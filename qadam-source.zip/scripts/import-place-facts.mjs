#!/usr/bin/env node
/** Reproducible import of reviewed facts. No network, LLM, new POI or fuzzy aliasing. */
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { validatePlaceFacts } from '../lib/place-facts.ts';

const appRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const evidenceRoot = resolve(appRoot, 'scripts/place-facts-evidence');
const readJson = async path => JSON.parse(await readFile(path, 'utf8'));
const serialize = value => `${JSON.stringify(value, null, 2)}\n`;
const equalIds = (a, b) => [...a].sort().join('|') === [...b].sort().join('|');

function isInside(point, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const a = polygon[i], b = polygon[j];
    if (((a.lat > point.lat) !== (b.lat > point.lat)) &&
        point.lon < (b.lon - a.lon) * (point.lat - a.lat) / (b.lat - a.lat) + a.lon) inside = !inside;
  }
  return inside;
}

/** A saved OSM shape plus reviewed official address supports only its listed identity. */
async function verifyIdentity(place, evidence, evidenceDir) {
  if (place.poiIds.length === 1) return;
  const proof = evidence.identityMappings?.find(item => item.canonicalId === place.canonicalId && equalIds(item.poiIds, place.poiIds));
  if (!proof || proof.method !== 'contained-named-node-and-official-address' || !proof.review || !proof.officialSourceUrl) {
    throw new Error(`Missing reviewed identity evidence: ${place.canonicalId}`);
  }
  const safeFile = relative => {
    const path = resolve(evidenceDir, relative);
    if (!path.startsWith(`${resolve(evidenceDir)}/`)) throw new Error('Identity evidence path escapes evidence directory');
    return path;
  };
  const [nodeFile, wayFile] = await Promise.all([readJson(safeFile(proof.nodeFile)), readJson(safeFile(proof.wayFile))]);
  const node = nodeFile.elements?.find(item => item.type === 'node' && place.poiIds.includes(`osm-node-${item.id}`));
  const way = wayFile.elements?.find(item => item.type === 'way' && place.poiIds.includes(`osm-way-${item.id}`));
  if (place.poiIds.length !== 2 || !node || !way || !Array.isArray(way.nodes) || way.nodes.length < 4 ||
      way.nodes[0] !== way.nodes.at(-1) || node.tags?.tourism !== 'museum' || way.tags?.tourism !== 'museum' ||
      !node.tags?.name || !node.tags?.website || !proof.officialStreet ||
      way.tags?.['addr:housenumber'] !== proof.officialHouseNumber) throw new Error('Incomplete identity geometry/address evidence');
  const nodes = new Map(wayFile.elements.filter(item => item.type === 'node').map(item => [item.id, item]));
  const polygon = way.nodes.map(id => nodes.get(id));
  if (polygon.some(point => !Number.isFinite(point?.lat) || !Number.isFinite(point?.lon)) || !isInside(node, polygon)) {
    throw new Error('Named POI is not contained in the reviewed building');
  }
  const host = url => new URL(url).hostname.replace(/^www\./, '');
  if (host(node.tags.website) !== host(proof.officialSourceUrl)) throw new Error('Identity official website mismatch');
}

export async function preparePlaceFacts(seed, snapshot, evidence, evidenceDir = evidenceRoot) {
  const validated = validatePlaceFacts(seed, snapshot);
  if (!validated) throw new Error('Invalid curated seed: schema, source URL, duplicate ID, timestamp or snapshot POI ID');
  if (validated.places.length < 8) throw new Error('Release needs at least eight reviewed canonical places');
  if (!evidence || evidence.version !== 1 || evidence.checkedAt !== validated.checkedAt || !Array.isArray(evidence.sources)) {
    throw new Error('Missing matching source-evidence index');
  }
  for (const place of validated.places) {
    for (const fact of place.facts) {
      const source = evidence.sources.find(item => item.sourceUrl === fact.sourceUrl);
      if (!source || !source.title || !source.publisher || !source.verification || source.checkedAt !== fact.checkedAt || !source.factIds?.includes(fact.id)) {
        throw new Error(`Fact lacks reviewed source evidence: ${fact.id}`);
      }
    }
    await verifyIdentity(place, evidence, evidenceDir);
  }
  return validated;
}

async function main() {
  const args = process.argv.slice(2);
  const values = new Map();
  let check = false;
  for (let index = 0; index < args.length; index++) {
    const flag = args[index];
    if (flag === '--check') { check = true; continue; }
    if (!['--input', '--snapshot', '--evidence', '--output'].includes(flag) || !args[index + 1] || args[index + 1].startsWith('--')) {
      throw new Error('Usage: node --experimental-strip-types scripts/import-place-facts.mjs [--check] [--input PATH] [--snapshot PATH] [--evidence PATH] [--output PATH]');
    }
    values.set(flag, resolve(args[++index]));
  }
  const input = values.get('--input') ?? resolve(evidenceRoot, 'curated-seed.json');
  const snapshotFile = values.get('--snapshot') ?? resolve(appRoot, 'data/poi.json');
  const evidenceFile = values.get('--evidence') ?? resolve(evidenceRoot, 'source-evidence.json');
  const output = values.get('--output') ?? resolve(appRoot, 'data/place-facts.json');
  const [seed, snapshot, evidence] = await Promise.all([readJson(input), readJson(snapshotFile), readJson(evidenceFile)]);
  const data = await preparePlaceFacts(seed, snapshot, evidence, dirname(evidenceFile));
  const content = serialize(data);
  if (check) {
    const existing = await readFile(output, 'utf8');
    if (existing !== content) throw new Error('Output differs from the validated curated seed; run import without --check');
  } else {
    if (output === snapshotFile) throw new Error('Refusing to overwrite original POI snapshot');
    await writeFile(output, content);
  }
  console.log(JSON.stringify({
    mode: check ? 'check' : 'import', canonicalPlaces: data.places.length,
    poiRecords: data.places.reduce((sum, place) => sum + place.poiIds.length, 0),
    facts: data.places.reduce((sum, place) => sum + place.facts.length, 0),
    checkedAt: data.checkedAt, sha256: createHash('sha256').update(content).digest('hex'),
  }));
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error instanceof Error ? error.message : 'Import failed'); process.exitCode = 1; });
}
