import { test } from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { almatyInput, inputInstant, isPlanResponse, safeExternalURL, isCityDataset } from '../lib/experience.ts';

const base = () => ({ plan: null, trace: [], warnings: [], generationMode: 'retrieval' });
test('Almaty wall time is stable across device timezone and leap days', () => {
  assert.equal(almatyInput(new Date('2028-02-28T20:10:00Z')), '2028-02-29T01:10');
  assert.equal(inputInstant('2028-02-29T01:10'), '2028-02-28T20:10:00.000Z');
  assert.equal(inputInstant('2026-02-31T12:00'), null);
  assert.equal(inputInstant('2026-02-29T12:00'), null);
  assert.equal(inputInstant('2026-10-20T24:00'), null);
});
test('network guard accepts empty/clarification but refuses malformed nested intent', () => {
  assert.equal(isPlanResponse(base()), true);
  assert.equal(isPlanResponse({ ...base(), intent: {} }), false);
  assert.equal(isPlanResponse({ ...base(), intent: { achievedCategories: [], unmetCategories: [], contract: null } }), true);
  assert.equal(isPlanResponse({ ...base(), intent: { achievedCategories: [], unmetCategories: [], contract: { desiredCategories: [], excludedCategories: [], unsupported: [{}] } } }), false);
  assert.equal(isPlanResponse({ ...base(), departureAt: 'not a date' }), false);
});
test('network guard rejects bad option payload before map renderer', () => {
  assert.equal(isPlanResponse({ ...base(), options: [{ id: 'x', label: 'x', tradeoff: 'x', plan: {} }] }), false);
  assert.equal(isPlanResponse({ ...base(), clarification: { question: 'Where?', options: [{ id:'x', label:'Go', action:'set-origin', origin: { lat:NaN,lon:71,label:'x' } }] } }), false);
  assert.equal(isPlanResponse({ ...base(), trace:[{step:'x',detail:[],ms:1}] }), false);
});
test('external handoffs accept map domains and reject credentials, active schemes and untrusted hosts', () => {
  assert.ok(safeExternalURL('https://www.google.com/maps/search/?api=1&query=Astana'));
  assert.ok(safeExternalURL('https://2gis.kz/astana/search/football'));
  assert.equal(safeExternalURL('javascript:alert(1)'), null);
  assert.equal(safeExternalURL('https://google.com.evil.invalid'), null);
  assert.equal(safeExternalURL('https://secret@www.google.com/maps'), null);
  assert.equal(isPlanResponse({ ...base(), clarification:{question:'Next?',options:[{id:'x',label:'Go',action:'external-search',value:'https://evil.invalid'}]} }), false);
});

test('malformed values read by cards and source dialogs are rejected before rendering', () => {
  const poi = { id:'osm-node-1', name:'Place', lat:51.128, lon:71.43, category:'cafe', description:'', tags:{name:'Place'}, sourceUrl:'https://www.openstreetmap.org/node/1', fetchedAt:'2026-10-20T00:00:00Z', openingHours:null, wheelchair:null, indoor:null };
  const valid = { ...base(), plan:{title:'Walk',summary:'Walk',stops:[{poi,visitMinutes:12,travelMinutes:2,why:'Category match',activity:'A break',hoursStatus:'unknown'}],totalMinutes:19,walkingMinutes:4,visitMinutes:12,bufferMinutes:3,distanceMeters:240,returnMinutes:2,routeCoordinates:[[71.43,51.128],[71.431,51.129]],routeKind:'walking'} };
  assert.equal(isPlanResponse(valid), true);
  assert.equal(isCityDataset({pois:[poi],count:1,fetchedAt:poi.fetchedAt}),true);
  assert.equal(isCityDataset({pois:[poi],count:1,fetchedAt:'bad-date'}),false);
  assert.equal(isCityDataset({pois:[poi],count:{bad:true},fetchedAt:poi.fetchedAt}),false);
  const badPOIs = [ {...poi,tags:{name:{bad:true}}}, {...poi,openingHours:{bad:true}}, {...poi,wheelchair:{bad:true}}, {...poi,fetchedAt:'bad-date'} ];
  for (const bad of badPOIs) assert.equal(isPlanResponse({...valid,plan:{...valid.plan,stops:[{...valid.plan.stops[0],poi:bad}]}}), false);
  assert.equal(isPlanResponse({...valid,plan:{...valid.plan,stops:[{...valid.plan.stops[0],observation:{bad:true}}]}}), false);
  assert.equal(isPlanResponse({...base(),clarification:{question:'Which?',message:{bad:true},options:[]}}), false);
});
