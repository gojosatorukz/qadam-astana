import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extension.
import { createLocationWatch, walkStartBlock } from '../lib/walk-session.ts';
test('a delayed permission result cannot start an expired or future plan',()=>{
  const now=Date.parse('2026-10-20T07:00:00Z'),iso=(delta:number)=>new Date(now+delta).toISOString();
  const base={nowMs:now,departureMode:'now' as const,computedAt:iso(0),deadlineAt:iso(45*60_000),hasStarted:false};
  assert.equal(walkStartBlock(base),null);
  assert.equal(walkStartBlock({...base,nowMs:now+61_000}),'expired');
  assert.equal(walkStartBlock({...base,departureMode:'custom',departureAt:iso(120_000)}),'future');
  assert.equal(walkStartBlock({...base,departureMode:'custom',departureAt:iso(-61_000)}),'expired');
});
test('an accepted walk keeps return guidance after the original time window',()=>{
  const now=Date.parse('2026-10-20T07:00:00Z');
  assert.equal(walkStartBlock({nowMs:now,departureMode:'now',computedAt:new Date(now-3_600_000).toISOString(),deadlineAt:new Date(now-60_000).toISOString(),hasStarted:true}),null);
});
test('stopping GPS rejects late position/error callbacks and clears only its own watch',()=>{
  const success:PositionCallback[]=[],errors:PositionErrorCallback[]=[],cleared:number[]=[];
  const watcher=createLocationWatch({watchPosition(ok,fail,options){assert.equal(options?.enableHighAccuracy,true);assert.equal(options?.maximumAge,0);success.push(ok);errors.push(fail!);return 7;},clearWatch(id){cleared.push(id);}});
  let fixes=0,failures=0;watcher.start(()=>fixes++,()=>failures++);success[0]({} as GeolocationPosition);assert.equal(fixes,1);
  watcher.stop();success[0]({} as GeolocationPosition);errors[0]({} as GeolocationPositionError);watcher.stop();
  assert.equal(fixes,1);assert.equal(failures,0);assert.deepEqual(cleared,[7]);
});
test('restarting a GPS session does not let the old callback revive its progress',()=>{
  const callbacks:PositionCallback[]=[],cleared:number[]=[];let count=0;
  const watcher=createLocationWatch({watchPosition(ok){callbacks.push(ok);return callbacks.length;},clearWatch(id){cleared.push(id);}});
  watcher.start(()=>count+=100,()=>{});watcher.start(()=>count++,()=>{});
  callbacks[0]({} as GeolocationPosition);callbacks[1]({} as GeolocationPosition);assert.equal(count,1);assert.deepEqual(cleared,[1]);watcher.stop();assert.deepEqual(cleared,[1,2]);
});
test('synchronous denial cannot leave the newly returned GPS watch running',()=>{
  const cleared:number[]=[];
  const watcher=createLocationWatch({watchPosition(_ok,fail){fail!({code:1} as GeolocationPositionError);return 9;},clearWatch(id){cleared.push(id);}});
  watcher.start(()=>assert.fail('unexpected fix'),()=>watcher.stop());assert.deepEqual(cleared,[9]);
});
