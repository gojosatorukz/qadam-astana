import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import test from 'node:test';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { planRoute } from '../lib/planner.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
import type { POIDataset } from '../lib/planner';
import type { RawWalkingGraph } from '../lib/walking-graph';
import type { PlanRequest, PlanResponse } from '../lib/qadam-types';

// Public landmark presets only. These are not a person's GPS history. The clock
// is the actual Almaty time of the original audit, frozen for reproducibility.
const AUDIT_TIME = '2026-10-19T23:35:00+05:00';
const origins = {
  baiterek: { lat: 51.12828, lon: 71.43055, label: 'Public preset: Baiterek' },
  expo: { lat: 51.08915, lon: 71.41293, label: 'Public preset: EXPO' },
  museum: { lat: 51.11862, lon: 71.46919, label: 'Public preset: National Museum' },
  riverfront: { lat: 51.16430, lon: 71.42580, label: 'Public preset: Yesil riverfront' },
};
const data = JSON.parse(readFileSync(new URL('../data/poi.json', import.meta.url), 'utf8')) as POIDataset;
const rawGraph = JSON.parse(readFileSync(new URL('../data/walk-graph.json', import.meta.url), 'utf8')) as RawWalkingGraph;
const graph = new WalkingGraph(rawGraph);
const sourceIds = new Set(data.pois.map(poi => poi.id));
const base: PlanRequest = {
  query: '', origin: origins.baiterek, minutes: 45, interests: [],
  indoor: false, knownHoursOnly: false, accessible: false, language: 'ru', now: AUDIT_TIME,
};

type Scenario = {
  id: string; description: string; overrides: Partial<PlanRequest>;
  expected: 'plan' | 'empty'; kind?: 'walking' | 'estimate';
  exactIds?: string[]; minimumStops?: number;
};

const scenarios: Scenario[] = [
  { id: 'S01', description: 'Baiterek, coffee, 45 min at night', overrides: { interests: ['cafe'] }, expected: 'plan', kind: 'walking' },
  { id: 'S02', description: 'Baiterek, café and park, 90 min', overrides: { interests: ['cafe', 'park'], minutes: 90 }, expected: 'plan', kind: 'walking', minimumStops: 2 },
  { id: 'S03', description: 'Baiterek, coffee, insufficient 20 min', overrides: { interests: ['cafe'], minutes: 20 }, expected: 'empty' },
  { id: 'S04', description: 'EXPO, coffee with explicitly unknown hours allowed', overrides: { origin: origins.expo, interests: ['cafe'] }, expected: 'plan', kind: 'walking' },
  { id: 'S05', description: 'EXPO, café and park, 90 min', overrides: { origin: origins.expo, interests: ['cafe', 'park'], minutes: 90 }, expected: 'plan', kind: 'walking', minimumStops: 2 },
  { id: 'S06', description: 'EXPO, architecture, 60 min', overrides: { origin: origins.expo, interests: ['attraction'], minutes: 60 }, expected: 'plan', kind: 'walking' },
  { id: 'S07', description: 'Museum area, unknown museum hours remain unknown', overrides: { origin: origins.museum, interests: ['museum'], minutes: 90 }, expected: 'plan', kind: 'walking' },
  { id: 'S08', description: 'Riverfront, park, 45 min', overrides: { origin: origins.riverfront, interests: ['park'] }, expected: 'plan', kind: 'walking' },
  { id: 'S09', description: 'Riverfront, café and park, 90 min', overrides: { origin: origins.riverfront, interests: ['cafe', 'park'], minutes: 90 }, expected: 'plan', kind: 'walking', minimumStops: 2 },
  { id: 'S10', description: 'Baiterek, strict listed opening hours', overrides: { interests: ['cafe'], knownHoursOnly: true }, expected: 'plan', kind: 'walking' },
  { id: 'S11', description: 'Baiterek, verified indoor café unavailable', overrides: { interests: ['cafe'], indoor: true, minutes: 90 }, expected: 'empty' },
  { id: 'S12', description: 'Venue wheelchair metadata, explicit network estimate fallback', overrides: { interests: ['cafe'], accessible: true, minutes: 90 }, expected: 'plan', kind: 'estimate' },
  { id: 'S13', description: 'All strict filters, no fabricated answer', overrides: { knownHoursOnly: true, indoor: true, accessible: true, minutes: 90 }, expected: 'empty' },
  { id: 'S14', description: 'Kazakh query and response templates', overrides: { query: 'Кофе мен саябақ', language: 'kk', minutes: 60 }, expected: 'plan', kind: 'walking' },
  { id: 'S15', description: 'English query from museum area', overrides: { origin: origins.museum, query: 'Coffee and a park', language: 'en', minutes: 90 }, expected: 'plan', kind: 'walking', minimumStops: 2 },
  { id: 'S16', description: 'Five-minute boundary, no impossible recommendation', overrides: { minutes: 5 }, expected: 'empty' },
  { id: 'S17', description: 'Public city-edge probe outside graph and nearby POI coverage', overrides: { origin: { lat: 51.33, lon: 71.70, label: 'Public coverage test' }, minutes: 120 }, expected: 'empty' },
  { id: 'S18', description: 'Reliable night demo, riverfront listed 24/7 café', overrides: { origin: origins.riverfront, interests: ['cafe'], knownHoursOnly: true }, expected: 'plan', kind: 'walking', exactIds: ['osm-way-1333795504'] },
  { id: 'S19', description: 'Same reliable night demo, 20 min cannot fit', overrides: { origin: origins.riverfront, interests: ['cafe'], knownHoursOnly: true, minutes: 20 }, expected: 'empty' },
  { id: 'S20', description: 'Explicit future departure replay, not a current opening claim', overrides: { origin: origins.baiterek, interests: ['cafe', 'park'], minutes: 90, now: '2026-10-20T12:00:00+05:00' }, expected: 'plan', kind: 'walking', minimumStops: 2 },
  { id: 'S21', description: 'Riverfront future mixed preferences retain near-park alternatives', overrides: { origin: origins.riverfront, interests: ['cafe', 'park'], minutes: 90, now: '2026-10-20T12:00:00+05:00' }, expected: 'plan', kind: 'walking', minimumStops: 2 },
];

function assertPlanInvariants(response: PlanResponse, request: PlanRequest, scenario: Scenario): void {
  assert.equal(response.generationMode, 'retrieval', 'This matrix does not call Gemini or claim generation quality.');
  assert.equal(response.dataset.count, data.pois.length);
  if (scenario.expected === 'empty') {
    assert.equal(response.plan, null);
    assert.ok(response.warnings.length > 0);
    return;
  }
  assert.ok(response.plan, `${scenario.id} should have a feasible snapshot itinerary.`);
  const plan = response.plan;
  assert.equal(plan.routeKind, scenario.kind);
  assert.ok(plan.stops.length >= (scenario.minimumStops ?? 1) && plan.stops.length <= 3);
  assert.equal(new Set(plan.stops.map(stop => stop.poi.id)).size, plan.stops.length);
  assert.ok(plan.stops.every(stop => sourceIds.has(stop.poi.id)), 'Every selected ID exists in the collected snapshot.');
  assert.equal(new Set(plan.stops.map(stop => stop.poi.category)).size, plan.stops.length);
  assert.equal(plan.totalMinutes, plan.walkingMinutes + plan.visitMinutes + plan.bufferMinutes);
  assert.equal(plan.walkingMinutes, plan.stops.reduce((sum, stop) => sum + stop.travelMinutes, 0) + plan.returnMinutes);
  assert.equal(plan.visitMinutes, plan.stops.reduce((sum, stop) => sum + stop.visitMinutes, 0));
  assert.ok(Number.isInteger(plan.totalMinutes) && plan.totalMinutes <= request.minutes);
  assert.ok(plan.returnMinutes > 0 && plan.bufferMinutes >= 3 && plan.distanceMeters > 0);
  assert.deepEqual(plan.routeCoordinates[0], [request.origin.lon, request.origin.lat]);
  assert.deepEqual(plan.routeCoordinates.at(-1), [request.origin.lon, request.origin.lat]);
  assert.ok(plan.routeCoordinates.every(([lon, lat]) => Number.isFinite(lon) && Number.isFinite(lat)));
  assert.ok(plan.stops.every(stop => stop.hoursStatus !== 'closed'));
  if (request.knownHoursOnly) assert.ok(plan.stops.every(stop => stop.hoursStatus === 'open' && stop.poi.openingHours));
  if (request.indoor) assert.ok(plan.stops.every(stop => stop.poi.indoor === true));
  if (request.accessible) assert.ok(plan.stops.every(stop => ['yes', 'designated'].includes(stop.poi.wheelchair ?? '')));
  if (plan.stops.some(stop => stop.hoursStatus === 'unknown')) assert.ok(response.warnings.some(warning => /неизвест|белгісіз|missing|unsupported/i.test(warning)));
  if (scenario.exactIds) assert.deepEqual(plan.stops.map(stop => stop.poi.id), scenario.exactIds);
  const graphTrace = response.trace.find(step => step.step === 'walking-graph');
  if (plan.routeKind === 'walking') {
    assert.ok(graphTrace);
    const searches = graphTrace.detail.match(/(\d+) Dijkstra searches/);
    assert.ok(searches && Number(searches[1]) <= 4);
    assert.ok(response.warnings.some(warning => /не официальная|not official|ресми навигация емес/.test(warning)));
  }
}

for (const scenario of scenarios) test(`real data ${scenario.id}: ${scenario.description}`, () => {
  const request = { ...base, ...scenario.overrides };
  const response = planRoute(request, data, { routing: graph });
  assertPlanInvariants(response, request, scenario);
});

test('real dataset provenance and honest missing-data metadata', () => {
  assert.equal(data.pois.length, 1204);
  const retained=data.pois.filter(poi=>poi.category!=='food');
  assert.equal(retained.length,890,'All original source records remain.');
  assert.equal(createHash('sha256').update(JSON.stringify(retained)).digest('hex'),'fa0888d64a40b9a90e45a99955be58a8047f02f3b77b068eb4a51849aed47ed4','The original 890 records and their order are byte-equivalent under JSON serialization.');
  const meals=data.pois.filter(poi=>poi.category==='food');assert.equal(meals.length,314);assert.ok(meals.every(poi=>['restaurant','fast_food','food_court'].includes(poi.tags.amenity)));
  assert.equal(graph.nodeCount, 81_383);
  assert.equal(graph.edgeCount, 97_427);
  assert.ok(data.source.includes('OpenStreetMap'));
  assert.ok(Number.isFinite(Date.parse(data.fetchedAt)));
  assert.ok(data.pois.every(poi => /^https:\/\/www\.openstreetmap\.org\/(node|way|relation)\/\d+$/.test(poi.sourceUrl)));
  assert.equal(data.pois.filter(poi => poi.openingHours !== null).length, 250);
  assert.equal(data.pois.filter(poi => poi.indoor === true).length, 8);
  assert.equal(data.pois.filter(poi => ['yes', 'designated'].includes(poi.wheelchair ?? '')).length, 31);
});

test('real dataset route is deterministic for the same frozen inputs', () => {
  const request = { ...base, origin: origins.riverfront, interests: ['cafe'], knownHoursOnly: true };
  const first = planRoute(request, data, { routing: graph });
  const second = planRoute(request, data, { routing: graph });
  assert.deepEqual(first.plan, second.plan);
});
