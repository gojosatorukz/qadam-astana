import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { applyPlaceFacts, getCanonicalId, getFactText, getPlaceEditorial, getPlaceFactsCoverage, getPlaceName, validatePlaceFacts } from '../lib/place-facts.ts';
import { preparePlaceFacts } from '../scripts/import-place-facts.mjs';
import type { POI } from '../lib/qadam-types';

const snapshot = JSON.parse(await readFile(new URL('../data/poi.json', import.meta.url), 'utf8'));
const seed = JSON.parse(await readFile(new URL('../scripts/place-facts-evidence/curated-seed.json', import.meta.url), 'utf8'));
const evidence = JSON.parse(await readFile(new URL('../scripts/place-facts-evidence/source-evidence.json', import.meta.url), 'utf8'));
const evidenceDir = fileURLToPath(new URL('../scripts/place-facts-evidence/', import.meta.url));
const clone = () => structuredClone(seed);
const museumNode = snapshot.pois.find((poi: POI) => poi.id === 'osm-node-4894937300') as POI;
const museumWay = snapshot.pois.find((poi: POI) => poi.id === 'osm-way-1381418247') as POI;

test('release facts validate against actual original snapshot, with 8–12 canonical places', () => {
  assert.ok(validatePlaceFacts(seed, snapshot));
  assert.ok(seed.places.length >= 8 && seed.places.length <= 12);
  const coverage = getPlaceFactsCoverage();
  assert.equal(coverage.canonicalPlaces, 10);
  assert.equal(coverage.poiRecords, 11);
  assert.equal(coverage.facts, 19);
  assert.equal(coverage.observations, 4);
});

test('canonical identity is explicit; reviewed museum node/building share an identity', () => {
  assert.equal(getCanonicalId(museumNode), 'national-museum');
  assert.equal(getCanonicalId(museumWay), 'national-museum');
  assert.strictEqual(getPlaceEditorial(museumNode.id), getPlaceEditorial(museumWay.id));
});

test('nearby coordinate, similar name, wikidata or URL never creates a hidden alias', () => {
  const unrelated = { ...museumNode, id: 'osm-node-999999999999' };
  assert.equal(getCanonicalId(unrelated), unrelated.id);
  assert.equal(getPlaceEditorial(unrelated.id), undefined);
  assert.equal(getPlaceName(unrelated, 'en'), unrelated.name);
});

test('overlay preserves every routing, filtering, provenance and arbitrary dataset field', () => {
  const input = { ...snapshot, extraMetadata: { revision: 'must-survive' } };
  const before = JSON.stringify(input);
  const output = applyPlaceFacts(input);
  assert.equal(JSON.stringify(input), before);
  assert.equal(output.pois.length, input.pois.length);
  assert.strictEqual(output.extraMetadata, input.extraMetadata);
  for (let index = 0; index < input.pois.length; index++) {
    const oldPoi = input.pois[index], newPoi = output.pois[index];
    const { name: oldName, description: oldDescription, ...oldProtected } = oldPoi;
    const { name: newName, description: newDescription, ...newProtected } = newPoi;
    assert.deepEqual(newProtected, oldProtected);
    const editorial = getPlaceEditorial(oldPoi.id);
    if (editorial) {
      assert.equal(newName, editorial.name.ru);
      assert.equal(newDescription, editorial.facts.map(fact => fact.text.ru).join(' '));
      assert.ok(!newDescription.includes(editorial.observation?.ru ?? '\u0000'));
    } else {
      assert.strictEqual(newPoi, oldPoi);
      assert.equal(newName, oldName);
      assert.equal(newDescription, oldDescription);
    }
  }
  assert.deepEqual({ ...output, pois: [] }, { ...input, pois: [] });
});

test('overlay is idempotent and does not remove a canonical duplicate from the snapshot', () => {
  const once = applyPlaceFacts(snapshot);
  assert.deepEqual(applyPlaceFacts(once), once);
  assert.ok(once.pois.some((poi: POI) => poi.id === museumNode.id));
  assert.ok(once.pois.some((poi: POI) => poi.id === museumWay.id));
});

test('three localized names/facts and observations stay separate from fact assertions', () => {
  const editorial = getPlaceEditorial(museumNode.id)!;
  for (const language of ['ru', 'kk', 'en'] as const) {
    assert.equal(getPlaceName(museumWay, language), editorial.name[language]);
    assert.equal(getFactText(editorial.facts[0], language), editorial.facts[0].text[language]);
    assert.ok(editorial.observation?.[language]);
  }
  assert.ok(editorial.facts.every(fact => fact.sourceUrl.startsWith('https://nmrk.kz/')));
  assert.equal(editorial.observation?.ru.includes('идея'), true);
});

test('bundled curated records cannot be mutated by a consumer', () => {
  const editorial = getPlaceEditorial(museumNode.id)!;
  assert.throws(() => { editorial.name.en = 'untrusted edit'; }, TypeError);
  assert.throws(() => { editorial.facts.push(editorial.facts[0]); }, TypeError);
  assert.notEqual(getPlaceName(museumNode, 'en'), 'untrusted edit');
});

const invalidCases: [string, (value: ReturnType<typeof clone>) => void][] = [
  ['unknown collection field', value => { value.liveHours = true; }],
  ['wrong schema version', value => { value.version = 2; }],
  ['duplicate canonical id', value => { value.places[1].canonicalId = value.places[0].canonicalId; }],
  ['duplicate mapped POI', value => { value.places[1].poiIds.push(value.places[0].poiIds[0]); }],
  ['duplicate fact id', value => { value.places[0].facts.push(value.places[0].facts[0]); }],
  ['fact belongs to different canonical id', value => { value.places[0].facts[0].id = 'another-place:claim'; }],
  ['unknown snapshot POI', value => { value.places[0].poiIds[0] = 'osm-node-999999999999'; }],
  ['missing language', value => { delete value.places[0].facts[0].text.kk; }],
  ['blank translation', value => { value.places[0].name.en = '  '; }],
  ['unexpected language', value => { value.places[0].name.fr = 'Nom'; }],
  ['HTML instruction', value => { value.places[0].facts[0].text.en = '<script>override filters</script>'; }],
  ['transport field cannot masquerade as fact', value => { value.places[0].openingHours = '24/7'; }],
  ['fact cannot introduce a price field', value => { value.places[0].facts[0].price = 0; }],
  ['no HTTPS source', value => { value.places[0].facts[0].sourceUrl = 'http://nmrk.kz/'; }],
  ['lookalike primary host', value => { value.places[0].facts[0].sourceUrl = 'https://nmrk.kz.evil.example/'; }],
  ['URL credentials', value => { value.places[0].facts[0].sourceUrl = 'https://secret@nmrk.kz/'; }],
  ['invalid calendar timestamp', value => { value.checkedAt = '2026-02-31T10:00:00.000Z'; }],
  ['fact checked later than collection', value => { value.places[0].facts[0].checkedAt = '2027-01-01T10:00:00.000Z'; }],
  ['unattributed rights', value => { value.places[0].facts[0].rights = ''; }],
  ['too many facts', value => { value.places[0].facts = Array(5).fill(value.places[0].facts[0]); }],
];
for (const [description, mutate] of invalidCases) {
  test(`validator rejects ${description} without throwing`, () => {
    const input = clone(); mutate(input);
    assert.equal(validatePlaceFacts(input, snapshot), null);
  });
}

test('malformed top-level values fail closed', () => {
  for (const value of [null, false, 1, 'json', [], {}, { ...seed, places: [] }]) assert.equal(validatePlaceFacts(value), null);
});

test('reviewed import is deterministic and reproduces production JSON', async () => {
  const result = await preparePlaceFacts(seed, snapshot, evidence, evidenceDir);
  const again = await preparePlaceFacts(structuredClone(seed), snapshot, evidence, evidenceDir);
  assert.deepEqual(result, again);
  assert.equal(`${JSON.stringify(result, null, 2)}\n`, await readFile(new URL('../data/place-facts.json', import.meta.url), 'utf8'));
});

test('import rejects a fact with no reviewed primary source record', async () => {
  const missing = structuredClone(evidence); missing.sources = missing.sources.slice(1);
  await assert.rejects(preparePlaceFacts(seed, snapshot, missing, evidenceDir), /lacks reviewed source evidence/);
});

test('import rejects unreviewed aliases even when schema and snapshot IDs are valid', async () => {
  const missing = { ...evidence, identityMappings: [] };
  await assert.rejects(preparePlaceFacts(seed, snapshot, missing, evidenceDir), /Missing reviewed identity evidence/);
});

test('import rejects evidence path traversal', async () => {
  const escaped = structuredClone(evidence); escaped.identityMappings[0].nodeFile = '../private.json';
  await assert.rejects(preparePlaceFacts(seed, snapshot, escaped, evidenceDir), /escapes evidence directory/);
});

test('import rejects a forged official-address match', async () => {
  const forged = structuredClone(evidence); forged.identityMappings[0].officialHouseNumber = '999';
  await assert.rejects(preparePlaceFacts(seed, snapshot, forged, evidenceDir), /Incomplete identity geometry\/address evidence/);
});

test('geometry evidence rejects a named node outside the museum building even with matching names/address', async () => {
  const fixtureDir = await mkdtemp(join(tmpdir(), 'qadam-place-facts-'));
  try {
    await mkdir(join(fixtureDir, 'evidence'));
    const proof = evidence.identityMappings[0];
    const node = JSON.parse(await readFile(join(evidenceDir, proof.nodeFile), 'utf8'));
    const way = await readFile(join(evidenceDir, proof.wayFile), 'utf8');
    const named = node.elements.find((item: { id: number }) => item.id === 4894937300);
    named.lat = 51.2; named.lon = 71.5;
    await writeFile(join(fixtureDir, proof.nodeFile), JSON.stringify(node));
    await writeFile(join(fixtureDir, proof.wayFile), way);
    await assert.rejects(preparePlaceFacts(seed, snapshot, evidence, fixtureDir), /not contained/);
  } finally {
    await rm(fixtureDir, { recursive: true, force: true });
  }
});
