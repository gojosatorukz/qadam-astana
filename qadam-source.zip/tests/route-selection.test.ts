import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { planRoute, validatePlanRequest } from '../lib/planner.ts';
// @ts-expect-error Native Node TS source extensions.
import { buildPlan } from '../lib/build-plan.ts';
// @ts-expect-error Native Node TS source extensions.
import { planSemanticsValid } from '../lib/plan-validation.ts';
// @ts-expect-error Native Node TS source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
// @ts-expect-error Native Node TS source extensions.
import { getCanonicalId } from '../lib/place-facts.ts';
import type { PlanRequest, POI, PlanResponse } from '../lib/qadam-types';
import type { IntentContract } from '../lib/intent-types';

const request:PlanRequest={query:'',origin:{lat:51.128,lon:71.43,label:'A'},destination:{lat:51.128,lon:71.44,label:'B'},minutes:70,interests:['food'],indoor:false,knownHoursOnly:false,accessible:false,language:'en',now:'2026-10-20T12:00:00+05:00'};
const food:IntentContract={version:1,desiredCategories:['food'],excludedCategories:[],includeMode:'any',unsupported:[],needsClarification:false};
function fixture(count=6){
 const pois:POI[]=Array.from({length:count},(_,i)=>({id:`meal-${i}`,name:`Source restaurant ${i}`,lat:51.129+i*0.0002,lon:71.432,category:'food',tags:{amenity:'restaurant',name:`Source restaurant ${i}`},description:'Source record',openingHours:'24/7',website:null,sourceUrl:`https://www.openstreetmap.org/node/${i+1}`,fetchedAt:'2026-10-20T00:00:00Z',indoor:true,wheelchair:'yes'}));
 const nodes=[[1,51.128,71.43],[2,51.128,71.44],...pois.map((p,i)=>[i+3,p.lat,p.lon])];
 const routing=new WalkingGraph({nodes,edges:[[1,2,700],...pois.map((_,i)=>[1,i+3,(i+1)*100])]});
 return {dataset:{pois,fetchedAt:pois[0].fetchedAt,source:'Synthetic OSM-like records'},routing};
}
const shown=(r:PlanResponse)=>[...new Set((r.options??[]).flatMap(o=>o.plan.stops.map(s=>s.canonicalId??s.poi.id)))];

test('selection request validates bounded IDs, keeps a defensive list copy and rejects malformed fields',()=>{
 const input={...request,requiredPoiId:'meal-1',excludePoiIds:Array.from({length:80},(_,i)=>`seen-${i}`)};
 const parsed=validatePlanRequest(input);assert.ok('value' in parsed);
 if('value' in parsed){assert.equal(parsed.value.requiredPoiId,'meal-1');assert.deepEqual(parsed.value.excludePoiIds,input.excludePoiIds);assert.notEqual(parsed.value.excludePoiIds,input.excludePoiIds);}
 for(const requiredPoiId of [null,2,'',' ', 'meal 1','x'.repeat(201)])assert.ok('error' in validatePlanRequest({...request,requiredPoiId}));
 for(const excludePoiIds of [null,'meal-1',Array(81).fill('x'),['x','x'],[''],['a b'],[1],['x'.repeat(201)]])assert.ok('error' in validatePlanRequest({...request,excludePoiIds}));
});
test('more batches are disjoint, bounded and exhaust without reusing an earlier place',()=>{
 const {dataset,routing}=fixture();let history:string[]=[];const sizes:number[]=[];
 for(let page=0;page<3;page++){
  const current={...request,excludePoiIds:[...history]};const result=planRoute(current,dataset,{routing,intent:food,withAlternatives:true});
  assert.ok(planSemanticsValid(result,current,dataset,food));const ids=shown(result);assert.ok(ids.every(id=>!history.includes(id)));history.push(...ids);sizes.push(result.options?.length??0);
  if(result.plan){assert.ok(result.trace.find(t=>t.step==='walking-graph')?.detail.includes('2 Dijkstra searches'));for(const option of result.options!){assert.deepEqual(option.plan.routeCoordinates.at(-1),[71.44,51.128]);assert.ok(option.plan.totalMinutes<=70);}}
  else {assert.equal(result.options?.length,0);assert.ok(result.directRoute);}
 }
 assert.deepEqual(sizes,[4,2,0]);assert.equal(new Set(history).size,6);
});
test('required place outside the usual shortlist is retained and really visited',()=>{
 const {dataset,routing}=fixture(25);const current={...request,requiredPoiId:'meal-24',minutes:180};
 const result=planRoute(current,dataset,{routing,intent:food,withAlternatives:true});assert.ok(result.plan);assert.equal(result.options?.length,1);
 assert.ok(result.plan.stops.some(s=>s.poi.id==='meal-24'));const target=dataset.pois[24];assert.ok(result.plan.routeCoordinates.some(([lon,lat])=>lon===target.lon&&lat===target.lat),'The route geometry actually passes through the required place.');assert.ok(planSemanticsValid(result,current,dataset,food));assert.deepEqual(result.plan.routeCoordinates.at(-1),[71.44,51.128]);
});
test('required place never bypasses time, filters, hours, category exclusions or seen history',()=>{
 const {dataset,routing}=fixture();
 for(const [current,input,wanted] of [
  [{...request,requiredPoiId:'unknown'},dataset,food],
  [{...request,requiredPoiId:'meal-5',minutes:10},dataset,food],
  [{...request,requiredPoiId:'meal-0',indoor:true},{...dataset,pois:dataset.pois.map(p=>p.id==='meal-0'?{...p,indoor:null}:p)},food],
  [{...request,requiredPoiId:'meal-0',accessible:true},{...dataset,pois:dataset.pois.map(p=>p.id==='meal-0'?{...p,wheelchair:null}:p)},food],
  [{...request,requiredPoiId:'meal-0',knownHoursOnly:true},{...dataset,pois:dataset.pois.map(p=>p.id==='meal-0'?{...p,openingHours:null}:p)},food],
  [{...request,requiredPoiId:'meal-0'},{...dataset,pois:dataset.pois.map(p=>p.id==='meal-0'?{...p,openingHours:'off'}:p)},food],
  [{...request,requiredPoiId:'meal-0'},dataset,{...food,desiredCategories:[],excludedCategories:['food']}],
  [{...request,requiredPoiId:'meal-0',excludePoiIds:['meal-0']},dataset,food],
 ] as [PlanRequest,typeof dataset,IntentContract][]){
  const result=planRoute(current,input,{routing,intent:wanted,withAlternatives:true});assert.equal(result.plan,null,JSON.stringify(current));assert.deepEqual(result.options,[]);assert.ok(result.warnings.some(w=>w.includes('selected place')));assert.ok(planSemanticsValid(result,current,input,wanted));
 }
});
test('reviewed raw aliases exclude together and exclusion wins a required alias',()=>{
 const original=fixture(2).dataset;const aliases=['osm-node-4894937300','osm-way-1381418247'].map((id,i)=>({...original.pois[i],id,category:'museum',tags:{tourism:'museum',name:'Museum'},lat:51.128,lon:71.432}));
 const dataset={...original,pois:aliases};const wanted={...food,desiredCategories:['museum'] as ['museum']};
 for(const excluded of ['national-museum',aliases[0].id,aliases[1].id]){
  const current={...request,minutes:90,requiredPoiId:aliases[0].id,excludePoiIds:[excluded]};const result=planRoute(current,dataset,{intent:wanted,canonicalId:getCanonicalId,withAlternatives:true});
  assert.equal(result.plan,null);assert.equal(result.candidates,0);assert.ok(result.excluded.some(e=>e.reason==='previously-shown'&&e.count===2));assert.ok(planSemanticsValid(result,current,dataset,wanted));
 }
 const base={...request,minutes:90,requiredPoiId:'national-museum'};const selected=planRoute(base,dataset,{intent:wanted,canonicalId:getCanonicalId,withAlternatives:true});assert.ok(selected.plan);assert.ok(planSemanticsValid(selected,base,dataset,wanted));
 assert.equal(planSemanticsValid(selected,{...base,excludePoiIds:[aliases[1].id]},dataset,wanted),false);
});
test('semantic boundary rejects missing required places and exclusions in any alternative',()=>{
 const {dataset,routing}=fixture();const result=planRoute(request,dataset,{routing,intent:food,withAlternatives:true});assert.equal(result.options?.length,4);
 assert.equal(planSemanticsValid(result,{...request,requiredPoiId:'meal-5'},dataset,food),false);
 const alternate=result.options![3].plan.stops[0].poi.id;assert.equal(planSemanticsValid(result,{...request,excludePoiIds:[alternate]},dataset,food),false);
 const spoof=structuredClone(result);for(const option of spoof.options!)for(const stop of option.plan.stops)stop.canonicalId='meal-5';if(spoof.plan)for(const stop of spoof.plan.stops)stop.canonicalId='meal-5';assert.equal(planSemanticsValid(spoof,{...request,requiredPoiId:'meal-5'},dataset,food),false);
});
test('explicit build-through uses no AI and preserves A/B and selected venue',async()=>{
 const {dataset,routing}=fixture();const current={...request,requiredPoiId:'meal-3',excludePoiIds:['meal-0','meal-1'],localOnly:true};let calls=0;
 const result=await buildPlan(current,dataset,{routing,interpret:async()=>{calls++;throw Error('must not call');},enrich:async()=>{calls++;throw Error('must not call');}});
 assert.equal(calls,0);assert.ok(result.plan);assert.ok(result.plan.stops.some(s=>s.poi.id==='meal-3'));assert.deepEqual(result.plan.destination,current.destination);assert.ok(result.plan.totalMinutes<=current.minutes);assert.ok(planSemanticsValid(result,current,dataset,food));
 const conflict=await buildPlan({...current,excludePoiIds:['meal-3']},dataset,{routing});assert.equal(conflict.plan,null);assert.ok(conflict.diagnostics?.codes.includes('required-place-unavailable'));
});
