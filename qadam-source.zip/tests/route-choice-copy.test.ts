import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extension.
import { cuisineLabel, compareRoute, routeIdentity } from '../lib/route-choice.ts';
import type { POI, RoutePlan } from '../lib/qadam-types';
const poi={id:'a',name:'Italian French Pizza Palace',category:'food',tags:{},lat:51.12,lon:71.43} as POI;
const route=(walk:number,stay:number,ids=['a'])=>({walkingMinutes:walk,visitMinutes:stay,stops:ids.map(id=>({poi:{...poi,id}}))}) as RoutePlan;
test('venue name cannot invent a cuisine and broad source labels stay broad',()=>{
  assert.equal(cuisineLabel(poi,'ru'),null);
  assert.equal(cuisineLabel({...poi,tags:{cuisine:'regional'}},'ru'),'Региональная');
  assert.equal(cuisineLabel({...poi,tags:{cuisine:'pizza'}},'ru'),'Пицца');
});
test('cuisine source tokens support comma, semicolon and case without duplicate labels',()=>{
  assert.equal(cuisineLabel({...poi,tags:{cuisine:'KOREAN; pizza, Korean'}},'en'),'Korean · Pizza');
  assert.equal(cuisineLabel({...poi,tags:{cuisine:'Kazakh'}},'kk'),'Қазақ');
});
test('route difference describes actual walking and visiting costs, including equal timing',()=>{
  assert.match(compareRoute(route(20,30),route(30,20),'ru'),/На 10 мин меньше идти/);
  assert.match(compareRoute(route(20,30),route(30,20),'ru'),/На 10 мин больше на остановки/);
  assert.equal(compareRoute(route(30,20),route(30,20),'en'),'Same timing, different places along the way.');
});
test('route identity compares canonical place sets without pretending order is a new option',()=>{
  assert.equal(routeIdentity(route(20,20,['b','a'])),routeIdentity(route(20,20,['a','b'])));
  const alias=route(20,20,['raw']);alias.stops[0].canonicalId='a';
  assert.equal(routeIdentity(alias),routeIdentity(route(20,20,['a'])));
});
