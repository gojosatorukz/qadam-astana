import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { inferInterests, inferExcludedInterests, planRoute, validatePlanRequest } from '../lib/planner.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
import type { IntentContract, SupportedCategory } from '../lib/intent-types';
import type { PlanRequest, POI } from '../lib/qadam-types';

const request: PlanRequest = {
  query: '', origin: { lat: 51.128, lon: 71.43, label: 'Synthetic test origin' },
  minutes: 90, interests: [], indoor: false, knownHoursOnly: false,
  accessible: false, language: 'en', now: '2026-10-20T12:00:00+05:00',
};
function poi(category: SupportedCategory, overrides: Partial<POI> = {}): POI {
  return {
    id: category, name: category, lat: 51.128, lon: 71.431,
    category, description: 'OSM test record', tags: {}, openingHours: '24/7',
    website: null, sourceUrl: 'https://www.openstreetmap.org/node/1',
    fetchedAt: '2026-10-19T05:00:00Z', indoor: null, wheelchair: null, ...overrides,
  };
}
function dataset(pois: POI[]) { return { pois, fetchedAt: '2026-10-19T05:00:00Z', source: 'Synthetic OSM-like records for regression tests' }; }
function intent(overrides: Partial<IntentContract> = {}): IntentContract {
  return { version: 1, desiredCategories: [], excludedCategories: [], includeMode: 'any', unsupported: [], needsClarification: false, ...overrides };
}
const categories: SupportedCategory[] = ['art', 'attraction', 'cafe', 'library', 'museum', 'park', 'playground', 'viewpoint'];

for (const [name, query] of [
  ['T1 RU negative list', 'Без кафе и парков.'],
  ['T1 EN negative list', 'No cafes and parks.'],
  ['T1 KK negative list', 'Кафелер мен саябақтарға барғым келмейді.'],
] as const) test(name, () => {
  assert.deepEqual(inferExcludedInterests(query), ['cafe', 'park']);
  assert.deepEqual(inferInterests(query), []);
  const result = planRoute({ ...request, query }, dataset(categories.map(category => poi(category))));
  assert.ok(result.plan);
  assert.ok(result.plan.stops.every((stop: { poi: POI }) => !['cafe', 'park'].includes(stop.poi.category)));
});

for (const [name, query] of [
  ['T2 RU insertion', 'Не хочу идти в кафе; хочу прогуляться на природе.'],
  ['T2 EN insertion', 'I do not want to go to cafes, only a park please.'],
  ['T2 KK insertion', 'Кофе ішуге барғым келмейді, табиғат аясында серуендегім келеді.'],
  ['T2 postposed RU negative', 'Хочу парк, кофе не предлагайте.'],
  ['T2 postposed mixed language negative', 'Хочу парк, coffee не предлагайте.'],
] as const) test(name, () => {
  assert.deepEqual(inferExcludedInterests(query), ['cafe']);
  assert.deepEqual(inferInterests(query, ['cafe']), ['park']);
  const result = planRoute({ ...request, query, interests: ['cafe'] }, dataset([poi('cafe'), poi('park')]));
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['park']);
});

test('T2 positive restart is not incorrectly included in the preceding negative scope', () => {
  assert.deepEqual(inferInterests('Хочу музей, не хочу кофе', ['cafe']), ['museum']);
  assert.deepEqual(inferExcludedInterests('Хочу музей, не хочу кофе'), ['cafe']);
  assert.deepEqual(inferInterests('Без кафе, только парк', ['cafe']), ['park']);
});

for (const query of ['Хочу музей.', 'A museum please.', 'Мұражайға барғым келеді.']) test(`T3 substantive museum text overrides default coffee chip: ${query}`, () => {
  assert.deepEqual(inferInterests(query, ['cafe']), ['museum']);
  const result = planRoute({ ...request, query, interests: ['cafe'] }, dataset([poi('cafe'), poi('museum')]));
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['museum']);
});

test('intent category contract is authoritative over both text and default chips', () => {
  const result = planRoute({ ...request, query: 'Coffee and a museum please', interests: ['cafe', 'museum'] }, dataset([poi('cafe'), poi('museum'), poi('park')]), {
    intent: intent({ desiredCategories: ['park'] }),
  });
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['park']);
  assert.ok(result.trace.some((item: { step: string; detail: string }) => item.step === 'intent' && item.detail.includes('desired=park')));
});

test('intent is not silently reparsed by the legacy negative grammar', () => {
  const result = planRoute({ ...request, query: 'without cafes', interests: ['museum'] }, dataset([poi('cafe'), poi('museum')]), { intent: intent({ desiredCategories: ['cafe'] }) });
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['cafe']);
});

test('hard intent exclusions win over desired categories and POI secondary source tags', () => {
  const input = dataset([poi('cafe'), poi('park'), poi('museum', { tags: { amenity: 'cafe' } }), poi('art')]);
  const contract = intent({ desiredCategories: ['cafe', 'park', 'museum'], excludedCategories: ['cafe'], includeMode: 'all' });
  const result = planRoute({ ...request, query: 'coffee', interests: ['cafe'] }, input, { intent: contract });
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.id), ['park']);
  assert.equal(result.excluded.find((item: { reason: string }) => item.reason === 'interest-excluded')?.count, 2);
  const contradictory = planRoute(request, input, { intent: intent({ desiredCategories: ['cafe'], excludedCategories: ['cafe'] }) });
  assert.equal(contradictory.plan, null);
});

test('art, gallery and artwork map to the same supported art category', () => {
  assert.deepEqual(inferInterests('A gallery of art'), ['art']);
  const result = planRoute(request, dataset([
    poi('art', { id: 'gallery', category: 'gallery', tags: { tourism: 'gallery' } }),
    poi('art', { id: 'artwork', tags: { tourism: 'artwork' } }), poi('cafe'),
  ]), { intent: intent({ desiredCategories: ['art'] }) });
  assert.equal(result.plan?.stops.length, 1);
  assert.ok(['gallery', 'artwork'].includes(result.plan!.stops[0].poi.id));
  assert.match(result.plan!.stops[0].why, /^Art: OSM category matches your request/);
});

test('needsClarification prevents a nearby substitute and returns visible localized trace', () => {
  for (const language of ['ru', 'en', 'kk'] as const) {
    const result = planRoute({ ...request, language, interests: ['cafe'] }, dataset([poi('cafe')]), { intent: intent({ desiredCategories: ['cafe'], needsClarification: true }) });
    assert.equal(result.plan, null);
    assert.equal(result.candidates, 0);
    assert.equal(result.trace[0].step, 'intent');
    assert.ok(result.trace[0].detail.length > 30);
    assert.deepEqual(result.warnings, [result.trace[0].detail]);
  }
});

test('empty intent permits nearby retrieval but never revives text or default chips', () => {
  const input = dataset([poi('cafe'), poi('park')]);
  const result = planRoute({ ...request, query: 'museum', interests: ['museum'] }, input, { intent: intent() });
  assert.ok(result.plan);
  assert.equal(result.candidates, 2);
  const excludedOnly = planRoute(request, input, { intent: intent({ excludedCategories: ['cafe'] }) });
  assert.deepEqual(excludedOnly.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['park']);
  assert.equal(planRoute(request, input, { intent: intent({ excludedCategories: categories }) }).plan, null);
});

test('all covers feasible requested categories while preserving the complete return budget', () => {
  const result = planRoute({ ...request, minutes: 80 }, dataset([poi('museum'), poi('cafe'), poi('park')]), { intent: intent({ desiredCategories: ['museum', 'cafe', 'park'], includeMode: 'all' }) });
  assert.deepEqual(new Set(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category)), new Set(['museum', 'cafe', 'park']));
  const plan = result.plan!;
  assert.equal(plan.totalMinutes, plan.visitMinutes + plan.walkingMinutes + plan.bufferMinutes);
  assert.equal(plan.walkingMinutes, plan.returnMinutes + plan.stops.reduce((sum: number, stop: { travelMinutes: number }) => sum + stop.travelMinutes, 0));
  assert.ok(plan.totalMinutes <= 80);
});

test('all can return a truthful feasible partial plan when one requested category is unavailable', () => {
  const input = dataset([poi('cafe'), poi('museum', { openingHours: 'off' })]);
  for (const includeMode of ['all', 'any'] as const) {
    const result = planRoute(request, input, { intent: intent({ desiredCategories: ['cafe', 'museum'], includeMode }) });
    assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['cafe']);
    assert.ok(result.excluded.some((item: { reason: string }) => item.reason === 'closed-during-visit'));
  }
});

test('all never relaxes unknown hours, indoor or wheelchair requirements to cover a category', () => {
  const input = dataset([poi('museum', { openingHours: null }), poi('cafe', { indoor: true, wheelchair: 'yes' })]);
  for (const constraints of [{ knownHoursOnly: true }, { indoor: true }, { accessible: true }]) {
    const result = planRoute({ ...request, ...constraints }, input, { intent: intent({ desiredCategories: ['museum', 'cafe'], includeMode: 'all' }) });
    assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['cafe']);
  }
});

test('all retains the maximum three-stop limit with four desired categories', () => {
  const result = planRoute({ ...request, minutes: 180 }, dataset([poi('museum'), poi('cafe'), poi('park'), poi('art')]), { intent: intent({ desiredCategories: ['museum', 'cafe', 'park', 'art'], includeMode: 'all' }) });
  assert.equal(result.plan?.stops.length, 3);
  assert.equal(new Set(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category)).size, 3);
});

function coverageFixture() {
  const graph = new WalkingGraph({
    nodes: [[1, 51.128, 71.43], [2, 51.128, 71.431], [3, 51.128, 71.432], [4, 51.128, 71.44]],
    edges: [[1, 2, 140], [1, 3, 210], [1, 4, 700]],
  });
  const input = dataset([
    poi('museum', { lat: 51.128, lon: 71.431 }),
    poi('cafe', { id: 'near-cafe', name: 'Tea', lat: 51.128, lon: 71.432 }),
    poi('cafe', { id: 'far-cafe', name: 'Coffee cafe café', lat: 51.128, lon: 71.44 }),
  ]);
  return { graph, input };
}

test('all graph coverage keeps a museum instead of spending its budget on a high-score distant café', () => {
  const { graph, input } = coverageFixture();
  const current = { ...request, query: 'coffee café cafe', minutes: 55 };
  const any = planRoute(current, input, { routing: graph, intent: intent({ desiredCategories: ['cafe', 'museum'] }) });
  const all = planRoute(current, input, { routing: graph, intent: intent({ desiredCategories: ['cafe', 'museum'], includeMode: 'all' }) });
  assert.deepEqual(any.plan?.stops.map((stop: { poi: POI }) => stop.poi.id), ['far-cafe']);
  assert.deepEqual(new Set(all.plan?.stops.map((stop: { poi: POI }) => stop.poi.id)), new Set(['museum', 'near-cafe']));
  assert.equal(all.plan?.routeKind, 'walking');
  assert.ok(all.plan!.totalMinutes <= current.minutes);
  assert.ok(all.trace.some((item: { step: string; detail: string }) => item.step === 'walking-graph' && /[1-4] Dijkstra searches/.test(item.detail)));
});

test('all graph budget failure cannot be replaced by a shorter geometric estimate', () => {
  const { graph, input } = coverageFixture();
  const result = planRoute({ ...request, minutes: 30 }, input, { routing: graph, intent: intent({ desiredCategories: ['museum', 'cafe'], includeMode: 'all' }) });
  assert.equal(result.plan?.routeKind, 'walking');
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.category), ['cafe']);
  assert.ok(result.plan!.totalMinutes <= 30);
});

test('all tie-breaking is deterministic when input record order is reversed', () => {
  const records = [poi('museum', { id: 'm-b' }), poi('museum', { id: 'm-a' }), poi('cafe', { id: 'c-b' }), poi('cafe', { id: 'c-a' })];
  const contract = intent({ desiredCategories: ['museum', 'cafe'], includeMode: 'all' });
  const first = planRoute(request, dataset(records), { intent: contract });
  const second = planRoute(request, dataset([...records].reverse()), { intent: contract });
  assert.deepEqual(first.plan, second.plan);
});

test('why is localized source-derived reasoning, without unsupported quality claims', () => {
  for (const [language, label] of [['ru', 'Музей'], ['en', 'Museum'], ['kk', 'Мұражай']] as const) {
    const result = planRoute({ ...request, language }, dataset([poi('museum', { openingHours: null })]), { intent: intent({ desiredCategories: ['museum'] }) });
    const why = result.plan!.stops[0].why;
    assert.ok(why.startsWith(label));
    assert.ok(why.includes('OSM'));
    assert.ok(why.includes(`${result.plan!.totalMinutes}/${request.minutes}`));
    assert.ok(!/quiet|cheap|beautiful|тихий|дешев|красив|тыныш|арзан/i.test(why));
    assert.equal(result.plan!.stops[0].hoursStatus, 'unknown');
  }
});

test('T6 now rejects timezone-less and malformed clock offsets', () => {
  for (const now of ['2026-10-20T12:00:00', '2026-10-20T12:00', '2026-10-20', '2026-10-20T12:00:00+0500', '2026-10-20T12:00:00+25:00', '2026-10-20T12:00:00+05:99']) {
    const validated = validatePlanRequest({ ...request, now });
    assert.ok('error' in validated, now);
  }
});

test('T6 Z and explicit positive/negative offsets preserve the same actual opening instant', () => {
  const instants = ['2026-10-20T07:00:00Z', '2026-10-20T12:00:00+05:00', '2026-10-20T03:00:00-04:00'];
  const input = dataset([poi('museum', { openingHours: 'Tu 12:00-13:30' })]);
  const plans = instants.map(now => {
    const validated = validatePlanRequest({ ...request, now, knownHoursOnly: true });
    assert.ok('value' in validated, now);
    return planRoute(validated.value, input, { intent: intent({ desiredCategories: ['museum'] }) }).plan;
  });
  assert.ok(plans[0]);
  assert.equal(plans[0].stops[0].hoursStatus, 'open');
  assert.deepEqual(plans[0], plans[1]);
  assert.deepEqual(plans[1], plans[2]);
  assert.ok('value' in validatePlanRequest({ ...request, now: undefined }));
});
