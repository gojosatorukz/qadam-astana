import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import dataset from '../data/place-photos.json' with { type: 'json' };
import pois from '../data/poi.json' with { type: 'json' };
// @ts-expect-error Native Node verification uses source extensions.
import { getPlacePhoto } from '../lib/place-photos.ts';

test('reviewed photograph bytes match the checked source and retain attribution', () => {
  for (const photo of dataset.photos) {
    const bytes = readFileSync(new URL('../public' + photo.path, import.meta.url));
    assert.equal(bytes.length, photo.bytes);
    assert.equal(createHash('sha256').update(bytes).digest('hex'), photo.sha256);
    assert.equal(photo.license, 'CC BY-SA 4.0');
    assert.ok(photo.author && photo.sourceUrl.startsWith('https://commons.wikimedia.org/wiki/File:'));
    assert.ok(photo.caption.ru && photo.caption.en && photo.caption.kk && photo.identityEvidence);
  }
});
test('photographs only attach to explicit existing POI identities', () => {
  const ids = new Set<string>();
  for (const photo of dataset.photos) for (const id of photo.poiIds) {
    assert.ok(pois.pois.some(poi => poi.id === id));
    assert.equal(ids.has(id), false); ids.add(id);
    assert.equal(getPlacePhoto(id)?.id, photo.id);
  }
});
test('unknown venues do not inherit a nearby or generic photo', () => {
  assert.equal(getPlacePhoto('osm-node-unknown'), null);
  for (const poi of pois.pois.filter(p => p.category === 'food')) assert.equal(getPlacePhoto(poi.id), null);
});
