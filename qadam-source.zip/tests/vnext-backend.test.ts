import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { buildPlan } from '../lib/build-plan.ts';
// @ts-expect-error Native Node TS source extensions.
import { planRoute, validatePlanRequest } from '../lib/planner.ts';
// @ts-expect-error Native Node TS source extensions.
import { parseIsoInstant, resolvePlanTime, almatyLocalToISO } from '../lib/time-context.ts';
// @ts-expect-error Native Node TS source extensions.
import { isPlanResponse, planSemanticsValid } from '../lib/plan-validation.ts';
// @ts-expect-error Native Node TS source extensions.
import { preflightContext, POI_COVERAGE } from '../lib/planning-context.ts';
// @ts-expect-error Native Node TS source extensions.
import { interpretIntent } from '../lib/intent.ts';
// @ts-expect-error Native Node TS source extensions.
import { enrichWithGemini } from '../lib/rag.ts';
// @ts-expect-error Native Node TS source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
import type { IntentContract } from '../lib/intent-types';
import type { PlanRequest, POI } from '../lib/qadam-types';

const base:PlanRequest={query:'',origin:{lat:51.128,lon:71.43,label:'Baiterek'},minutes:90,interests:['cafe'],indoor:false,knownHoursOnly:false,accessible:false,language:'en',now:'2026-10-20T12:00:00+05:00'};
const cafe:POI={id:'one',name:'Source café',lat:51.128,lon:71.431,category:'cafe',description:'OSM café',tags:{amenity:'cafe'},openingHours:'24/7',website:null,sourceUrl:'https://www.openstreetmap.org/node/1',fetchedAt:'2026-10-19T10:00:00Z',indoor:true,wheelchair:'yes'};
const data=(pois:POI[]=[cafe])=>({pois,fetchedAt:cafe.fetchedAt,source:'OpenStreetMap'});
const contract:IntentContract={version:1,desiredCategories:['cafe'],excludedCategories:[],includeMode:'any',unsupported:[],needsClarification:false};
const interpreted:typeof interpretIntent=async()=>({mode:'gemini',contract,ms:0});
const identity:typeof enrichWithGemini=async r=>r;

for(const invalid of ['2026-02-31T12:00:00+05:00','2026-02-29T12:00:00Z','2100-02-29T12:00:00Z','2024-02-30T12:00:00Z','2026-04-31T12:00:00Z','2026-10-20T24:00:00Z','2026-10-20T12:00:00','2026-10-20T12:60:00Z'])test(`calendar rejects ${invalid}`,()=>{
 assert.equal(parseIsoInstant(invalid),null);assert.ok('error' in validatePlanRequest({...base,now:invalid}));
});
test('leap dates and UTC+5 round-trip without host timezone dependence',()=>{
 assert.equal(parseIsoInstant('2024-02-29T12:30:05+05:00')?.toISOString(),'2024-02-29T07:30:05.000Z');
 assert.equal(parseIsoInstant('2000-02-29T00:00:00Z')?.toISOString(),'2000-02-29T00:00:00.000Z');
 assert.equal(almatyLocalToISO('2026-10-20T00:15'),'2026-10-19T19:15:00.000Z');
 assert.equal(almatyLocalToISO('2026-02-31T12:00'),null);
});
test('HTTP past policy applies only to explicit custom mode; historical fixtures are retained',()=>{
 const current=new Date('2026-10-21T07:00:00Z');
 assert.deepEqual(resolvePlanTime({...base,departureMode:'custom'},current,true),{error:'past-departure'});
 assert.ok(!('error' in resolvePlanTime(base,current,true)));
 assert.equal((resolvePlanTime({...base,departureMode:'now'},current,true) as {departureAt:string}).departureAt,current.toISOString());
});
test('returnBy overrides stale minutes, floors seconds and rejects impossible windows',()=>{
 const now=new Date('2026-10-20T07:00:30Z');
 const time=resolvePlanTime({...base,departureMode:'now',returnBy:'2026-10-20T08:00:00+01:00'},now);
 assert.deepEqual(time,{error:'return-before-departure'});
 const good=resolvePlanTime({...base,departureMode:'now',returnBy:'2026-10-20T08:00:00Z'},now);
 assert.ok(!('error' in good));if(!('error' in good))assert.equal(good.effectiveMinutes,59);
 assert.deepEqual(resolvePlanTime({...base,returnBy:'2026-10-20T07:04:59Z'},new Date()),{error:'budget-expired'});
 assert.deepEqual(resolvePlanTime({...base,returnBy:'2026-10-20T15:00:00Z'},new Date()),{error:'budget-too-long'});
});
test('now deadline is refreshed after interpretation before feasibility and echoed',async()=>{
 let clock=0;const instants=[new Date('2026-10-20T07:00:00Z'),new Date('2026-10-20T07:03:45Z')];
 const r=await buildPlan({...base,query:'coffee',departureMode:'now',returnBy:'2026-10-20T07:25:00Z'},data(),{interpret:interpreted,enrich:identity,clock:()=>instants[Math.min(clock++,1)]});
 assert.equal(r.departureAt,instants[1].toISOString());assert.equal(r.effectiveMinutes,21);assert.ok(r.plan);assert.ok(r.plan.totalMinutes<=21);assert.equal(r.returnBy,'2026-10-20T07:25:00.000Z');
});
test('an expired now deadline does not return the earlier feasible plan',async()=>{
 let n=0;const r=await buildPlan({...base,query:'coffee',departureMode:'now',returnBy:'2026-10-20T07:06:00Z'},data(),{interpret:interpreted,enrich:identity,clock:()=>new Date(n++?'2026-10-20T07:02:00Z':'2026-10-20T07:00:00Z')});
 assert.equal(r.plan,null);assert.equal(r.clarification?.reason,'stale-time');assert.equal(r.diagnostics?.enrichment,'not-attempted');
});
test('Mega start conflict asks before either AI stage, preserving original request',async()=>{
 let calls=0;const request={...base,query:'Хочу погулять в парке возле Mega Silk Way, старт от Mega',language:'ru' as const};
 const before=structuredClone(request);
 const r=await buildPlan(request,data(),{interpret:async()=>{calls++;return interpreted(request);},enrich:async r=>{calls++;return r;}});
 assert.equal(calls,0);assert.equal(r.plan,null);assert.equal(r.clarification?.reason,'control-conflict');assert.equal(r.clarification?.options.length,2);
 assert.equal(r.clarification?.options[0].action,'set-origin');assert.equal(r.clarification?.options[1].origin?.lat,base.origin.lat);assert.deepEqual(request,before);
});
test('explicit confirmation permits keeping the configured start without another location conflict',async()=>{
 let calls=0;const r=await buildPlan({...base,query:'coffee near Mega, start at Mega',contextConfirmed:true},data(),{interpret:async()=>{calls++;return {mode:'gemini',contract,ms:0};},enrich:identity});
 assert.equal(calls,1);assert.ok(r.plan);assert.equal(r.clarification,undefined);
});
for(const query of ['Хочу поиграть в футбол','I want shoppings','Футбол ойнағым келеді','Хочу галерею'])test(`unsupported goal offers honest explicit actions: ${query}`,async()=>{
 const r=await buildPlan({...base,query},data(),{interpret:async()=>{throw Error('preflight must precede provider');}});
 assert.equal(r.plan,null);assert.equal(r.clarification?.reason,'unsupported-activity');assert.ok(r.clarification!.options.length>=2&&r.clarification!.options.length<=4);
 assert.ok(r.clarification?.options.some(o=>o.action==='external-search'&&o.value?.startsWith('https://')));assert.equal(r.diagnostics?.intent,'not-attempted');assert.equal(isPlanResponse(r),true);
});
test('outside snapshot clarification has covered area choices and no provider claim',async()=>{
 const r=await buildPlan({...base,origin:{lat:51.3,lon:71.7,label:'Outside'},query:'coffee'},data(),{coverageBounds:POI_COVERAGE,interpret:async()=>{throw Error('must not call');}});
 assert.equal(r.clarification?.reason,'outside-coverage');assert.equal(r.diagnostics?.coverage,'outside');assert.ok(r.clarification?.options.every(o=>o.action==='set-origin'));assert.equal(r.diagnostics?.enrichment,'not-attempted');
});
test('semantic unavailable clarification has usable manual choices excluding simple prohibitions',async()=>{
 const r=await buildPlan({...base,query:'Без кафе, хочется отдохнуть',language:'ru'},data(),{intentOptions:{apiKey:''}});
 assert.equal(r.clarification?.reason,'model-unavailable');assert.ok(r.clarification?.options.some(o=>o.action==='manual-category'));assert.ok(!r.clarification?.options.some(o=>o.value==='cafe'));assert.equal(r.plan,null);
});
test('explicit manual recovery does not call either injected provider and preserves hard filters',async()=>{
 let calls=0;const r=await buildPlan({...base,localOnly:true,indoor:true,accessible:true,knownHoursOnly:true},data([cafe,{...cafe,id:'unverified',indoor:null,lon:71.432}]),{interpret:async()=>{calls++;throw Error();},enrich:async()=>{calls++;throw Error();}});
 assert.equal(calls,0);assert.ok(r.plan);assert.equal(r.intent?.mode,'manual');assert.equal(r.diagnostics?.enrichment,'local');assert.ok(r.plan.stops.every(s=>s.poi.indoor===true&&s.poi.wheelchair==='yes'&&s.hoursStatus==='open'));
 assert.ok('error' in validatePlanRequest({...base,query:'coffee',localOnly:true}));
});
test('supported cafe plus unknown quietness remains partial without forced clarification',async()=>{
 const r=await buildPlan({...base,query:'quiet coffee'},data(),{interpret:async()=>({mode:'gemini',contract:{...contract,unsupported:[{text:'quiet',reason:'no-data'}]},ms:0}),enrich:identity});
 assert.ok(r.plan);assert.equal(r.intent?.status,'partial');assert.equal(r.clarification,undefined);
});
test('empty result truthfully says enrichment was not attempted and does not claim provider failure',async()=>{
 const r=await buildPlan({...base,localOnly:true},data([]));assert.equal(r.plan,null);assert.equal(r.diagnostics?.enrichment,'not-attempted');assert.ok(r.diagnostics?.codes.includes('no-candidates'));assert.ok(!r.warnings.some(w=>/not connected|не подключ|provider unavailable/i.test(w)));
});
test('malformed interpreter shape is rejected rather than entering the planner',async()=>{
 const r=await buildPlan({...base,query:'coffee'},data(),{interpret:(async()=>({mode:'gemini',contract:{...contract,desiredCategories:['shopping']},ms:0})) as unknown as typeof interpretIntent,enrich:identity});
 assert.equal(r.plan,null);assert.equal(r.intent?.failure,'invalid-output');assert.equal(r.clarification?.reason,'model-unavailable');
});
test('parent cancellation before request never invokes a provider',async()=>{
 const controller=new AbortController();controller.abort();let calls=0;
 await assert.rejects(buildPlan({...base,query:'coffee'},data(),{signal:controller.signal,interpret:async()=>{calls++;return interpreted(base);}}),{name:'AbortError'});assert.equal(calls,0);
});
test('parent cancellation interrupts an ignored-signal interpreter without starting enrichment',async()=>{
 const controller=new AbortController();let enrich=0;const pending=buildPlan({...base,query:'coffee'},data(),{signal:controller.signal,interpret:async()=>new Promise(()=>{}),enrich:async r=>{enrich++;return r;}});
 setTimeout(()=>controller.abort(),10);await assert.rejects(pending,{name:'AbortError'});assert.equal(enrich,0);
});
test('parent cancellation during enrichment is propagated, not converted into a fallback success',async()=>{
 const controller=new AbortController();let called=0;const pending=buildPlan({...base,query:'coffee'},data(),{signal:controller.signal,interpret:interpreted,enrich:async()=>{called++;setTimeout(()=>controller.abort(),10);return new Promise(()=>{});}});
 await assert.rejects(pending,{name:'AbortError'});assert.equal(called,1);
});
test('actual intent transport receives parent cancellation even while body parsing hangs',async()=>{
 const controller=new AbortController();let transport:AbortSignal|undefined;
 const pending=interpretIntent({...base,query:'coffee'},{apiKey:'mock',signal:controller.signal,fetcher:async(_url,options)=>{transport=options?.signal??undefined;return {ok:true,json:()=>new Promise(()=>{})} as Response;}});
 setTimeout(()=>controller.abort(),10);await assert.rejects(pending,{name:'AbortError'});assert.equal(transport?.aborted,true);
});
test('enrichment cannot replace source POIs or mutate the original plan through an injected renderer',async()=>{
 const r=await buildPlan({...base,query:'coffee'},data(),{interpret:interpreted,enrich:async response=>{response.plan!.stops[0].poi.id='fabricated';return response;}});
 assert.equal(r.plan?.stops[0].poi.id,cafe.id);assert.ok(r.diagnostics?.codes.includes('enrichment-invalid-output'));
});
test('shape and semantic guards reject malformed totals and forbidden secondary categories',()=>{
 const r=planRoute(base,data(),{intent:contract});assert.equal(isPlanResponse(r),true);assert.equal(planSemanticsValid(r,base,data(),contract),true);
 assert.equal(isPlanResponse({...r,plan:{...r.plan,totalMinutes:NaN}}),false);
 assert.equal(planSemanticsValid({...r,plan:{...r.plan!,totalMinutes:91}},base,data(),contract),false);
 assert.equal(isPlanResponse({...r,clarification:{reason:'ambiguous',question:'?',allowFreeText:true,options:[{id:'x',label:'x',action:'external-search',value:'javascript:alert(1)'},{id:'edit',label:'Edit',action:'edit-query'}]}}),false);
});
test('up to two alternatives have distinct canonical sets, numeric tradeoffs and equal hard constraints',()=>{
 const snapshot=data([cafe,{...cafe,id:'two',name:'Second café',lon:71.434},{...cafe,id:'three',name:'Unknown hours',lon:71.435,openingHours:null}]);
 const request={...base,knownHoursOnly:true,accessible:true,indoor:true};
 const r=planRoute(request,snapshot,{intent:contract,withAlternatives:true});assert.equal(r.options?.length,2);assert.equal(r.plan,r.options![0].plan);
 assert.notEqual(r.options![0].id,r.options![1].id);assert.notDeepEqual(r.options![0].plan.stops.map(s=>s.canonicalId),r.options![1].plan.stops.map(s=>s.canonicalId));
 for(const o of r.options!){assert.match(o.tradeoff,/\d+.*\d+/);assert.ok(o.plan.totalMinutes<=request.minutes);assert.ok(o.plan.returnMinutes>0);assert.ok(o.plan.stops.every(s=>s.hoursStatus==='open'&&s.poi.indoor&&s.poi.wheelchair==='yes'));}
 assert.equal(planSemanticsValid(r,request,snapshot,contract),true);
 const reordered=planRoute(request,data([...snapshot.pois].reverse()),{intent:contract,withAlternatives:true});assert.deepEqual(r.options,reordered.options);
});
test('reviewed aliases do not become two options or duplicate stops',()=>{
 const snapshot=data([cafe,{...cafe,id:'footprint',lon:71.4311}]);const r=planRoute(base,snapshot,{intent:contract,withAlternatives:true,canonicalId:()=> 'same-place'});
 assert.equal(r.candidates,1);assert.equal(r.options?.length,1);assert.equal(r.plan?.stops[0].canonicalId,'same-place');
});
test('two graph alternatives share at most four Dijkstra trees and retain graph return costs',()=>{
 const graph=new WalkingGraph({nodes:[[1,51.128,71.43],[2,51.128,71.431],[3,51.128,71.434],[4,51.129,71.431]],edges:[[1,2,100],[1,3,300],[2,4,150],[3,4,260]]});
 const snapshot=data([cafe,{...cafe,id:'two',lon:71.434}]);const r=planRoute({...base,minutes:45},snapshot,{routing:graph,intent:contract,withAlternatives:true});
 assert.equal(r.options?.length,2);assert.ok(r.options?.every(o=>o.plan.routeKind==='walking'&&o.plan.walkingMinutes===o.plan.stops.reduce((n,s)=>n+s.travelMinutes,0)+o.plan.returnMinutes));
 const detail=r.trace.find(t=>t.step==='walking-graph')!.detail;assert.match(detail,/[1-4] Dijkstra searches/);
 assert.ok(r.options![1].plan.distanceMeters>=200);assert.deepEqual(r.options![1].plan.routeCoordinates.at(-1),[base.origin.lon,base.origin.lat]);
});
test('alternatives never weaken all-category coverage merely to offer a shorter route',()=>{
 const park={...cafe,id:'park',name:'Park',category:'park',tags:{leisure:'park'},lon:71.432};const c={...contract,desiredCategories:['cafe','park'] as ['cafe','park'],includeMode:'all' as const};
 const r=planRoute({...base,minutes:90},data([cafe,{...cafe,id:'two',lon:71.435},park]),{intent:c,withAlternatives:true});
 for(const option of r.options??[])assert.deepEqual(new Set(option.plan.stops.map(s=>s.poi.category)),new Set(['park','cafe']));
});

test('visible follow-up replaces old unsupported preflight while full query and exclusions reach the model',async()=>{
 const query='Хочу футбол, без кафе\nУточнение: Нет, лучше парк';let seen='';
 const c:IntentContract={...contract,desiredCategories:['park'],excludedCategories:['cafe']};
 const park={...cafe,id:'park',category:'park',tags:{leisure:'park'}};
 const r=await buildPlan({...base,query},data([cafe,park]),{interpret:async request=>{seen=request.query;return {mode:'gemini',contract:c,ms:0};},enrich:identity});
 assert.equal(seen,query);assert.ok(r.plan);assert.equal(r.clarification,undefined);assert.ok(r.plan.stops.every(s=>s.poi.category==='park'));assert.deepEqual(r.intent?.contract?.excludedCategories,['cafe']);
});
test('free-answer context inspects the new named start instead of repeating the previous one',()=>{
 const r=preflightContext({...base,query:'start at Mega\nClarification: start at the National Museum'});
 assert.equal(r?.reason,'control-conflict');assert.equal(r?.options[0].id,'origin-museum');
});
test('explicit custom departure that becomes past during interpretation is rejected as stale',async()=>{
 let n=0;const r=await buildPlan({...base,query:'coffee',departureMode:'custom',now:'2026-10-20T07:00:02Z'},data(),{interpret:interpreted,enrich:identity,clock:()=>new Date(n++?'2026-10-20T07:00:04Z':'2026-10-20T07:00:00Z')});
 assert.equal(r.plan,null);assert.equal(r.clarification?.reason,'stale-time');assert.ok(r.diagnostics?.codes.includes('past-departure'));
});

test('production content preference picks a named feasible park over a nearby anonymous garden',()=>{
 const anonymous={...cafe,id:'anonymous',category:'park',tags:{leisure:'park'},name:'OSM garden',lon:71.4301};
 const named={...anonymous,id:'named',name:'Named park',tags:{leisure:'park',name:'Named park'},lon:71.435};
 const c={...contract,desiredCategories:['park'] as ['park']};
 const request={...base,interests:['park'],minutes:45};
 const legacy=planRoute(request,data([anonymous,named]),{intent:c});assert.equal(legacy.plan?.stops[0].poi.id,'anonymous');
 const r=planRoute(request,data([anonymous,named]),{intent:c,withAlternatives:true,retrievalQuality:p=>p.tags.name?1:0});
 assert.equal(r.plan?.stops[0].poi.id,'named');assert.ok(r.plan!.totalMinutes<=45);assert.ok(r.trace.some(t=>t.step==='source-ranking'));
});
test('content preference cannot revive a closed or hard-filtered rich record',()=>{
 const anonymous={...cafe,id:'anonymous',lon:71.4301};
 const closed={...cafe,id:'curated-closed',lon:71.431,openingHours:'off'};
 const unverified={...cafe,id:'named-unknown',lon:71.432,openingHours:null};
 const r=planRoute({...base,knownHoursOnly:true},data([anonymous,closed,unverified]),{intent:contract,retrievalQuality:p=>p.id==='anonymous'?0:2,withAlternatives:true});
 assert.equal(r.plan?.stops[0].poi.id,'anonymous');assert.equal(r.options?.length,1);
});
test('all-category coverage remains ahead of source richness in estimate search',()=>{
 const namedPark={...cafe,id:'named-park',category:'park',tags:{leisure:'park',name:'Named park'},lon:71.43};
 const anonymousCafe={...cafe,id:'anonymous-cafe',lon:71.4301};
 const c={...contract,desiredCategories:['park','cafe'] as ['park','cafe'],includeMode:'all' as const};
 const r=planRoute(base,data([namedPark,anonymousCafe]),{intent:c,retrievalQuality:p=>p.id==='named-park'?2:0});
 assert.deepEqual(new Set(r.plan?.stops.map(s=>s.poi.category)),new Set(['park','cafe']));
});
test('alternative prefers another named source over a shorter anonymous record when both fit',()=>{
 const first={...cafe,id:'named-one',tags:{amenity:'cafe',name:'One'},lon:71.431};
 const second={...cafe,id:'named-two',tags:{amenity:'cafe',name:'Two'},lon:71.435};
 const anonymous={...cafe,id:'anonymous',lon:71.4301};
 const r=planRoute({...base,minutes:45},data([anonymous,first,second]),{intent:contract,retrievalQuality:p=>p.tags.name?1:0,withAlternatives:true});
 assert.equal(r.options?.length,2);assert.ok(r.options?.every(o=>o.plan.stops[0].poi.tags.name));
 assert.notEqual(r.options![0].id,r.options![1].id);
});
test('content preference does not replace an infeasible named network path with a geometric shortcut',()=>{
 const graph=new WalkingGraph({nodes:[[1,51.128,71.43],[2,51.128,71.431],[3,51.128,71.434]],edges:[[1,2,100],[1,3,10_000]]});
 const anonymous={...cafe,id:'anonymous',lon:71.431};const named={...cafe,id:'named',lon:71.434,tags:{amenity:'cafe',name:'Named'}};
 const r=planRoute({...base,minutes:45},data([anonymous,named]),{routing:graph,intent:contract,retrievalQuality:p=>p.tags.name?2:0,withAlternatives:true});
 assert.equal(r.plan?.stops[0].poi.id,'anonymous');assert.equal(r.plan?.routeKind,'walking');assert.ok(r.excluded.some(e=>e.reason==='walking-time-budget'));
});
test('an identical-cost alternate cannot hide a later measurable named option',()=>{
 const graph=new WalkingGraph({nodes:[[1,51.128,71.43],[2,51.128,71.431],[3,51.129,71.43],[4,51.128,71.434]],edges:[[1,2,100],[1,3,100],[1,4,250]]});
 const pois=[{...cafe,id:'a',lon:71.431},{...cafe,id:'b',lat:51.129,lon:71.43},{...cafe,id:'c',lon:71.434}].map(p=>({...p,tags:{amenity:'cafe',name:p.id}}));
 const r=planRoute({...base,minutes:45},data(pois),{routing:graph,intent:contract,withAlternatives:true,retrievalQuality:()=>1});
 assert.equal(r.options?.length,2);assert.notEqual(r.options![0].plan.distanceMeters,r.options![1].plan.distanceMeters);
});

test('option labels compare walking time and stop counts use natural RU EN KK forms',()=>{
 const second={...cafe,id:'farther',lon:71.435};
 const expected={ru:['Ближе к старту','Больше прогулки'],en:['Closer to the start','A longer walk'],kk:['Бастауға жақынырақ','Ұзағырақ серуен']};
 for(const language of ['ru','en','kk'] as const){
  const r=planRoute({...base,language},data([cafe,second]),{intent:contract,withAlternatives:true});assert.equal(r.options?.length,2);
  const sorted=[...r.options!].sort((a,b)=>a.plan.walkingMinutes-b.plan.walkingMinutes);
  assert.deepEqual(sorted.map(o=>o.label),expected[language]);
  assert.match(r.options![0].tradeoff,language==='ru'?/^1 остановка ·/:language==='en'?/^1 stop ·/:/^1 аялдама ·/);
 }
 const park={...cafe,id:'park',category:'park',tags:{leisure:'park'},lon:71.432};
 const mixed={...contract,desiredCategories:['cafe','park'] as ['cafe','park'],includeMode:'all' as const};
 const r=planRoute({...base,language:'ru'},data([cafe,park]),{intent:mixed,withAlternatives:true});assert.match(r.options![0].tradeoff,/^2 остановки ·/);
 const en=planRoute({...base,language:'en'},data([cafe,park]),{intent:mixed,withAlternatives:true});assert.match(en.options![0].tradeoff,/^2 stops ·/);
});
