import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { isAbsolute } from 'node:path';
import test, { after } from 'node:test';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { buildPlan } from '../lib/build-plan.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { interpretIntent, validateIntentContract } from '../lib/intent.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { planRoute } from '../lib/planner.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { enrichWithGemini } from '../lib/rag.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
import type { IntentContract, IntentResolution, SupportedCategory } from '../lib/intent-types';
import type { POIDataset } from '../lib/planner';
import type { PlanRequest, PlanResponse, POI } from '../lib/qadam-types';
import type { RawWalkingGraph } from '../lib/walking-graph';

type GoldCase = {
  id: string; language: PlanRequest['language']; query: string;
  controls: Omit<PlanRequest, 'query' | 'language'>;
  expected: { desiredCategories: SupportedCategory[]; excludedCategories: SupportedCategory[]; includeMode: 'all' | 'any';
    unsupported: { text: string; reason: 'no-data' | 'not-supported' }[]; controlConflicts: string[] };
};
const GOLD_SHA = 'a3172fd7314c898e8fc5eb4cb56c62e0eb80fae8559619dc499744c092fc3d95';
const goldBytes = readFileSync(new URL('./fixtures/intent-gold.v1.json', import.meta.url));
const sha = (data: string | Uint8Array) => createHash('sha256').update(data).digest('hex');
assert.equal(sha(goldBytes), GOLD_SHA, 'Fixture must be the exact independent frozen gold, not a rewritten test set.');
const gold = JSON.parse(goldBytes.toString()) as { cases: GoldCase[] };
const replaySourceHashes = Object.fromEntries(['lib/build-plan.ts', 'lib/planner.ts', 'lib/intent-feedback.ts', 'lib/intent.ts', 'lib/rag.ts', 'data/poi.json', 'data/walk-graph.json'].map(path => [path, sha(readFileSync(new URL('../' + path, import.meta.url)))]));
const data = JSON.parse(readFileSync(new URL('../data/poi.json', import.meta.url), 'utf8')) as POIDataset;
const graph = new WalkingGraph(JSON.parse(readFileSync(new URL('../data/walk-graph.json', import.meta.url), 'utf8')) as RawWalkingGraph);
const sourceIds = new Set(data.pois.map(poi => poi.id));
const categories = new Set(['art', 'attraction', 'cafe', 'library', 'museum', 'park', 'playground', 'viewpoint']);
const canonical = (category: string) => category === 'gallery' ? 'art' : category;
const sorted = (values: string[]) => [...new Set(values)].sort();
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
const identityEnrich: typeof enrichWithGemini = async response => response;

// This exact mapping was fixed after the public contract added use-controls,
// before seeing new outputs. It does not change independent semantic labels.
function oracleContract(entry: GoldCase, request: PlanRequest): IntentContract {
  const conflict = entry.expected.controlConflicts.length > 0;
  const value = {
    version: 1,
    desiredCategories: entry.expected.desiredCategories,
    excludedCategories: entry.expected.excludedCategories,
    includeMode: entry.expected.includeMode,
    unsupported: entry.expected.unsupported.map(wish => ({ ...wish, reason: conflict ? 'use-controls' : wish.reason })),
    needsClarification: conflict,
  };
  const validated = validateIntentContract(value, request);
  assert.ok(validated, `Frozen oracle must satisfy the public contract: ${entry.id}`);
  return validated;
}
function sourceCategories(poi: POI): string[] {
  const values = [canonical(poi.category)];
  const sourceTags = [poi.tags.amenity, poi.tags.tourism, poi.tags.leisure];
  for (const value of sourceTags) {
    const mapped = value === 'gallery' || value === 'artwork' ? 'art' : value === 'garden' ? 'park' : value;
    if (mapped && categories.has(mapped)) values.push(mapped);
  }
  return sorted(values);
}
function assertPlanIntegrity(response: PlanResponse, request: PlanRequest, contract: IntentContract) {
  assert.ok(response.intent);
  assert.deepEqual(response.intent.contract, contract);
  const actual = new Set(response.plan?.stops.map(stop => canonical(stop.poi.category)) ?? []);
  const achieved = contract.desiredCategories.filter(category => actual.has(category));
  const unmet = contract.includeMode === 'any' && achieved.length ? [] : contract.desiredCategories.filter(category => !actual.has(category));
  assert.deepEqual(sorted(response.intent.achievedCategories), sorted(achieved));
  assert.deepEqual(sorted(response.intent.unmetCategories), sorted(unmet));
  if (contract.needsClarification) {
    assert.equal(response.plan, null);
    assert.equal(response.intent.status, 'needs-clarification');
  } else if (!response.plan) assert.equal(response.intent.status, 'empty');
  else assert.equal(response.intent.status, unmet.length || contract.unsupported.length ? 'partial' : 'matched');
  if (contract.unsupported.length) assert.notEqual(response.intent.status, 'matched', 'Unknown wishes cannot count as a completely matched query.');
  if (!response.plan) return;
  const plan = response.plan;
  assert.ok(plan.totalMinutes <= request.minutes);
  assert.equal(plan.totalMinutes, plan.walkingMinutes + plan.visitMinutes + plan.bufferMinutes);
  assert.equal(plan.walkingMinutes, plan.stops.reduce((sum, stop) => sum + stop.travelMinutes, 0) + plan.returnMinutes);
  assert.equal(plan.visitMinutes, plan.stops.reduce((sum, stop) => sum + stop.visitMinutes, 0));
  assert.deepEqual(plan.routeCoordinates[0], [request.origin.lon, request.origin.lat]);
  assert.deepEqual(plan.routeCoordinates.at(-1), [request.origin.lon, request.origin.lat]);
  assert.ok(plan.stops.length > 0 && plan.stops.length <= 3);
  assert.equal(new Set(plan.stops.map(stop => stop.poi.id)).size, plan.stops.length);
  for (const stop of plan.stops) {
    assert.ok(sourceIds.has(stop.poi.id));
    assert.ok(!sourceCategories(stop.poi).some(category => contract.excludedCategories.includes(category as SupportedCategory)), `Forbidden source category: ${stop.poi.id}`);
    if (contract.desiredCategories.length) assert.ok(contract.desiredCategories.includes(canonical(stop.poi.category) as SupportedCategory));
    assert.notEqual(stop.hoursStatus, 'closed');
    if (request.knownHoursOnly) assert.equal(stop.hoursStatus, 'open');
    if (request.indoor) assert.equal(stop.poi.indoor, true);
  }
  if (response.intent.status === 'matched') {
    if (contract.includeMode === 'all') assert.deepEqual(sorted(achieved), sorted(contract.desiredCategories));
    else if (contract.desiredCategories.length) assert.ok(achieved.length > 0);
  }
}

const recorded: { id: string; request: PlanRequest; oracleContract: IntentContract; interpretationOrigin: string; checksPassed: boolean; output: PlanResponse }[] = [];
for (const entry of gold.cases) {
  test(`integration given a validated frozen oracle contract ${entry.id} (${entry.language})`, async () => {
    const request: PlanRequest = { ...entry.controls, query: entry.query, language: entry.language };
    const before = structuredClone(request);
    const contract = oracleContract(entry, request);
    let interpretCalls = 0; let enrichCalls = 0;
    const interpret: typeof interpretIntent = async () => {
      interpretCalls++;
      // Simulated provider resolution to exercise the same production path.
      // The contract is oracle-supplied; this is NOT real Gemini parsing.
      return { mode: entry.query.trim() ? 'gemini' : 'manual', contract, ms: 0 };
    };
    const output = await buildPlan(request, data, { routing: graph, interpret,
      enrich: async response => { enrichCalls++; return response; } });
    const row = { id: entry.id, request: before, oracleContract: contract, interpretationOrigin: 'independent-gold oracle injection; no LLM call', checksPassed: false, output };
    recorded.push(row);
    assert.equal(interpretCalls, 1);
    assert.equal(enrichCalls, output.plan && output.intent?.status !== 'needs-clarification' ? 1 : 0);
    assert.equal(output.generationMode, 'retrieval');
    assertPlanIntegrity(output, request, contract);
    assert.deepEqual(request, before, 'Pipeline must not mutate controls or query.');
    // The pipeline may add feedback/trace, not change deterministic route facts.
    const direct = planRoute(request, data, { routing: graph, intent: contract });
    assert.deepEqual(output.plan, direct.plan);
    if (entry.id === 'RU04' || entry.id === 'KK04' || entry.id === 'EN04') {
      assert.deepEqual(output.intent?.contract?.desiredCategories, ['museum']);
      assert.ok(!output.plan?.stops.some(stop => stop.poi.category === 'cafe'));
    }
    row.checksPassed = true;
  });
}

const base: PlanRequest = {
  query: 'Coffee please.', origin: { lat: 51.12828, lon: 71.43055, label: 'Public preset: Bayterek' },
  minutes: 90, interests: ['museum'], indoor: false, knownHoursOnly: false, accessible: false, language: 'en', now: '2026-10-20T12:00:00+05:00',
};
const cafeContract: IntentContract = { version: 1, desiredCategories: ['cafe'], excludedCategories: [], includeMode: 'any', unsupported: [], needsClarification: false };
// Deadline tests isolate model-stage timing from full-graph CPU contention.
// The 30 oracle cases above always use the complete real POI and walking graph.
const lifecycleData: POIDataset = { ...data, pois: planRoute({ ...base, query: '', interests: ['cafe'] }, data).plan?.stops.map(stop => stop.poi) ?? [] };
assert.ok(lifecycleData.pois.length > 0, 'Use an actually feasible source café for controlled lifecycle checks.');
function intentResponse(value: IntentContract = cafeContract) { return Response.json({ candidates: [{ finishReason: 'STOP', content: { parts: [{ text: JSON.stringify(value) }] } }] }); }

test('pipeline text without a key asks for clarification and never silently becomes manual chips or lexical retrieval', async () => {
  let calls = 0; let enrichCalls = 0;
  const response = await buildPlan(base, lifecycleData, {
    intentOptions: { apiKey: '', fetcher: async () => { calls++; throw Error('must not call'); } },
    enrich: async response => { enrichCalls++; return response; } });
  assert.equal(calls, 0); assert.equal(enrichCalls, 0); assert.equal(response.plan, null);
  assert.equal(response.intent?.mode, 'unavailable'); assert.equal(response.intent?.failure, 'not-configured');
  assert.equal(response.intent?.status, 'needs-clarification');
});

test('manual empty-text chips work without any model call or credentials', async () => {
  let calls = 0;
  const fetcher: typeof fetch = async () => { calls++; throw Error('must not call'); };
  const request = { ...base, query: '  ', interests: ['cafe'] };
  const response = await buildPlan(request, lifecycleData, { intentOptions: { apiKey: '', fetcher }, generationOptions: { apiKey: '', fetcher } });
  assert.equal(calls, 0); assert.equal(response.intent?.mode, 'manual'); assert.equal(response.generationMode, 'retrieval');
  assert.ok(response.plan); assert.deepEqual(response.intent?.contract?.desiredCategories, ['cafe']);
});

test('slow intent leaves only the unspent shared budget for real bounded enrichment', async () => {
  const total = 220; const start = performance.now(); let remaining = 0; let intentCalls = 0; let generationCalls = 0;
  const response = await buildPlan(base, lifecycleData, { totalTimeoutMs: total,
    intentOptions: { apiKey: 'mock-intent-key', model: 'mock-model', fetcher: async () => { intentCalls++; await delay(40); return intentResponse(); } },
    generationOptions: { apiKey: 'mock-generation-key', model: 'mock-model', fallbackModels: [], fetcher: async () => { generationCalls++; return new Promise<Response>(() => {}); } },
    enrich: async (response, request, options) => { remaining = options?.totalTimeoutMs ?? 0; return enrichWithGemini(response, request, options); },
  });
  assert.equal(intentCalls, 1); assert.equal(generationCalls, 1);
  assert.ok(remaining > 0 && remaining < total - 25, `Expected a remaining budget, got ${remaining}`);
  assert.equal(response.intent?.mode, 'gemini'); assert.equal(response.generationMode, 'retrieval');
  assert.ok(performance.now() - start < 500);
  assert.ok(response.trace.some(item => item.step === 'gemini-unavailable'));
  assertPlanIntegrity(response, base, cafeContract);
});

test('pipeline skips the enrichment stage when slow intent has consumed its remaining budget', async () => {
  let calls = 0;
  const interpret: typeof interpretIntent = async () => { await delay(45); return { mode: 'gemini', contract: cafeContract, ms: 45 }; };
  const response = await buildPlan(base, lifecycleData, { totalTimeoutMs: 70, interpret,
    enrich: async response => { calls++; return response; } });
  assert.equal(calls, 0); assert.ok(response.plan); assert.equal(response.generationMode, 'retrieval');
  assert.ok(response.trace.some(item => item.step === 'gemini-fallback' && item.detail.includes('Shared model deadline')));
});

test('a hanging actual intent stage is bounded and cannot start enrichment or return a guessed plan', async () => {
  let enrichCalls = 0; const start = performance.now();
  const response = await buildPlan(base, lifecycleData, { totalTimeoutMs: 60,
    intentOptions: { apiKey: 'mock-key', model: 'mock-model', fetcher: async () => new Promise<Response>(() => {}) },
    enrich: async response => { enrichCalls++; return response; } });
  assert.equal(response.plan, null); assert.equal(response.intent?.mode, 'unavailable');
  assert.equal(response.intent?.failure, 'timeout'); assert.equal(response.intent?.status, 'needs-clarification');
  assert.equal(enrichCalls, 0); assert.ok(performance.now() - start < 250);
});

test('an unavailable injected resolution also produces clarification without reviving default chips', async () => {
  const unavailable: IntentResolution = { mode: 'unavailable', contract: null, failure: 'provider', ms: 0 };
  const response = await buildPlan(base, lifecycleData, { interpret: async () => unavailable, enrich: identityEnrich });
  assert.equal(response.plan, null); assert.equal(response.intent?.status, 'needs-clarification');
  assert.deepEqual(response.intent?.achievedCategories, []); assert.deepEqual(response.intent?.unmetCategories, []);
});

after(() => {
  const outputPath = process.env.QADAM_INTENT_REPLAY_OUTPUT;
  if (!outputPath) return;
  assert.ok(isAbsolute(outputPath), 'Replay evidence destination must be an explicit absolute path.');
  assert.equal(recorded.length, 30);
  const result = {
    evaluationKind: 'integration given validated independent-gold oracle contracts', generatedAt: new Date().toISOString(),
    goldSha256: GOLD_SHA, fixtureExactCopy: true, nodeVersion: process.version, sourceSha256: replaySourceHashes,
    method: 'Injected oracle IntentResolution exercises production buildPlan, feedback and planner on real OSM data/graph. Enrichment is an identity function. mode=gemini in replay outputs is SIMULATED transport metadata, not a model call.',
    cloudCalls: 0, limits: ['This is not 30-query AI-quality or language-model parsing accuracy.', 'Expected contracts were independently frozen before implementation; only the pre-fixed use-controls compatibility mapping is applied.', 'Small adversarial set; not a representative population sample.', 'Planner may honestly return partial/empty when constraints prevent category coverage.'],
    dataset: { pois: data.pois.length, graphNodes: graph.nodeCount, graphEdges: graph.edgeCount },
    summary: { cases: 30, invariantPassed: recorded.filter(row => row.checksPassed).length,
      statuses: Object.fromEntries(['matched', 'partial', 'empty', 'needs-clarification'].map(status => [status, recorded.filter(row => row.output.intent?.status === status).length])),
      invariantFailures: recorded.filter(row => !row.checksPassed).length,
      forbiddenCategoryViolations: recorded.filter(row => row.output.plan?.stops.some(stop => sourceCategories(stop.poi).some(category => row.oracleContract.excludedCategories.includes(category as SupportedCategory)))).length,
      budgetViolations: recorded.filter(row => row.output.plan && row.output.plan.totalMinutes > row.request.minutes).length,
      returnViolations: recorded.filter(row => row.output.plan && JSON.stringify(row.output.plan.routeCoordinates.at(-1)) !== JSON.stringify([row.request.origin.lon, row.request.origin.lat])).length,
      defaultChipOverrideViolations: recorded.filter(row => ['RU04', 'KK04', 'EN04'].includes(row.id) && row.output.plan?.stops.some(stop => stop.poi.category === 'cafe')).length,
      unsupportedClaimedMatched: recorded.filter(row => row.oracleContract.unsupported.length && row.output.intent?.status === 'matched').length,
      clarificationReturnedPlan: recorded.filter(row => row.oracleContract.needsClarification && row.output.plan).length },
    results: recorded,
  };
  writeFileSync(outputPath, JSON.stringify(result, null, 2) + '\n');
});
