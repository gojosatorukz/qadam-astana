import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { planRoute, validatePlanRequest, inferInterests, categoriesOf } from '../lib/planner.ts';
// @ts-expect-error Native Node TS source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
// @ts-expect-error Native Node TS source extensions.
import { buildPlan } from '../lib/build-plan.ts';
// @ts-expect-error Native Node TS source extensions.
import { planSemanticsValid, isPlanResponse } from '../lib/plan-validation.ts';
// @ts-expect-error Native Node TS source extensions.
import { manualIntent, interpretIntent, validateIntentContract } from '../lib/intent.ts';
// @ts-expect-error Native Node TS source extensions.
import { enrichWithGemini } from '../lib/rag.ts';
// @ts-expect-error Native Node TS source extensions.
import { isPlanResponse as isClientPlanResponse } from '../lib/experience.ts';
import type { PlanRequest, POI } from '../lib/qadam-types';
import type { IntentContract } from '../lib/intent-types';

const base:PlanRequest={query:'',origin:{lat:51.128,lon:71.43,label:'A'},destination:{lat:51.128,lon:71.434,label:'B'},minutes:27,interests:['food'],indoor:false,knownHoursOnly:false,accessible:false,language:'en',now:'2026-10-20T12:00:00+05:00'};
const meal:POI={id:'meal',name:'Recorded restaurant',lat:51.128,lon:71.434,category:'food',tags:{amenity:'restaurant',name:'Recorded restaurant'},description:'Source restaurant',openingHours:'24/7',sourceUrl:'https://www.openstreetmap.org/node/1',website:null,fetchedAt:'2026-10-20T00:00:00Z',indoor:true,wheelchair:'yes'};
const data=(pois:POI[]=[meal])=>({pois,fetchedAt:meal.fetchedAt,source:'OpenStreetMap'});
const graph=(meters=140)=>new WalkingGraph({nodes:[[1,51.128,71.43],[2,51.128,71.432],[3,51.128,71.434]],edges:[[1,2,meters],[2,3,meters]]});
const food:IntentContract={version:1,desiredCategories:['food'],excludedCategories:[],includeMode:'any',unsupported:[],needsClarification:false};

for(const destination of [null,[],{lat:NaN,lon:71.4},{lat:51.1,lon:80},{lat:51.1,lon:71.4,label:10},{lat:51.1,lon:71.4,label:'x'.repeat(201)}])test(`destination rejects malformed or outside-city ${JSON.stringify(destination)}`,()=>assert.ok('error' in validatePlanRequest({...base,destination})));
test('validated B survives without accepting arbitrary destination properties',()=>{
 const validated=validatePlanRequest({...base,destination:{...base.destination,unexpected:'ignored'}});assert.ok('value' in validated);
 if('value' in validated)assert.deepEqual(validated.value.destination,base.destination);
});
test('one-way meal fits when the mandatory round trip would not',()=>{
 const one=planRoute(base,data(),{routing:graph(),intent:food,withAlternatives:true});
 assert.ok(one.plan);assert.equal(one.plan.routeMode,'one-way');assert.deepEqual(one.plan.destination,base.destination);
 assert.equal(one.plan.walkingMinutes,4);assert.equal(one.plan.returnMinutes,0);assert.equal(one.plan.visitMinutes,20);assert.equal(one.plan.totalMinutes,27);
 assert.deepEqual(one.plan.routeCoordinates[0],[base.origin.lon,base.origin.lat]);assert.deepEqual(one.plan.routeCoordinates.at(-1),[base.destination!.lon,base.destination!.lat]);
 assert.ok(planSemanticsValid(one,base,data(),food));assert.equal(planRoute({...base,destination:undefined},data(),{routing:graph(),intent:food}).plan,null);
});
test('final leg is B distance, never the reverse A distance',()=>{
 const input=data([{...meal,lon:71.432}]);const result=planRoute({...base,minutes:40},input,{routing:graph(),intent:food});
 assert.equal(result.plan?.returnMinutes,2);assert.equal(result.plan?.distanceMeters,280);assert.equal(result.plan?.walkingMinutes,4);assert.ok(result.plan?.summary.includes('B'));
});
test('final semantic boundary rejects an otherwise valid route ending back at A',()=>{
 const result=planRoute(base,data(),{routing:graph(),intent:food});assert.ok(planSemanticsValid(result,base,data(),food));
 result.plan!.routeCoordinates[result.plan!.routeCoordinates.length-1]=[base.origin.lon,base.origin.lat];assert.equal(planSemanticsValid(result,base,data(),food),false);
});
test('A→B shortest path exceeding budget cannot become a shorter estimate',()=>{
 const result=planRoute({...base,minutes:30},data(),{routing:graph(1400),intent:food});
 assert.equal(result.plan,null);assert.equal(result.directRoute?.routeKind,'walking');assert.equal(result.directRoute?.feasible,false);assert.equal(result.directRoute?.minutes,40);assert.equal(result.directRoute?.minimumMinutes,43);
});
test('direct A→B remains actionable without claiming a restaurant was found',()=>{
 const result=planRoute(base,data([]),{routing:graph(),intent:food});assert.equal(result.plan,null);assert.ok(result.directRoute?.feasible);assert.equal(result.directRoute?.minutes,4);assert.equal(result.directRoute?.minimumMinutes,7);assert.ok(isPlanResponse(result));
});
test('known disconnected B never produces a fictitious geometric journey',()=>{
 const disconnected=new WalkingGraph({nodes:[[1,51.128,71.43],[2,51.128,71.432],[3,51.14,71.45],[4,51.14,71.452]],edges:[[1,2,140],[3,4,140]]});
 const result=planRoute({...base,destination:{lat:51.14,lon:71.45,label:'Disconnected B'},minutes:180},data([{...meal,lon:71.432}]),{routing:disconnected,intent:food});
 assert.equal(result.plan,null);assert.equal(result.directRoute,undefined);assert.ok(result.warnings.some(w=>w.includes('disconnected')));
});
test('missing B coverage uses an explicitly labelled estimate ending at B',()=>{
 const current={...base,destination:{lat:51.14,lon:71.45,label:'Missing network'},minutes:180};const result=planRoute(current,data(),{routing:graph(),intent:food});
 assert.equal(result.plan?.routeKind,'estimate');assert.equal(result.directRoute?.routeKind,'estimate');assert.deepEqual(result.plan?.routeCoordinates.at(-1),[71.45,51.14]);assert.ok(planSemanticsValid(result,current,data(),food));
});
test('food never relabels a café as a restaurant or claims a menu',()=>{
 assert.deepEqual(categoriesOf({...meal,category:'cafe',tags:{amenity:'cafe'}}),['cafe']);
 for(const amenity of ['restaurant','fast_food','food_court'])assert.deepEqual(categoriesOf({...meal,category:amenity,tags:{amenity}}),['food']);
 const result=planRoute(base,data([{...meal,category:'cafe',tags:{amenity:'cafe'}}]),{intent:food});assert.equal(result.plan,null);
});
test('meal verbs and manual recovery share one closed food category',()=>{
 for(const query of ['покушать','поесть','обед','тамақ ішу','eat','lunch'])assert.deepEqual(inferInterests(query),['food']);
 assert.deepEqual(manualIntent(base).desiredCategories,['food']);assert.deepEqual(validateIntentContract(food,{...base,query:'покушать'}),food);
});
test('clear food interpretation plus meal data exits clarification instead of asking again',async()=>{
 const result=await buildPlan({...base,query:'покушать'},data(),{routing:graph(),interpret:async()=>({mode:'gemini',contract:food,ms:0}),enrich:async r=>r});
 assert.ok(result.plan);assert.equal(result.clarification,undefined);assert.equal(result.intent?.status,'matched');assert.equal(result.plan.stops[0].poi.category,'food');assert.ok(result.plan.stops[0].activity.includes('meal'));
});
test('food semantic call has a bounded schema and explicit clear-meal instruction',async()=>{
 let calls=0;const result=await interpretIntent({...base,query:'покушать'}, {apiKey:'test-key',fetcher:async(_url,init)=>{
  calls++;const body=JSON.parse(String(init?.body));assert.ok(body.systemInstruction.parts[0].text.includes('покушать'));assert.ok(body.generationConfig.responseJsonSchema.properties.desiredCategories.items.enum.includes('food'));assert.equal(body.generationConfig.responseJsonSchema.properties.desiredCategories.maxItems,9);
  return Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(food)}]}}]});
 }});assert.equal(calls,1);assert.equal(result.contract?.needsClarification,false);
});
test('meal renderer uses meal activity and preserves A→B summary and destination budget',async()=>{
 const input=planRoute(base,data(),{routing:graph(),intent:food});input.intent={mode:'gemini',ms:0,contract:food,status:'matched',achievedCategories:['food'],unmetCategories:[]};
 const result=await enrichWithGemini(input,base,{apiKey:'test-key',fetcher:async()=>Response.json({candidates:[{content:{parts:[{text:JSON.stringify({summaryKey:'short-round-trip',stops:[{id:'meal',reasonKeys:['category-match','time-budget'],activityKey:'meal-break'}]})}]}}]})});
 assert.equal(result.generationMode,'gemini');assert.equal(result.plan?.summary,input.plan?.summary);assert.ok(result.plan?.stops[0].why.includes('destination'));assert.ok(result.plan?.stops[0].activity.includes('meal'));assert.ok(!result.plan?.stops[0].activity.includes('coffee'));
});
test('four distinct meal choices independently reach B within budget using two cached trees',()=>{
 const nodes=[[1,51.128,71.43],[2,51.128,71.44],...Array.from({length:6},(_,i)=>[i+3,51.129+i*0.001,71.432])];
 const routing=new WalkingGraph({nodes,edges:[[1,2,700],...Array.from({length:6},(_,i)=>[1,i+3,(i+1)*100])]});
 const snapshot=data(Array.from({length:6},(_,i)=>({...meal,id:`meal-${i}`,name:`Recorded restaurant ${i}`,lat:51.129+i*0.001,lon:71.432})));
 const current={...base,destination:{lat:51.128,lon:71.44,label:'B'},minutes:70};
 const result=planRoute(current,snapshot,{routing,intent:food,withAlternatives:true});
 assert.equal(result.options?.length,4);assert.equal(isClientPlanResponse(result),true);assert.equal(new Set(result.options.map(o=>o.id)).size,4);assert.equal(planSemanticsValid(result,current,snapshot,food),true);
 for(const option of result.options){assert.deepEqual(option.plan.routeCoordinates.at(-1),[71.44,51.128]);assert.ok(option.plan.totalMinutes<=70);assert.equal(option.plan.walkingMinutes,option.plan.stops.reduce((n,s)=>n+s.travelMinutes,0)+option.plan.returnMinutes);}
 assert.ok(result.trace.find(t=>t.step==='walking-graph')?.detail.includes('2 Dijkstra searches'));
});
test('multi-category route keeps both endpoints with no more than five bounded searches',()=>{
 const nodes=Array.from({length:6},(_,i)=>[i+1,51.128,71.43+i*0.002]);const routing=new WalkingGraph({nodes,edges:Array.from({length:5},(_,i)=>[i+1,i+2,140])});
 const snapshot=data([{...meal,lon:71.432},{...meal,id:'park',category:'park',tags:{leisure:'park'},lon:71.436},{...meal,id:'coffee',category:'cafe',tags:{amenity:'cafe'},lon:71.438}]);
 const current={...base,destination:{lat:51.128,lon:71.44,label:'B'},minutes:120};const wanted={...food,desiredCategories:['food','park','cafe'] as ['food','park','cafe'],includeMode:'all' as const};
 const result=planRoute(current,snapshot,{routing,intent:wanted,withAlternatives:true});assert.equal(result.plan?.stops.length,3);assert.ok(planSemanticsValid(result,current,snapshot,wanted));
 const searches=Number(result.trace.find(t=>t.step==='walking-graph')?.detail.match(/(\d+) Dijkstra/)?.[1]);assert.ok(searches<=5);
});
test('final expiry validation retires every A→B option after slow enrichment',async()=>{
 let ms=Date.parse('2026-10-20T07:00:00Z');const current={...base,departureMode:'custom' as const,now:'2026-10-20T07:00:01Z',minutes:40};
 const result=await buildPlan(current,data([meal,{...meal,id:'second',lon:71.432}]),{routing:graph(),clock:()=>new Date(ms),enrich:async r=>{ms+=2000;return r;}});
 assert.equal(result.plan,null);assert.deepEqual(result.options,[]);assert.equal(result.clarification?.reason,'stale-time');
});
test('wire guards reject a fifth option and malformed direct-route coordinates',()=>{
 const result=planRoute(base,data(),{routing:graph(),intent:food,withAlternatives:true});
 assert.equal(isPlanResponse({...result,options:Array.from({length:5},(_,i)=>({...result.options![0],id:String(i)}))}),false);
 assert.equal(isPlanResponse({...result,directRoute:{...result.directRoute,routeCoordinates:[[NaN,51],[71,51]]}}),false);
 assert.equal(isClientPlanResponse({...result,options:Array.from({length:5},(_,i)=>({...result.options![0],id:String(i)}))}),false);
 assert.equal(isClientPlanResponse({...result,directRoute:{...result.directRoute,routeCoordinates:[[NaN,51],[71,51]]}}),false);
});
