import { test } from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Native Node verification uses explicit source extensions.
import { preflightContext, POI_COVERAGE } from '../lib/planning-context.ts';
// @ts-expect-error Native Node verification uses explicit source extensions.
import { isAstanaCoordinate, hasExpiredCustomDeparture } from '../lib/experience.ts';
import type { PlanRequest, PlanResponse } from '../lib/qadam-types';

const request = (query: string, language: PlanRequest['language'] = 'ru'): PlanRequest => ({
  query, language, origin: { lat: 51.12828, lon: 71.43055, label: 'Байтерек' },
  minutes: 90, interests: [], indoor: false, accessible: false, knownHoursOnly: false,
  now: '2026-10-20T07:00:00.000Z', departureMode: 'custom',
});
test('unknown explicit text starts ask for a point before planning in RU/KK/EN', () => {
  for (const [query, language] of [
    ['Старт от Ботсада, хочу парк без кафе', 'ru'],
    ['Старт от Ботсада, хочу Национальный музей', 'ru'],
    ['Start from Botanical Garden, a park without cafes', 'en'],
    ['Ботсадтан бастаймын, кафе емес саябақ', 'kk'],
  ] as const) {
    const question = preflightContext(request(query, language), POI_COVERAGE);
    assert.equal(question?.reason, 'control-conflict');
    assert.ok(question?.options.some(option => option.id === 'edit-origin'));
    assert.deepEqual(question?.options.find(option => option.id === 'keep-origin')?.origin, request(query).origin);
  }
});
test('a deliberately confirmed custom start does not loop into text reconciliation', () => {
  const r = { ...request('Старт от Ботсада, хочу парк без кафе'), origin: { lat: 51.1061652, lon: 71.4165705, label: 'Ботанический сад' }, contextConfirmed: true };
  assert.equal(preflightContext(r, POI_COVERAGE), undefined);
});
test('the same known text start does not require unnecessary confirmation', () => {
  assert.equal(preflightContext(request('Старт от Байтерека, хочу парк без кафе'), POI_COVERAGE), undefined);
});
test('all start entry paths can reject distant, swapped or nonfinite points', () => {
  assert.ok(isAstanaCoordinate({ lat: 51.1061652, lon: 71.4165705 }));
  for (const point of [{ lat: 52, lon: 71.4 }, { lat: 71.4, lon: 51.1 }, { lat: NaN, lon: 71.4 }, { lat: 51.1, lon: Infinity }]) assert.equal(isAstanaCoordinate(point), false);
});
test('a custom itinerary retires when its departure passes, preserving now refresh semantics', () => {
  const response = { plan: { stops: [] }, departureAt: '2026-10-20T07:00:00.000Z' } as unknown as PlanResponse;
  assert.equal(hasExpiredCustomDeparture(response, 'custom', Date.parse('2026-10-20T06:59:59.999Z')), false);
  assert.equal(hasExpiredCustomDeparture(response, 'custom', Date.parse('2026-10-20T07:00:00.001Z')), true);
  assert.equal(hasExpiredCustomDeparture(response, 'now', Date.parse('2026-10-20T07:00:00.001Z')), false);
  assert.equal(hasExpiredCustomDeparture({ ...response, plan: null }, 'custom', Date.parse('2026-10-20T07:00:00.001Z')), false);
});
