import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS source extensions.
import { appendClarificationQuery, MAX_QUERY_LENGTH, MAX_CLARIFICATION_LENGTH, MAX_PLAN_REQUEST_BYTES } from '../lib/query-policy.ts';
// @ts-expect-error Native Node TS source extensions.
import { validatePlanRequest } from '../lib/planner.ts';
// @ts-expect-error Native Node TS source extensions.
import { validateIntentContract } from '../lib/intent.ts';
// @ts-expect-error Native Node TS source extensions.
import { buildPlan } from '../lib/build-plan.ts';
// @ts-expect-error Native Node TS source extensions.
import { isPlanResponse } from '../lib/plan-validation.ts';
import type { IntentContract } from '../lib/intent-types';
import type { PlanRequest, POI } from '../lib/qadam-types';

const base: PlanRequest = {
  query: 'coffee', origin: { lat: 51.128, lon: 71.43, label: 'Public test start' }, minutes: 90,
  interests: ['cafe'], indoor: false, knownHoursOnly: false, accessible: false, language: 'en',
  now: '2026-10-20T12:00:00+05:00',
};
const cafe: POI = {
  id: 'cafe', name: 'Source café', lat: 51.128, lon: 71.431, category: 'cafe', description: 'OSM café',
  tags: { amenity: 'cafe' }, openingHours: '24/7', website: null,
  sourceUrl: 'https://www.openstreetmap.org/node/1', fetchedAt: '2026-10-19T10:00:00Z',
  indoor: true, wheelchair: 'yes',
};
const park: POI = { ...cafe, id: 'park', category: 'park', name: 'Source park', tags: { leisure: 'park' }, sourceUrl: 'https://www.openstreetmap.org/node/2' };
const data = (pois: POI[] = [cafe]) => ({ pois, fetchedAt: cafe.fetchedAt, source: 'OpenStreetMap' });
const contract: IntentContract = { version: 1, desiredCategories: ['cafe'], excludedCategories: [], includeMode: 'any', unsupported: [], needsClarification: false };

test('F1: a previously valid 1000-character wish plus a 500-character answer remains a valid complete dialog', () => {
  const query = 'Без кафе. ' + 'а'.repeat(1000 - 'Без кафе. '.length);
  const answer = 'Парк. ' + 'б'.repeat(MAX_CLARIFICATION_LENGTH - 'Парк. '.length);
  const result = appendClarificationQuery(query, answer, 'ru');
  assert.ok('query' in result);
  assert.equal(result.query, `${query}\nУточнение: ${answer}`);
  assert.ok('value' in validatePlanRequest({ ...base, query: result.query }));
  assert.match(result.query, /^Без кафе\./);
});

for (const [language, marker] of [['ru', 'Уточнение: '], ['en', 'Clarification: '], ['kk', 'Нақтылау: ']] as const) {
  test(`F1: ${language} dialog boundary accepts exactly the limit and rejects overflow without discarding previous text`, () => {
    const query = 'x'.repeat(MAX_QUERY_LENGTH - marker.length - 2);
    const valid = appendClarificationQuery(query, 'y', language);
    assert.ok('query' in valid);
    assert.equal(valid.query.length, MAX_QUERY_LENGTH);
    assert.ok('value' in validatePlanRequest({ ...base, query: valid.query }));
    assert.deepEqual(appendClarificationQuery(query + 'x', 'y', language), { error: 'query-too-long' });
    assert.deepEqual(appendClarificationQuery(query, 'y'.repeat(MAX_CLARIFICATION_LENGTH + 1), language), { error: 'answer-too-long' });
    assert.deepEqual(appendClarificationQuery(query, '  ', language), { error: 'empty' });
    assert.ok('error' in validatePlanRequest({ ...base, query: 'x'.repeat(MAX_QUERY_LENGTH + 1) }));
  });
}

test('F1: the HTTP byte ceiling covers maximum valid dialog and context even with six-byte JSON character escaping', () => {
  const request = { ...base, query: '\u0000'.repeat(MAX_QUERY_LENGTH), origin: { ...base.origin, label: '\u0000'.repeat(200) }, interests: Array(10).fill('\u0000'.repeat(40)) };
  assert.ok('value' in validatePlanRequest(request));
  assert.ok(new TextEncoder().encode(JSON.stringify(request)).byteLength <= MAX_PLAN_REQUEST_BYTES);
});

test('F2: custom departure expiring during enrichment returns a useful stale-time clarification and preserves hard intent', async () => {
  let current = new Date('2026-10-20T07:00:00Z'), intentCalls = 0, enrichmentCalls = 0;
  const input = { ...base, query: 'park without cafes', departureMode: 'custom' as const, now: '2026-10-20T07:00:01Z', returnBy: '2026-10-20T07:45:01Z', indoor: false };
  const original = structuredClone(input);
  const applied: IntentContract = { ...contract, desiredCategories: ['park'], excludedCategories: ['cafe'] };
  const result = await buildPlan(input, data([park, cafe]), {
    clock: () => current,
    interpret: async () => { intentCalls++; return { mode: 'gemini', contract: applied, ms: 0 }; },
    enrich: async response => { enrichmentCalls++; current = new Date('2026-10-20T07:00:11Z'); return response; },
  });
  assert.equal(intentCalls, 1); assert.equal(enrichmentCalls, 1);
  assert.equal(result.plan, null); assert.deepEqual(result.options, []);
  assert.equal(result.clarification?.reason, 'stale-time');
  assert.ok(result.clarification?.options.some(option => option.id === 'edit-time'));
  assert.ok(result.diagnostics?.codes.includes('past-departure'));
  assert.equal(result.diagnostics?.intent, 'gemini');
  assert.deepEqual(result.intent?.contract?.excludedCategories, ['cafe']);
  assert.deepEqual(result.intent?.achievedCategories, []);
  assert.equal(result.returnBy, '2026-10-20T07:45:01.000Z');
  assert.equal(result.planComputedAt, current.toISOString());
  assert.equal(isPlanResponse(result), true);
  assert.deepEqual(input, original);
});

test('F2: a custom departure still in the future remains fixed after enrichment', async () => {
  let current = new Date('2026-10-20T07:00:00Z');
  const result = await buildPlan({ ...base, departureMode: 'custom', now: '2026-10-20T07:00:15Z', returnBy: '2026-10-20T07:45:15Z' }, data(), {
    clock: () => current, interpret: async () => ({ mode: 'gemini', contract, ms: 0 }),
    enrich: async response => { current = new Date('2026-10-20T07:00:11Z'); return response; },
  });
  assert.ok(result.plan); assert.equal(result.clarification, undefined);
  assert.equal(result.departureAt, '2026-10-20T07:00:15.000Z');
  assert.equal(result.effectiveMinutes, 45);
  assert.equal(result.planComputedAt, current.toISOString());
});

test('F2: now returnBy expiring during failed enrichment cannot become a fallback plan', async () => {
  let current = new Date('2026-10-20T07:00:00Z'), calls = 0;
  const result = await buildPlan({ ...base, departureMode: 'now', returnBy: '2026-10-20T07:35:00Z' }, data(), {
    clock: () => current, interpret: async () => ({ mode: 'gemini', contract, ms: 0 }),
    enrich: async () => { calls++; current = new Date('2026-10-20T07:31:00Z'); throw new Error('mock transport failure'); },
  });
  assert.equal(calls, 1); assert.equal(result.plan, null);
  assert.equal(result.clarification?.reason, 'stale-time');
  assert.ok(result.diagnostics?.codes.includes('budget-expired'));
  assert.ok(result.diagnostics?.codes.includes('enrichment-unavailable'));
  assert.equal(result.diagnostics?.enrichment, 'unavailable');
});

test('F2: final now departure and return budget remain consistent across Almaty midnight without another provider call', async () => {
  let current = new Date('2026-10-20T18:59:45Z'), calls = 0;
  const result = await buildPlan({ ...base, departureMode: 'now', returnBy: '2026-10-21T00:45:00+05:00' }, data(), {
    clock: () => current, interpret: async () => ({ mode: 'gemini', contract, ms: 0 }),
    enrich: async response => { calls++; current = new Date('2026-10-20T19:00:11Z'); return response; },
  });
  assert.equal(calls, 1); assert.ok(result.plan);
  assert.equal(result.departureAt, '2026-10-20T19:00:11.000Z');
  assert.equal(result.returnBy, '2026-10-20T19:45:00.000Z');
  assert.equal(result.effectiveMinutes, 44);
  for (const option of result.options ?? []) assert.ok(option.plan.totalMinutes <= 44);
});

test('F2: a now itinerary whose opening-hours constraint changes during enrichment is not returned as current', async () => {
  let current = new Date('2026-10-20T18:20:00Z');
  const result = await buildPlan({ ...base, departureMode: 'now', knownHoursOnly: true }, data([{ ...cafe, openingHours: 'Tu 23:00-23:55' }]), {
    clock: () => current, interpret: async () => ({ mode: 'gemini', contract, ms: 0 }),
    enrich: async response => { current = new Date('2026-10-20T18:50:00Z'); return response; },
  });
  assert.equal(result.plan, null); assert.equal(result.clarification?.reason, 'stale-time');
  assert.ok(result.diagnostics?.codes.includes('time-context-changed'));
});

for (const [language, query, quotes] of [
  ['ru', 'Хочу парк, без кафе', ['без кафе']],
  ['en', 'A park, without cafes', ['without cafes']],
  ['kk', 'Кофе емес, prk керек, без кафе', ['Кофе емес', 'без кафе']],
] as const) {
  test(`F3: ${language} consistency fixture does not call an applied category exclusion unsupported`, async () => {
    const input = { ...base, query, language };
    const applied: IntentContract = { ...contract, desiredCategories: ['park'], excludedCategories: ['cafe'], unsupported: quotes.map(text => ({ text, reason: 'not-supported' })) };
    const original = structuredClone(applied);
    const result = await buildPlan(input, data([cafe, park]), {
      interpret: async () => ({ mode: 'gemini', contract: applied, ms: 0 }), enrich: async response => response,
    });
    assert.ok(result.plan); assert.equal(result.intent?.status, 'matched');
    assert.deepEqual(result.intent?.contract?.unsupported, []);
    assert.deepEqual(result.intent?.contract?.excludedCategories, ['cafe']);
    for (const option of result.options ?? []) assert.ok(option.plan.stops.every(stop => stop.poi.category !== 'cafe'));
    assert.deepEqual(applied, original);
  });
}

test('F3: true no-data wishes, mixed clauses and unresolved controls are never erased by exclusion consistency', () => {
  const input = { ...base, query: 'Без кафе с розетками, хочу тихий недорогой парк, только в помещении' };
  const unsupported: IntentContract['unsupported'] = [
    { text: 'Без кафе с розетками', reason: 'not-supported' },
    { text: 'розетками', reason: 'no-data' }, { text: 'тихий', reason: 'no-data' },
    { text: 'недорогой', reason: 'no-data' }, { text: 'только в помещении', reason: 'use-controls' },
  ];
  const result = validateIntentContract({ ...contract, desiredCategories: ['park'], excludedCategories: ['cafe'], unsupported, needsClarification: true }, input);
  assert.deepEqual(result?.unsupported, unsupported);
  assert.equal(result?.needsClarification, true);
  const unapplied = validateIntentContract({ ...contract, desiredCategories: ['park'], unsupported: [{ text: 'Без кафе', reason: 'not-supported' }] }, input);
  assert.deepEqual(unapplied?.unsupported, [{ text: 'Без кафе', reason: 'not-supported' }]);
});
