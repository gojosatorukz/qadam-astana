import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { haversineMeters, inferInterests, openingHoursStatus, planRoute, validatePlanRequest } from '../lib/planner.ts';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { WalkingGraph } from '../lib/walking-graph.ts';
import type { PlanRequest, POI } from '../lib/qadam-types';

const request: PlanRequest = {
  query: '', origin: { lat: 51.128, lon: 71.43, label: 'Test origin' },
  minutes: 90, interests: [], indoor: false, knownHoursOnly: false,
  accessible: false, language: 'en', now: '2026-10-19T10:00:00+05:00',
};

function poi(overrides: Partial<POI> = {}): POI {
  return {
    id: 'osm:node:1', name: 'Example café', lat: 51.128, lon: 71.431,
    category: 'cafe', description: 'A café recorded in OpenStreetMap.', tags: { amenity: 'cafe' },
    openingHours: 'Mo-Su 09:00-22:00', website: null,
    sourceUrl: 'https://www.openstreetmap.org/node/1', fetchedAt: '2026-10-19T05:00:00Z',
    indoor: true, wheelchair: 'yes', ...overrides,
  };
}

function dataset(pois: POI[]) { return { pois, fetchedAt: '2026-10-19T05:00:00Z', source: 'OpenStreetMap' }; }

test('tight budget returns no impossible itinerary', () => {
  const result = planRoute({ ...request, minutes: 5 }, dataset([poi()]));
  assert.equal(result.plan, null);
  assert.ok(result.excluded.some(item => item.reason === 'time-budget'));
});

test('all totals include every leg, final return, visits and contingency', () => {
  const result = planRoute({ ...request, minutes: 45 }, dataset([poi({ lon: 71.435 })]));
  assert.ok(result.plan);
  const plan = result.plan;
  assert.ok(plan.returnMinutes > 0);
  assert.equal(plan.walkingMinutes, plan.stops.reduce((sum: number, stop: { travelMinutes: number }) => sum + stop.travelMinutes, 0) + plan.returnMinutes);
  assert.equal(plan.totalMinutes, plan.walkingMinutes + plan.visitMinutes + plan.bufferMinutes);
  assert.ok(plan.totalMinutes <= 45);
  assert.deepEqual(plan.routeCoordinates.at(-1), [request.origin.lon, request.origin.lat]);
  assert.equal(plan.routeKind, 'estimate');
});

test('an outbound-feasible stop is rejected if return makes it infeasible', () => {
  // About 9 min each way + 12 min minimum café visit + 3 min buffer.
  const result = planRoute({ ...request, minutes: 26 }, dataset([poi({ lon: 71.436 })]));
  assert.equal(result.plan, null);
});

test('unknown hours are never labelled open, and strict hours excludes them', () => {
  const input = dataset([poi({ openingHours: null })]);
  const permissive = planRoute(request, input);
  assert.equal(permissive.plan?.stops[0].hoursStatus, 'unknown');
  assert.ok(permissive.warnings.some(message => message.includes('Opening hours')));
  assert.equal(planRoute({ ...request, knownHoursOnly: true }, input).plan, null);
});

test('closed locations are excluded even when the verified-hours filter is off', () => {
  const result = planRoute(request, dataset([poi({ openingHours: 'Mo-Su 12:00-18:00' })]));
  assert.equal(result.plan, null);
  assert.ok(result.excluded.some(item => item.reason === 'closed-during-visit'));
});

test('hours checks cover the whole visit rather than just arrival', () => {
  assert.equal(openingHoursStatus('Mo-Su 09:00-10:05', new Date(request.now!), 12), 'closed');
  assert.equal(openingHoursStatus('Mo-Su 09:00-10:12', new Date(request.now!), 12), 'open');
  assert.equal(openingHoursStatus('Mo-Su 09:00-10:05,10:10-20:00', new Date(request.now!), 12), 'closed');
});

test('hours are interpreted in Almaty time, including weekends and overnight intervals', () => {
  assert.equal(openingHoursStatus('Mo-Fr 09:00-18:00', new Date('2026-10-19T05:00:00Z')), 'open');
  assert.equal(openingHoursStatus('Mo-Fr 09:00-18:00', new Date('2026-10-18T05:00:00Z')), 'closed');
  assert.equal(openingHoursStatus('Mo 20:00-02:00', new Date('2026-10-20T01:00:00+05:00')), 'open');
  assert.equal(openingHoursStatus('Mo 20:00-02:00', new Date('2026-10-20T03:00:00+05:00')), 'closed');
  assert.equal(openingHoursStatus('Mo-Su 09:00-18:00; Mo off', new Date(request.now!)), 'closed');
  assert.equal(openingHoursStatus('Mo-Su 09:00-18:00; Mo 11:00-12:00', new Date(request.now!)), 'closed');
});

test('unsupported or ambiguous hours remain unknown', () => {
  for (const value of ['PH off; Mo-Su 09:00-18:00', 'sunrise-sunset', 'by appointment', '09:99-18:00', '25:00-26:00', 'Mo-Su 09:00+']) {
    assert.equal(openingHoursStatus(value, new Date(request.now!)), 'unknown', value);
  }
});

test('indoor and accessibility filters require affirmative source metadata', () => {
  const input = dataset([
    poi({ id: 'unknown', indoor: null, wheelchair: null }),
    poi({ id: 'limited', indoor: true, wheelchair: 'limited' }),
    poi({ id: 'verified', indoor: true, wheelchair: 'designated' }),
  ]);
  const result = planRoute({ ...request, indoor: true, accessible: true }, input);
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.id), ['verified']);
});

test('retrieval infers Russian, Kazakh and English categories and respects them', () => {
  assert.deepEqual(inferInterests('Хочу кофе'), ['cafe']);
  assert.deepEqual(inferInterests('Саябақта серуен'), ['park']);
  assert.deepEqual(inferInterests('A museum near me'), ['museum']);
  const input = dataset([poi(), poi({ id: 'park', category: 'park', tags: { leisure: 'park' } })]);
  const result = planRoute({ ...request, query: 'Хочу кофе' }, input);
  assert.deepEqual(result.plan?.stops.map((stop: { poi: POI }) => stop.poi.id), ['osm:node:1']);
});

test('zero retrieval results and empty datasets return a useful null plan', () => {
  assert.equal(planRoute(request, dataset([])).plan, null);
  const result = planRoute({ ...request, interests: ['museum'] }, dataset([poi()]));
  assert.equal(result.plan, null);
  assert.equal(result.candidates, 0);
  assert.ok(result.warnings.some(message => message.includes('No feasible')));
});

test('itinerary has at most three source POIs and no fabricated or duplicate IDs', () => {
  const categories = ['cafe', 'park', 'museum', 'art', 'playground', 'viewpoint', 'library'];
  const input = dataset(Array.from({ length: 7 }, (_, index) => poi({ id: `osm:${index}`, category: categories[index], tags: {}, lon: 71.431 + index * 0.0001 })));
  const result = planRoute({ ...request, minutes: 180 }, input);
  const ids = result.plan!.stops.map((stop: { poi: POI }) => stop.poi.id);
  assert.equal(ids.length, 3);
  assert.equal(new Set(ids).size, ids.length);
  assert.ok(ids.every((id: string) => input.pois.some(item => item.id === id)));
});

test('a coffee request does not become an arbitrary three-café crawl', () => {
  const input = dataset([poi(), poi({ id: 'second-cafe', lon: 71.432 }), poi({ id: 'third-cafe', lon: 71.433 })]);
  const result = planRoute({ ...request, query: 'coffee', minutes: 180 }, input);
  assert.equal(result.plan?.stops.length, 1);
});

test('invalid coordinates, duplicated records and missing sources cannot enter the route', () => {
  const input = dataset([poi(), poi(), poi({ id: 'outside', lat: 55 }), poi({ id: 'no-source', sourceUrl: '' })]);
  const result = planRoute(request, input);
  assert.equal(result.candidates, 1);
  assert.equal(result.excluded.find(item => item.reason === 'invalid-or-duplicate')?.count, 3);
});

test('request validation rejects outside-city, excessive sizes and unsafe types', () => {
  for (const invalid of [null, [], { ...request, minutes: 1 }, { ...request, minutes: 361 }, { ...request, minutes: 5.5 }, { ...request, origin: { lat: 51.1, lon: 77 } }, { ...request, query: 'x'.repeat(1001) }, { ...request, indoor: 'true' }, { ...request, now: 'not-a-date' }, { ...request, interests: Array(11).fill('cafe') }]) {
    assert.ok('error' in validatePlanRequest(invalid));
  }
  assert.ok('value' in validatePlanRequest(request));
});

test('haversine handles coincident points and a known short northbound distance', () => {
  assert.equal(haversineMeters(request.origin, request.origin), 0);
  const meters = haversineMeters({ lat: 51.1, lon: 71.4 }, { lat: 51.101, lon: 71.4 });
  assert.ok(meters > 110 && meters < 112);
});

function graphFixture(stepEdges: number[] = []) {
  // A U-shaped path: the final node is geographically close to the origin,
  // but a barrier requires 420 m on the walking network in each direction.
  return new WalkingGraph({
    nodes: [[1, 51.128, 71.43], [2, 51.128, 71.432], [3, 51.129, 71.432], [4, 51.129, 71.43]],
    edges: [[1, 2, 140], [2, 3, 140], [3, 4, 140]], stepEdges,
    directed: false, source: 'Synthetic walking network for tests',
  });
}

test('walking network shortest paths include intermediate vertices and both directions', () => {
  const graph = graphFixture();
  const session = graph.createSession(request.origin)!;
  const target = { lat: 51.129, lon: 71.43 };
  const leg = session.leg(request.origin, target)!;
  assert.equal(leg.meters, 420);
  assert.deepEqual(leg.coordinates, [[71.43, 51.128], [71.432, 51.128], [71.432, 51.129], [71.43, 51.129]]);
  assert.equal(session.distanceBetween(target, request.origin), 420);
  assert.equal(session.searchCount, 2);
});

test('network feasibility rejects a superficially short trip when real return exceeds budget', () => {
  const input = dataset([poi({ lat: 51.129, lon: 71.43 })]);
  assert.ok(planRoute({ ...request, minutes: 22 }, input).plan);
  const routed = planRoute({ ...request, minutes: 22 }, input, { routing: graphFixture() });
  assert.equal(routed.plan, null);
  assert.ok(routed.excluded.some(item => item.reason === 'walking-time-budget'));
});

test('network plan budgets the actual round trip before selecting and drawing it', () => {
  const input = dataset([poi({ lat: 51.129, lon: 71.43 })]);
  const response = planRoute({ ...request, minutes: 40 }, input, { routing: graphFixture() });
  const plan = response.plan!;
  assert.equal(plan.routeKind, 'walking');
  assert.equal(plan.distanceMeters, 840);
  assert.equal(plan.walkingMinutes, 12);
  assert.equal(plan.returnMinutes, 6);
  assert.ok(plan.totalMinutes <= 40);
  assert.ok(plan.routeCoordinates.length > plan.stops.length + 2);
  assert.ok(response.trace.some(item => item.step === 'walking-graph' && item.detail.includes('2 Dijkstra')));
});

test('snap threshold uses explicit estimate fallback outside network coverage', () => {
  const graph = graphFixture();
  assert.equal(graph.createSession({ lat: 51.14, lon: 71.45 }), null);
  const result = planRoute({ ...request, origin: { lat: 51.14, lon: 71.45, label: 'Outside graph' } }, dataset([poi({ lat: 51.14, lon: 71.4501 })]), { routing: graph });
  assert.equal(result.plan?.routeKind, 'estimate');
  assert.ok(result.warnings.some(message => message.includes('does not cover')));
});

test('snap connectors are included and explicitly described as unverified', () => {
  const graph = graphFixture();
  const input = dataset([poi({ lat: 51.1291, lon: 71.43 })]);
  const result = planRoute(request, input, { routing: graph });
  assert.equal(result.plan?.routeKind, 'walking');
  assert.ok(result.plan!.distanceMeters > 840);
  assert.ok(result.warnings.some(message => message.includes('unverified for obstacles')));
});

test('wheelchair route avoids stair edges and never labels disconnected routes as walking', () => {
  const graph = graphFixture([1]);
  const target = { lat: 51.129, lon: 71.43 };
  assert.equal(graph.createSession(request.origin, { avoidSteps: true })!.distanceBetween(request.origin, target), null);
  const result = planRoute({ ...request, accessible: true }, dataset([poi(target)]), { routing: graph });
  assert.equal(result.plan?.routeKind, 'estimate');
});

test('graph search is bounded to origin plus three stop sources', () => {
  const graph = graphFixture();
  const session = graph.createSession(request.origin)!;
  for (const point of [{ lat: 51.128, lon: 71.432 }, { lat: 51.129, lon: 71.432 }, { lat: 51.129, lon: 71.43 }]) session.distanceBetween(point, request.origin);
  assert.equal(session.searchCount, 4);
});

test('Dijkstra chooses the lower weighted path rather than the first discovered edge', () => {
  const graph = new WalkingGraph({
    nodes: [[1, 51.128, 71.43], [2, 51.128, 71.431], [3, 51.129, 71.43]],
    edges: [[1, 3, 1000], [1, 2, 100], [2, 3, 100]],
  });
  assert.equal(graph.createSession(request.origin)!.distanceBetween(request.origin, { lat: 51.129, lon: 71.43 }), 200);
});

test('retrieval preserves category diversity despite many higher-scoring cafés', () => {
  const input = dataset([
    ...Array.from({ length: 30 }, (_, i) => poi({ id: `cafe:${i}`, lon: 71.431 + i * 0.00001 })),
    poi({ id: 'park', category: 'park', tags: { leisure: 'park' }, openingHours: null, lon: 71.4312 }),
  ]);
  const result = planRoute(request, input);
  assert.ok(result.plan?.stops.some((stop: { poi: POI }) => stop.poi.id === 'park'));
});

test('three-stop graph planning shares search trees and includes the final return path', () => {
  const input = dataset([
    poi({ id: 'cafe', lat: 51.128, lon: 71.432, category: 'cafe', tags: {} }),
    poi({ id: 'park', lat: 51.129, lon: 71.432, category: 'park', tags: {} }),
    poi({ id: 'art', lat: 51.129, lon: 71.43, category: 'art', tags: {} }),
  ]);
  const result = planRoute({ ...request, minutes: 180 }, input, { routing: graphFixture() });
  assert.equal(result.plan?.routeKind, 'walking');
  assert.equal(result.plan?.stops.length, 3);
  assert.ok(result.trace.some(item => item.step === 'walking-graph' && item.detail.includes('4 Dijkstra')));
  assert.equal(result.plan!.walkingMinutes, result.plan!.stops.reduce((sum: number, stop: { travelMinutes: number }) => sum + stop.travelMinutes, 0) + result.plan!.returnMinutes);
  assert.deepEqual(result.plan!.routeCoordinates.at(-1), [request.origin.lon, request.origin.lat]);
});

test('English substrings do not create unrelated art or mall interests', () => {
  assert.deepEqual(inferInterests('Start with a small walk'), []);
});

test('simple Russian, English and Kazakh negations exclude unwanted categories', () => {
  const input = dataset([poi(), poi({ id: 'park', category: 'park', tags: { leisure: 'park' }, lon: 71.4312 })]);
  for (const query of ['Без кафе, только парк', 'Не хочу кофе, хочу парк', 'I do not want coffee, only a park', 'Without cafes, a park please', 'Кофе керек емес, саябақ', 'Кофесіз саябақ']) {
    const response = planRoute({ ...request, query, interests: ['cafe'] }, input);
    assert.deepEqual(response.plan?.stops.map((stop: { poi: POI }) => stop.poi.id), ['park'], query);
  }
  const exclusionOnly = planRoute({ ...request, query: 'без кафе', interests: [] }, input);
  assert.ok(exclusionOnly.plan?.stops.every((stop: { poi: POI }) => stop.poi.category !== 'cafe'));
});

test('sub-minute arrival cannot overrun closing time while being labelled open', () => {
  const arrival = new Date('2026-10-19T10:00:30+05:00');
  assert.equal(openingHoursStatus('Mo-Su 09:00-10:12', arrival, 12), 'closed');
  assert.equal(openingHoursStatus('Mo-Su 09:00-10:12', arrival, 11.5), 'open');
});

test('future departure uses its explicit date and opening-hours context', () => {
  const input = dataset([poi({ openingHours: 'Mo-Su 09:00-18:00' })]);
  const night = planRoute({ ...request, knownHoursOnly: true, now: '2026-10-19T23:35:00+05:00' }, input);
  const tomorrow = planRoute({ ...request, knownHoursOnly: true, now: '2026-10-20T12:00:00+05:00' }, input);
  assert.equal(night.plan, null);
  assert.equal(tomorrow.plan?.stops[0].hoursStatus, 'open');
  assert.ok(tomorrow.plan!.totalMinutes <= request.minutes);
});

test('mixed shortlist keeps a nearby unknown-hours park behind a far 24/7 park', () => {
  const input = dataset([
    ...Array.from({ length: 30 }, (_, i) => poi({ id: `cafe:${i}`, openingHours: '24/7', lon: 71.431 + i * 0.00001 })),
    poi({ id: 'far-park', category: 'park', tags: { leisure: 'park' }, openingHours: '24/7', lon: 71.453 }),
    poi({ id: 'near-park', category: 'park', tags: { leisure: 'park' }, openingHours: null, lon: 71.4315 }),
  ]);
  const result = planRoute({ ...request, interests: ['cafe', 'park'] }, input);
  assert.ok(result.plan?.stops.some((stop: { poi: POI }) => stop.poi.id === 'near-park'));
  assert.ok(result.plan?.stops.some((stop: { poi: POI }) => stop.poi.category === 'cafe'));
});
