import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS execution requires explicit source extensions.
import { enrichWithGemini, validateGroundedGeneration } from '../lib/rag.ts';
import type { GroundedGeneration } from '../lib/rag';
import type { PlanRequest, PlanResponse, PlanStop } from '../lib/qadam-types';

const request: PlanRequest = {
  query: '', origin: { lat: 51.12828, lon: 71.43055, label: 'Private starting point' }, minutes: 45,
  interests: ['cafe'], indoor: false, knownHoursOnly: false, accessible: false, language: 'en', now: '2026-10-20T12:00:00+05:00',
};
function stop(category = 'cafe', id = 'osm:node:1'): PlanStop {
  return { poi: { id, name: 'Source place', category, lat: 51.129, lon: 71.431, description: 'Source facts.', tags: { amenity: category },
    sourceUrl: 'https://www.openstreetmap.org/node/1', fetchedAt: '2026-10-19T05:00:00Z', openingHours: null,
    website: null, indoor: null, wheelchair: null }, visitMinutes: 25, travelMinutes: 5,
    hoursStatus: 'unknown', why: 'Deterministic reason.', activity: 'Deterministic idea.' };
}
function original(): PlanResponse {
  return { plan: { title: 'Qadam', summary: 'Deterministic summary.', stops: [stop()], totalMinutes: 39,
    walkingMinutes: 10, visitMinutes: 25, bufferMinutes: 4, distanceMeters: 700, returnMinutes: 5,
    routeCoordinates: [[71.43055, 51.12828], [71.431, 51.129], [71.43055, 51.12828]], routeKind: 'walking' },
    candidates: 2, excluded: [], trace: [{ step: 'retrieve', detail: '2 records', ms: 0 }], generationMode: 'retrieval',
    warnings: ['Retrieval mode: Gemini generation is not connected.'], dataset: { count: 2, fetchedAt: '2026-10-19T05:00:00Z', source: 'OpenStreetMap' } };
}
function codes(overrides: Partial<GroundedGeneration> = {}): GroundedGeneration {
  return { summaryKey: 'short-round-trip', stops: [{ id: 'osm:node:1', reasonKeys: ['category-match', 'time-budget'], activityKey: 'coffee-break' }], ...overrides };
}
function modelResponse(value: unknown = codes()): Response {
  return Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify(value) }] } }] });
}
function mock(value: unknown = codes()): typeof fetch { return async () => modelResponse(value); }
function freeze<T>(value: T): T {
  if (value && typeof value === 'object') { Object.freeze(value); for (const child of Object.values(value)) freeze(child); }
  return value;
}
const options = { apiKey: 'test-secret', model: 'verified-primary', fallbackModels: [] as string[] };

// Migrated ID/order/immutability/retry/provider semantics from planner.test.ts,
// extended to reject plausible but unsupported prose and coded contradictions.
test('closed generation preserves exact unique IDs and order, allowing only finite code vocabulary', () => {
  const valid = codes();
  assert.equal(validateGroundedGeneration(valid, ['osm:node:1']), true);
  assert.equal(validateGroundedGeneration(valid, ['invented']), false);
  assert.equal(validateGroundedGeneration({ ...valid, stops: [valid.stops[0], valid.stops[0]] }, ['osm:node:1', 'osm:node:1']), false);
  const two = { ...valid, stops: [valid.stops[0], { ...valid.stops[0], id: 'osm:node:2' }] };
  assert.equal(validateGroundedGeneration(two, ['osm:node:2', 'osm:node:1']), false);
  for (const invalid of [null, [], { ...valid, extra: true }, { ...valid, summaryKey: 'free-entry' },
    { ...valid, stops: [{ ...valid.stops[0], why: 'Nearby.' }] },
    { ...valid, stops: [{ ...valid.stops[0], reasonKeys: ['time-budget', 'time-budget'] }] },
    { ...valid, stops: [{ ...valid.stops[0], reasonKeys: [] }] },
    { ...valid, stops: [{ ...valid.stops[0], reasonKeys: ['wheelchair-safe'] }] },
    { ...valid, stops: [{ ...valid.stops[0], activityKey: 'buy-a-ticket' }] },
    { ...valid, stops: [{ ...valid.stops[0], activityKey: '<script>bad</script>' }] }]) {
    assert.equal(validateGroundedGeneration(invalid, ['osm:node:1']), false);
  }
});

test('T5 rejects old free prose even when it contains plausible unsupported claims without digits', async () => {
  const input = original();
  const response = await enrichWithGemini(input, request, { ...options, fetcher: mock({ summary: 'Free entrance and a safe route.',
    stops: [{ id: 'osm:node:1', why: 'Open all night and wheelchair accessible.', activity: 'Idea: use the free Wi-Fi.' }] }) });
  assert.equal(response.generationMode, 'retrieval');
  assert.deepEqual(response.plan, input.plan);
  assert.ok(response.trace.some(item => item.step === 'gemini-grounding'));
  assert.ok(!JSON.stringify(response).includes('Free entrance'));
});

test('provider cannot invent, remove or duplicate selected stops while enriching', async () => {
  const input = original(); const valid = codes();
  for (const stops of [[{ ...valid.stops[0], id: 'invented' }], [], [valid.stops[0], valid.stops[0]]]) {
    const response = await enrichWithGemini(input, request, { ...options, fetcher: mock(codes({ stops })) });
    assert.equal(response.generationMode, 'retrieval');
    assert.deepEqual(response.plan, input.plan);
    assert.ok(response.trace.some(item => item.step === 'gemini-fallback'));
  }
});

test('successful coded generation modifies only rendered explanation fields and never mutates input', async () => {
  const input = freeze(original()); const req = freeze(structuredClone(request)); const before = structuredClone(input);
  const response = await enrichWithGemini(input, req, { ...options, fetcher: mock() });
  assert.equal(response.generationMode, 'gemini');
  assert.deepEqual(input, before);
  const unchangedFields = (plan: NonNullable<PlanResponse['plan']>) => Object.fromEntries(Object.entries(plan).filter(([key]) => !['summary', 'stops'].includes(key)));
  assert.deepEqual(unchangedFields(response.plan!), unchangedFields(input.plan!));
  assert.deepEqual(response.plan!.stops[0].poi, input.plan!.stops[0].poi);
  assert.equal(response.plan!.stops[0].hoursStatus, 'unknown');
  assert.equal(response.plan!.stops[0].visitMinutes, input.plan!.stops[0].visitMinutes);
  assert.equal(response.plan!.stops[0].travelMinutes, input.plan!.stops[0].travelMinutes);
  assert.match(response.plan!.stops[0].why, /39 of 45 minutes/);
  assert.match(response.plan!.stops[0].activity, /^Idea:/);
  assert.equal(response.warnings.length, 0);
});

test('model prompt gets per-stop allowed keys but no exact origin, coordinates or free-prose schema', async () => {
  type SentBody = { contents: { parts: { text: string }[] }[]; generationConfig: { responseJsonSchema: { additionalProperties: boolean; properties: { summary?: unknown; stops: { items: { additionalProperties: boolean } } } } } };
  let body: SentBody | undefined;
  await enrichWithGemini(original(), request, { ...options, fetcher: async (_url, init) => { body = JSON.parse(String(init?.body)); return modelResponse(); } });
  const supplied = JSON.parse(body!.contents[0].parts[0].text);
  assert.deepEqual(supplied.selectedPOIs[0].allowedReasonKeys, ['category-match', 'time-budget']);
  assert.deepEqual(supplied.selectedPOIs[0].allowedActivityKeys, ['coffee-break']);
  assert.equal(body!.generationConfig.responseJsonSchema.additionalProperties, false);
  assert.equal(body!.generationConfig.responseJsonSchema.properties.stops.items.additionalProperties, false);
  assert.ok(!JSON.stringify(body).includes('Private starting point'));
  assert.ok(!JSON.stringify(body).includes('71.43055'));
  assert.ok(!JSON.stringify(body).includes('test-secret'));
  assert.equal(body!.generationConfig.responseJsonSchema.properties.summary, undefined);
});

test('unknown hours cannot be turned into listed-hours reason', async () => {
  const response = await enrichWithGemini(original(), request, { ...options, fetcher: mock(codes({ stops: [{ id: 'osm:node:1', reasonKeys: ['listed-hours'], activityKey: 'coffee-break' }] })) });
  assert.equal(response.generationMode, 'retrieval');
  assert.ok(response.trace.some(item => item.step === 'gemini-grounding'));
});

test('listed-hours is allowed only with open visit status and a source schedule', async () => {
  const input = original(); input.plan!.stops[0].hoursStatus = 'open';
  const generation = codes({ stops: [{ id: 'osm:node:1', reasonKeys: ['listed-hours'], activityKey: 'coffee-break' }] });
  assert.equal((await enrichWithGemini(input, request, { ...options, fetcher: mock(generation) })).generationMode, 'retrieval');
  input.plan!.stops[0].poi.openingHours = 'Mo-Su 09:00-22:00';
  const response = await enrichWithGemini(input, request, { ...options, fetcher: mock(generation) });
  assert.equal(response.generationMode, 'gemini');
  assert.match(response.plan!.stops[0].why, /listed opening hours/);
  assert.ok(!response.plan!.stops[0].why.includes('verified open'));
});

test('free text without validated intent cannot assert category match from stale café chip', async () => {
  const response = await enrichWithGemini(original(), { ...request, query: 'I want a museum.' }, { ...options, fetcher: mock() });
  assert.equal(response.generationMode, 'retrieval');
});

test('validated requested category authorizes match; excluded or unmatched category never does', async () => {
  const input = original(); input.intent = { mode: 'gemini', contract: { version: 1, desiredCategories: ['cafe'], excludedCategories: [],
    includeMode: 'any', unsupported: [], needsClarification: false }, status: 'matched', achievedCategories: ['cafe'], unmetCategories: [], ms: 1 };
  const req = { ...request, query: 'Coffee please.' };
  assert.equal((await enrichWithGemini(input, req, { ...options, fetcher: mock() })).generationMode, 'gemini');
  input.intent.contract!.desiredCategories = ['museum'];
  assert.equal((await enrichWithGemini(input, req, { ...options, fetcher: mock() })).generationMode, 'retrieval');
  input.intent.contract!.desiredCategories = ['cafe']; input.intent.contract!.excludedCategories = ['cafe'];
  assert.equal((await enrichWithGemini(input, req, { ...options, fetcher: mock() })).generationMode, 'retrieval');
});

test('time-budget reason rejects totals outside budget or inconsistent with plan components', async () => {
  for (const total of [46, 38, NaN]) {
    const input = original(); input.plan!.totalMinutes = total;
    const response = await enrichWithGemini(input, request, { ...options, fetcher: mock() });
    assert.equal(response.generationMode, 'retrieval');
  }
});

test('activity code must match this stop category, not merely the global enum', async () => {
  const response = await enrichWithGemini(original(), request, { ...options, fetcher: mock(codes({ stops: [{ id: 'osm:node:1', reasonKeys: ['time-budget'], activityKey: 'exhibit-visit' }] })) });
  assert.equal(response.generationMode, 'retrieval');
});

test('every supported POI category receives its own bounded activity idea', async () => {
  const categories = { cafe: 'coffee-break', park: 'short-walk', art: 'look-around', attraction: 'look-around', museum: 'exhibit-visit', library: 'read-break', playground: 'play-break', viewpoint: 'view-pause' } as const;
  for (const [category, activityKey] of Object.entries(categories)) {
    const input = original(); input.plan!.stops[0] = stop(category);
    const response = await enrichWithGemini(input, { ...request, interests: [category] }, { ...options,
      fetcher: mock(codes({ stops: [{ id: 'osm:node:1', reasonKeys: ['category-match', 'time-budget'], activityKey }] })) });
    assert.equal(response.generationMode, 'gemini', category);
    assert.match(response.plan!.stops[0].activity, /^Idea:/);
    assert.ok(!/free|safe|wheelchair|Wi-Fi|price/i.test(response.plan!.stops[0].activity));
  }
});

test('mixed summary needs at least two different selected source categories', async () => {
  const input = original();
  assert.equal((await enrichWithGemini(input, request, { ...options, fetcher: mock(codes({ summaryKey: 'mixed-round-trip' })) })).generationMode, 'retrieval');
  input.plan!.stops.push(stop('park', 'osm:node:2'));
  input.plan!.stops.forEach(s => { s.visitMinutes = 15; });
  Object.assign(input.plan!, { totalMinutes: 50, walkingMinutes: 14, visitMinutes: 30, bufferMinutes: 6, returnMinutes: 4 });
  const generation = codes({ summaryKey: 'mixed-round-trip', stops: [
    { id: 'osm:node:1', reasonKeys: ['category-match', 'time-budget'], activityKey: 'coffee-break' },
    { id: 'osm:node:2', reasonKeys: ['category-match', 'time-budget'], activityKey: 'short-walk' },
  ] });
  const response = await enrichWithGemini(input, { ...request, minutes: 90, interests: ['cafe', 'park'] }, { ...options, fetcher: mock(generation) });
  assert.equal(response.generationMode, 'gemini');
  assert.match(response.plan!.summary, /different place categories/);
  input.plan!.stops[1].poi.category = 'cafe';
  generation.stops[1].activityKey = 'coffee-break';
  assert.equal((await enrichWithGemini(input, { ...request, minutes: 90 }, { ...options, fetcher: mock(generation) })).generationMode, 'retrieval');
});

test('all published explanation and activity strings are rendered in the requested language', async () => {
  for (const language of ['ru', 'kk', 'en'] as const) {
    const response = await enrichWithGemini(original(), { ...request, language }, { ...options, fetcher: mock() });
    assert.equal(response.generationMode, 'gemini');
    assert.match(response.plan!.stops[0].activity, language === 'en' ? /^Idea:/ : /^Идея:/);
    assert.match(response.plan!.summary, language === 'ru' ? /Короткий/ : language === 'kk' ? /Бастапқы/ : /round trip/);
  }
});

test('temporary Gemini HTTP 503 gets one bounded same-model retry without leaking provider error bodies or key', async () => {
  let calls = 0;
  const response = await enrichWithGemini(original(), request, { ...options, fetcher: async () => ++calls === 1 ? Response.json({ error: 'sensitive provider details test-secret' }, { status: 503 }) : modelResponse() });
  assert.equal(calls, 2); assert.equal(response.generationMode, 'gemini');
  assert.ok(response.trace.some(item => item.step === 'gemini-unavailable' && item.detail.includes('HTTP 503')));
  assert.ok(!JSON.stringify(response).includes('sensitive provider details'));
  assert.ok(!JSON.stringify(response).includes('test-secret'));
});

test('only explicitly configured fallback models replace an unavailable primary', async () => {
  const models: string[] = [];
  const response = await enrichWithGemini(original(), request, { ...options, fallbackModels: ['verified-fallback'], fetcher: async input => {
    models.push(String(input)); return models.length === 1 ? Response.json({}, { status: 429 }) : modelResponse();
  } });
  assert.equal(response.generationMode, 'gemini'); assert.equal(models.length, 2);
  assert.match(models[0], /verified-primary:generateContent$/); assert.match(models[1], /verified-fallback:generateContent$/);
});

test('nontransient provider failure is not retried and never exposes its body or thrown secret', async () => {
  let calls = 0;
  const response = await enrichWithGemini(original(), request, { ...options, fetcher: async () => { calls++; return Response.json({ error: 'test-secret' }, { status: 400 }); } });
  assert.equal(calls, 1); assert.equal(response.generationMode, 'retrieval');
  assert.ok(response.trace.some(item => item.step === 'gemini-unavailable'));
  assert.ok(!JSON.stringify(response).includes('test-secret'));
  const thrown = await enrichWithGemini(original(), request, { ...options, fetcher: async () => { throw new Error('test-secret provider-body'); } });
  assert.ok(!JSON.stringify(thrown).includes('test-secret')); assert.ok(!JSON.stringify(thrown).includes('provider-body'));
});

test('grounding failure is distinct from provider failure and never retried even with configured fallback', async () => {
  let calls = 0;
  const response = await enrichWithGemini(original(), request, { ...options, fallbackModels: ['verified-fallback'], fetcher: async () => {
    calls++; return Response.json({ candidates: [{ content: { parts: [{ text: 'not JSON' }] } }] });
  } });
  assert.equal(calls, 1); assert.equal(response.generationMode, 'retrieval');
  assert.ok(response.trace.some(item => item.step === 'gemini-grounding'));
  assert.ok(response.warnings.some(message => message.includes('source-grounding')));
});

test('real Promise.race deadline bounds a fetcher that entirely ignores AbortSignal', async () => {
  const start = performance.now();
  const response = await enrichWithGemini(original(), request, { ...options, totalTimeoutMs: 50, fetcher: async () => new Promise<Response>(() => {}) });
  assert.equal(response.generationMode, 'retrieval'); assert.ok(performance.now() - start < 250);
  assert.ok(response.trace.some(item => item.step === 'gemini-unavailable'));
});

test('deadline also bounds a response body reader that ignores AbortSignal', async () => {
  const start = performance.now();
  const response = await enrichWithGemini(original(), request, { ...options, totalTimeoutMs: 50,
    fetcher: async () => ({ ok: true, status: 200, json: () => new Promise(() => {}) }) as unknown as Response });
  assert.equal(response.generationMode, 'retrieval'); assert.ok(performance.now() - start < 250);
});

test('retry attempts share one deadline rather than resetting timeout for the second request', async () => {
  let calls = 0; const start = performance.now();
  const response = await enrichWithGemini(original(), request, { ...options, totalTimeoutMs: 80, fetcher: async () => {
    calls++;
    if (calls === 1) { await new Promise(resolve => setTimeout(resolve, 20)); return Response.json({}, { status: 503 }); }
    return new Promise<Response>(() => {});
  } });
  assert.equal(calls, 2); assert.equal(response.generationMode, 'retrieval'); assert.ok(performance.now() - start < 220);
});

test('no key, no plan, zero budget or clarification never starts a provider request', async () => {
  let calls = 0; const fetcher: typeof fetch = async () => { calls++; return modelResponse(); };
  const input = original();
  assert.equal(await enrichWithGemini(input, request, { ...options, apiKey: '', fetcher }), input);
  const empty = { ...original(), plan: null };
  assert.equal(await enrichWithGemini(empty, request, { ...options, fetcher }), empty);
  await enrichWithGemini(original(), request, { ...options, totalTimeoutMs: 0, fetcher });
  const clarify = original(); clarify.intent = { mode: 'gemini', contract: { version: 1, desiredCategories: [], excludedCategories: [], includeMode: 'any', unsupported: [], needsClarification: true }, status: 'needs-clarification', achievedCategories: [], unmetCategories: [], ms: 0 };
  assert.equal(await enrichWithGemini(clarify, request, { ...options, fetcher }), clarify);
  assert.equal(calls, 0);
});
