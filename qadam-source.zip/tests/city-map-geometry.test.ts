import assert from 'node:assert/strict';
import test from 'node:test';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { balancedViewportPOIs, coordinateAtMapPixel, fitMapPoints, isMapTap, pointOnMap, projectMapPoint, snapshotCorners, unprojectMapPoint } from '../components/city-map-geometry.ts';
import type { MapPoint, MapSize, MapView } from '../components/city-map-geometry';
const origin = { lat: 51.12828, lon: 71.43055 };
const padding = { top: 86, right: 64, bottom: 88, left: 32 };
function assertVisible(points: MapPoint[], view: MapView, size: MapSize) {
  for (const point of points) {
    const screen = pointOnMap(point, view, size);
    assert.ok(screen.x >= padding.left - .001 && screen.x <= size.width - padding.right + .001, `Clipped x=${screen.x}`);
    assert.ok(screen.y >= padding.top - .001 && screen.y <= size.height - padding.bottom + .001, `Clipped y=${screen.y}`);
  }
}
test('Mercator round trip preserves Astana coordinates and remains finite at the poles', () => {
  for (const zoom of [10, 14, 18]) {
    const p = projectMapPoint(origin, zoom), restored = unprojectMapPoint(p.x, p.y, zoom);
    assert.ok(Math.abs(restored.lat - origin.lat) < 1e-9); assert.ok(Math.abs(restored.lon - origin.lon) < 1e-9);
  }
  for (const lat of [-90, 90]) assert.ok(Number.isFinite(projectMapPoint({ lat, lon: 71.4 }, 14).y));
});
test('fit includes a far intermediate route vertex rather than only nearby stops and origin', () => {
  const geometry = [origin, { lat: 51.129, lon: 71.431 }, { lat: 51.192, lon: 71.503 }, { lat: 51.1288, lon: 71.432 }, origin];
  const size = { width: 900, height: 650 }, view = fitMapPoints(geometry, size, { padding });
  assertVisible(geometry, view, size);
  const stopsOnly = fitMapPoints([geometry[0], geometry[1], geometry[3]], size, { padding });
  assert.ok(view.zoom < stopsOnly.zoom, 'The graph detour must affect zoom.');
});
test('resize refits full geometry on a narrow mobile viewport', () => {
  const geometry = [origin, { lat: 51.16, lon: 71.49 }, { lat: 51.18, lon: 71.40 }, origin];
  const desktop = fitMapPoints(geometry, { width: 1200, height: 700 }, { padding });
  const mobileSize = { width: 390, height: 420 }, mobile = fitMapPoints(geometry, mobileSize, { padding });
  assertVisible(geometry, mobile, mobileSize); assert.ok(mobile.zoom <= desktop.zoom);
});
test('the stated POI snapshot rectangle fits without claiming graph connectivity', () => {
  const points = snapshotCorners(), size = { width: 390, height: 500 }, view = fitMapPoints(points, size, { padding });
  assert.deepEqual(points[0], { lat: 51.065, lon: 71.35 });
  assert.deepEqual(points[2], { lat: 51.205, lon: 71.515 });
  assertVisible(points, view, size); assert.ok(view.zoom >= 10);
});
test('tap coordinate matches the displayed point; dragging does not qualify as a pin tap', () => {
  const size = { width: 800, height: 600 }, view = { center: origin, zoom: 15 };
  const point = { lat: 51.13, lon: 71.435 }, screen = pointOnMap(point, view, size);
  const selected = coordinateAtMapPixel(screen.x, screen.y, view, size);
  assert.ok(Math.abs(selected.lat - point.lat) < 1e-9); assert.ok(Math.abs(selected.lon - point.lon) < 1e-9);
  assert.equal(isMapTap(3, 4), true); assert.equal(isMapTap(0, 7), true);
  assert.equal(isMapTap(0, 8), false); assert.equal(isMapTap(-6, 6), false);
});
const size = { width: 800, height: 600 }, view = { center: origin, zoom: 15 };
function poiAt(id: string, x: number, y: number, category = 'cafe', name = `Place ${id}`) { return { id, ...coordinateAtMapPixel(x, y, view, size), category, name }; }
test('viewport sampling retains rare categories after many café records and is row-order independent', () => {
  const cafes = Array.from({ length: 100 }, (_, i) => poiAt(`c${i}`, 60 + i % 10 * 68, 80 + Math.floor(i / 10) * 47));
  const park = poiAt('park-last-row', 718, 510, 'park', 'Named park');
  const input = [...cafes, park];
  const sampled = balancedViewportPOIs(input, view, size, 15);
  assert.ok(sampled.some(poi => poi.id === park.id)); assert.ok(sampled.some(poi => poi.category === 'cafe'));
  assert.ok(sampled.length <= 15);
  assert.deepEqual(sampled.map(poi => poi.id), balancedViewportPOIs([...input].reverse(), view, size, 15).map(poi => poi.id));
});
test('spatial selection spreads markers and excludes outside/invalid points', () => {
  const grid = [100, 300, 500, 700].flatMap((x, i) => [100, 300, 500].map((y, j) => poiAt(`${i}-${j}`, x, y)));
  const input = [...grid, poiAt('outside', -10, 100), { ...grid[0], id: 'invalid', lat: NaN }];
  const selected = balancedViewportPOIs(input, view, size, 8), positions = selected.map(poi => pointOnMap(poi, view, size));
  assert.equal(selected.length, 8); assert.ok(!selected.some(poi => ['outside', 'invalid'].includes(poi.id)));
  assert.ok(Math.max(...positions.map(p => p.x)) - Math.min(...positions.map(p => p.x)) > 500);
  assert.ok(Math.max(...positions.map(p => p.y)) - Math.min(...positions.map(p => p.y)) > 300);
  for (let i = 0; i < positions.length; i++) for (let j = i + 1; j < positions.length; j++) assert.ok(Math.hypot(positions[i].x - positions[j].x, positions[i].y - positions[j].y) >= 44);
});
test('same-cell discovery prefers a named record over a generated OSM label', () => {
  const generic = poiAt('generic', 200, 200, 'park', 'Парк — OSM 7'), named = poiAt('named', 205, 205, 'park', 'Сквер шахматистов');
  assert.deepEqual(balancedViewportPOIs([generic, named], view, size, 10).map(poi => poi.id), ['named']);
  assert.deepEqual(balancedViewportPOIs([named, generic], view, size, 10).map(poi => poi.id), ['named']);
});
