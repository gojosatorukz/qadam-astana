import type { PlanRequest, PlanResponse, RoutePlan } from './qadam-types';
import type { IntentContract } from './intent-types';
// @ts-expect-error Native Node TS verification uses source extensions.
import { SUPPORTED_CATEGORIES } from './intent-types.ts';
import type { POIDataset } from './planner';
// @ts-expect-error Native Node TS verification uses source extensions.
import { categoriesOf, openingHoursStatus, resolvePoiSelection } from './planner.ts';
// @ts-expect-error Native Node TS verification uses source extensions.
import { getCanonicalId } from './place-facts.ts';

const object=(v:unknown):v is Record<string,unknown>=>Boolean(v)&&typeof v==='object'&&!Array.isArray(v);
const finite=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
const string=(v:unknown):v is string=>typeof v==='string'&&v.length<=10_000;
const point=(v:unknown):boolean=>object(v)&&typeof v.lat==='number'&&Number.isFinite(v.lat)&&typeof v.lon==='number'&&Number.isFinite(v.lon)&&string(v.label);
const coordinates=(v:unknown):boolean=>Array.isArray(v)&&v.length>=2&&v.length<=200_000&&v.every(p=>Array.isArray(p)&&p.length===2&&p.every(n=>typeof n==='number'&&Number.isFinite(n)));
function planShape(v:unknown):v is RoutePlan {
 if(!object(v)||(v.destination!==undefined&&!point(v.destination))||(v.routeMode!==undefined&&!['one-way','round-trip'].includes(v.routeMode as string))||!string(v.title)||!string(v.summary)||!Array.isArray(v.stops)||v.stops.length<1||v.stops.length>3
  ||!['walking','estimate'].includes(v.routeKind as string)||!['totalMinutes','walkingMinutes','visitMinutes','bufferMinutes','distanceMeters','returnMinutes'].every(k=>finite(v[k]))
  ||!Array.isArray(v.routeCoordinates)||v.routeCoordinates.length<2||v.routeCoordinates.length>200_000
  ||!v.routeCoordinates.every(p=>Array.isArray(p)&&p.length===2&&p.every(n=>typeof n==='number'&&Number.isFinite(n))))return false;
 return v.stops.every(s=>object(s)&&object(s.poi)&&string(s.poi.id)&&string(s.poi.sourceUrl)&&finite(s.visitMinutes)&&s.visitMinutes>0&&finite(s.travelMinutes)
  &&string(s.why)&&string(s.activity)&&['open','closed','unknown'].includes(s.hoursStatus as string)
  &&(s.facts===undefined||(Array.isArray(s.facts)&&s.facts.length<=4&&s.facts.every(f=>object(f)&&['id','text','sourceUrl','checkedAt','rights'].every(k=>string(f[k]))))));
}
/** Non-throwing wire-shape guard; this is not proof of source truth. */
export function isPlanResponse(v:unknown):v is PlanResponse {
 try {
 if(!object(v)||(v.plan!==null&&!planShape(v.plan))||!finite(v.candidates)||!Array.isArray(v.excluded)
  ||!v.excluded.every(x=>object(x)&&string(x.reason)&&finite(x.count))||!Array.isArray(v.trace)
  ||!v.trace.every(x=>object(x)&&string(x.step)&&string(x.detail)&&finite(x.ms))
  ||!['gemini','retrieval'].includes(v.generationMode as string)||!Array.isArray(v.warnings)||!v.warnings.every(string)
  ||!object(v.dataset)||!finite(v.dataset.count)||!string(v.dataset.fetchedAt)||!string(v.dataset.source))return false;
 if(v.directRoute!==undefined){const d=v.directRoute;if(!object(d)||!['minutes','distanceMeters','minimumMinutes'].every(k=>finite(d[k]))||typeof d.feasible!=='boolean'||!['walking','estimate'].includes(d.routeKind as string)||!coordinates(d.routeCoordinates))return false;}
 if(v.options!==undefined&&(!Array.isArray(v.options)||v.options.length>4||!v.options.every(o=>object(o)&&string(o.id)&&string(o.label)&&string(o.tradeoff)&&planShape(o.plan))
  ||new Set(v.options.map(o=>(o as {id:string}).id)).size!==v.options.length))return false;
 if(v.clarification!==undefined){const c=v.clarification;
  if(!object(c)||!['ambiguous','control-conflict','unsupported-activity','outside-coverage','model-unavailable','invalid-time','stale-time'].includes(c.reason as string)
   ||!string(c.question)||typeof c.allowFreeText!=='boolean'||!Array.isArray(c.options)||c.options.length<2||c.options.length>5)return false;
  if(!c.options.every(o=>{if(!object(o)||!string(o.id)||!string(o.label)||!['manual-category','set-origin','external-search','retry','edit-query'].includes(o.action as string))return false;
   if(o.action==='set-origin')return object(o.origin)&&typeof o.origin.lat==='number'&&Number.isFinite(o.origin.lat)&&typeof o.origin.lon==='number'&&Number.isFinite(o.origin.lon)&&string(o.origin.label);
   if(o.action==='external-search'){try{const url=new URL(String(o.value));return url.protocol==='https:'&&!url.username&&!url.password;}catch{return false;}}
   return o.action!=='manual-category'||SUPPORTED_CATEGORIES.some(category=>category===o.value);
  })||new Set(c.options.map(o=>(o as {id:string}).id)).size!==c.options.length)return false;
 }
 return true;
 }catch{return false;}
}

/** Deterministic semantic checks at the model boundary; never accepts new POIs. */
export function planSemanticsValid(response:unknown,request:PlanRequest,dataset:POIDataset,intent:IntentContract):response is PlanResponse {
 if(!isPlanResponse(response))return false;
 const endpoint=request.destination??request.origin;
 if(response.directRoute){const d=response.directRoute,first=d.routeCoordinates[0],last=d.routeCoordinates.at(-1)!;
  const buffer=Math.max(3,Math.min(10,Math.ceil(request.minutes*0.08)));
  if(!request.destination||d.minimumMinutes!==d.minutes+buffer||d.feasible!==(d.minimumMinutes<=request.minutes)||Math.abs(first[0]-request.origin.lon)>1e-6||Math.abs(first[1]-request.origin.lat)>1e-6||Math.abs(last[0]-endpoint.lon)>1e-6||Math.abs(last[1]-endpoint.lat)>1e-6)return false;
 }
 const selection=resolvePoiSelection(request,dataset);
 const known=new Map(dataset.pois.map(p=>[p.id,p]));
 const plans=[...(response.plan?[response.plan]:[]),...(response.options?.map(o=>o.plan)??[])];
 for(const plan of plans){
  if(plan.totalMinutes>request.minutes||plan.totalMinutes!==plan.walkingMinutes+plan.visitMinutes+plan.bufferMinutes
   ||plan.visitMinutes!==plan.stops.reduce((n,s)=>n+s.visitMinutes,0)
   ||plan.walkingMinutes!==plan.stops.reduce((n,s)=>n+s.travelMinutes,0)+plan.returnMinutes||plan.bufferMinutes<3)return false;
  const ids=new Set<string>();const selectedIds=new Set<string>();let elapsed=0;
  for(const stop of plan.stops){const p=known.get(stop.poi.id);if(!p||p.lat!==stop.poi.lat||p.lon!==stop.poi.lon||p.category!==stop.poi.category||p.sourceUrl!==stop.poi.sourceUrl)return false;
   const canonical=getCanonicalId(p);
   if(selection.excludedCanonical.has(canonical))return false;selectedIds.add(canonical);
   const id=stop.canonicalId??p.id;if(ids.has(id))return false;ids.add(id);
   const cats=categoriesOf(p);if(cats.some(c=>intent.excludedCategories.some(category=>category===c))||(intent.desiredCategories.length&&!intent.desiredCategories.some(c=>cats.includes(c))))return false;
   if(request.indoor&&p.indoor!==true||request.accessible&&!['yes','designated'].includes((p.wheelchair??'').toLowerCase()))return false;
   elapsed+=stop.travelMinutes;
   const status=openingHoursStatus(p.openingHours,new Date(new Date(request.now??Date.now()).getTime()+elapsed*60_000),stop.visitMinutes);
   if(status==='closed'||(request.knownHoursOnly&&status!=='open')||stop.hoursStatus!==status)return false;
   elapsed+=stop.visitMinutes;
  }
  if(request.requiredPoiId!==undefined&&(selection.requiredCanonical===null||!selectedIds.has(selection.requiredCanonical!)))return false;
  if(request.destination&&(!plan.destination||plan.routeMode!=='one-way'||plan.destination.lat!==endpoint.lat||plan.destination.lon!==endpoint.lon)||!request.destination&&(plan.destination!==undefined||plan.routeMode==='one-way'))return false;
  const first=plan.routeCoordinates[0],last=plan.routeCoordinates.at(-1)!;
  if(Math.abs(first[0]-request.origin.lon)>1e-6||Math.abs(first[1]-request.origin.lat)>1e-6||Math.abs(last[0]-endpoint.lon)>1e-6||Math.abs(last[1]-endpoint.lat)>1e-6)return false;
 }
 return response.plan!==null||!response.options?.length;
}
