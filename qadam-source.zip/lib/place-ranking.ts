import type { POI } from './qadam-types';
// @ts-expect-error Native Node TS verification uses source extensions.
import { getPlaceEditorial } from './place-facts.ts';
/** Content richness, not a review, safety rating or quality of the venue. */
export function retrievalQuality(poi:POI):0|1|2 {
 if(getPlaceEditorial(poi.id)?.facts.length)return 2;
 return ['name','name:ru','name:kk','name:en'].some(key=>Boolean(poi.tags[key]?.trim()))?1:0;
}
