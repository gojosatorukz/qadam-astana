/** Closed vocabulary from the collected POI corpus. The model cannot add places. */
export const SUPPORTED_CATEGORIES = ['art', 'attraction', 'cafe', 'library', 'museum', 'park', 'playground', 'viewpoint'] as const;
export type SupportedCategory = typeof SUPPORTED_CATEGORIES[number];
export type UnsupportedWish = { text: string; reason: 'no-data' | 'use-controls' | 'not-supported' };
export type IntentContract = {
  version: 1;
  desiredCategories: SupportedCategory[];
  excludedCategories: SupportedCategory[];
  includeMode: 'all' | 'any';
  unsupported: UnsupportedWish[];
  needsClarification: boolean;
};
export type IntentResolution = {
  mode: 'gemini' | 'manual' | 'unavailable';
  contract: IntentContract | null;
  failure?: 'not-configured' | 'timeout' | 'provider' | 'invalid-output';
  ms: number;
};
export type IntentFeedback = IntentResolution & {
  status: 'matched' | 'partial' | 'empty' | 'needs-clarification';
  achievedCategories: SupportedCategory[];
  unmetCategories: SupportedCategory[];
};
