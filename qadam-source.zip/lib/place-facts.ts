import rawFacts from '../data/place-facts.json' with { type: 'json' };
import type { POI, PlanRequest } from './qadam-types';
import type { POIDataset } from './planner';

export type LocalizedText = { ru: string; kk: string; en: string };
export type PlaceFact = {
  id: string;
  text: LocalizedText;
  sourceUrl: string;
  checkedAt: string;
  rights: string;
};
export type PlaceEditorial = {
  canonicalId: string;
  /** Only reviewed identity mappings, never proximity or name matching. */
  poiIds: string[];
  name: LocalizedText;
  facts: PlaceFact[];
  /** A suggested observation, not a sourced historical assertion or access guarantee. */
  observation?: LocalizedText;
};
export type PlaceFactsDataset = {
  version: 1;
  checkedAt: string;
  places: PlaceEditorial[];
};

const languages = ['ru', 'kk', 'en'] as const;
const primaryHosts = new Set([
  'visitastana.kz', 'nmrk.kz', 'astanabotsad.kz', 'nabrk.kz',
  'gov.kz', 'law.gov.kz', 'zan.gov.kz', 'adilet.zan.kz', 'akorda.kz',
]);
const record = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);
function keys(value: Record<string, unknown>, required: string[], optional: string[] = []): boolean {
  return required.every(key => Object.hasOwn(value, key)) &&
    Object.keys(value).every(key => required.includes(key) || optional.includes(key));
}
function text(value: unknown, max: number): value is string {
  return typeof value === 'string' && value.length > 0 && value.length <= max &&
    value === value.trim() && !/[\u0000-\u001f\u007f<>]/.test(value);
}
function localized(value: unknown, max: number): value is LocalizedText {
  return record(value) && keys(value, [...languages]) && languages.every(lang => text(value[lang], max));
}
function isoTimestamp(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) return false;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) && new Date(parsed).toISOString() === value;
}
function sourceUrl(value: unknown): value is string {
  if (!text(value, 500)) return false;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password && !url.port &&
      !url.hash && primaryHosts.has(url.hostname.replace(/^www\./, ''));
  } catch { return false; }
}

/** Structural guard only. Source identity, factual correctness and translations need human review. */
export function validatePlaceFacts(value: unknown, snapshot?: Pick<POIDataset, 'pois'>): PlaceFactsDataset | null {
  if (!record(value) || !keys(value, ['version', 'checkedAt', 'places']) || value.version !== 1 ||
      !isoTimestamp(value.checkedAt) || !Array.isArray(value.places) ||
      value.places.length < 1 || value.places.length > 12) return null;
  const canonicalIds = new Set<string>();
  const poiIds = new Set<string>();
  const factIds = new Set<string>();
  const knownIds = snapshot ? new Set(snapshot.pois.map(poi => poi.id)) : null;
  for (const place of value.places) {
    if (!record(place) || !keys(place, ['canonicalId', 'poiIds', 'name', 'facts'], ['observation']) ||
        !text(place.canonicalId, 80) || !/^[a-z][a-z0-9-]*$/.test(place.canonicalId) || canonicalIds.has(place.canonicalId) ||
        !Array.isArray(place.poiIds) || place.poiIds.length < 1 || place.poiIds.length > 5 ||
        !localized(place.name, 160) || !Array.isArray(place.facts) || place.facts.length < 1 || place.facts.length > 4 ||
        (Object.hasOwn(place, 'observation') && !localized(place.observation, 400))) return null;
    canonicalIds.add(place.canonicalId);
    for (const poiId of place.poiIds) {
      if (typeof poiId !== 'string' || !/^osm-(node|way|relation)-[1-9]\d*$/.test(poiId) ||
          poiIds.has(poiId) || (knownIds && !knownIds.has(poiId))) return null;
      poiIds.add(poiId);
    }
    for (const fact of place.facts) {
      if (!record(fact) || !keys(fact, ['id', 'text', 'sourceUrl', 'checkedAt', 'rights']) ||
          !text(fact.id, 120) || !new RegExp(`^${place.canonicalId}:[a-z][a-z0-9-]*$`).test(fact.id) || factIds.has(fact.id) ||
          !localized(fact.text, 400) || !sourceUrl(fact.sourceUrl) || !isoTimestamp(fact.checkedAt) ||
          Date.parse(fact.checkedAt) > Date.parse(value.checkedAt) || !text(fact.rights, 500)) return null;
      factIds.add(fact.id);
    }
  }
  return value as PlaceFactsDataset;
}

function freeze<T>(value: T): T {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
const checkedFacts = validatePlaceFacts(rawFacts);
if (!checkedFacts) throw new Error('Invalid bundled place facts; run scripts/import-place-facts.mjs --check');
const facts = freeze(checkedFacts);
const byPoiId = new Map(facts.places.flatMap(place => place.poiIds.map(id => [id, place] as const)));

export function getPlaceEditorial(poiId: string): PlaceEditorial | undefined {
  return byPoiId.get(poiId);
}

export function getCanonicalId(poi: POI): string {
  return getPlaceEditorial(poi.id)?.canonicalId ?? poi.id;
}

export function getPlaceName(poi: POI, language: PlanRequest['language']): string {
  return getPlaceEditorial(poi.id)?.name[language] ?? poi.name;
}

export function getFactText(fact: PlaceFact, language: PlanRequest['language']): string {
  return fact.text[language];
}

/** Overlay display name and sourced description only; never change routing/filter/OSM provenance fields. */
export function applyPlaceFacts<T extends POIDataset>(dataset: T): T {
  return {
    ...dataset,
    pois: dataset.pois.map(poi => {
      const editorial = getPlaceEditorial(poi.id);
      return editorial ? { ...poi, name: editorial.name.ru, description: editorial.facts.map(fact => fact.text.ru).join(' ') } : poi;
    }),
  };
}

/** Collection metadata for UI/source dialogs; it does not imply current hours or field verification. */
export function getPlaceFactsCoverage() {
  return {
    version: facts.version,
    checkedAt: facts.checkedAt,
    canonicalPlaces: facts.places.length,
    poiRecords: byPoiId.size,
    facts: facts.places.reduce((sum, place) => sum + place.facts.length, 0),
    observations: facts.places.filter(place => place.observation).length,
    sourceUrls: [...new Set(facts.places.flatMap(place => place.facts.map(fact => fact.sourceUrl)))],
  };
}
