import type { POI, RoutePlan } from './qadam-types';
type Language = 'ru' | 'kk' | 'en';
const cuisines: Record<string, [string, string, string]> = {
  kazakh:['Казахская','Kazakh','Қазақ'], local:['Местная','Local','Жергілікті'], regional:['Региональная','Regional','Өңірлік'],
  european:['Европейская','European','Еуропа'], asian:['Азиатская','Asian','Азия'], oriental:['Восточная','Oriental','Шығыс'],
  chinese:['Китайская','Chinese','Қытай'], korean:['Корейская','Korean','Корей'], japanese:['Японская','Japanese','Жапон'],
  italian:['Итальянская','Italian','Итальян'], italian_pizza:['Итальянская пицца','Italian pizza','Итальян пиццасы'],
  georgian:['Грузинская','Georgian','Грузин'], turkish:['Турецкая','Turkish','Түрік'], indian:['Индийская','Indian','Үнді'],
  french:['Французская','French','Француз'], russian:['Русская','Russian','Орыс'], mexican:['Мексиканская','Mexican','Мексика'],
  mediterranean:['Средиземноморская','Mediterranean','Жерорта теңізі'], international:['Международная','International','Халықаралық'],
  pizza:['Пицца','Pizza','Пицца'], burger:['Бургеры','Burgers','Бургерлер'], sushi:['Суши','Sushi','Суши'],
  shawarma:['Шаурма','Shawarma','Шаурма'], kebab:['Кебаб','Kebab','Кебаб'], grill:['Гриль','Grill','Гриль'],
  barbecue:['Барбекю','Barbecue','Барбекю'], steak_house:['Стейки','Steaks','Стейктер'], pasta:['Паста','Pasta','Паста'],
  seafood:['Морепродукты','Seafood','Теңіз өнімдері'], chicken:['Курица','Chicken','Тауық'], breakfast:['Завтраки','Breakfast','Таңғы ас'],
  sandwich:['Сэндвичи','Sandwiches','Сэндвичтер'], dessert:['Десерты','Desserts','Десерттер'], cake:['Выпечка','Cake','Тәтті нан'],
  tea:['Чай','Tea','Шай'], coffee_shop:['Кофе','Coffee','Кофе'], hot_dog:['Хот-доги','Hot dogs','Хот-догтар'],
  curry:['Карри','Curry','Карри'], beef_bowl:['Мясные боулы','Beef bowls','Ет боулдары'], fish_and_chips:['Рыба и картофель','Fish and chips','Балық пен картоп'],
  fries:['Картофель фри','Fries','Фри картоп'], friture:['Фритюр','Fried food','Қуырылған тағам'], diner:['Дайнер','Diner','Дайнер'],
};
/** Cuisine is a source tag, never inferred from the venue's name or branding. */
export function cuisineLabel(poi: POI, language: Language): string | null {
  const index = language === 'en' ? 1 : language === 'kk' ? 2 : 0;
  const tags = [...new Set((poi.tags.cuisine ?? '').split(/[;,]/).map(s => s.trim().toLowerCase()).filter(Boolean))].slice(0, 3);
  return tags.length ? tags.map(tag => cuisines[tag]?.[index] ?? tag.replaceAll('_', ' ')).join(' · ') : null;
}
export function routeIdentity(plan: RoutePlan): string {
  return [...new Set(plan.stops.map(stop => stop.canonicalId ?? stop.poi.id))].sort().join('|');
}
/** Display a real numeric comparison; equal routes do not get a made-up advantage. */
export function compareRoute(plan: RoutePlan, reference: RoutePlan, language: Language): string {
  const walk = plan.walkingMinutes - reference.walkingMinutes;
  const stay = plan.visitMinutes - reference.visitMinutes;
  const L = (ru:string,en:string,kk:string) => language === 'en' ? en : language === 'kk' ? kk : ru;
  const parts: string[] = [];
  if (walk) parts.push(walk < 0 ? L(`На ${-walk} мин меньше идти`, `${-walk} min less walking`, `${-walk} мин аз жүру`) : L(`На ${walk} мин больше идти`, `${walk} min more walking`, `${walk} мин көп жүру`));
  if (stay) parts.push(stay > 0 ? L(`На ${stay} мин больше на остановки`, `${stay} min more at stops`, `Аялдауға ${stay} мин көп`) : L(`На ${-stay} мин меньше на остановки`, `${-stay} min less at stops`, `Аялдауға ${-stay} мин аз`));
  return parts.join(' · ') || L('Время такое же — отличаются места по пути.', 'Same timing, different places along the way.', 'Уақыт бірдей — жолдағы орындар басқа.');
}
