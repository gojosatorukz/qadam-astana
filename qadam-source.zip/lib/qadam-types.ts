export type POI = {
  id: string; name: string; lat: number; lon: number; category: string;
  description: string; tags: Record<string,string>; openingHours: string | null;
  website: string | null; sourceUrl: string; fetchedAt: string;
  indoor: boolean | null; wheelchair: string | null;
};
export type PlanRequest = {
  query: string; origin: {lat:number;lon:number;label:string}; minutes: number;
  interests: string[]; indoor: boolean; knownHoursOnly: boolean;
  accessible: boolean; language: 'ru'|'kk'|'en'; now?: string;
};
export type PlanStop = {
  poi: POI; visitMinutes:number; travelMinutes:number;
  why:string; activity:string; hoursStatus:'open'|'closed'|'unknown';
};
export type PlanResponse = {
  plan: { title:string; summary:string; stops:PlanStop[]; totalMinutes:number;
    walkingMinutes:number; visitMinutes:number; bufferMinutes:number;
    distanceMeters:number; returnMinutes:number;
    /** GeoJSON order: longitude, latitude. */ routeCoordinates:[number,number][]; routeKind:'walking'|'estimate'; } | null;
  candidates:number; excluded:{reason:string;count:number}[];
  trace:{step:string;detail:string;ms:number}[];
  generationMode:'gemini'|'retrieval'; warnings:string[];
  dataset:{count:number;fetchedAt:string;source:string};
  weather?:{temperature:number;windKmh:number;sourceUrl:string;fetchedAt:string}|null;
};
