import type { IntentFeedback } from './intent-types';
export type POI = {
  id: string; name: string; lat: number; lon: number; category: string;
  description: string; tags: Record<string,string>; openingHours: string | null;
  website: string | null; sourceUrl: string; fetchedAt: string;
  indoor: boolean | null; wheelchair: string | null;
};
export type PlanRequest = {
  query: string; origin: {lat:number;lon:number;label:string}; minutes: number;
  /** Omit for a round trip; otherwise the final leg must reach this point. */
  destination?: {lat:number;lon:number;label:string};
  interests: string[]; indoor: boolean; knownHoursOnly: boolean;
  accessible: boolean; language: 'ru'|'kk'|'en'; now?: string;
  departureMode?: 'now'|'custom'; returnBy?: string;
  contextConfirmed?: boolean; localOnly?: boolean;
  /** IDs already shown; reviewed aliases are excluded together (maximum 80). */
  excludePoiIds?:string[];
  /** Every returned itinerary must visit this source POI or reviewed canonical place. */
  requiredPoiId?:string;
};
export type StopFact = { id:string; text:string; sourceUrl:string; checkedAt:string; rights:string };
export type PlanStop = {
  poi: POI; visitMinutes:number; travelMinutes:number;
  why:string; activity:string; hoursStatus:'open'|'closed'|'unknown';
  canonicalId?:string; facts?:StopFact[]; observation?:string;
};
export type RoutePlan = {
  title:string; summary:string; stops:PlanStop[]; totalMinutes:number;
  walkingMinutes:number; visitMinutes:number; bufferMinutes:number;
  distanceMeters:number; returnMinutes:number;
  /** GeoJSON order: longitude, latitude. */
  routeCoordinates:[number,number][]; routeKind:'walking'|'estimate';
  destination?:{lat:number;lon:number;label:string}; routeMode?:'round-trip'|'one-way';
};
export type Clarification = {
  reason:'ambiguous'|'control-conflict'|'unsupported-activity'|'outside-coverage'|'model-unavailable'|'invalid-time'|'stale-time';
  question:string;
  options:{id:string;label:string;action:'manual-category'|'set-origin'|'external-search'|'retry'|'edit-query';value?:string;origin?:{lat:number;lon:number;label:string}}[];
  allowFreeText:boolean; message?:string;
};
export type PlanDiagnostics = {
  stage:'context'|'intent'|'planning'|'enrichment'|'complete';
  intent:'manual'|'gemini'|'unavailable'|'not-attempted';
  enrichment:'gemini'|'local'|'unavailable'|'not-attempted';
  coverage:'walking'|'estimate'|'outside'|'unknown';
  codes:string[]; recomputeAfterSeconds?:number;
};
export type PlanResponse = {
  intent?: IntentFeedback;
  /** Baseline A→B route, excluding venue visits. Never substitutes for a POI plan. */
  directRoute?:{minutes:number;distanceMeters:number;routeKind:'walking'|'estimate';feasible:boolean;minimumMinutes:number;routeCoordinates:[number,number][]};
  plan: RoutePlan | null;
  options?:{id:string;label:string;plan:RoutePlan;tradeoff:string}[];
  clarification?:Clarification;
  diagnostics?:PlanDiagnostics;
  departureAt?:string; planComputedAt?:string; returnBy?:string; effectiveMinutes?:number;
  candidates:number; excluded:{reason:string;count:number}[];
  trace:{step:string;detail:string;ms:number}[];
  generationMode:'gemini'|'retrieval'; warnings:string[];
  dataset:{count:number;fetchedAt:string;source:string};
  weather?:{temperature:number;windKmh:number;sourceUrl:string;fetchedAt:string}|null;
};
