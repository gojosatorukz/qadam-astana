import type { PlanRequest } from './qadam-types';

/** One visible dialog budget shared by the editor and HTTP validator. */
export const MAX_QUERY_LENGTH = 4_000;
export const MAX_CLARIFICATION_LENGTH = 500;
// A maximum valid dialog, label and chips fit even with JSON character escapes.
export const MAX_PLAN_REQUEST_BYTES = 32_768;

type ClarificationAppend = { query: string } | { error: 'empty' | 'answer-too-long' | 'query-too-long' };

/** Never truncates an earlier wish or exclusion to make a follow-up fit. */
export function appendClarificationQuery(query: string, answer: string, language: PlanRequest['language']): ClarificationAppend {
  const text = answer.trim();
  if (!text) return { error: 'empty' };
  if (answer.length > MAX_CLARIFICATION_LENGTH) return { error: 'answer-too-long' };
  const marker = language === 'en' ? 'Clarification: ' : language === 'kk' ? 'Нақтылау: ' : 'Уточнение: ';
  const next = query ? `${query}\n${marker}${text}` : text;
  return next.length <= MAX_QUERY_LENGTH ? { query: next } : { error: 'query-too-long' };
}
