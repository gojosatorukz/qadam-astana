import dataset from '../data/place-photos.json' with { type: 'json' };
export function getPlacePhoto(poiId: string) {
  return dataset.photos.find(photo => photo.poiIds.includes(poiId)) ?? null;
}
