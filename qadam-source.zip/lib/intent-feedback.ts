import type { IntentFeedback, IntentResolution, SupportedCategory } from './intent-types';
import type { PlanResponse } from './qadam-types';

/** Feedback reflects selected POIs; it never changes the model's contract. */
export function buildIntentFeedback(response: PlanResponse, resolution: IntentResolution): IntentFeedback {
  const contract = resolution.contract;
  const actual = new Set(response.plan?.stops.map(stop => stop.poi.category === 'gallery' ? 'art' : stop.poi.category) ?? []);
  const achievedCategories = contract?.desiredCategories.filter(category => actual.has(category)) ?? [];
  const unmetCategories: SupportedCategory[] = !contract ? [] : contract.includeMode === 'any' && achievedCategories.length ? [] : contract.desiredCategories.filter(category => !actual.has(category));
  const clarification = !contract || contract.needsClarification;
  return {
    ...resolution,
    status: clarification ? 'needs-clarification' : !response.plan ? 'empty' : unmetCategories.length || contract.unsupported.length ? 'partial' : 'matched',
    achievedCategories,
    unmetCategories,
  };
}
