import type { Clarification, PlanRequest } from './qadam-types';
import type { IntentResolution, SupportedCategory } from './intent-types';
// @ts-expect-error Native Node TS verification uses source extensions.
import { haversineMeters, inferExcludedInterests } from './planner.ts';

export type CoverageBounds = { south:number;north:number;west:number;east:number };
export const POI_COVERAGE:CoverageBounds={south:51.065,north:51.205,west:71.35,east:71.515};
const presets=[
 {id:'baiterek',lat:51.12828,lon:71.43055,names:{ru:'Байтерек',en:'Baiterek',kk:'Бәйтерек'},match:/байтерек|бәйтерек|baiterek|bayterek/iu},
 {id:'mega',lat:51.08915,lon:71.41293,names:{ru:'Район Mega Silk Way · EXPO',en:'Mega Silk Way · EXPO area',kk:'Mega Silk Way · EXPO ауданы'},match:/\bmega\b|мега|\bexpo\b|экспо/iu},
 {id:'museum',lat:51.11862,lon:71.46919,names:{ru:'Национальный музей',en:'National Museum',kk:'Ұлттық музей'},match:/национальн\S*\s+музе|national\s+museum|ұлттық\s+мұражай|ұлттық\s+музей/iu},
 {id:'riverfront',lat:51.1643,lon:71.4258,names:{ru:'Набережная Есиля',en:'Yesil riverfront',kk:'Есіл жағалауы'},match:/набережн|riverfront|есіл\s+жағалау/iu},
] as const;
const labels:Record<PlanRequest['language'],Record<SupportedCategory,string>>={
 ru:{art:'Искусство',attraction:'Достопримечательности',cafe:'Кафе',food:'Поесть',library:'Библиотека',museum:'Музей',park:'Парк',playground:'Детская площадка',viewpoint:'Смотровая площадка'},
 en:{art:'Art',attraction:'Landmarks',cafe:'Café',food:'Food',library:'Library',museum:'Museum',park:'Park',playground:'Playground',viewpoint:'Viewpoint'},
 kk:{art:'Өнер',attraction:'Көрікті орындар',cafe:'Кафе',food:'Тамақтану',library:'Кітапхана',museum:'Мұражай',park:'Саябақ',playground:'Балалар алаңы',viewpoint:'Көрініс алаңы'},
};
function local<T>(request:PlanRequest,ru:T,en:T,kk:T):T{return request.language==='en'?en:request.language==='kk'?kk:ru;}
const edit=(r:PlanRequest):Clarification['options'][number]=>({id:'edit-query',label:local(r,'Написать своё желание','Describe another wish','Басқа тілекті жазу'),action:'edit-query'});
const retry=(r:PlanRequest):Clarification['options'][number]=>({id:'retry',label:local(r,'Повторить запрос','Try again','Қайта сұрау'),action:'retry'});
const originOption=(r:PlanRequest,p:typeof presets[number]):Clarification['options'][number]=>({id:`origin-${p.id}`,label:p.names[r.language],action:'set-origin',origin:{lat:p.lat,lon:p.lon,label:p.names[r.language]}});
export function timeClarification(r:PlanRequest,stale=false):Clarification{return {reason:stale?'stale-time':'invalid-time',question:local(r,'Какое время отправления и возвращения использовать?','Which departure and return time should we use?','Қай шығу және қайту уақытын қолданамыз?'),message:stale?local(r,'Пока собирали план, время выхода или возврата изменилось. Желание, старт и фильтры сохранены. Обновите время и пересчитайте.','Time changed while we were building the plan. Your wish, start and filters are preserved. Update the time and recalculate.','Жоспар жасалғанша шығу не қайту уақыты өзгерді. Тілек, бастау және сүзгілер сақталды. Уақытты жаңартып, қайта есептеңіз.'):local(r,'Проверьте дату Алматы и оставшееся время. Нужно 5–360 минут до возвращения.','Check the Almaty date and remaining time. A return window of 5–360 minutes is supported.','Алматы күнін және қалған уақытты тексеріңіз. Қайтуға дейінгі уақыт 5–360 минут болуы керек.'),options:[{id:'edit-time',label:local(r,'Изменить дату или время','Edit date or time','Күнді не уақытты өзгерту'),action:'edit-query'},retry(r)],allowFreeText:false};}

/** Bounded, known-preset reconciliation; never silently geocodes arbitrary text. */
export function preflightContext(r:PlanRequest,bounds?:CoverageBounds):Clarification|undefined {
 const fullText=r.query.toLowerCase().replace(/ё/g,'е');
 // The UI appends free answers as visible text. Inspect the newest answer for
 // known context conflicts; the interpreter still receives the full dialogue.
 // This does not turn an answer into a trusted category or discard exclusions.
 const text=fullText.split(/\n(?:уточнение|clarification|нақтылау):\s*/iu).at(-1)??fullText;
 // Public artworks are not evidence of a gallery or painting collection.
 if(/galler(?:y|ies)|галере/iu.test(text)&&!/(?:без|не хочу|no|without)\s+(?:galler|галере)/iu.test(text)
   &&!/кафе|coffee|\bcafe\b|покуш|поесть|обед|ужин|ресторан|тамақ|\beat\b|\blunch\b|\bfood\b|парк|саябақ|\bpark\b|музе|museum|мұражай/iu.test(text))return {
  reason:'unsupported-activity',question:local(r,'Искать галерею снаружи или выбрать уличное искусство?','Search externally for a gallery, or choose public artworks?','Галереяны сырттан іздейміз бе, әлде көше өнерін таңдаймыз ба?'),
  message:local(r,'Категория «Искусство» в этом снимке содержит уличные произведения, а не подтверждённые галереи или коллекции картин.','The Art category in this snapshot contains public artworks, not verified galleries or painting collections.','Бұл деректегі «Өнер» санаты тексерілген галерея не сурет жинақтары емес, көше өнерін қамтиды.'),
  options:[{id:'external-gallery',label:local(r,'Найти галереи в картах','Search maps for galleries','Галереяны картадан іздеу'),action:'external-search',value:'https://www.google.com/maps/search/?api=1&query=art+galleries+Astana'},
   {id:'manual-art',label:local(r,'Выбрать уличное искусство','Choose public artworks','Көше өнерін таңдау'),action:'manual-category',value:'art'},edit(r)],allowFreeText:true};
 const hasActivity=/football|soccer|футбол|shoppings?|шоппинг|шопинг|сауда\s+жас|shopping/iu.test(text);
 // Dedicated unsupported goals get an immediate honest data boundary and useful
 // external actions. These do not add a pretend sports/shopping POI category.
 if(hasActivity && !/(?:без|не хочу|no|without)\s+(?:футбол|football|soccer|shopping|шоппинг)/iu.test(text)
   && !/кафе|coffee|\bcafe\b|покуш|поесть|обед|ужин|ресторан|тамақ|\beat\b|\blunch\b|\bfood\b|парк|саябақ|\bpark\b|музе|museum|мұражай/iu.test(text)) {
  const football=/football|soccer|футбол/iu.test(text);
  const query=football?local(r,'футбольные площадки Астана','football pitches Astana','Астана футбол алаңдары'):local(r,'торговые центры Астана','shopping centres Astana','Астана сауда орталықтары');
  return {reason:'unsupported-activity',question:football?local(r,'Найти площадку для игры или информацию о матче?','Find a pitch to play on, or information about a match?','Ойнайтын алаң ба, әлде матч туралы ақпарат па?'):local(r,'Найти торговый центр или конкретный магазин?','Find a shopping centre or a particular shop?','Сауда орталығын ба, әлде нақты дүкенді ме?'),message:football?local(r,'В нашем снимке нет футбольных площадок, матчей и расписаний. Внешний поиск откроется только по нажатию; Qadam не проверяет его результаты.','Our snapshot has no football pitches, matches or schedules. External search opens only on your click; Qadam does not verify its results.','Біздің деректерде футбол алаңдары, матчтар не кестелер жоқ. Сыртқы іздеу тек басқанда ашылады; нәтижелерін Qadam тексермейді.'):local(r,'В нашем снимке нет торговых центров, магазинов и их ассортимента. Внешний поиск откроется только по нажатию; Qadam не проверяет его результаты.','Our snapshot has no shopping centres, shops or product ranges. External search opens only on your click; Qadam does not verify its results.','Біздің деректерде сауда орталықтары, дүкендер не тауарлар жоқ. Сыртқы іздеу тек басқанда ашылады; нәтижелерін Qadam тексермейді.'),options:[{id:'external-places',label:football?local(r,'Найти площадку в 2ГИС','Find a pitch in 2GIS','Алаңды 2GIS-тен іздеу'):local(r,'Торговые центры в 2ГИС','Shopping centres in 2GIS','Сауда орталықтарын 2GIS-тен іздеу'),action:'external-search',value:`https://2gis.kz/astana/search/${encodeURIComponent(query)}`},{id:'external-details',label:football?local(r,'Поиск матчей и трансляций','Search matches and screenings','Матчтар мен көрсетілімдерді іздеу'):local(r,'Поиск конкретного магазина','Search for a specific shop','Нақты дүкенді іздеу'),action:'external-search',value:`https://www.google.com/search?q=${encodeURIComponent(football?local(r,'Астана футбол матчи трансляции','Astana football matches screenings','Астана футбол матчтары көрсетілімдері'):r.query+' Astana')}`},edit(r)],allowFreeText:true};
 }
 if(bounds&&(r.origin.lat<bounds.south||r.origin.lat>bounds.north||r.origin.lon<bounds.west||r.origin.lon>bounds.east))return {reason:'outside-coverage',question:local(r,'В каком из изученных районов начать?','Which covered area would you like to start in?','Зерттелген қай ауданда бастаймыз?'),message:local(r,'Старт за границей снимка мест. Выбор района сохранит желание, время и фильтры; граница снимка не гарантирует связность каждого пути.','The start is outside our place snapshot. Choosing an area preserves your wish, time and filters; the snapshot boundary does not guarantee every path is connected.','Бастау нүктесі орындар дерегінен тыс. Аудан таңдау тілекті, уақытты, сүзгілерді сақтайды; шекара әр жолдың байланысын кепілдемейді.'),options:[...presets].sort((a,b)=>haversineMeters(r.origin,a)-haversineMeters(r.origin,b)).slice(0,3).map(p=>originOption(r,p)),allowFreeText:false};
 if(!r.contextConfirmed && /(?:старт|нач(?:ать|нем)|выйти\s+(?:из|от)|start|depart|бастау|бастай|шығу|возле|рядом\s+с|near|жанында|қасында)/iu.test(text)){
  const startMention=text.match(/(?:старт\s*(?:от|из|у|с)|нач(?:ать|нем)\s+(?:от|из|у|с)|выйти\s+(?:из|от)|\bstart(?:ing)?\s+(?:from|at|near)\b|\bdepart\s+from\b)\s+([^,;.!?\n]+)/iu)?.[1];
  const locationText=startMention?.split(/\s+(?:хочу|хотим|want|келеді)(?:\s|$)/iu)[0]??text;
  const target=presets.find(p=>p.match.test(locationText)&&haversineMeters(r.origin,p)>600);
  if(target)return {reason:'control-conflict',question:local(r,`Начать у «${target.names.ru}» или оставить «${r.origin.label}»?`,`Start at ${target.names.en}, or keep ${r.origin.label}?`,`«${target.names.kk}» жерінен бастаймыз ба, әлде «${r.origin.label}» қалсын ба?`),message:local(r,'Место старта в тексте отличается от выбранной точки. Ничего не меняем без вашего выбора. Точка района приблизительна, это не проверенный вход.','The text names a different start. We will not change it without your choice. The area point is approximate, not a verified entrance.','Мәтіндегі бастау таңдалған нүктеден өзгеше. Таңдаусыз өзгертпейміз. Аудан нүктесі жуық, тексерілген кіреберіс емес.'),options:[originOption(r,target),{id:'keep-origin',label:local(r,`Оставить: ${r.origin.label}`,`Keep: ${r.origin.label}`,`Қалдыру: ${r.origin.label}`),action:'set-origin',origin:{...r.origin}}],allowFreeText:true};
  const explicitStart=/(?:старт\s*(?:от|из|у|с)|нач(?:ать|нем)\s+(?:от|из|у|с)|выйти\s+(?:из|от)|\bstart(?:ing)?\s+(?:from|at|near)\b|\bdepart\s+from\b|бастау|бастай)/iu.test(text);
  if(explicitStart && !presets.some(p=>p.match.test(locationText)))return {
   reason:'control-conflict',question:local(r,'Какую точку старта использовать?','Which starting point should we use?','Қай бастау нүктесін қолданамыз?'),
   message:local(r,'В тексте указан старт, который мы не можем надёжно сопоставить с точкой. Выбери его поиском или на карте либо явно оставь текущий. Желание, время и фильтры сохранятся.','The text names a start we cannot reliably match to a point. Choose it with search or the map, or explicitly keep the current one. Your wish, time and filters are saved.','Мәтіндегі бастауды нүктемен сенімді сәйкестендіре алмадық. Іздеу не карта арқылы таңда немесе ағымдағысын қалдыр. Тілек, уақыт және сүзгілер сақталады.'),
   options:[{id:'edit-origin',label:local(r,'Выбрать точку старта','Choose a starting point','Бастау нүктесін таңдау'),action:'edit-query'},{id:'keep-origin',label:local(r,`Оставить: ${r.origin.label}`,`Keep: ${r.origin.label}`,`Қалдыру: ${r.origin.label}`),action:'set-origin',origin:{...r.origin}}],allowFreeText:false};
 }
 return undefined;
}

export function intentClarification(r:PlanRequest,resolution:IntentResolution):Clarification {
 const unavailable=resolution.mode==='unavailable';
 const excluded=new Set([...(resolution.contract?.excludedCategories??[]),...inferExcludedInterests(r.query)]);
 const preferred=resolution.contract?.desiredCategories.length?resolution.contract.desiredCategories:['park','cafe','museum'] as SupportedCategory[];
 const options:Clarification['options']=preferred.filter(c=>!excluded.has(c)).slice(0,3).map(category=>({id:`manual-${category}`,label:local(r,`Выбрать вручную: ${labels.ru[category]}`,`Choose manually: ${labels.en[category]}`,`Қолмен таңдау: ${labels.kk[category]}`),action:'manual-category',value:category}));
 if(unavailable)options.push(retry(r));else options.push(edit(r));
 if(options.length<2)options.push(unavailable?edit(r):retry(r));
 return {reason:unavailable?'model-unavailable':resolution.contract?.unsupported.some(x=>x.reason==='use-controls')?'control-conflict':'ambiguous',question:unavailable?local(r,'Как продолжим без распознавания текста?','How would you like to continue without text interpretation?','Мәтінді түсіндірусіз қалай жалғастырамыз?'):local(r,'Чем вы хотите заняться в эту паузу?','What would you like to do during this break?','Осы үзілісте не істегіңіз келеді?'),message:unavailable?local(r,'Текст не удалось надёжно понять. Явный ручной выбор сохранит старт, время и фильтры и не потребует повторного вызова AI.','The text could not be reliably interpreted. Explicit manual choice preserves the start, time and filters without another AI call.','Мәтінді сенімді түсіндіру мүмкін болмады. Қолмен таңдау бастау, уақыт, сүзгілерді сақтап, AI-ды қайта шақырмайды.'):local(r,'Выберите одно занятие или уточните своими словами. Неподтверждённые свойства не станут фактами.','Choose an activity or clarify in your own words. Unverified properties will not become facts.','Әрекетті таңдаңыз не өз сөзіңізбен нақтылаңыз. Расталмаған қасиеттер дерекке айналмайды.'),options:options.slice(0,4),allowFreeText:true};
}
