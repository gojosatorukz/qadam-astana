/** Recheck at permission resolution, since the browser prompt can remain open. */
export function walkStartBlock(options: {nowMs:number; departureMode:'now'|'custom'; departureAt?:string; computedAt?:string; deadlineAt:string; hasStarted:boolean}):'future'|'expired'|null {
  const {nowMs,departureAt,computedAt,departureMode,deadlineAt,hasStarted}=options;
  if(departureAt&&Date.parse(departureAt)>nowMs+30_000)return 'future';
  // A real walk may continue home beyond its original window. An old plan must
  // be refreshed before its first accepted position, not during that walk.
  if(!hasStarted&&((computedAt&&departureMode==='now'&&nowMs-Date.parse(computedAt)>60_000)||(departureAt&&departureMode==='custom'&&nowMs>Date.parse(departureAt)+60_000)||Date.parse(deadlineAt)<=nowMs))return 'expired';
  return null;
}

/** An ephemeral browser watch. Stopped/replaced sessions ignore late callbacks. */
export function createLocationWatch(api: Pick<Geolocation, 'watchPosition' | 'clearWatch'>) {
  let epoch = 0;
  let id: number | null = null;
  function stop() {
    epoch++;
    if (id !== null) api.clearWatch(id);
    id = null;
  }
  function start(success: PositionCallback, failure: PositionErrorCallback) {
    stop();
    const session = epoch;
    const next = api.watchPosition(
      position => { if (session === epoch) success(position); },
      error => { if (session === epoch) failure(error); },
      { enableHighAccuracy: true, maximumAge: 0, timeout: 15_000 },
    );
    // Covers a synchronous denial followed by a caller's stop() as well.
    if (session === epoch) id = next;
    else api.clearWatch(next);
  }
  return { start, stop };
}
