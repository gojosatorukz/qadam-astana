import type { POI } from './qadam-types';
import type { SupportedCategory } from './intent-types';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { getPlaceEditorial } from './place-facts.ts';
export type Language = 'ru' | 'en' | 'kk';
const labels: Record<SupportedCategory, [string,string,string]> = {
  food: ['Поесть','Food','Тамақтану'], cafe: ['Кофе','Coffee','Кофе'], park: ['Природа','Nature','Табиғат'], museum: ['Музей','Museum','Мұражай'],
  art: ['Искусство','Art','Өнер'], attraction: ['Достопримечательности','Landmarks','Көрікті жерлер'],
  library: ['Библиотека','Library','Кітапхана'], playground: ['С детьми','With kids','Балалармен'], viewpoint: ['Вид на город','City views','Қала көрінісі'],
};
export function categoryLabel(category: string, language: Language): string {
  const key = category === 'gallery' ? 'art' : category;
  return labels[key as SupportedCategory]?.[language === 'ru' ? 0 : language === 'en' ? 1 : 2] ?? category;
}

/** Preserve source names; translate only our generated category fallback. */
export function poiDisplayName(poi: POI, language: Language): string {
  const editorial = getPlaceEditorial(poi.id);
  if (editorial) return editorial.name[language];
  const translated = poi.tags[`name:${language}`];
  if (translated) return translated;
  if (poi.tags.name || poi.tags['name:ru'] || poi.tags['name:kk'] || poi.tags['name:en']) return poi.name;
  return `${categoryLabel(poi.category, language)} · OSM ${poi.id.match(/\d+$/)?.[0] ?? poi.id}`;
}

/** Stable month names even in browsers with partial Kazakh ICU data. */
export function formatAlmatyDate(value: string, language: Language, withTime = false): string {
  const parts = new Intl.DateTimeFormat('en-GB', {timeZone:'Asia/Almaty',year:'numeric',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date(value));
  const part = (type: string) => parts.find(item => item.type === type)?.value ?? '';
  const months = {
    ru: ['янв.','февр.','мар.','апр.','мая','июн.','июл.','авг.','сент.','окт.','нояб.','дек.'],
    en: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    kk: ['қаң.','ақп.','нау.','сәу.','мам.','мау.','шіл.','там.','қыр.','қаз.','қар.','жел.'],
  };
  return `${part('day')} ${months[language][Number(part('month')) - 1]} ${part('year')}${withTime ? `, ${part('hour')}:${part('minute')}` : ''}`;
}
