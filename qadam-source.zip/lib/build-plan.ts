// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { interpretIntent } from './intent.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { planRoute } from './planner.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { enrichWithGemini } from './rag.ts';
// @ts-expect-error Native Node TS verification uses explicit source extensions.
import { buildIntentFeedback } from './intent-feedback.ts';
import type { POIDataset } from './planner';
import type { PlanRequest, PlanResponse } from './qadam-types';
import type { WalkingGraph } from './walking-graph';
import type { IntentContract } from './intent-types';

const clarification: IntentContract = { version: 1, desiredCategories: [], excludedCategories: [], includeMode: 'any', unsupported: [], needsClarification: true };
export type BuildPlanOptions = {
  routing?: WalkingGraph;
  totalTimeoutMs?: number;
  interpret?: typeof interpretIntent;
  enrich?: typeof enrichWithGemini;
  intentOptions?: Parameters<typeof interpretIntent>[1];
  generationOptions?: Parameters<typeof enrichWithGemini>[2];
};

/** Both model stages share a single deadline. No client-supplied intent is trusted. */
export async function buildPlan(request: PlanRequest, dataset: POIDataset, options: BuildPlanOptions = {}): Promise<PlanResponse> {
  const started = performance.now();
  const total = Math.max(1, Math.min(14_500, options.totalTimeoutMs ?? 14_500));
  const resolution = await (options.interpret ?? interpretIntent)(request, { ...options.intentOptions, totalTimeoutMs: Math.min(6_500, total) });
  const result = planRoute(request, dataset, { routing: options.routing, intent: resolution.contract ?? clarification });
  result.intent = buildIntentFeedback(result, resolution);
  result.trace.unshift({ step: 'intent', detail: `${resolution.mode}${resolution.failure ? `; ${resolution.failure}` : ''}; ${resolution.contract?.desiredCategories.join(', ') || 'nearby'}; exclusions=${resolution.contract?.excludedCategories.join(', ') || 'none'}; ${result.intent.status}`, ms: resolution.ms });
  if (!result.plan || result.intent.status === 'needs-clarification') return result;
  const remaining = total - (performance.now() - started);
  if (remaining < 50) {
    result.trace.push({ step: 'gemini-fallback', detail: 'Shared model deadline reached; deterministic source explanations preserved', ms: 0 });
    return result;
  }
  return (options.enrich ?? enrichWithGemini)(result, request, { ...options.generationOptions, totalTimeoutMs: remaining });
}
