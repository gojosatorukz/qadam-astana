import type { PlanRequest } from './qadam-types';

/** Strict calendar validation before Date: JS otherwise normalises Feb 31. */
export function parseIsoInstant(value: unknown): Date | null {
  if (typeof value !== 'string' || value.length > 64) return null;
  const match = value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(Z|([+-])(\d{2}):(\d{2}))$/);
  if (!match) return null;
  const [,y,m,d,h,min,sec,fraction,zone,sign,offsetH,offsetM] = match;
  const [year,month,day,hour,minute,second] = [y,m,d,h,min,sec ?? '0'].map(Number);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const maxDay = [31,leap ? 29 : 28,31,30,31,30,31,31,30,31,30,31][month-1];
  if (!maxDay || day < 1 || day > maxDay || hour > 23 || minute > 59 || second > 59
    || (zone !== 'Z' && (Number(offsetH) > 23 || Number(offsetM) > 59))) return null;
  const ms = Number((fraction ?? '').padEnd(3,'0').slice(0,3));
  const local = new Date(0); local.setUTCFullYear(year,month-1,day); local.setUTCHours(hour,minute,second,ms);
  const offset = zone === 'Z' ? 0 : (Number(offsetH)*60+Number(offsetM))*(sign === '+' ? 1 : -1);
  const result = new Date(local.getTime()-offset*60_000);
  return Number.isFinite(result.getTime()) ? result : null;
}

export type TimeContext = { departureAt:string; planComputedAt:string; returnBy?:string; effectiveMinutes:number };
export type TimeFailure = { error:'invalid-departure'|'past-departure'|'invalid-return'|'return-before-departure'|'budget-expired'|'budget-too-long' };
export function resolvePlanTime(request:PlanRequest, computedAt = new Date(), enforcePast = false): TimeContext | TimeFailure {
  const supplied = request.now === undefined ? computedAt : parseIsoInstant(request.now);
  if (!supplied) return {error:'invalid-departure'};
  const departure = request.departureMode === 'now' ? computedAt : supplied;
  if (enforcePast && request.departureMode === 'custom' && departure.getTime() < computedAt.getTime()) return {error:'past-departure'};
  let effectiveMinutes = request.minutes;
  let returnBy:Date|null = null;
  if (request.returnBy !== undefined) {
    returnBy = parseIsoInstant(request.returnBy);
    if (!returnBy) return {error:'invalid-return'};
    if (returnBy.getTime() <= departure.getTime()) return {error:'return-before-departure'};
    effectiveMinutes = Math.floor((returnBy.getTime()-departure.getTime())/60_000);
    if (effectiveMinutes < 5) return {error:'budget-expired'};
    if (effectiveMinutes > 360) return {error:'budget-too-long'};
  }
  return {departureAt:departure.toISOString(),planComputedAt:computedAt.toISOString(),effectiveMinutes,...(returnBy?{returnBy:returnBy.toISOString()}:{})};
}

/** A datetime-local value is an Almaty wall clock, never the browser's timezone. */
export function almatyLocalToISO(value:string):string|null {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/.test(value)) return null;
  const parsed = parseIsoInstant(`${value}+05:00`);
  return parsed?.toISOString() ?? null;
}
