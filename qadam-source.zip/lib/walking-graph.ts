export type GraphPoint = { lat: number; lon: number };
export type RawWalkingGraph = {
  nodes: number[][]; edges: number[][]; stepEdges?: number[];
  source?: string; fetchedAt?: string; directed?: boolean;
};
export type GraphLeg = { meters: number; coordinates: [number, number][]; connectorMeters: number };

type Snap = { index: number; meters: number; point: GraphPoint };
type Search = { distances: Float64Array; previous: Int32Array };

const EARTH_RADIUS = 6_371_000;
const RAD = Math.PI / 180;
function distance(a: GraphPoint, b: GraphPoint): number {
  const y = Math.sin((b.lat - a.lat) * RAD / 2) ** 2 + Math.cos(a.lat * RAD) * Math.cos(b.lat * RAD) * Math.sin((b.lon - a.lon) * RAD / 2) ** 2;
  return EARTH_RADIUS * 2 * Math.atan2(Math.sqrt(y), Math.sqrt(Math.max(0, 1 - y)));
}

/** Compact binary min heap: no per-vertex JS objects and no O(V²) scan. */
class MinHeap {
  private nodes = new Uint32Array(1024);
  private costs = new Float64Array(1024);
  size = 0;

  push(node: number, cost: number): void {
    if (this.size === this.nodes.length) {
      const nodes = new Uint32Array(this.nodes.length * 2); nodes.set(this.nodes); this.nodes = nodes;
      const costs = new Float64Array(this.costs.length * 2); costs.set(this.costs); this.costs = costs;
    }
    let position = this.size++;
    while (position > 0) {
      const parent = (position - 1) >>> 1;
      if (this.costs[parent] <= cost) break;
      this.nodes[position] = this.nodes[parent]; this.costs[position] = this.costs[parent]; position = parent;
    }
    this.nodes[position] = node; this.costs[position] = cost;
  }

  pop(): [number, number] {
    const result: [number, number] = [this.nodes[0], this.costs[0]];
    const last = --this.size;
    if (!last) return result;
    const node = this.nodes[last]; const cost = this.costs[last];
    let position = 0;
    while (position * 2 + 1 < last) {
      let child = position * 2 + 1;
      if (child + 1 < last && this.costs[child + 1] < this.costs[child]) child++;
      if (this.costs[child] >= cost) break;
      this.nodes[position] = this.nodes[child]; this.costs[position] = this.costs[child]; position = child;
    }
    this.nodes[position] = node; this.costs[position] = cost;
    return result;
  }
}

/**
 * CSR adjacency is about 4 MB for the current Astana snapshot. The temporary
 * OSM-ID map exists only during construction; request search trees are scoped
 * to a session so their memory can be reclaimed between requests.
 */
export class WalkingGraph {
  readonly nodeCount: number;
  readonly edgeCount: number;
  readonly source: string;
  readonly fetchedAt: string;
  private latitudes: Float64Array;
  private longitudes: Float64Array;
  private offsets: Uint32Array;
  private neighbours: Uint32Array;
  private lengths: Float64Array;
  private stairs: Uint8Array;

  constructor(raw: RawWalkingGraph) {
    if (raw.directed === true) throw new Error('The walking snapshot must be undirected.');
    this.nodeCount = raw.nodes.length;
    this.edgeCount = raw.edges.length;
    this.source = raw.source ?? 'OpenStreetMap';
    this.fetchedAt = raw.fetchedAt ?? '';
    this.latitudes = new Float64Array(this.nodeCount);
    this.longitudes = new Float64Array(this.nodeCount);
    this.offsets = new Uint32Array(this.nodeCount + 1);
    const ids = new Map<number, number>();
    raw.nodes.forEach((node, index) => {
      if (node.length < 3 || !Number.isFinite(node[1]) || !Number.isFinite(node[2]) || ids.has(node[0])) throw new Error('Invalid walking graph node.');
      ids.set(node[0], index); this.latitudes[index] = node[1]; this.longitudes[index] = node[2];
    });
    for (const [from, to, meters] of raw.edges) {
      const a = ids.get(from); const b = ids.get(to);
      if (a === undefined || b === undefined || !Number.isFinite(meters) || meters <= 0) throw new Error('Invalid walking graph edge.');
      this.offsets[a + 1]++; this.offsets[b + 1]++;
    }
    for (let i = 1; i < this.offsets.length; i++) this.offsets[i] += this.offsets[i - 1];
    this.neighbours = new Uint32Array(raw.edges.length * 2);
    this.lengths = new Float64Array(raw.edges.length * 2);
    this.stairs = new Uint8Array(raw.edges.length * 2);
    const next = this.offsets.slice(0, this.nodeCount);
    const stepIndexes = new Set(raw.stepEdges ?? []);
    raw.edges.forEach(([from, to, meters], index) => {
      const a = ids.get(from)!; const b = ids.get(to)!;
      const forward = next[a]++; const backward = next[b]++;
      this.neighbours[forward] = b; this.neighbours[backward] = a;
      this.lengths[forward] = meters; this.lengths[backward] = meters;
      this.stairs[forward] = this.stairs[backward] = Number(stepIndexes.has(index));
    });
  }

  snap(point: GraphPoint, maxMeters: number): Snap | null {
    if (!Number.isFinite(point.lat) || !Number.isFinite(point.lon)) return null;
    const lonScale = 111_195 * Math.cos(point.lat * RAD);
    let nearest = -1;
    let bestSquared = (maxMeters + 1) ** 2;
    // Equirectangular screening is exact enough over 200 m; the final distance
    // and threshold use great-circle distance, not this screening projection.
    for (let i = 0; i < this.nodeCount; i++) {
      if (this.offsets[i] === this.offsets[i + 1]) continue;
      const north = (this.latitudes[i] - point.lat) * 111_195;
      if (Math.abs(north) > maxMeters + 1) continue;
      const east = (this.longitudes[i] - point.lon) * lonScale;
      const squared = north * north + east * east;
      if (squared < bestSquared) { bestSquared = squared; nearest = i; }
    }
    if (nearest < 0) return null;
    const meters = distance(point, { lat: this.latitudes[nearest], lon: this.longitudes[nearest] });
    return meters <= maxMeters ? { index: nearest, meters, point } : null;
  }

  search(source: number, avoidSteps: boolean): Search {
    const distances = new Float64Array(this.nodeCount); distances.fill(Infinity); distances[source] = 0;
    const previous = new Int32Array(this.nodeCount); previous.fill(-1);
    const heap = new MinHeap(); heap.push(source, 0);
    while (heap.size) {
      const [node, cost] = heap.pop();
      if (cost !== distances[node]) continue;
      for (let edge = this.offsets[node]; edge < this.offsets[node + 1]; edge++) {
        if (avoidSteps && this.stairs[edge]) continue;
        const to = this.neighbours[edge]; const nextCost = cost + this.lengths[edge];
        if (nextCost < distances[to]) {
          distances[to] = nextCost; previous[to] = node; heap.push(to, nextCost);
        }
      }
    }
    return { distances, previous };
  }

  coordinate(index: number): [number, number] { return [this.longitudes[index], this.latitudes[index]]; }

  createSession(origin: GraphPoint, options: { maxSnapMeters?: number; avoidSteps?: boolean } = {}): WalkingSession | null {
    const maxSnap = options.maxSnapMeters ?? 200;
    if (maxSnap < 0 || maxSnap > 200) throw new Error('Walking graph snap limit must be at most 200 m.');
    const start = this.snap(origin, maxSnap);
    return start ? new WalkingSession(this, start, maxSnap, options.avoidSteps ?? false) : null;
  }
}

export class WalkingSession {
  private snaps = new Map<string, Snap | null>();
  private searches = new Map<number, Search>();
  readonly origin: GraphPoint;
  searchCount = 0;
  maxConnectorMeters = 0;
  private graph: WalkingGraph;
  private maxSnap: number;
  private avoidSteps: boolean;

  constructor(graph: WalkingGraph, origin: Snap, maxSnap: number, avoidSteps: boolean) {
    this.graph = graph; this.maxSnap = maxSnap; this.avoidSteps = avoidSteps;
    this.origin = origin.point;
    this.snaps.set(this.key(origin.point), origin);
    this.maxConnectorMeters = origin.meters;
    this.getSearch(origin.index);
  }

  private key(point: GraphPoint): string { return `${point.lat},${point.lon}`; }
  private getSnap(point: GraphPoint): Snap | null {
    const key = this.key(point);
    if (!this.snaps.has(key)) this.snaps.set(key, this.graph.snap(point, this.maxSnap));
    const result = this.snaps.get(key)!;
    if (result) this.maxConnectorMeters = Math.max(this.maxConnectorMeters, result.meters);
    return result;
  }

  private getSearch(index: number): Search {
    if (!this.searches.has(index)) {
      // Origin plus at most three selected stop sources. This bound prevents a
      // route request from turning into all-pairs shortest paths over 81k nodes.
      if (this.searchCount >= 4) throw new Error('Walking graph search limit exceeded.');
      this.searches.set(index, this.graph.search(index, this.avoidSteps)); this.searchCount++;
    }
    return this.searches.get(index)!;
  }

  distanceBetween(from: GraphPoint, to: GraphPoint): number | null {
    const a = this.getSnap(from); const b = this.getSnap(to);
    if (!a || !b) return null;
    const network = this.getSearch(a.index).distances[b.index];
    return Number.isFinite(network) ? a.meters + network + b.meters : null;
  }

  leg(from: GraphPoint, to: GraphPoint): GraphLeg | null {
    const a = this.getSnap(from); const b = this.getSnap(to);
    if (!a || !b) return null;
    const search = this.getSearch(a.index);
    const network = search.distances[b.index];
    if (!Number.isFinite(network)) return null;
    const path: number[] = [];
    let node = b.index;
    while (node !== a.index) {
      path.push(node); node = search.previous[node];
      if (node < 0 || path.length > this.graph.nodeCount) return null;
    }
    path.push(a.index); path.reverse();
    const coordinates: [number, number][] = [[from.lon, from.lat], ...path.map(index => this.graph.coordinate(index)), [to.lon, to.lat]];
    return { meters: a.meters + network + b.meters, connectorMeters: a.meters + b.meters, coordinates: coordinates.filter((coordinate, i) => !i || coordinate[0] !== coordinates[i - 1][0] || coordinate[1] !== coordinates[i - 1][1]) };
  }
}
