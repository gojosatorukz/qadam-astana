export function throwIfAborted(signal?:AbortSignal):void {
  if (signal?.aborted) throw new DOMException('Request cancelled','AbortError');
}
export function isAbortError(error:unknown):boolean {
  return error instanceof Error && error.name === 'AbortError';
}
export class StageTimeout extends Error { constructor(){super('Stage timeout');this.name='TimeoutError';} }
/** Also bounds mocks/transports which ignore AbortSignal; listeners are released. */
export async function boundedOperation<T>(operation:(signal:AbortSignal)=>Promise<T>,timeoutMs:number,parent?:AbortSignal):Promise<T> {
  throwIfAborted(parent);
  const controller = new AbortController();
  let timer:ReturnType<typeof setTimeout>|undefined;
  let listener:(()=>void)|undefined;
  const stop = new Promise<never>((_,reject)=>{
    timer=setTimeout(()=>{controller.abort();reject(new StageTimeout());},Math.max(1,Math.floor(timeoutMs)));
    if(parent){listener=()=>{controller.abort();reject(new DOMException('Request cancelled','AbortError'));};parent.addEventListener('abort',listener,{once:true});}
  });
  try{return await Promise.race([Promise.resolve().then(()=>operation(controller.signal)),stop]);}
  finally{if(timer!==undefined)clearTimeout(timer);if(parent&&listener)parent.removeEventListener('abort',listener);}
}
