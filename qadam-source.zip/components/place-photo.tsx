'use client';
import { useState } from 'react';
import { getPlacePhoto } from '@/lib/place-photos';
import type { Language } from '@/lib/experience';

/** Only reviewed identity matches receive an actual venue photograph. */
export default function PlacePhoto({ poiId, language }: { poiId: string; language: Language }) {
  const photo = getPlacePhoto(poiId), [failed, setFailed] = useState(false);
  if (!photo || failed) return null;
  return <figure className="place-photo"><img src={photo.path} alt={photo.caption[language]} width={photo.width} height={photo.height} loading="lazy" onError={() => setFailed(true)}/><figcaption><a href={photo.sourceUrl} target="_blank" rel="noreferrer">{photo.author} · {photo.capturedAt.slice(0,4)}</a><a href={photo.licenseUrl} target="_blank" rel="noreferrer">{photo.license}</a><span>{language === 'en' ? 'Source photograph · cropped' : language === 'kk' ? 'Дереккөз фотосы · қиылған' : 'Фото из источника · кадрировано'}</span></figcaption></figure>;
}
