/** Small, dependency-free Web Mercator helpers shared by the raster map/tests. */
export type MapPoint = { lat: number; lon: number };
export type MapSize = { width: number; height: number };
export type MapView = { center: MapPoint; zoom: number };
export type MapPixel = { x: number; y: number };
export type MapPadding = { top: number; right: number; bottom: number; left: number };
export const TILE_SIZE = 256;
export const MIN_MAP_ZOOM = 10;
export const MAX_MAP_ZOOM = 18;
/** Bounds of the collected POI snapshot, not proof of walking-graph coverage. */
export const POI_SNAPSHOT_BOUNDS = { south: 51.065, north: 51.205, west: 71.35, east: 71.515 } as const;
const MERCATOR_LATITUDE = 85.05112878;
const clamp = (value: number, low: number, high: number) => Math.max(low, Math.min(high, value));

export function projectMapPoint(point: MapPoint, zoom: number): { x: number; y: number } {
  const scale = TILE_SIZE * 2 ** zoom;
  const sine = Math.sin(clamp(point.lat, -MERCATOR_LATITUDE, MERCATOR_LATITUDE) * Math.PI / 180);
  return { x: (point.lon + 180) / 360 * scale, y: (.5 - Math.log((1 + sine) / (1 - sine)) / (4 * Math.PI)) * scale };
}
export function unprojectMapPoint(x: number, y: number, zoom: number): MapPoint {
  const scale = TILE_SIZE * 2 ** zoom;
  return { lon: ((x / scale * 360) % 360 + 360) % 360 - 180,
    lat: clamp(Math.atan(Math.sinh(Math.PI * (1 - 2 * y / scale))) * 180 / Math.PI, -MERCATOR_LATITUDE, MERCATOR_LATITUDE) };
}
export function pointOnMap(point: MapPoint, view: MapView, size: MapSize): { x: number; y: number } {
  const center = projectMapPoint(view.center, view.zoom), projected = projectMapPoint(point, view.zoom);
  return { x: projected.x - center.x + size.width / 2, y: projected.y - center.y + size.height / 2 };
}
export function coordinateAtMapPixel(x: number, y: number, view: MapView, size: MapSize): MapPoint {
  const center = projectMapPoint(view.center, view.zoom);
  return unprojectMapPoint(center.x + x - size.width / 2, center.y + y - size.height / 2, view.zoom);
}
export function isMapTap(dx: number, dy: number, threshold = 7): boolean { return dx * dx + dy * dy <= threshold * threshold; }

/** Keep the geographic point beneath the fingers fixed as they zoom and move. */
export function pinchMapView(view: MapView, size: MapSize, start: [MapPixel, MapPixel], current: [MapPixel, MapPixel]): MapView {
  const startDistance = Math.hypot(start[1].x - start[0].x, start[1].y - start[0].y);
  const currentDistance = Math.hypot(current[1].x - current[0].x, current[1].y - current[0].y);
  if (startDistance < 1 || currentDistance < 1) return view;
  const initialMidpoint = { x: (start[0].x + start[1].x) / 2, y: (start[0].y + start[1].y) / 2 };
  const midpoint = { x: (current[0].x + current[1].x) / 2, y: (current[0].y + current[1].y) / 2 };
  const anchor = coordinateAtMapPixel(initialMidpoint.x, initialMidpoint.y, view, size);
  const zoom = clamp(view.zoom + Math.log2(currentDistance / startDistance), MIN_MAP_ZOOM, MAX_MAP_ZOOM);
  const projected = projectMapPoint(anchor, zoom);
  return { center: unprojectMapPoint(projected.x - midpoint.x + size.width / 2, projected.y - midpoint.y + size.height / 2, zoom), zoom };
}

export function fitMapPoints(
  points: MapPoint[], size: MapSize,
  { padding = { top: 56, right: 64, bottom: 76, left: 32 }, minZoom = MIN_MAP_ZOOM, maxZoom = 17 }:
    { padding?: MapPadding; minZoom?: number; maxZoom?: number } = {},
): MapView {
  const usable = points.filter(point => Number.isFinite(point.lat) && Number.isFinite(point.lon));
  if (!usable.length) return { center: { lat: 51.12828, lon: 71.43055 }, zoom: 14 };
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const point of usable) {
    const p = projectMapPoint(point, 0);
    minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
  }
  const width = Math.max(32, size.width - padding.left - padding.right), height = Math.max(32, size.height - padding.top - padding.bottom);
  const zoomX = maxX > minX ? Math.log2(width / (maxX - minX)) : maxZoom;
  const zoomY = maxY > minY ? Math.log2(height / (maxY - minY)) : maxZoom;
  const zoom = clamp(Math.floor(Math.min(zoomX, zoomY)), minZoom, maxZoom);
  const scale = 2 ** zoom;
  const center = unprojectMapPoint((minX + maxX) / 2 + (padding.right - padding.left) / (2 * scale),
    (minY + maxY) / 2 + (padding.bottom - padding.top) / (2 * scale), 0);
  return { center, zoom };
}

export function snapshotCorners(): MapPoint[] {
  const b = POI_SNAPSHOT_BOUNDS;
  return [{ lat: b.south, lon: b.west }, { lat: b.north, lon: b.west }, { lat: b.north, lon: b.east }, { lat: b.south, lon: b.east }];
}

type MappablePOI = MapPoint & { id: string; category: string; name: string };
type Candidate<T> = { poi: T; x: number; y: number; cell: string; generic: boolean; cellDistance: number };
function genericName(name: string): boolean {
  return !name.trim() || /\bosm\b|^\s*(?:cafe|park|museum|art|кафе|парк|музей|кофехана|саябақ)\s*$/i.test(name);
}
/** Spatial/category sampling, independent of the dataset's row order. */
export function balancedViewportPOIs<T extends MappablePOI>(pois: T[], view: MapView, size: MapSize, limit?: number): T[] {
  if (size.width <= 0 || size.height <= 0) return [];
  const maximum = limit ?? clamp(Math.floor(size.width * size.height / 16_000), 10, 38);
  const cellSize = size.width < 500 ? 66 : 80;
  const buckets = new Map<string, Map<string, Candidate<T>>>();
  for (const poi of pois) {
    if (!Number.isFinite(poi.lat) || !Number.isFinite(poi.lon)) continue;
    const p = pointOnMap(poi, view, size);
    if (p.x < 24 || p.x > size.width - 24 || p.y < 52 || p.y > size.height - 36) continue;
    const col = Math.floor(p.x / cellSize), row = Math.floor(p.y / cellSize), cell = `${col}:${row}`;
    const candidate = { poi, x: p.x, y: p.y, cell, generic: genericName(poi.name), cellDistance: (p.x - (col + .5) * cellSize) ** 2 + (p.y - (row + .5) * cellSize) ** 2 };
    const category = poi.category === 'gallery' ? 'art' : poi.category;
    const bucket = buckets.get(category) ?? new Map<string, Candidate<T>>();
    const old = bucket.get(cell);
    if (!old || Number(candidate.generic) < Number(old.generic) || (candidate.generic === old.generic && (candidate.cellDistance < old.cellDistance
        || (candidate.cellDistance === old.cellDistance && candidate.poi.id.localeCompare(old.poi.id) < 0)))) bucket.set(cell, candidate);
    buckets.set(category, bucket);
  }
  // Rare visible categories get a chance before abundant cafés consume cells.
  const groups = [...buckets.entries()].sort((a, b) => a[1].size - b[1].size || a[0].localeCompare(b[0])).map(([, bucket]) => [...bucket.values()]);
  const selected: Candidate<T>[] = [], occupied = new Set<string>();
  const spacingSquared = (size.width < 500 ? 50 : 46) ** 2;
  while (selected.length < maximum) {
    let added = false;
    for (const group of groups) {
      let best: Candidate<T> | undefined, bestScore = -Infinity;
      for (const candidate of group) {
        if (occupied.has(candidate.cell)) continue;
        const distance = selected.length ? Math.min(...selected.map(other => (candidate.x - other.x) ** 2 + (candidate.y - other.y) ** 2)) : Infinity;
        if (distance < spacingSquared) continue;
        const score = (selected.length ? distance : -((candidate.x - size.width / 2) ** 2 + (candidate.y - size.height / 2) ** 2)) + (candidate.generic ? 0 : cellSize ** 2);
        if (score > bestScore || (score === bestScore && candidate.poi.id.localeCompare(best?.poi.id ?? '') < 0)) { best = candidate; bestScore = score; }
      }
      if (best) { selected.push(best); occupied.add(best.cell); added = true; }
      if (selected.length >= maximum) break;
    }
    if (!added) break;
  }
  return selected.map(candidate => candidate.poi);
}
