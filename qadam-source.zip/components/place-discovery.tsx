import { ExternalLink } from 'lucide-react';
import type { StopFact } from '@/lib/qadam-types';
import type { Language } from '@/lib/experience';

/** Two concise sourced details share one card; suggested observations stay outside it. */
export default function PlaceDiscovery({ facts, language }: { facts: StopFact[]; language: Language }) {
  if (!facts.length) return null;
  const selected = facts.slice(0, 2);
  const sources = [...new Set(selected.map(fact => fact.sourceUrl))];
  const label = language === 'en' ? 'A LITTLE DISCOVERY' : language === 'kk' ? 'ШАҒЫН ЖАҢАЛЫҚ' : 'МАЛЕНЬКОЕ ОТКРЫТИЕ';
  const sourceLabel = language === 'en' ? 'Fact source' : language === 'kk' ? 'Дерек көзі' : 'Источник факта';
  return <div className="place-discovery"><span className="discovery-kicker">{label}</span>
    {selected.map(fact => <p key={fact.id}>{fact.text}</p>)}
    <div className="fact-sources">{sources.map((url, i) => <a key={url} href={url} target="_blank" rel="noreferrer">{sourceLabel}{sources.length > 1 ? ' ' + (i + 1) : ''}<ExternalLink size={12}/></a>)}</div>
  </div>;
}
