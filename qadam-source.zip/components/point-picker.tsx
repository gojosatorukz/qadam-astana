'use client';
import { useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, LocateFixed, MapPin, Search, X } from 'lucide-react';
import CityMap from './city-map';
import { ORIGINS, isAstanaCoordinate } from '@/lib/experience';
import { categoryLabel, poiDisplayName } from '@/lib/ui-copy';
import { getPlaceEditorial } from '@/lib/place-facts';
import type { Origin, Language } from '@/lib/experience';
import type { POI } from '@/lib/qadam-types';

/** The whole phone viewport is a point picker. Tapping never exits pick mode. */
export default function PointPicker({ target, origin, initial, pois, language, onConfirm, onClose }: {
  target: 'origin' | 'destination'; origin: Origin; initial: Origin | null;
  pois: POI[]; language: Language; onConfirm: (point: Origin) => void; onClose: () => void;
}) {
  const L = (ru: string, en: string, kk: string) => language === 'en' ? en : language === 'kk' ? kk : ru;
  const [point, setPoint] = useState<Origin | null>(initial);
  const [search, setSearch] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [error, setError] = useState('');
  const [locating, setLocating] = useState(false);
  const [mapRevision, setMapRevision] = useState(0);
  const [coordinates, setCoordinates] = useState('');
  const input = useRef<HTMLInputElement>(null);
  const letter = target === 'origin' ? 'A' : 'B';
  function choose(value: Origin, recenter = false) {
    if (!isAstanaCoordinate(value)) { setError(L('Эта точка вне поддерживаемой области Астаны. Выбери ближе к городу.', 'This point is outside the supported Astana area. Pick closer to the city.', 'Бұл нүкте Астананың қолдау аумағынан тыс. Қалаға жақынырақ таңда.')); return; }
    setPoint(value); setError(''); setSearchOpen(false); input.current?.blur();
    if (recenter) setMapRevision(n => n + 1);
  }
  function locate() {
    if (!navigator.geolocation) { setError(L('Локация недоступна. Нажми на карту или найди место.', 'Location is unavailable. Tap the map or search.', 'Орның қолжетімсіз. Картадан таңда не ізде.')); return; }
    setLocating(true); setError('');
    navigator.geolocation.getCurrentPosition(position => {
      setLocating(false);
      choose({ lat: position.coords.latitude, lon: position.coords.longitude, label: L('Моя точка', 'My location', 'Менің орным') }, true);
    }, () => { setLocating(false); setError(L('Не удалось получить локацию. Выбери точку на карте.', 'Could not read your location. Pick a map point.', 'Орның анықталмады. Картадан нүкте таңда.')); }, { timeout: 8000, maximumAge: 30000 });
  }
  const seen = new Set<string>(), term = search.trim().toLocaleLowerCase();
  const matches = term ? pois.filter(poi => {
    const editorial = getPlaceEditorial(poi.id), id = editorial?.canonicalId ?? poi.id;
    if (seen.has(id)) return false;
    const names = [poi.name, poi.tags.name, poi.tags['name:ru'], poi.tags['name:en'], poi.tags['name:kk'], ...Object.values(editorial?.name ?? {})].filter(Boolean).join(' ');
    if (!names.toLocaleLowerCase().includes(term)) return false;
    seen.add(id); return true;
  }).slice(0, 8) : [];
  return <section className="point-picker">
    <header className="point-picker-header"><button onClick={onClose} aria-label={L('Закрыть выбор точки', 'Close point picker', 'Нүкте таңдауды жабу')}><ArrowLeft size={22}/></button><div><small>{L('ТОЧКА ', 'POINT ', 'НҮКТЕ ')}{letter}</small><h2 id="modal-title">{target === 'origin' ? L('Откуда идёшь?', 'Where from?', 'Қайдан шығасың?') : L('Куда нужно успеть?', 'Where do you need to be?', 'Қайда үлгеру керек?')}</h2></div><span className={'endpoint-badge endpoint-' + letter.toLowerCase()}>{letter}</span></header>
    <div className="point-search-area">
      <label className="point-search"><Search size={20}/><input ref={input} value={search} onFocus={() => setSearchOpen(true)} onChange={e => { setSearch(e.target.value); setSearchOpen(true); }} placeholder={L('Найти место или выбрать на карте', 'Search a place or tap the map', 'Орынды ізде не картадан таңда')} aria-label={L('Поиск точки ' + letter, 'Find point ' + letter, letter + ' нүктесін іздеу')}/>{searchOpen && <button onClick={() => { setSearchOpen(false); input.current?.blur(); }} aria-label={L('Скрыть поиск', 'Hide search', 'Іздеуді жасыру')}><X size={18}/></button>}</label>
      {searchOpen && <div className="point-search-results">
        {(term ? matches.map(poi => ({ ...poi, label: poiDisplayName(poi, language), categoryName: categoryLabel(poi.category, language) })) : ORIGINS.map(p => ({ ...p, label: p.labels[language], categoryName: L('Ориентир', 'Landmark', 'Бағдар') }))).map(p => <button key={p.label + p.lat} onClick={() => choose({ lat: p.lat, lon: p.lon, label: p.label }, true)}><MapPin size={18}/><span><b>{p.label}</b><small>{p.categoryName}</small></span><ArrowRight size={17}/></button>)}
        {term && !matches.length && <p>{L('В нашем снимке название не найдено. Поставь любую точку на карте ниже.', 'This name is not in our snapshot. Pick a point on the map below.', 'Атау деректерден табылмады. Төмендегі картадан нүкте таңда.')}</p>}
        <details className="point-coordinates"><summary>{L('Ввести координаты', 'Enter coordinates', 'Координаттарды енгізу')}</summary><div><input aria-label={L('Широта, долгота', 'Latitude, longitude', 'Ендік, бойлық')} value={coordinates} onChange={e => setCoordinates(e.target.value)} placeholder="51.12828, 71.43055"/><button onClick={() => { const pair = coordinates.trim().split(/[,;\s]+/).map(Number); if (pair.length !== 2 || !isAstanaCoordinate({ lat: pair[0], lon: pair[1] })) { setError(L('Нужны широта и долгота в Астане.', 'Enter latitude and longitude within Astana.', 'Астанадағы ендік пен бойлықты енгіз.')); return; } choose({ lat: pair[0], lon: pair[1], label: L('Моя точка ', 'My point ', 'Менің нүктем ') + letter }, true); }} aria-label={L('Выбрать координаты', 'Use coordinates', 'Координаттарды таңдау')}><Check size={20}/></button></div></details>
      </div>}
    </div>
    <div className="point-picker-map"><CityMap key={mapRevision} origin={target === 'origin' ? point ?? origin : origin} destination={target === 'destination' ? point ?? undefined : undefined} pois={pois} plan={null} language={language} pickingOrigin onOriginSelect={value => choose({ ...value, label: value.label === L('Точка на карте', 'Map point', 'Картадағы нүкте') ? L('Точка ', 'Point ', 'Нүкте ') + letter : value.label })} onSelect={poi => choose({ lat: poi.lat, lon: poi.lon, label: poiDisplayName(poi, language) })} pickingLabel={L('Нажми в любом месте карты · двигай и приближай двумя пальцами', 'Tap anywhere · move and pinch with two fingers', 'Кез келген жерді бас · екі саусақпен жылжыт және үлкейт')} showCoverage/>
      <button className="point-locate" onClick={locate} disabled={locating}><LocateFixed size={19}/>{locating ? L('Определяем…', 'Locating…', 'Іздеудеміз…') : L('Моя локация', 'My location', 'Менің орным')}</button>
    </div>
    <footer className="point-picker-footer">
      {error && <p className="point-error" role="alert">{error}</p>}
      <div className="point-selection" aria-live="polite"><span className={'endpoint-badge endpoint-' + letter.toLowerCase()}>{letter}</span><div><b>{point?.label ?? L('Нажми, где нужно закончить путь', 'Tap where your walk should end', 'Бағыт аяқталатын жерді бас')}</b><small>{point ? point.lat.toFixed(5) + ', ' + point.lon.toFixed(5) : L('Можно выбрать место или свободную точку', 'Choose a place or any map point', 'Орын не картадан кез келген нүкте')}</small></div></div>
      <button className="primary-action" disabled={!point} onClick={() => point && onConfirm(point)}>{target === 'origin' ? L('Начать отсюда', 'Start here', 'Осы жерден бастау') : L('Прийти сюда', 'Finish here', 'Осы жерге келу')}<Check size={20}/></button>
    </footer>
  </section>;
}
