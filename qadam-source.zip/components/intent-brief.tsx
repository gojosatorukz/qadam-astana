'use client';
import { Check, Info, Sparkles, X } from 'lucide-react';
import type { IntentFeedback } from '@/lib/intent-types';
import { categoryLabel } from '@/lib/ui-copy';
import type { Language } from '@/lib/ui-copy';

export default function IntentBrief({ feedback, language, onManual }: { feedback: IntentFeedback; language: Language; onManual: () => void }) {
  const li = language === 'ru' ? 0 : language === 'en' ? 1 : 2;
  const c = (values: [string,string,string]) => values[li];
  const contract = feedback.contract;
  const statuses = {
    matched: ['Учтено в плане','Included in the plan','Жоспарда ескерілді'],
    partial: ['Выполнено частично','Partially matched','Ішінара орындалды'],
    empty: ['План пока не найден','No plan found yet','Жоспар табылмады'],
    'needs-clarification': ['Нужно уточнение','Clarification needed','Нақтылау қажет'],
  };
  const status = statuses[feedback.status][li];
  return <section className={`intent-brief intent-${feedback.status}`} aria-label={c(['Как понят запрос','How your request was understood','Сұрау қалай түсінілді'])}>
    <div className="intent-heading"><span><Sparkles size={13}/>{feedback.mode === 'gemini' ? c(['Gemini · разбор запроса','Gemini · request interpretation','Gemini · сұрауды түсіну']) : feedback.mode === 'manual' ? c(['Выбранные интересы','Selected interests','Таңдалған қызығушылықтар']) : c(['Разбор недоступен','Interpretation unavailable','Түсіндіру қолжетімсіз'])}</span><b>{status}</b></div>
    {!contract ? <><h3>{c(['Текст пока не удалось разобрать','We couldn’t interpret this text yet','Мәтінді түсіндіру мүмкін болмады'])}</h3><p>{c(['Уточни запрос или используй кнопки интересов. Не будем выдавать случайный маршрут за ответ на твою просьбу.','Rephrase your request or use the interest buttons. We won’t present an arbitrary route as a match.','Сұрауды нақтылаңыз немесе қызығушылық түймелерін таңдаңыз. Кездейсоқ бағытты сәйкес деп көрсетпейміз.'])}</p><button className="manual-recovery" onClick={onManual}>{c(['Выбрать интересы кнопками','Use the interest buttons','Түймелермен таңдау'])}</button></> : <>
      <h3>{c(['Вот как я понял','Here’s what I understood','Сұрауды былай түсіндім'])}</h3>
      <div className="intent-category-list">{contract.desiredCategories.length ? contract.desiredCategories.map((category, index) => <span key={category} className="intent-want">{index > 0 && <small>{contract.includeMode === 'all' ? c(['и','and','және']) : c(['или','or','немесе'])}</small>}{categoryLabel(category,language)}</span>) : <span className="intent-nearby">{c(['Места рядом','Places nearby','Жақын орындар'])}</span>}</div>
      {contract.excludedCategories.length > 0 && <p className="intent-exclusions"><X size={13}/><span>{c(['Исключаю: ','Excluding: ','Алып тастаймын: '])}{contract.excludedCategories.map(category => categoryLabel(category,language)).join(', ')}</span></p>}
      {feedback.achievedCategories.length > 0 && <p className="intent-achieved"><Check size={13}/><span>{c(['В плане: ','In the plan: ','Жоспарда: '])}{feedback.achievedCategories.map(category => categoryLabel(category,language)).join(', ')}</span></p>}
      {feedback.unmetCategories.length > 0 && <p className="intent-unmet"><Info size={13}/><span>{c(['Не удалось включить: ','Couldn’t include: ','Қосу мүмкін болмады: '])}{feedback.unmetCategories.map(category => categoryLabel(category,language)).join(', ')}</span></p>}
      {contract.unsupported.length > 0 && <div className="unsupported-wishes"><strong>{c(['Что осталось непроверенным','What remains unverified','Тексерілмеген шарттар'])}</strong>{contract.unsupported.map((wish,index) => <p key={`${wish.text}-${index}`}><Info size={12}/><span><q>{wish.text}</q> — {wish.reason === 'no-data' ? c(['нет достоверных данных','no reliable data','сенімді дерек жоқ']) : wish.reason === 'use-controls' ? c(['нужно уточнить условия в настройках','adjust the explicit controls','баптауларда нақтылау қажет']) : c(['это условие пока не поддерживается','this condition is not supported yet','бұл шарт әзірше қолдау таппайды'])}</span></p>)}</div>}
      {contract.needsClarification && <p className="intent-clarify">{c(['Уточни текст или настройки и построй план снова. Противоречащие условия автоматически не меняются.','Clarify the text or controls and build again. Conflicting controls are never changed automatically.','Мәтінді немесе баптауларды нақтылап, қайта жоспарлаңыз. Қайшы шарттар автоматты өзгермейді.'])}</p>}
      <p className="intent-disclosure">{feedback.mode === 'gemini' ? c(['Разбор AI виден тебе; маршрут и ограничения проверяет код.','You can review the AI interpretation; code checks the route and constraints.','AI түсіндіруі көрсетілген; бағыт пен шектеулерді код тексереді.']) : c(['План по выбранным категориям.','A plan based on your selected categories.','Таңдалған санаттар бойынша жоспар.'])}</p>
    </>}
  </section>;
}
