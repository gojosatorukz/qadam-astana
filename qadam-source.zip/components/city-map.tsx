"use client";
/* Public raster tiles use the browser's normal image cache. */
/* eslint-disable @next/next/no-img-element */
import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, PointerEvent as ReactPointerEvent } from 'react';
import { Plus, Minus, LocateFixed, Coffee, Trees, Landmark, Baby, Palette, BookOpen, Binoculars, Layers, Crosshair, ChevronDown, Route } from 'lucide-react';
import { poiDisplayName } from '@/lib/ui-copy';
import type { POI, PlanResponse } from '@/lib/qadam-types';
import { balancedViewportPOIs, coordinateAtMapPixel, fitMapPoints, isMapTap, MAX_MAP_ZOOM, MIN_MAP_ZOOM, pointOnMap, projectMapPoint, snapshotCorners, TILE_SIZE, unprojectMapPoint } from './city-map-geometry';
import type { MapPoint, MapSize, MapView } from './city-map-geometry';
import './city-map.css';

type Language = 'ru' | 'en' | 'kk';
type Origin = MapPoint & { label: string };
export type CityMapProps = {
  language?: Language; origin: Origin; pois: POI[]; plan: PlanResponse['plan']; onSelect: (poi: POI) => void;
  onOriginSelect?: (point: Origin) => void; pickingOrigin?: boolean;
  /** Snapshot bounds only, not proof of walking-graph coverage/connectivity. */
  showCoverage?: boolean;
};
const categoryStyle = {
  cafe: { color: '#db6b35', icon: Coffee }, park: { color: '#357d52', icon: Trees },
  museum: { color: '#756096', icon: Landmark }, art: { color: '#a74677', icon: Palette },
  library: { color: '#416e9b', icon: BookOpen }, playground: { color: '#a37618', icon: Baby },
  attraction: { color: '#075a63', icon: Landmark }, viewpoint: { color: '#287f96', icon: Binoculars },
} as const;
const text = {
  ru: { map: 'Карта мест Астаны', categories: 'Категории', start: 'Старт', selected: 'Точка на карте',
    picking: 'Нажмите на карту, чтобы выбрать старт. Для перемещения потяните карту.',
    zoomIn: 'Приблизить карту', zoomOut: 'Отдалить карту', fit: 'Показать весь маршрут', center: 'Показать начальную точку',
    coverage: 'Область снимка мест', coverageNote: 'Граница снимка POI. Покрытие и связность путей проверяются отдельно.',
    tiles: 'Подложка не загрузилась. Точки, выбор старта и расчёт доступны.', choose: 'Выбрать старт у', walking: 'Путь по графу OSM', estimated: 'Оценка пути',
    names: { cafe: 'Кафе', park: 'Природа', museum: 'Музеи', art: 'Искусство', library: 'Библиотеки', playground: 'Детские площадки', attraction: 'Достопримечательности', viewpoint: 'Видовые точки' },
  },
  en: { map: 'Map of Astana places', categories: 'Categories', start: 'Start', selected: 'Point on the map',
    picking: 'Tap the map to choose a start. Drag to move the map.', zoomIn: 'Zoom in', zoomOut: 'Zoom out', fit: 'Fit the whole route', center: 'Show the starting point',
    coverage: 'Place snapshot area', coverageNote: 'POI snapshot boundary. Path coverage and connectivity are checked separately.',
    tiles: 'Map tiles did not load. Places, start selection and planning still work.', choose: 'Start near', walking: 'OSM walking graph', estimated: 'Estimated path',
    names: { cafe: 'Cafés', park: 'Nature', museum: 'Museums', art: 'Art', library: 'Libraries', playground: 'Playgrounds', attraction: 'Landmarks', viewpoint: 'Viewpoints' },
  },
  kk: { map: 'Астана орындарының картасы', categories: 'Санаттар', start: 'Бастау', selected: 'Картадағы нүкте',
    picking: 'Бастау нүктесін таңдау үшін картаны түртіңіз. Картаны жылжыту үшін сүйреңіз.', zoomIn: 'Жақындату', zoomOut: 'Алыстату', fit: 'Толық бағытты көрсету', center: 'Бастапқы нүктені көрсету',
    coverage: 'Орындар дерегінің аумағы', coverageNote: 'POI деректерінің шекарасы. Жолдардың қамтылуы мен байланысы бөлек тексеріледі.',
    tiles: 'Карта қабаты жүктелмеді. Орындар, бастау нүктесін таңдау және есептеу қолжетімді.', choose: 'Осы жерден бастау:', walking: 'OSM жаяу жолдар графы', estimated: 'Жолдың бағасы',
    names: { cafe: 'Кофеханалар', park: 'Табиғат', museum: 'Мұражайлар', art: 'Өнер', library: 'Кітапханалар', playground: 'Ойын алаңдары', attraction: 'Көрікті орындар', viewpoint: 'Шолу орындары' },
  },
} as const;
const ignoreDrag = 'button,a,input,select,textarea,summary,[data-map-control]';
type Drag = { pointerId: number; x: number; y: number; centerX: number; centerY: number; zoom: number; moved: boolean };

export default function CityMap({ origin, pois, plan, onSelect, language = 'ru', onOriginSelect, pickingOrigin = false, showCoverage = false }: CityMapProps) {
  const copy = text[language], mapRef = useRef<HTMLDivElement>(null), drag = useRef<Drag | null>(null);
  const panFrame = useRef<number | null>(null), pendingPan = useRef<MapView | null>(null);
  const [size, setSize] = useState<MapSize>({ width: 0, height: 0 });
  const [view, setView] = useState<MapView>({ center: { lat: origin.lat, lon: origin.lon }, zoom: 14 });
  const [dragging, setDragging] = useState(false), [failedTiles, setFailedTiles] = useState<Set<string>>(() => new Set());
  const hasRoute = !!plan?.stops.length;
  useEffect(() => {
    const element = mapRef.current;
    if (!element) return;
    const measure = () => { const rect = element.getBoundingClientRect(); setSize(previous => previous.width === rect.width && previous.height === rect.height ? previous : { width: rect.width, height: rect.height }); };
    const observer = new ResizeObserver(measure); observer.observe(element);
    const initial = requestAnimationFrame(measure);
    return () => { observer.disconnect(); cancelAnimationFrame(initial); };
  }, []);
  useEffect(() => () => { if (panFrame.current !== null) cancelAnimationFrame(panFrame.current); }, []);
  const fitPoints = useMemo(() => [{ lat: origin.lat, lon: origin.lon }, ...(plan?.routeCoordinates ?? []).map(([lon, lat]) => ({ lat, lon })), ...(plan?.stops ?? []).map(stop => ({ lat: stop.poi.lat, lon: stop.poi.lon }))], [origin.lat, origin.lon, plan?.routeCoordinates, plan?.stops]);
  const fitted = useMemo(() => fitMapPoints(fitPoints, size, { maxZoom: hasRoute ? 17 : 14, padding: { top: 86, right: size.width < 500 ? 64 : 84, bottom: 88, left: 32 } }), [fitPoints, hasRoute, size]);
  const fitLat = fitted.center.lat, fitLon = fitted.center.lon, fitZoom = fitted.zoom;
  useEffect(() => {
    if (!size.width || !size.height) return;
    const frame = requestAnimationFrame(() => setView({ center: { lat: fitLat, lon: fitLon }, zoom: fitZoom }));
    return () => cancelAnimationFrame(frame);
  }, [fitLat, fitLon, fitZoom, size.width, size.height]);
  const centerPixel = projectMapPoint(view.center, view.zoom), left = centerPixel.x - size.width / 2, top = centerPixel.y - size.height / 2, tileCount = 2 ** view.zoom;
  const tiles = [];
  if (size.width && size.height) for (let x = Math.floor(left / TILE_SIZE); x <= Math.floor((left + size.width) / TILE_SIZE); x++) for (let y = Math.max(0, Math.floor(top / TILE_SIZE)); y <= Math.min(tileCount - 1, Math.floor((top + size.height) / TILE_SIZE)); y++) {
    const wrappedX = (x % tileCount + tileCount) % tileCount;
    tiles.push({ key: `${view.zoom}/${wrappedX}/${y}`, x: wrappedX, y, left: x * TILE_SIZE - left, top: y * TILE_SIZE - top });
  }
  const tileError = tiles.some(tile => failedTiles.has(tile.key));
  const shown = useMemo(() => hasRoute ? plan!.stops.map(stop => stop.poi) : balancedViewportPOIs(pois, view, size), [hasRoute, plan, pois, view, size]);
  const originScreen = pointOnMap(origin, view, size), route = (plan?.routeCoordinates ?? []).map(([lon, lat]) => pointOnMap({ lat, lon }, view, size));
  const routeKey = useMemo(() => `${plan?.stops.map(stop => stop.poi.id).join('|') ?? ''}:${plan?.routeCoordinates.length ?? 0}`, [plan?.stops, plan?.routeCoordinates]);
  const coverage = snapshotCorners().map(point => pointOnMap(point, view, size));
  function selectOrigin(point: MapPoint, label: string = copy.selected) {
    if (pickingOrigin && onOriginSelect) onOriginSelect({ lat: Number(point.lat.toFixed(6)), lon: Number(point.lon.toFixed(6)), label });
  }
  function pointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    if (drag.current || (event.pointerType === 'mouse' && event.button !== 0) || (event.target as HTMLElement).closest(ignoreDrag)) return;
    drag.current = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, centerX: centerPixel.x, centerY: centerPixel.y, zoom: view.zoom, moved: false };
    event.currentTarget.setPointerCapture(event.pointerId);
  }
  function pointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId) return;
    const dx = event.clientX - current.x, dy = event.clientY - current.y;
    if (!current.moved && isMapTap(dx, dy)) return;
    if (!current.moved) { current.moved = true; setDragging(true); }
    pendingPan.current = { center: unprojectMapPoint(current.centerX - dx, current.centerY - dy, current.zoom), zoom: current.zoom };
    if (panFrame.current === null) panFrame.current = requestAnimationFrame(() => { if (pendingPan.current) setView(pendingPan.current); panFrame.current = null; });
  }
  function finishPointer(event: ReactPointerEvent<HTMLDivElement>, cancelled = false) {
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId) return;
    if (panFrame.current !== null) { cancelAnimationFrame(panFrame.current); panFrame.current = null; }
    if (current.moved && pendingPan.current) setView(pendingPan.current);
    const tap = !cancelled && !current.moved && isMapTap(event.clientX - current.x, event.clientY - current.y);
    drag.current = null; pendingPan.current = null; setDragging(false);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    if (tap && pickingOrigin && onOriginSelect) { const rect = event.currentTarget.getBoundingClientRect(); selectOrigin(coordinateAtMapPixel(event.clientX - rect.left, event.clientY - rect.top, view, size)); }
  }
  function changeZoom(amount: number) { setView(previous => ({ ...previous, zoom: Math.max(MIN_MAP_ZOOM, Math.min(MAX_MAP_ZOOM, previous.zoom + amount)) })); }
  function tileFailed(key: string) {
    setFailedTiles(previous => { if (previous.has(key)) return previous; const next = new Set(previous); next.add(key); if (next.size > 80) next.delete(next.values().next().value!); return next; });
  }
  return <div className={`city-map cm-map${pickingOrigin ? ' cm-picking' : ''}${dragging ? ' cm-dragging' : ''}`} ref={mapRef} role="region" aria-label={copy.map}
    onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={event => finishPointer(event)} onPointerCancel={event => finishPointer(event, true)} onLostPointerCapture={event => finishPointer(event, true)}>
    <div className="cm-tiles" aria-hidden="true">{tiles.map(tile => <img key={tile.key} src={`https://tile.openstreetmap.org/${view.zoom}/${tile.x}/${tile.y}.png`} alt="" draggable={false} width={TILE_SIZE} height={TILE_SIZE} style={{ transform: `translate3d(${tile.left}px,${tile.top}px,0)` }} onError={() => tileFailed(tile.key)} onLoad={() => setFailedTiles(previous => { if (!previous.has(tile.key)) return previous; const next = new Set(previous); next.delete(tile.key); return next; })} />)}</div>
    {showCoverage && <svg className="cm-coverage" width={size.width} height={size.height} aria-hidden="true"><polygon points={coverage.map(point => `${point.x},${point.y}`).join(' ')} /></svg>}
    {route.length > 1 && <svg className="cm-route" width={size.width} height={size.height} aria-hidden="true" key={routeKey}><polyline className="cm-route-halo" points={route.map(point => `${point.x},${point.y}`).join(' ')} /><polyline className={`cm-route-stroke${plan?.routeKind === 'estimate' ? ' cm-route-estimate' : ''}`} points={route.map(point => `${point.x},${point.y}`).join(' ')} /></svg>}
    <div className="cm-origin" style={{ left: originScreen.x, top: originScreen.y }} title={`${copy.start}: ${origin.label}`} aria-hidden="true"><span /><small>{copy.start}</small></div>
    {shown.map((poi, index) => {
      const category = (poi.category === 'gallery' ? 'art' : poi.category) as keyof typeof categoryStyle, styling = categoryStyle[category] ?? categoryStyle.attraction;
      const Icon = styling.icon, name = poiDisplayName(poi, language), categoryName = copy.names[category] ?? copy.names.attraction, position = pointOnMap(poi, view, size);
      return <button type="button" key={poi.id} className={`cm-poi${hasRoute ? ' cm-stop' : ''}`} style={{ left: position.x, top: position.y, '--poi-color': styling.color } as CSSProperties} onClick={() => pickingOrigin && onOriginSelect ? selectOrigin(poi, name) : onSelect(poi)} aria-label={pickingOrigin ? `${copy.choose} ${name}` : `${name} · ${categoryName}`} title={`${name} · ${categoryName}`}>
        {hasRoute ? <><b>{index + 1}</b><span className="cm-stop-category"><Icon size={11} /></span></> : <Icon size={16} />}
        <span className="cm-tooltip"><strong>{name}</strong><small>{categoryName}</small></span>
      </button>;
    })}
    {pickingOrigin && <div className="cm-pick-hint" role="status"><Crosshair size={18} /><span>{copy.picking}</span></div>}
    <div className="cm-controls" data-map-control><button type="button" onClick={() => changeZoom(1)} disabled={view.zoom >= MAX_MAP_ZOOM} aria-label={copy.zoomIn} title={copy.zoomIn}><Plus size={20} /></button><button type="button" onClick={() => changeZoom(-1)} disabled={view.zoom <= MIN_MAP_ZOOM} aria-label={copy.zoomOut} title={copy.zoomOut}><Minus size={20} /></button><span /><button type="button" onClick={() => setView({ center: { lat: fitLat, lon: fitLon }, zoom: fitZoom })} aria-label={hasRoute ? copy.fit : copy.center} title={hasRoute ? copy.fit : copy.center}><LocateFixed size={19} /></button>{showCoverage && <button type="button" onClick={() => setView(fitMapPoints(snapshotCorners(), size, { maxZoom: 14 }))} aria-label={copy.coverage} title={copy.coverage}><Layers size={19} /></button>}</div>
    <details className="cm-legend" data-map-control><summary><Layers size={15} /><span>{copy.categories}</span><ChevronDown size={14} /></summary><div className="cm-legend-grid">{Object.entries(categoryStyle).map(([category, styling]) => { const Icon = styling.icon; return <span key={category}><Icon size={14} style={{ color: styling.color }} /><span>{copy.names[category as keyof typeof categoryStyle]}</span></span>; })}</div>{hasRoute && <p className="cm-route-note"><Route size={13} />{plan?.routeKind === 'walking' ? copy.walking : copy.estimated}</p>}{showCoverage && <p className="cm-coverage-note">{copy.coverageNote}</p>}</details>
    {showCoverage && <span className="cm-snapshot-label" data-map-control>{copy.coverage}</span>}
    {tileError && <div className="cm-tile-error" role="status">{copy.tiles}</div>}
    <div className="cm-attribution" data-map-control>© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors</div>
  </div>;
}
