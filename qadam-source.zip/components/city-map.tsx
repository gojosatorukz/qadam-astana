"use client";
/* Public raster tiles use the browser's normal image cache. */
/* eslint-disable @next/next/no-img-element */
import { useEffect, useId, useMemo, useRef, useState } from 'react';
import type { CSSProperties, KeyboardEvent as ReactKeyboardEvent, PointerEvent as ReactPointerEvent } from 'react';
import { Plus, Minus, LocateFixed, Coffee, Utensils, Trees, Landmark, Baby, Palette, BookOpen, Binoculars, Layers, Crosshair, ChevronDown, Route } from 'lucide-react';
import { poiDisplayName } from '@/lib/ui-copy';
import type { POI, PlanResponse } from '@/lib/qadam-types';
import { balancedViewportPOIs, coordinateAtMapPixel, fitMapPoints, isMapTap, MAX_MAP_ZOOM, MIN_MAP_ZOOM, pinchMapView, pointOnMap, projectMapPoint, snapshotCorners, TILE_SIZE, unprojectMapPoint } from './city-map-geometry';
import type { MapPixel, MapPoint, MapSize, MapView } from './city-map-geometry';
import './city-map.css';

type Language = 'ru' | 'en' | 'kk';
type Origin = MapPoint & { label: string };
export type CityMapProps = {
  language?: Language; origin: Origin; pois: POI[]; plan: PlanResponse['plan']; onSelect: (poi: POI) => void;
  onOriginSelect?: (point: Origin) => void; pickingOrigin?: boolean;
  destination?: Origin;
  /** Parent chooses whether a picked point is A or B and confirms it explicitly. */
  pickingLabel?: string;
  /** Focus mode retains zoom/fit and attribution, without explanatory overlays. */
  hideChrome?: boolean;
  /** A picker can expand without resetting the user's current map position. */
  preserveViewOnResize?: boolean;
  /** Snapshot bounds only, not proof of walking-graph coverage/connectivity. */
  showCoverage?: boolean;
};
const categoryStyle = {
  cafe: { color: '#db6b35', icon: Coffee }, food: { color: '#be4e34', icon: Utensils }, park: { color: '#357d52', icon: Trees },
  museum: { color: '#756096', icon: Landmark }, art: { color: '#a74677', icon: Palette },
  library: { color: '#416e9b', icon: BookOpen }, playground: { color: '#a37618', icon: Baby },
  attraction: { color: '#075a63', icon: Landmark }, viewpoint: { color: '#287f96', icon: Binoculars },
} as const;
const text = {
  ru: { map: 'Карта мест Астаны', categories: 'Категории', start: 'Старт', destination: 'Финиш', selected: 'Точка на карте',
    picking: 'Коснитесь любого места на карте. Двумя пальцами меняйте масштаб.', keyboard: 'Стрелки перемещают карту, плюс и минус меняют масштаб. Enter выбирает точку в центре.',
    zoomIn: 'Приблизить карту', zoomOut: 'Отдалить карту', fit: 'Показать весь маршрут', center: 'Показать начальную точку',
    coverage: 'Область снимка мест', coverageNote: 'Граница снимка POI. Покрытие и связность путей проверяются отдельно.',
    tiles: 'Подложка не загрузилась. Точки, выбор старта и расчёт доступны.', choose: 'Выбрать точку у', walking: 'Путь по графу OSM', estimated: 'Оценка пути',
    names: { cafe: 'Кофейни', food: 'Поесть', park: 'Природа', museum: 'Музеи', art: 'Искусство', library: 'Библиотеки', playground: 'Детские площадки', attraction: 'Достопримечательности', viewpoint: 'Видовые точки' },
  },
  en: { map: 'Map of Astana places', categories: 'Categories', start: 'Start', destination: 'Finish', selected: 'Point on the map',
    picking: 'Tap anywhere on the map. Use two fingers to zoom.', keyboard: 'Arrow keys move the map; plus and minus zoom. Enter selects the point at the centre.', zoomIn: 'Zoom in', zoomOut: 'Zoom out', fit: 'Fit the whole route', center: 'Show the starting point',
    coverage: 'Place snapshot area', coverageNote: 'POI snapshot boundary. Path coverage and connectivity are checked separately.',
    tiles: 'Map tiles did not load. Places, start selection and planning still work.', choose: 'Choose point near', walking: 'OSM walking graph', estimated: 'Estimated path',
    names: { cafe: 'Coffee', food: 'Food', park: 'Nature', museum: 'Museums', art: 'Art', library: 'Libraries', playground: 'Playgrounds', attraction: 'Landmarks', viewpoint: 'Viewpoints' },
  },
  kk: { map: 'Астана орындарының картасы', categories: 'Санаттар', start: 'Бастау', destination: 'Аяқтау', selected: 'Картадағы нүкте',
    picking: 'Картадағы кез келген жерді түртіңіз. Масштабты екі саусақпен өзгертіңіз.', keyboard: 'Көрсеткілер картаны жылжытады, плюс пен минус масштабты өзгертеді. Enter орталық нүктені таңдайды.', zoomIn: 'Жақындату', zoomOut: 'Алыстату', fit: 'Толық бағытты көрсету', center: 'Бастапқы нүктені көрсету',
    coverage: 'Орындар дерегінің аумағы', coverageNote: 'POI деректерінің шекарасы. Жолдардың қамтылуы мен байланысы бөлек тексеріледі.',
    tiles: 'Карта қабаты жүктелмеді. Орындар, бастау нүктесін таңдау және есептеу қолжетімді.', choose: 'Осы нүктені таңдау:', walking: 'OSM жаяу жолдар графы', estimated: 'Жолдың бағасы',
    names: { cafe: 'Кофеханалар', food: 'Тамақтану', park: 'Табиғат', museum: 'Мұражайлар', art: 'Өнер', library: 'Кітапханалар', playground: 'Ойын алаңдары', attraction: 'Көрікті орындар', viewpoint: 'Шолу орындары' },
  },
} as const;
const ignoreDrag = 'button,a,input,select,textarea,summary,[data-map-control]';
type Drag = { pointerId: number; x: number; y: number; centerX: number; centerY: number; zoom: number; moved: boolean; fromPOI: boolean };
type Pinch = { ids: [number, number]; start: [MapPixel, MapPixel]; view: MapView };

export default function CityMap({ origin, destination, pois, plan, onSelect, language = 'ru', onOriginSelect, pickingOrigin = false, pickingLabel, hideChrome = false, preserveViewOnResize = false, showCoverage = false }: CityMapProps) {
  const copy = text[language], mapRef = useRef<HTMLDivElement>(null), drag = useRef<Drag | null>(null);
  const pointers = useRef(new Map<number, MapPixel>()), pinch = useRef<Pinch | null>(null), instructionsId = useId();
  const lastFitSize = useRef<MapSize | null>(null);
  const panFrame = useRef<number | null>(null), pendingPan = useRef<MapView | null>(null);
  const [size, setSize] = useState<MapSize>({ width: 0, height: 0 });
  const [view, setView] = useState<MapView>({ center: { lat: origin.lat, lon: origin.lon }, zoom: 14 });
  const viewRef = useRef(view);
  function updateView(next: MapView) { viewRef.current = next; setView(next); }
  const [dragging, setDragging] = useState(false), [failedTiles, setFailedTiles] = useState<Set<string>>(() => new Set());
  const hasRoute = !!plan?.stops.length;
  useEffect(() => {
    const element = mapRef.current;
    if (!element) return;
    const measure = () => { const rect = element.getBoundingClientRect(); setSize(previous => previous.width === rect.width && previous.height === rect.height ? previous : { width: rect.width, height: rect.height }); };
    const observer = new ResizeObserver(measure); observer.observe(element);
    const initial = requestAnimationFrame(measure);
    return () => { observer.disconnect(); cancelAnimationFrame(initial); };
  }, []);
  useEffect(() => () => { if (panFrame.current !== null) cancelAnimationFrame(panFrame.current); }, []);
  const fitPoints = useMemo(() => [{ lat: origin.lat, lon: origin.lon }, ...(destination ? [{ lat: destination.lat, lon: destination.lon }] : []), ...(plan?.routeCoordinates ?? []).map(([lon, lat]) => ({ lat, lon })), ...(plan?.stops ?? []).map(stop => ({ lat: stop.poi.lat, lon: stop.poi.lon }))], [origin.lat, origin.lon, destination, plan?.routeCoordinates, plan?.stops]);
  const fitted = useMemo(() => fitMapPoints(fitPoints, size, { maxZoom: hasRoute ? 17 : 14, padding: { top: 86, right: size.width < 500 ? 64 : 84, bottom: 88, left: 32 } }), [fitPoints, hasRoute, size]);
  const fitLat = fitted.center.lat, fitLon = fitted.center.lon, fitZoom = fitted.zoom;
  useEffect(() => {
    if (!size.width || !size.height) return;
    // Moving a draft pin must not jerk a phone user's map back to the starting zoom.
    if (pickingOrigin && lastFitSize.current && (preserveViewOnResize || (lastFitSize.current.width === size.width && lastFitSize.current.height === size.height))) return;
    lastFitSize.current = { width: size.width, height: size.height };
    const frame = requestAnimationFrame(() => updateView({ center: { lat: fitLat, lon: fitLon }, zoom: fitZoom }));
    return () => cancelAnimationFrame(frame);
  }, [fitLat, fitLon, fitZoom, size.width, size.height, pickingOrigin, preserveViewOnResize]);
  const rasterZoom = Math.floor(view.zoom), tileScale = 2 ** (view.zoom - rasterZoom);
  const centerPixel = projectMapPoint(view.center, rasterZoom), left = centerPixel.x - size.width / (2 * tileScale), top = centerPixel.y - size.height / (2 * tileScale), tileCount = 2 ** rasterZoom;
  const tiles = [];
  if (size.width && size.height) for (let x = Math.floor(left / TILE_SIZE); x <= Math.floor((left + size.width / tileScale) / TILE_SIZE); x++) for (let y = Math.max(0, Math.floor(top / TILE_SIZE)); y <= Math.min(tileCount - 1, Math.floor((top + size.height / tileScale) / TILE_SIZE)); y++) {
    const wrappedX = (x % tileCount + tileCount) % tileCount;
    tiles.push({ key: `${rasterZoom}/${wrappedX}/${y}`, x: wrappedX, y, left: (x * TILE_SIZE - left) * tileScale, top: (y * TILE_SIZE - top) * tileScale });
  }
  const tileError = tiles.some(tile => failedTiles.has(tile.key));
  const shown = useMemo(() => hasRoute ? plan!.stops.map(stop => stop.poi) : balancedViewportPOIs(pois, view, size), [hasRoute, plan, pois, view, size]);
  const originScreen = pointOnMap(origin, view, size), destinationScreen = destination && pointOnMap(destination, view, size), route = (plan?.routeCoordinates ?? []).map(([lon, lat]) => pointOnMap({ lat, lon }, view, size));
  const routeKey = useMemo(() => `${plan?.stops.map(stop => stop.poi.id).join('|') ?? ''}:${plan?.routeCoordinates.length ?? 0}`, [plan?.stops, plan?.routeCoordinates]);
  const coverage = snapshotCorners().map(point => pointOnMap(point, view, size));
  function selectOrigin(point: MapPoint, label: string = copy.selected) {
    if (pickingOrigin && onOriginSelect) onOriginSelect({ lat: Number(point.lat.toFixed(6)), lon: Number(point.lon.toFixed(6)), label });
  }
  function localPixel(event: ReactPointerEvent<HTMLDivElement>): MapPixel {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }
  function queueView(next: MapView) {
    viewRef.current = next; pendingPan.current = next;
    if (panFrame.current === null) panFrame.current = requestAnimationFrame(() => { if (pendingPan.current) setView(pendingPan.current); panFrame.current = null; });
  }
  function flushView() {
    if (panFrame.current !== null) { cancelAnimationFrame(panFrame.current); panFrame.current = null; }
    if (pendingPan.current) updateView(pendingPan.current);
    pendingPan.current = null;
  }
  function pointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    const target = event.target as HTMLElement, fromPOI = !!target.closest('.cm-poi');
    if (pointers.current.size >= 2 || (event.pointerType === 'mouse' && event.button !== 0) || (!fromPOI && target.closest(ignoreDrag))) return;
    const pixel = localPixel(event);
    pointers.current.set(event.pointerId, pixel);
    if (pointers.current.size === 2) {
      const entries = [...pointers.current.entries()];
      pinch.current = { ids: [entries[0][0], entries[1][0]], start: [entries[0][1], entries[1][1]], view: viewRef.current };
      drag.current = null; setDragging(true);
      // A two-finger gesture may start on a venue marker too. Capture both
      // fingers once it becomes a gesture so releasing cannot click that venue.
      for (const [id] of entries) event.currentTarget.setPointerCapture(id);
    } else {
      const current = viewRef.current, projected = projectMapPoint(current.center, current.zoom);
      drag.current = { pointerId: event.pointerId, x: pixel.x, y: pixel.y, centerX: projected.x, centerY: projected.y, zoom: current.zoom, moved: false, fromPOI };
      // Preserve a normal button click until a finger actually moves.
      if (!fromPOI) event.currentTarget.setPointerCapture(event.pointerId);
    }
  }
  function pointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    if (!pointers.current.has(event.pointerId)) return;
    const pixel = localPixel(event); pointers.current.set(event.pointerId, pixel);
    const currentPinch = pinch.current;
    if (currentPinch) {
      const first = pointers.current.get(currentPinch.ids[0]), second = pointers.current.get(currentPinch.ids[1]);
      if (first && second) queueView(pinchMapView(currentPinch.view, size, currentPinch.start, [first, second]));
      return;
    }
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId) return;
    const dx = pixel.x - current.x, dy = pixel.y - current.y;
    if (!current.moved && isMapTap(dx, dy)) return;
    if (!current.moved) { current.moved = true; setDragging(true); event.currentTarget.setPointerCapture(event.pointerId); }
    queueView({ center: unprojectMapPoint(current.centerX - dx, current.centerY - dy, current.zoom), zoom: current.zoom });
  }
  function finishPointer(event: ReactPointerEvent<HTMLDivElement>, cancelled = false) {
    if (!pointers.current.has(event.pointerId)) return;
    const pixel = localPixel(event), current = drag.current;
    const tap = !cancelled && !pinch.current && current?.pointerId === event.pointerId && !current.moved && !current.fromPOI && isMapTap(pixel.x - current.x, pixel.y - current.y);
    pointers.current.delete(event.pointerId); flushView();
    pinch.current = null; drag.current = null;
    const remaining = [...pointers.current.entries()][0];
    if (remaining) {
      // Lifting one finger after a pinch continues panning; it never drops a pin.
      const previous = viewRef.current, projected = projectMapPoint(previous.center, previous.zoom);
      drag.current = { pointerId: remaining[0], x: remaining[1].x, y: remaining[1].y, centerX: projected.x, centerY: projected.y, zoom: previous.zoom, moved: true, fromPOI: false };
    }
    setDragging(!!remaining);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    if (tap && pickingOrigin && onOriginSelect) selectOrigin(coordinateAtMapPixel(pixel.x, pixel.y, viewRef.current, size));
  }
  function changeZoom(amount: number) { const previous = viewRef.current; updateView({ ...previous, zoom: Math.max(MIN_MAP_ZOOM, Math.min(MAX_MAP_ZOOM, previous.zoom + amount)) }); }
  function keyDown(event: ReactKeyboardEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget) return;
    const moves: Record<string, MapPixel> = { ArrowLeft: { x: -80, y: 0 }, ArrowRight: { x: 80, y: 0 }, ArrowUp: { x: 0, y: -80 }, ArrowDown: { x: 0, y: 80 } };
    const delta = moves[event.key], previous = viewRef.current;
    if (delta) { event.preventDefault(); const point = projectMapPoint(previous.center, previous.zoom); updateView({ ...previous, center: unprojectMapPoint(point.x + delta.x, point.y + delta.y, previous.zoom) }); }
    else if (event.key === '+' || event.key === '=') { event.preventDefault(); changeZoom(1); }
    else if (event.key === '-') { event.preventDefault(); changeZoom(-1); }
    else if (pickingOrigin && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); selectOrigin(previous.center); }
  }
  function tileFailed(key: string) {
    setFailedTiles(previous => { if (previous.has(key)) return previous; const next = new Set(previous); next.add(key); if (next.size > 80) next.delete(next.values().next().value!); return next; });
  }
  return <div className={`city-map cm-map${pickingOrigin ? ' cm-picking' : ''}${dragging ? ' cm-dragging' : ''}`} ref={mapRef} role="region" aria-label={copy.map} tabIndex={0} aria-describedby={instructionsId}
    onKeyDown={keyDown} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={event => finishPointer(event)} onPointerCancel={event => finishPointer(event, true)} onLostPointerCapture={event => { if (event.target === event.currentTarget) finishPointer(event, true); }}>
    <span id={instructionsId} className="cm-sr-only">{copy.keyboard}</span>
    <div className="cm-tiles" aria-hidden="true">{tiles.map(tile => <img key={tile.key} src={`https://tile.openstreetmap.org/${rasterZoom}/${tile.x}/${tile.y}.png`} alt="" draggable={false} width={TILE_SIZE} height={TILE_SIZE} style={{ width: TILE_SIZE * tileScale + .4, height: TILE_SIZE * tileScale + .4, transform: `translate3d(${tile.left}px,${tile.top}px,0)` }} onError={() => tileFailed(tile.key)} onLoad={() => setFailedTiles(previous => { if (!previous.has(tile.key)) return previous; const next = new Set(previous); next.delete(tile.key); return next; })} />)}</div>
    {showCoverage && <svg className="cm-coverage" width={size.width} height={size.height} aria-hidden="true"><polygon points={coverage.map(point => `${point.x},${point.y}`).join(' ')} /></svg>}
    {route.length > 1 && <svg className="cm-route" width={size.width} height={size.height} aria-hidden="true" key={routeKey}><polyline className="cm-route-halo" points={route.map(point => `${point.x},${point.y}`).join(' ')} /><polyline className={`cm-route-stroke${plan?.routeKind === 'estimate' ? ' cm-route-estimate' : ''}`} points={route.map(point => `${point.x},${point.y}`).join(' ')} /></svg>}
    <div className="cm-origin" style={{ left: originScreen.x, top: originScreen.y }} title={`${copy.start}: ${origin.label}`} aria-hidden="true"><span>A</span><small>{copy.start}</small></div>
    {destination && destinationScreen && <div className="cm-origin cm-destination" style={{ left: destinationScreen.x, top: destinationScreen.y }} title={`${copy.destination}: ${destination.label}`} aria-hidden="true"><span>B</span><small>{copy.destination}</small></div>}
    {shown.map((poi, index) => {
      const category = (poi.category === 'gallery' ? 'art' : poi.category) as keyof typeof categoryStyle, styling = categoryStyle[category] ?? categoryStyle.attraction;
      const Icon = styling.icon, name = poiDisplayName(poi, language), categoryName = copy.names[category] ?? copy.names.attraction, position = pointOnMap(poi, view, size);
      return <button type="button" key={poi.id} className={`cm-poi${hasRoute ? ' cm-stop' : ''}`} style={{ left: position.x, top: position.y, '--poi-color': styling.color } as CSSProperties} onClick={() => pickingOrigin && onOriginSelect ? selectOrigin(poi, name) : onSelect(poi)} aria-label={pickingOrigin ? `${copy.choose} ${name}` : `${name} · ${categoryName}`} title={`${name} · ${categoryName}`}>
        {hasRoute ? <><b>{index + 1}</b><span className="cm-stop-category"><Icon size={12} /></span></> : <Icon size={19} />}
        <span className="cm-tooltip"><strong>{name}</strong><small>{categoryName}</small></span>
      </button>;
    })}
    {pickingOrigin && !hideChrome && <div className="cm-pick-hint" role="status"><Crosshair size={18} /><span>{pickingLabel ?? copy.picking}</span></div>}
    <div className="cm-controls" data-map-control><button type="button" onClick={() => changeZoom(1)} disabled={view.zoom >= MAX_MAP_ZOOM} aria-label={copy.zoomIn} title={copy.zoomIn}><Plus size={20} /></button><button type="button" onClick={() => changeZoom(-1)} disabled={view.zoom <= MIN_MAP_ZOOM} aria-label={copy.zoomOut} title={copy.zoomOut}><Minus size={20} /></button><span /><button type="button" onClick={() => updateView({ center: { lat: fitLat, lon: fitLon }, zoom: fitZoom })} aria-label={hasRoute || destination ? copy.fit : copy.center} title={hasRoute || destination ? copy.fit : copy.center}><LocateFixed size={19} /></button>{showCoverage && !hideChrome && <button type="button" onClick={() => updateView(fitMapPoints(snapshotCorners(), size, { maxZoom: 14 }))} aria-label={copy.coverage} title={copy.coverage}><Layers size={19} /></button>}</div>
    {!hideChrome && <details className="cm-legend" data-map-control><summary><Layers size={15} /><span>{copy.categories}</span><ChevronDown size={14} /></summary><div className="cm-legend-grid">{Object.entries(categoryStyle).map(([category, styling]) => { const Icon = styling.icon; return <span key={category}><Icon size={14} style={{ color: styling.color }} /><span>{copy.names[category as keyof typeof categoryStyle]}</span></span>; })}</div>{hasRoute && <p className="cm-route-note"><Route size={13} />{plan?.routeKind === 'walking' ? copy.walking : copy.estimated}</p>}{showCoverage && <p className="cm-coverage-note">{copy.coverageNote}</p>}</details>}
    {showCoverage && !hideChrome && <span className="cm-snapshot-label" data-map-control>{copy.coverage}</span>}
    {tileError && <div className="cm-tile-error" role="status">{copy.tiles}</div>}
    <div className="cm-attribution" data-map-control>© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors</div>
  </div>;
}
