'use client';
import { Check, Clock3, Footprints, RefreshCw, Utensils } from 'lucide-react';
import { categoryLabel, poiDisplayName } from '@/lib/ui-copy';
import { cuisineLabel, compareRoute } from '@/lib/route-choice';
import type { PlanResponse } from '@/lib/qadam-types';
type Props = { options: NonNullable<PlanResponse['options']>; selected: number; language:'ru'|'kk'|'en'; onSelect:(index:number)=>void; onMore:()=>void; pending:boolean; exhausted:boolean; message:string; pinned:boolean; };
export default function RouteChoices({options,selected,language,onSelect,onMore,pending,exhausted,message,pinned}:Props) {
  const L=(ru:string,en:string,kk:string)=>language==='en'?en:language==='kk'?kk:ru;
  const chosen=options[selected]??options[0], baseline=selected===0?options[1]:options[0];
  return <section className="route-choices" aria-label={L('Выбери маршрут','Choose a route','Бағытты таңда')}>
    <div className="choices-heading"><h3>{L('Выбери свой маршрут','Choose your route','Бағытыңды таңда')}</h3><span>{options.length} {L('на выбор','to choose from','нұсқа')}</span></div>
    <div className="option-grid" role="group" aria-label={L('Варианты маршрута','Route options','Бағыт нұсқалары')}>
      {options.map((option,i)=>{
        const food=option.plan.stops.some(s=>s.poi.category==='food'||['restaurant','fast_food','food_court'].includes(s.poi.tags.amenity));
        const cuisines=[...new Set(option.plan.stops.map(stop=>cuisineLabel(stop.poi,language)).filter(Boolean))].join(' / ');
        return <button key={option.id} className={'route-option '+(i===selected?'selected':'')} aria-pressed={i===selected} onClick={()=>onSelect(i)}>
          <div><span className="option-index">{L('Маршрут','Route','Бағыт')} {i+1}</span><span className="option-check">{i===selected&&<Check size={15}/>}</span></div>
          <h3>{option.plan.stops.map(stop=>poiDisplayName(stop.poi,language)).join(' → ')}</h3>
          <p className="option-category">{cuisines?<><Utensils size={12}/>{cuisines}</>:food?L('Кухня не указана в OSM','Cuisine not listed in OSM','OSM-де асүй көрсетілмеген'):option.plan.stops.map(stop=>categoryLabel(stop.poi.category,language)).filter((x,j,a)=>a.indexOf(x)===j).join(' · ')}</p>
          <div className="option-metrics"><span><Footprints size={14}/>{option.plan.walkingMinutes} {L('мин идти','min walk','мин жүру')}</span><span><Clock3 size={14}/>{option.plan.visitMinutes} {L('мин на месте','min at stops','мин орында')}</span></div>
          <strong>{option.plan.totalMinutes} <small>{L('мин всего','min total','мин барлығы')}</small><span>{(option.plan.distanceMeters/1000).toFixed(1)} km</span></strong>
        </button>;
      })}
    </div>
    {chosen&&baseline&&<div className="route-difference" role="status"><b>{L('Чем отличается?','What is different?','Айырмашылығы неде?')}</b><p>{compareRoute(chosen.plan,baseline.plan,language)} <small>{L('По сравнению с маршрутом ','Compared with route ','Салыстырған бағыт ')}{selected===0?2:1}.</small></p></div>}
    <div className="more-route-row"><button className="outline-button" onClick={onMore} disabled={pending||exhausted}><RefreshCw size={16} className={pending?'spin':''}/>{pending?L('Ищем новые места…','Finding new places…','Жаңа орындар ізделуде…'):pinned?L('Другие места','Other places','Басқа орындар'):L('Ещё варианты','More options','Тағы нұсқалар')}</button><span>{L('Другие места, те же А, Б и время.','New places, same A, B and time.','Басқа орындар, сол A, B және уақыт.')}</span></div>
    {message&&<p className="more-route-message" role="status">{message}</p>}
  </section>;
}
