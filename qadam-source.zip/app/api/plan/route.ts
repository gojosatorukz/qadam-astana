import rawDataset from '@/data/poi.json';
import rawWalkingGraph from '@/data/walk-graph.json';
import { planRoute, validatePlanRequest } from '@/lib/planner';
import type { POIDataset } from '@/lib/planner';
import { enrichWithGemini } from '@/lib/rag';
import { WalkingGraph } from '@/lib/walking-graph';
import type { RawWalkingGraph } from '@/lib/walking-graph';

// TypeScript infers mutually exclusive optional tag keys for the JSON union;
// the ingestion pipeline emits ordinary string-valued tag objects at runtime.
const dataset = rawDataset as unknown as POIDataset;
const MAX_REQUEST_BYTES = 16_384;
let walkingGraph: WalkingGraph | null = null;

function getWalkingGraph(): WalkingGraph | undefined {
  try { walkingGraph ??= new WalkingGraph(rawWalkingGraph as RawWalkingGraph); return walkingGraph; } catch { return undefined; }
}

export async function GET(): Promise<Response> {
  return Response.json({
    status: 'ok',
    poiCount: dataset.pois.length,
    datasetFetchedAt: dataset.fetchedAt,
    datasetSource: dataset.source,
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    generationMode: process.env.GEMINI_API_KEY ? 'gemini' : 'retrieval',
    routing: 'osm-walking-graph-with-estimate-fallback',
    walkingGraphNodes: rawWalkingGraph.nodes.length,
    walkingGraphEdges: rawWalkingGraph.edges.length,
  }, { headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(httpRequest: Request): Promise<Response> {
  if (Number(httpRequest.headers.get('content-length') ?? 0) > MAX_REQUEST_BYTES) return Response.json({ error: 'Request is too large.' }, { status: 413 });
  let input: unknown;
  try {
    const text = await httpRequest.text();
    if (new TextEncoder().encode(text).byteLength > MAX_REQUEST_BYTES) return Response.json({ error: 'Request is too large.' }, { status: 413 });
    input = JSON.parse(text);
  } catch {
    return Response.json({ error: 'Expected valid JSON.' }, { status: 400 });
  }
  const validated = validatePlanRequest(input);
  if ('error' in validated) return Response.json({ error: validated.error }, { status: 400 });
  try {
    const graph = getWalkingGraph();
    const result = planRoute(validated.value, dataset, { routing: graph });
    const response = await enrichWithGemini(result, validated.value);
    return Response.json(response, { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return Response.json({ error: 'Unable to plan a route. Please try another starting point or time budget.' }, { status: 500 });
  }
}
