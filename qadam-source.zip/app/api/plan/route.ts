import rawDataset from '@/data/poi.json';
import rawWalkingGraph from '@/data/walk-graph.json';
import { validatePlanRequest } from '@/lib/planner';
import { buildPlan } from '@/lib/build-plan';
import { applyPlaceFacts, getPlaceFactsCoverage } from '@/lib/place-facts';
import { resolvePlanTime } from '@/lib/time-context';
import { POI_COVERAGE } from '@/lib/planning-context';
import { isAbortError, throwIfAborted } from '@/lib/request-abort';
import type { POIDataset } from '@/lib/planner';
import { WalkingGraph } from '@/lib/walking-graph';
import type { RawWalkingGraph } from '@/lib/walking-graph';

// TypeScript infers mutually exclusive optional tag keys for the JSON union;
// the ingestion pipeline emits ordinary string-valued tag objects at runtime.
const dataset = applyPlaceFacts(rawDataset as unknown as POIDataset);
const MAX_REQUEST_BYTES = 16_384;
let walkingGraph: WalkingGraph | null = null;

function getWalkingGraph(): WalkingGraph | undefined {
  try { walkingGraph ??= new WalkingGraph(rawWalkingGraph as RawWalkingGraph); return walkingGraph; } catch { return undefined; }
}

export async function GET(): Promise<Response> {
  return Response.json({
    status: 'ok',
    poiCount: dataset.pois.length,
    datasetFetchedAt: dataset.fetchedAt,
    datasetSource: dataset.source,
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    intentCapability: 'validated-request-interpretation-with-local-recovery',
    placeFacts: getPlaceFactsCoverage(),
    capabilities: ['typed-clarification','confirmed-origin','return-deadline','canonical-variants','parent-abort'],
    generationMode: 'request-dependent',
    routing: 'osm-walking-graph-with-estimate-fallback',
    walkingGraphNodes: rawWalkingGraph.nodes.length,
    walkingGraphEdges: rawWalkingGraph.edges.length,
  }, { headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(httpRequest: Request): Promise<Response> {
  if (Number(httpRequest.headers.get('content-length') ?? 0) > MAX_REQUEST_BYTES) return Response.json({ error: 'Request is too large.' }, { status: 413 });
  if (httpRequest.signal.aborted) return Response.json({error:'Request cancelled.'},{status:499});
  let input: unknown;
  try {
    const text = await httpRequest.text();
    if (new TextEncoder().encode(text).byteLength > MAX_REQUEST_BYTES) return Response.json({ error: 'Request is too large.' }, { status: 413 });
    input = JSON.parse(text);
  } catch {
    if (httpRequest.signal.aborted) return Response.json({error:'Request cancelled.'},{status:499});
    return Response.json({ error: 'Expected valid JSON.' }, { status: 400 });
  }
  const validated = validatePlanRequest(input);
  if ('error' in validated) return Response.json({ error: validated.error }, { status: 400 });
  const time = resolvePlanTime(validated.value, new Date(), true);
  if ('error' in time) return Response.json({error: time.error},{status:400});
  try {
    throwIfAborted(httpRequest.signal);
    const graph = getWalkingGraph();
    const response = await buildPlan(validated.value, dataset, { routing: graph, coverageBounds: POI_COVERAGE, signal: httpRequest.signal });
    throwIfAborted(httpRequest.signal);
    return Response.json(response, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    if (isAbortError(error)) return Response.json({error:'Request cancelled.'},{status:499});
    return Response.json({ error: 'Unable to plan a route. Please try another starting point or time budget.' }, { status: 500 });
  }
}
