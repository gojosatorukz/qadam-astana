import data from '@/data/poi.json';
export async function GET(){return Response.json({pois:data.pois,count:data.pois.length,fetchedAt:data.fetchedAt,generationAvailable:Boolean(process.env.GEMINI_API_KEY)},{headers:{'Cache-Control':'public, max-age=300'}});}
