import data from '@/data/poi.json';
import { applyPlaceFacts, getPlaceFactsCoverage } from '@/lib/place-facts';
import type { POIDataset } from '@/lib/planner';
const enriched = applyPlaceFacts(data as unknown as POIDataset);
export async function GET(){return Response.json({pois:enriched.pois,count:enriched.pois.length,fetchedAt:enriched.fetchedAt,generationAvailable:Boolean(process.env.GEMINI_API_KEY),editorial:getPlaceFactsCoverage(),coverage:{poiBounds:[51.065,71.35,51.205,71.515],note:'POI snapshot boundary; not walking network coverage'}},{headers:{'Cache-Control':'public, max-age=300'}});}
