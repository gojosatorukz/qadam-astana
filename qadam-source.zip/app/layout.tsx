import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Qadam — Астана в твоём ритме",
  description: "Найди прогулку по Астане с реальными местами, понятным планом и проверяемыми источниками.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
