import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Qadam — маленькое открытие между делами",
  description: "Твоё желание, свой старт и время. Выбери маленькую прогулку по Астане с источниками, понятными условиями и расчётом пути обратно.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
